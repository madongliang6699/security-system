package org.springblade.xxljob.constant;

import static org.springblade.core.launch.constant.AppConstant.APPLICATION_NAME_PREFIX;

/**
 * @Author：liuyi
 * @Package：org.springblade.xxljob.constant
 * @Project：BladeX
 * @name：XxlJobConstant
 * @Date：2024/9/23 10:01
 * @Filename：XxlJobConstant
 * @Describe: 学习是你一生的财富~多多挣钱实现心里的梦想
 */
public interface XxlJobConstant {

	/**
	 * xxljob
	 */
	String APPLICATION_XXLJOB_NAME = APPLICATION_NAME_PREFIX + "xxl-job";

}
