package org.springblade.xxljob.core.feign; /**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */


import org.springblade.xxljob.core.constant.XxlJobConstant;
import org.springblade.core.tool.api.R;
import org.springblade.xxljob.core.model.XxlJobInfo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * xxl-job远程调用接口.
 *
 * @author Chill
 */
@FeignClient(value = XxlJobConstant.APPLICATION_XXLJOB_NAME)
public interface IXxlJobClient {

	String API_PREFIX = "/feign/client/xxlJob";
	String ADD = API_PREFIX+"/add";
	String UPDATE = API_PREFIX+"/update";
	String REMOVE = API_PREFIX+"/remove";
	String STOP = API_PREFIX+"/stop";
	String START = API_PREFIX+"/start";
	String GETJOBINFOBYID = API_PREFIX+"/getJobInfoById";

	@PostMapping(value = ADD)
	R<String> add(@RequestBody XxlJobInfo jobInfo);

	@PostMapping(value = UPDATE)
	R<String> update(@RequestBody XxlJobInfo jobInfo);

	@PostMapping(value = REMOVE)
	R<String> remove(@RequestParam("id") Integer id);

	@PostMapping(value = STOP)
	R<String> pause(@RequestParam("id") Integer id);

	@PostMapping(value = START)
	R<String> start(@RequestParam("id") Integer id);

	@PostMapping(value = GETJOBINFOBYID)
	R<XxlJobInfo> getJobInfoById(@RequestParam("id") Integer id);

}
