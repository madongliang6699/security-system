package org.springblade.resource.feign;

import org.springblade.core.launch.constant.AppConstant;
import org.springblade.core.oss.model.BladeFile;
import org.springblade.core.tool.api.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

@FeignClient(value = AppConstant.APPLICATION_RESOURCE_NAME)
public interface IOssClient {
	String API_PREFIX = "/feign/client";
	String FILE_LINK = API_PREFIX + "/file-link";
	String FILE_LINK_IN_TENANT = API_PREFIX + "/file-link-in-tenant";
	String REMOVE_FILES = API_PREFIX + "/remove-files";
	String PUT_FILE = API_PREFIX + "/put-file";
	String PUT_FILE_TO_TENANT = API_PREFIX + "/put-file-to-tenant";


	/**
	 * 获取文件链接
	 *
	 * @param fileName 文件名称
	 * @return R
	 */
	@PostMapping(FILE_LINK)
	R<String> fileLink(@RequestParam String fileName);

	/**
	 * 获取文件链接
	 *
	 * @param fileName 文件名称
	 * @return R
	 */
	@PostMapping(FILE_LINK_IN_TENANT)
	R<String> fileLinkInTenant(@RequestParam String tenantId, @RequestParam String fileName);

	/**
	 * 批量删除文件
	 *
	 * @param fileNames 存储桶对象名称集合
	 * @return R
	 */
	@PostMapping(REMOVE_FILES)
	R<Boolean> removeFiles(@RequestParam String fileNames);

	/**
	 * 上传文件
	 *
	 * @param file 文件
	 * @return R
	 */
	@PostMapping(value = PUT_FILE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	R<BladeFile> putFile(@RequestParam("fileName") String fileName,
						 @RequestPart("file") MultipartFile file);

	/**
	 * 上传文件至某个租户，如果带Web上下文，请使用不带租户id的方法
	 *
	 * @param file 文件
	 * @return R
	 */
	@PostMapping(value = PUT_FILE_TO_TENANT, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	R<BladeFile> putFileToTenant(@RequestParam("tenantId") String tenantId, @RequestParam("fileName") String fileName,
								 @RequestPart("file") MultipartFile file);
}
