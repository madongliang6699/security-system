package org.springblade.resource.feign;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.oss.model.BladeFile;
import org.springblade.core.tenant.annotation.NonDS;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.StringPool;
import org.springblade.resource.builder.OssBuilder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@NonDS
@RestController
@AllArgsConstructor
@Slf4j
public class OssClient implements IOssClient {
	private OssBuilder ossBuilder;

	@Override
	public R<String> fileLink(String fileName) {
		return R.data(ossBuilder.template().fileLink(fileName));
	}

	@Override
	public R<String> fileLinkInTenant(String tenantId, String fileName) {
		return R.data(ossBuilder.template(tenantId, StringPool.EMPTY).fileLink(fileName));
	}

	@Override
	public R<Boolean> removeFiles(String fileNames) {
		ossBuilder.template().removeFiles(Func.toStrList(fileNames));
		return R.data(true);
	}

	@Override
	public R<BladeFile> putFile(String fileName, MultipartFile file) {
		try {
			return R.data(ossBuilder.template().putFile(fileName, file.getInputStream()));
		} catch (IOException e) {
			log.error("上传文件时文件流读取失败", e);
			throw new ServiceException("上传文件时文件流读取失败");
		}
	}

	@Override
	public R<BladeFile> putFileToTenant(String tenantId, String fileName, MultipartFile file) {
		try {
			return R.data(ossBuilder.template(tenantId, StringPool.EMPTY).putFile(fileName, file.getInputStream()));
		} catch (IOException e) {
			log.error("上传文件时文件流读取失败", e);
			throw new ServiceException("上传文件时文件流读取失败");
		}
	}
}
