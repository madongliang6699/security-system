package org.springblade.resource.utils;


import org.apache.tika.Tika;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.tool.utils.FileUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.ObjectUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

/**
 * 过滤文件类型a
 */
public class FileTypeFilterUtil {
	private static final HashMap<String, String> TYPES = new HashMap<>();

	//TODO  有其他类型的可自行配置
	static {
		TYPES.put("doc", "application/msword");  //doc
		TYPES.put("ppt", "application/vnd.ms-powerpoint"); //ppt
		TYPES.put("xls", "application/vnd.ms-excel"); //xls
		TYPES.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");//docx
		TYPES.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");//pptx
		TYPES.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");//xlsx
		TYPES.put("rar", "application/x-rar-compressed");//rar
		TYPES.put("zip", "application/zip");//zip
		TYPES.put("pdf", "application/pdf"); //pdf
		TYPES.put("png", "image/png,image/jpg,image/jpeg");//png
		TYPES.put("gif", "image/gif");//gif
		TYPES.put("jpg", "image/jpg,image/jpeg,image/png");//jpg
		TYPES.put("jpeg", "image/jpeg,image/jpg,image/png");//jpeg
		TYPES.put("txt", "text/plain"); //txt 纯文本
		TYPES.put("apk", "application/vnd.android.package-archive");//APP版本更新
		TYPES.put("json", "application/json");//json文件格式
		TYPES.put("mp4", "video/mp4");//mp4格式文件
	}


	/**
	 * 判断文件格式是否在允许的范围内
	 */
	public static boolean isFileTypeNoMatch(String fileName, InputStream inputStream) {
		//获取文件后缀名
		String fileSuffix = FileUtil.getFileExtension(fileName);
		//忽略大小写获取文件后缀名类型
		String type = TYPES.get(fileSuffix.toLowerCase());
		//后缀名不符合
		if (ObjectUtil.isEmpty(type)) return true;
		//获取文件媒体类型
		Tika tika = new Tika();
		String detect;
		try {
			detect = tika.detect(inputStream, fileName);
		} catch (IOException e) {
			e.printStackTrace();
			throw new ServiceException("获取文件媒体类型失败,请检查上传文件是否正常");
		}
		//防止误判,手机图片等文件信息会混淆
		List<String> types = Func.toStrList(type);
		//判断文件类型和文件后缀名是否符合
		return !types.contains(detect.toLowerCase());
	}

	public static boolean isFileTypeNoMatch(String fileName) {
		//获取文件后缀名
		String fileSuffix = FileUtil.getFileExtension(fileName);
		//忽略大小写获取文件后缀名类型
		String type = TYPES.get(fileSuffix.toLowerCase());
		//后缀名不符合
		return ObjectUtil.isEmpty(type);
	}
}
