package org.springblade.plugin.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springblade.plugin.message.entity.MqMessage;


/**
 * mq消息可靠记录 Mapper 接口
 *
 * @author weikun
 * @since 2021-05-08
 */
public interface MqMessageMapper extends BaseMapper<MqMessage> {

}
