package org.springblade.plugin.message;

import org.springblade.core.cloud.client.BladeCloudApplication;
import org.springblade.core.cloud.feign.EnableBladeFeign;
import org.springblade.core.launch.BladeApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration;

/**
 * Message启动器
 *
 * @author weikun
 */
@EnableBladeFeign
@BladeCloudApplication
@EnableAutoConfiguration(exclude = RabbitAutoConfiguration.class)
public class MessageApplication {

	public static void main(String[] args) {
		BladeApplication.run("cnooc-qhse-message", MessageApplication.class, args);
	}

}

