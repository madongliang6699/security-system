package org.springblade.plugin.message.rabbitmq.constant;

/**
 * @author weikun
 */
public class RabbitMqConstant {
	/**
	 * 直连交换机
	 */
	public final static String EXCHANGE_DIRECT = "directExchange";

	/**
	 * 普通通知消息
	 */
	public final static String QUEUE_SINGLE_MSG = "single_msg_";

	/**
	 * 群发通知消息
	 */
	public final static String QUEUE_GROUP_MSG = "group_msg_";


}
