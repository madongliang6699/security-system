package org.springblade.plugin.message.service;

import org.springblade.plugin.message.entity.Message;
import org.springblade.plugin.message.entity.MessageLog;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.params.MessageParams;
import org.springblade.core.mp.base.BaseService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.vo.TopMessageVO;

/**
 * 消息详情表 服务类
 *
 * @author weikun
 * @since 2021-05-08
 */
public interface IMessageService extends BaseService<Message> {


	/**
	 * 查询顶部消息
	 * @return
	 */
	TopMessageVO selectTopMessage();


	/**
	 * 我接受的消息
	 *
	 * @param page
	 * @param message
	 * @return
	 */
	IPage<Message> selectMessagePage(IPage<Message> page, Message message);


	/**
	 * 我发送的消息
	 * @param page
	 * @param message
	 * @return
	 */
	IPage<MessageLog> selectMessageSendPage(IPage<MessageLog> page, MessageLog message);


	/**
	 * 发送消息
	 * @param messageLog 消息
	 * @return 是否成功
	 */
	Boolean sendMessage(MessageParams messageLog);


	/**
	 * 发送消息历史详情
	 * @param id 发送历史记录主键
	 * @return
	 */
	MessageLog getSendDetail(Long id);


	/**
	 * 查询是否有失败消息并且 重新投递消息
	 * @return 是否成功
	 */
	Boolean resendMessage();

	/**
	 * 发送服务端可靠消息
	 * @param msgParam
	 * @return
	 */
	Boolean sendServeMessage(ServeMessageParams msgParam);
}
