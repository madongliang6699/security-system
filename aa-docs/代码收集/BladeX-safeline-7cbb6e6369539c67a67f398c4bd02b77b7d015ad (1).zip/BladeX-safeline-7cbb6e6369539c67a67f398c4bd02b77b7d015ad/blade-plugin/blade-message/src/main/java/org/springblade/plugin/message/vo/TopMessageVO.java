package org.springblade.plugin.message.vo;

import lombok.Data;
import org.springblade.plugin.message.entity.Message;

import java.util.List;

/**
 * 顶部消息数据
 * @author weikun
 */
@Data
public class TopMessageVO {

	/**
	 * 未读消息数量
	 */
	private Integer unReadCount;

	/**
	 * 未读消息数量
	 */
	private List<Message> messageList;
}
