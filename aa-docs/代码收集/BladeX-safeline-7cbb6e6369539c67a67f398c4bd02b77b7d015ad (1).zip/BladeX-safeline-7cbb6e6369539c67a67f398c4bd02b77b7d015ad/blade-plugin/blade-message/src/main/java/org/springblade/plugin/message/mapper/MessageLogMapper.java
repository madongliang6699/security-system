package org.springblade.plugin.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Param;
import org.springblade.plugin.message.entity.MessageLog;

import java.util.List;

/**
 * 消息记录表 Mapper 接口
 *
 * @author weikun
 * @since 2021-05-08
 */
public interface MessageLogMapper extends BaseMapper<MessageLog> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param message
	 * @return
	 */
	List<MessageLog> selectMessageLogPage(IPage page, MessageLog message);


	/**
	 * 查询部门下用户id
	 *
	 * @param deptId 部门id
	 * @return
	 */
	List<Long> selectUserIdsByDept(@Param("deptId") Long deptId);

	/**
	 * 查询角色下用户id
	 *
	 * @param roleId 角色id
	 * @return
	 */
	List<Long> selectUserIdsByRole(@Param("roleId") Long roleId);
}
