package org.springblade.plugin.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.plugin.message.entity.Message;

import java.util.List;

/**
 * 消息详情表 Mapper 接口
 *
 * @author weikun
 * @since 2021-05-08
 */
public interface MessageMapper extends BaseMapper<Message> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param message
	 * @return
	 */
	List<Message> selectMessagePage(IPage page, Message message);

	/**
	 * 查询顶部前十条消息
	 *
	 * @param userId
	 * @return
	 */
	List<Message> selectTopMessageList(Long userId);
}
