package org.springblade.plugin.message.vo;

import lombok.Data;
import org.springblade.plugin.message.entity.MessageLog;

/**
 * mq推送消息模板
 * @author weikun
 */
/**
 * mq推送消息模板
 * @author weikun
 */
@Data
public class MqMessageVO {

	/**
	 * 接收人id
	 */
	private Long receiveUser;

	/**
	 * 类型
	 */
	private Integer type;

	/**
	 * 标题
	 */
	private String title;

	/**
	 * 发送内容
	 */
	private String content;

	/**
	 * 发送日志id
	 */
	private Long messageLogId;


	public MqMessageVO(String title,String content,Integer type) {
		this.title=title;
		this.content=content;
		this.type=type;
	}

	public MqMessageVO(MessageLog messageLog) {
		this.title=messageLog.getTitle();
		this.content=messageLog.getContent();
		this.type=messageLog.getType();
		this.messageLogId=messageLog.getId();
	}
}
