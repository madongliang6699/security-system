package org.springblade.plugin.message.feign;

import lombok.AllArgsConstructor;
import org.springblade.core.tenant.annotation.NonDS;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.params.MessageParams;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.service.IMessageService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author weikun
 */
@NonDS
@RestController
@AllArgsConstructor
public class MessageClient implements IMessageClient {

	private final IMessageService messageService;

	@Override
	@PostMapping(SEND_MSG)
	public R<Boolean> sendMsg(MessageParams msgParams) {
		return R.data(messageService.sendMessage(msgParams));
	}

	@Override
	@PostMapping(SEND_SERVE_MSG)
	public R<Boolean> sendServeMsg(ServeMessageParams msgParam) {
		return R.data(messageService.sendServeMessage(msgParam));
	}

	@Override
	@GetMapping(RESEND_MSG)
	public R<Boolean> reSend() {
		return R.data(messageService.resendMessage());
	}

}
