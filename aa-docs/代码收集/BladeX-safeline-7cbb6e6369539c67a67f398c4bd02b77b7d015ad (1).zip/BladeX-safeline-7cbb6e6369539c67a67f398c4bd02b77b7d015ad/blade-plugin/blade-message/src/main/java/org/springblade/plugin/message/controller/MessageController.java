package org.springblade.plugin.message.controller;

import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import jakarta.validation.Valid;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.plugin.message.entity.Message;
import org.springblade.plugin.message.entity.MessageLog;
import org.springblade.plugin.message.enums.MessageEnum;
import org.springblade.plugin.message.params.MessageParams;
import org.springblade.plugin.message.service.IMessageService;
import org.springblade.plugin.message.vo.TopMessageVO;
import org.springblade.system.cache.UserCache;
import org.springframework.web.bind.annotation.*;



/**
 * 消息controller
 *
 * @author weikun
 * @since 2021-05-08
 */
@RestController
@AllArgsConstructor
@RequestMapping("/message")
public class MessageController extends BladeController {

	private final IMessageService messageService;


	/**
	 * 顶部我的消息,查询前十条
	 */
	@GetMapping("/my/topList")
	@ApiOperationSupport(order = 1)
	public R<TopMessageVO> topMessageList() {
		return R.data(messageService.selectTopMessage());
	}


	/**
	 * 获取我接收的消息
	 */
	@GetMapping("/my/list")
	@ApiOperationSupport(order = 2)
	public R<IPage<Message>> myMessageList(Message message, Query query) {
		message.setReceiveUser(SecureUtil.getUserId());
		IPage<Message> pages = messageService.selectMessagePage(Condition.getPage(query), message);
		return R.data(pages);
	}


	/**
	 * 获取我发送的消息
	 */
	@GetMapping("/my/sendList")
	@ApiOperationSupport(order = 3)
	public R<IPage<MessageLog>> myMessageSend(MessageLog message, Query query) {
		message.setCreateUser(SecureUtil.getUserId());
		IPage<MessageLog> pages = messageService.selectMessageSendPage(Condition.getPage(query), message);
		return R.data(pages);
	}

	/**
	 * 发送消息详情
	 */
	@GetMapping("/sendDetail")
	@ApiOperationSupport(order = 4)
	public R<MessageLog> sendDetail(Long id) {
		MessageLog detail = messageService.getSendDetail(id);
		return R.data(detail);
	}


	/**
	 * 接收消息详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 5)
	public R<Message> detail(Message message) {
		Message detail = messageService.getOne(Condition.getQueryWrapper(message));
		//查询过详情默认已读
		if (detail.getIsRead().equals(MessageEnum.UNREAD.getCode())) {
			detail.setIsRead(MessageEnum.READ.getCode());
			messageService.updateById(detail);
		}
		detail.setCreateUserName(UserCache.getUser(detail.getCreateUser()).getName());
		return R.data(detail);
	}

	/**
	 * 发送消息
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 6)
	public R save(@Valid @RequestBody MessageParams messageParams) {
		boolean result = messageService.sendMessage(messageParams);
		return R.status(result);
	}


	/**
	 * 全部标记为已读
	 */
	@PostMapping("/readAll")
	@ApiOperationSupport(order = 7)
	public R messageRead() {
		LambdaUpdateWrapper<Message> updateWrapper = new LambdaUpdateWrapper<Message>().set(Message::getIsRead, MessageEnum.READ.getCode())
			.eq(Message::getReceiveUser, SecureUtil.getUserId())
			.eq(Message::getIsRead, MessageEnum.UNREAD.getCode());
		boolean result = messageService.update(updateWrapper);
		return R.status(result);
	}


	/**
	 * 删除发送消息
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 8)
	public R remove(@RequestParam String ids) {
		return R.status(messageService.deleteLogic(Func.toLongList(ids)));
	}


}
