package org.springblade.plugin.message.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.annotation.Resource;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.SecureUtil;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.plugin.message.entity.Message;
import org.springblade.plugin.message.entity.MessageLog;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.enums.MessageEnum;
import org.springblade.plugin.message.enums.MessageStatusEnum;
import org.springblade.plugin.message.mapper.MessageLogMapper;
import org.springblade.plugin.message.mapper.MessageMapper;
import org.springblade.plugin.message.mapper.MqMessageMapper;
import org.springblade.plugin.message.params.MessageParams;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.sender.IMqSender;
import org.springblade.plugin.message.service.IMessageService;
import org.springblade.plugin.message.vo.MqMessageVO;
import org.springblade.plugin.message.vo.TopMessageVO;
import org.springblade.system.cache.SysCache;
import org.springblade.system.cache.UserCache;
import org.springblade.system.pojo.entity.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 消息服务实现类
 *
 * @author weikun
 * @since 2021-05-08
 */
@Service
public class MessageServiceImpl extends BaseServiceImpl<MessageMapper, Message> implements IMessageService {

	@Resource
	private  MessageLogMapper messageLogMapper;

	@Resource(name="${message.type.name}")
	private IMqSender mqSender;

	@Resource
	private MqMessageMapper mqMessageMapper;


	/**
	 * 最大重试次数
	 */
	@Value("${spring.rabbitmq.serve.max-retry-times}")
	private int retryTimes;



	@Override
	public TopMessageVO selectTopMessage() {
		TopMessageVO result = new TopMessageVO();
		//查询前十条消息
		List<Message> topMessageList = baseMapper.selectTopMessageList(SecureUtil.getUserId());
		for (Message message : topMessageList) {
			User user = UserCache.getUser(message.getCreateUser());
			if(user!=null){
				message.setCreateUserName(user.getName());
			}
		}
		//查询未读消息数量
		LambdaQueryWrapper<Message> queryWrapper = new LambdaQueryWrapper<Message>().eq(Message::getReceiveUser, SecureUtil.getUserId())
				.eq(Message::getIsDeleted, BladeConstant.DB_NOT_DELETED)
				.eq(Message::getIsRead, MessageEnum.UNREAD.getCode());

		result.setMessageList(topMessageList);
		result.setUnReadCount(Math.toIntExact(baseMapper.selectCount(queryWrapper)));
		return result;
	}

	@Override
	public MessageLog getSendDetail(Long id) {
		MessageLog messageLog = messageLogMapper.selectById(id);
		messageLogHandle(messageLog);
		return messageLog;
	}



	@Override
	public IPage<Message> selectMessagePage(IPage<Message> page, Message message) {
		List<Message> messageList = baseMapper.selectMessagePage(page, message);
		for (Message msg : messageList) {
			if(UserCache.getUser(msg.getCreateUser())!=null){
				msg.setCreateUserName(UserCache.getUser(msg.getCreateUser()).getName());
			}
		}
		return page.setRecords(messageList);
	}

	@Override
	public IPage<MessageLog> selectMessageSendPage(IPage<MessageLog> page, MessageLog message) {
		List<MessageLog> messageSendList = messageLogMapper.selectMessageLogPage(page, message);
		for (MessageLog messageLog : messageSendList) {
			messageLogHandle(messageLog);
		}
		return page.setRecords(messageSendList);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public Boolean sendMessage(MessageParams messageParams) {
		MessageLog messageLog = new MessageLog(messageParams);
		messageLog.setCreateUser(SecureUtil.getUserId());
		messageLog.setIsDeleted(BladeConstant.DB_NOT_DELETED);
		//保存发送记录
		messageLogMapper.insert(messageLog);
		//消息详情保存
		Message message = new Message(messageLog);
		//mq消息封装
		MqMessageVO mqMessageVO=new MqMessageVO(messageLog);
		if (MessageEnum.SINGLE.getCode() == messageParams.getType()) {
			this.save(message);
			mqSender.sendSingleMsg(messageParams.getReceiveUser(), mqMessageVO);

		}else{
			Set<Long> userSet = new HashSet<>();
			if(MessageEnum.GROUP.getCode() == messageParams.getType()){
				//查询部门下用户，可改feign调用user-api，若频繁调用可加缓存
				for (Long deptId : messageParams.getReceiveGroupList()) {
					List<Long> userIdList = messageLogMapper.selectUserIdsByDept(deptId);
					userSet.addAll(userIdList);
				}
			}
			if(MessageEnum.ROLE.getCode() == messageParams.getType()){
				//查询角色下用户，可改feign调用user-api，若频繁调用可加缓存
				for (Long roleId : messageParams.getReceiveGroupList()) {
					List<Long> userIdList = messageLogMapper.selectUserIdsByRole(roleId);
					userSet.addAll(userIdList);
				}
			}
			for (Long userId : userSet) {
				message.setReceiveUser(userId);
				message.setId(null);
				this.save(message);
			}
			mqSender.sendGroupMsg(messageLog.getReceiveGroupList(),userSet, mqMessageVO);

		}

		return true;
	}


	@Override
	public Boolean resendMessage() {
		List<MqMessage> messages = mqMessageMapper.selectList(
				Wrappers.<MqMessage>lambdaQuery()
						//发送中的消息
						.eq(MqMessage::getStatus, MessageStatusEnum.SENDING.getStatus())
						//已到达下次发送时间
						.le(MqMessage::getNextRetryDateTime, LocalDateTime.now(ZoneOffset.ofHours(8)))
		);
		messages.forEach(message -> {
			if (retryTimes <= message.getRetryTimes()) {
				//已达到最大投递次数，将消息设置为投递失败
				mqMessageMapper.update(null, Wrappers.<MqMessage>lambdaUpdate()
						.set(MqMessage::getStatus, MessageStatusEnum.FAIL.getStatus())
						.eq(MqMessage::getId, message.getId()));
			} else {
				mqSender.resendServeMsg(message);
			}
		});
		return true;
	}

	@Override
	public Boolean sendServeMessage(ServeMessageParams msgParam) {
		return mqSender.sendServeMsg(msgParam);
	}


	/**
	 * 发送消息记录接收人、部门处理
	 *
	 * @param messageLog 发送消息记录
	 */
	private void messageLogHandle(MessageLog messageLog) {
		if (messageLog.getType().equals(MessageEnum.SINGLE.getCode())) {
			if(UserCache.getUser(messageLog.getReceiveUser())!=null){
				messageLog.setReceiveUserName(UserCache.getUser(messageLog.getReceiveUser()).getName());
			}
		}
		if (messageLog.getType().equals(MessageEnum.GROUP.getCode())) {
			List<String> deptName = new ArrayList<>();
			for (String groupId : messageLog.getReceiveGroup().split(",")) {
				deptName.add(SysCache.getDeptName(Long.valueOf(groupId)));
			}
			messageLog.setReceiveGroupName(deptName);
		}
		if (messageLog.getType().equals(MessageEnum.ROLE.getCode())) {
			List<String> roleName = new ArrayList<>();
			for (String roleId : messageLog.getReceiveGroup().split(",")) {
				roleName.add(SysCache.getRoleName(Long.valueOf(roleId)));
			}
			messageLog.setReceiveGroupName(roleName);
		}
	}


}
