package org.springblade.plugin.message.sender;

import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.vo.MqMessageVO;

import java.util.List;
import java.util.Set;

/**
 * mq发送消息接口
 * @author weikun
 */
public interface IMqSender {

	/**
     * 发送普通消息
	 * @param receiveUserId 接收人id
	 * @param mqMessageVO mq消息实体
	 */
	void sendSingleMsg(Long receiveUserId,MqMessageVO mqMessageVO);


	/**
	 * 发送群消息  支持多选部门
	 * @param receiveGroupId 接收群id
	 * @param userSet 所有接收人
	 * @param mqMessageVO mq消息实体
	 */
	void sendGroupMsg(List<Long> receiveGroupId, Set<Long> userSet,MqMessageVO mqMessageVO);

	/**
	 * 发送服务端可靠消息
	 * @param msgParam
	 */
	Boolean sendServeMsg(ServeMessageParams msgParam);

	/**
	 * 重新投递消息
	 * @param mqMessage mq消息实体
	 * @return 是否成功
	 */
	Boolean resendServeMsg(MqMessage mqMessage);
}
