package org.springblade.plugin.message.sender;


import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.mqtt.MyMqttServer;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.vo.MqMessageVO;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;

/**
 * 生产者-直连交换机模式
 * 此模式下路由键匹配，同一账号多处在线都可接收到消息，未登录账号无法接收推送
 * 且再登录账号不会有推送，路由消息丢失，适用于web端
 *
 * @author weikun
 */
@Slf4j
@Component("mqttSender")
@ConditionalOnProperty(
	name = "message.type.name",
	havingValue = "mqttSender"
)
public class MqttSender implements IMqSender{


	@Override
	public void sendSingleMsg(Long receiveUserId, MqMessageVO mqMessageVO) {
		MyMqttServer.mqttServer.publishAll("/userId" + receiveUserId,
			ByteBuffer.wrap(JSONObject.toJSONString(mqMessageVO).getBytes(StandardCharsets.UTF_8)));
	}

	@Override
	public void sendGroupMsg(List<Long> receiveGroupId, Set<Long> userIds, MqMessageVO mqMessageVO) {
		userIds.forEach(userId-> this.sendSingleMsg(userId,mqMessageVO));

	}


	@Override
	public Boolean sendServeMsg(ServeMessageParams msgParam) {
		return false;
	}

	@Override
	public Boolean resendServeMsg(MqMessage mqMessage) {
		return false;
	}


}
