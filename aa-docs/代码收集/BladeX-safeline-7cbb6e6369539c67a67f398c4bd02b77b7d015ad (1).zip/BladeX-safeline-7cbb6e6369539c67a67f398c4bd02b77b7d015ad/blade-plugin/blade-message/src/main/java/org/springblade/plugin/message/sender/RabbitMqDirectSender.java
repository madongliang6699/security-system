package org.springblade.plugin.message.sender;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.enums.MessageStatusEnum;
import org.springblade.plugin.message.mapper.MqMessageMapper;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springblade.plugin.message.rabbitmq.constant.RabbitMqConstant;
import org.springblade.plugin.message.vo.MqMessageVO;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Set;

/**
 * 生产者-直连交换机模式
 * 此模式下路由键匹配，同一账号多处在线都可接收到消息，未登录账号无法接收推送
 * 且再登录账号不会有推送，路由消息丢失，适用于web端
 *
 * @author weikun
 */
@Slf4j
@Component("rabbitDirectSender")
@ConditionalOnProperty(
	name = "message.type.name",
	havingValue = "rabbitDirectSender"
)
public class RabbitMqDirectSender implements IMqSender{

	@Resource
    @Qualifier(value = "webRabbitTemplate")
    public RabbitTemplate webRabbitTemplate;

//	@Resource
//	@Qualifier(value = "serveRabbitTemplate")
//	public RabbitTemplate serveRabbitTemplate;

	@Resource
	private MqMessageMapper  mqMessageMapper;


	/**
	 * 每次重试时间间隔
	 */
	@Value("${spring.rabbitmq.serve.retry-interval}")
	private Duration retryInterval;

	/**
	 * 服务端交换机名称
	 */
	@Value("${spring.rabbitmq.serve.exchange}")
	private String exchange;


	@Override
	public void sendSingleMsg(Long receiveUserId, MqMessageVO mqMessageVO) {
        try {
            this.webRabbitTemplate.convertAndSend(RabbitMqConstant.EXCHANGE_DIRECT,
                    RabbitMqConstant.QUEUE_SINGLE_MSG + receiveUserId,JSONObject.toJSONString(mqMessageVO));
        }catch (Exception e){
            log.error("发送消息失败：",e);
        }
    }


	@Override
	public void sendGroupMsg(List<Long> receiveGroupId, Set<Long> userIds,MqMessageVO mqMessageVO) {
		try {
			userIds.forEach(userId-> this.webRabbitTemplate.convertAndSend(RabbitMqConstant.EXCHANGE_DIRECT,
				RabbitMqConstant.QUEUE_SINGLE_MSG +userId, JSONObject.toJSONString(mqMessageVO)));
		}catch (Exception e){
			log.error("发送消息失败：",e);
		}
	}


	@Override
	public Boolean sendServeMsg(ServeMessageParams msgParam) {
		MqMessage mqMessage=MqMessage.builder()
			.msgData(msgParam.getContent())
			.exchangeName(exchange)
			.routingKey(msgParam.getRoutingKey())
			.status(MessageStatusEnum.SENDING.getStatus())
			//下次重试时间
			.nextRetryDateTime(LocalDateTime.now(ZoneOffset.ofHours(8)).plus(retryInterval))
			.retryTimes(0)
			.build();
		mqMessageMapper.insert(mqMessage);
		CorrelationData correlationData = new CorrelationData(mqMessage.getId().toString());
		//消息投递到MQ
		//serveRabbitTemplate.convertAndSend(exchange, msgParam.getRoutingKey(), msgParam.getContent(), correlationData);
		return true;
	}


	@Override
	public Boolean resendServeMsg(MqMessage mqMessage) {
		mqMessageMapper.update(null,
			Wrappers.<MqMessage>lambdaUpdate()
				.set(MqMessage::getRetryTimes, mqMessage.getRetryTimes() + 1)
				.set(MqMessage::getNextRetryDateTime, LocalDateTime.now(ZoneOffset.ofHours(8)).plus(retryInterval))
				.eq(MqMessage::getId, mqMessage.getId())
		);
		try {
			//再次投递
			//serveRabbitTemplate.convertAndSend(mqMessage.getExchangeName(), mqMessage.getRoutingKey(), mqMessage.getMsgData(), new CorrelationData(mqMessage.getId().toString()));
			return true;
		} catch (Exception e) {
			log.error("消息[{}]投递失败", JSON.toJSONString(mqMessage));
			return false;
		}
	}


}
