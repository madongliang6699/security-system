package org.springblade.plugin.message.rabbitmq.config;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springblade.plugin.message.entity.MqMessage;
import org.springblade.plugin.message.enums.MessageStatusEnum;
import org.springblade.plugin.message.mapper.MqMessageMapper;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * rabbitmq配置
 *
 * @author weikun
 */
@Configuration
@ConditionalOnProperty(
	name = "message.type.name",
	havingValue = "rabbitDirectSender"
)
@Slf4j
public class RabbitMqConfiguration {

	/**
	 * 消息的最大重试次数
	 */
	@Value("${spring.rabbitmq.serve.max-retry-times}")
	private int maxRetryTimes;

	/**
	 * 每次重试时间间隔
	 */
	@Value("${spring.rabbitmq.serve.retry-interval}")
	private Duration retryInterval;

	@Resource
	private MqMessageMapper mqMessageMapper;

	/**
	 * web端连接工厂，如有其他连接域方便扩展
	 *
	 * @param host        地址
	 * @param port        端口
	 * @param username    账号
	 * @param password    密码
	 * @param virtualHost mq库
	 * @return web工厂实例
	 */
	@Bean(name = "webConnectionFactory")
	@Primary
	@ConditionalOnProperty(
		name = "message.type.name",
		havingValue = "rabbitDirectSender"
	)
	public ConnectionFactory webConnectionFactory(
		@Value("${spring.rabbitmq.host}") String host,
		@Value("${spring.rabbitmq.port}") int port,
		@Value("${spring.rabbitmq.web.username}") String username,
		@Value("${spring.rabbitmq.web.password}") String password,
		@Value("${spring.rabbitmq.web.virtual-host}") String virtualHost) {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
		connectionFactory.setHost(host);
		connectionFactory.setPort(port);
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setVirtualHost(virtualHost);

		return connectionFactory;
	}

	@Bean(name = "webRabbitTemplate")
	@Primary
	@ConditionalOnProperty(
		name = "message.type.name",
		havingValue = "rabbitDirectSender"
	)
	public RabbitTemplate webRabbitTemplate(@Qualifier("webConnectionFactory") ConnectionFactory connectionFactory) {
		RabbitTemplate webRabbitTemplate = new RabbitTemplate(connectionFactory);
		//使用外部事物
		//ydtRabbitTemplate.setChannelTransacted(true);
		return webRabbitTemplate;
	}


	/**
	 * 后端服务连接工厂，用于可靠消息投递
	 *
	 * @param host        地址
	 * @param port        端口
	 * @param username    账号
	 * @param password    密码
	 * @param virtualHost mq库
	 * @return web工厂实例
	 */
	@Bean(name = "serveConnectionFactory")
	@Primary
	@ConditionalOnProperty(
		name = "message.type.serve-rabbitmq",
		havingValue = "true"
	)
	public ConnectionFactory serveConnectionFactory(
		@Value("${spring.rabbitmq.host}") String host,
		@Value("${spring.rabbitmq.port}") int port,
		@Value("${spring.rabbitmq.serve.username}") String username,
		@Value("${spring.rabbitmq.serve.password}") String password,
		@Value("${spring.rabbitmq.serve.virtual-host}") String virtualHost) {
		CachingConnectionFactory connectionFactory = new CachingConnectionFactory();
		connectionFactory.setHost(host);
		connectionFactory.setPort(port);
		connectionFactory.setUsername(username);
		connectionFactory.setPassword(password);
		connectionFactory.setVirtualHost(virtualHost);
		//发送确认机制
		connectionFactory.setPublisherConfirmType(CachingConnectionFactory.ConfirmType.CORRELATED);
		//路由失败回调
		connectionFactory.setPublisherReturns(true);
		return connectionFactory;
	}

	@Bean(name = "serveRabbitTemplate")
	@Primary
	@ConditionalOnProperty(
		name = "message.type.serve-rabbitmq",
		havingValue = "true"
	)
	public RabbitTemplate serveRabbitTemplate(@Qualifier("serveConnectionFactory") ConnectionFactory connectionFactory) {
		RabbitTemplate serverRabbitTemplate = new RabbitTemplate(connectionFactory);
		//消息路由失败通知监听者，而不是将消息丢弃
		serverRabbitTemplate.setMandatory(true);
		//确认消息是否到达MQ
		serverRabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> {
			String correlationDataId = correlationData.getId();
			if (ack) {
				//ACK
				log.debug("消息[{}]投递成功，将DB中的消息状态设置为投递成功", correlationDataId);
				mqMessageMapper.update(null,
					Wrappers.<MqMessage>lambdaUpdate()
						.set(MqMessage::getStatus, MessageStatusEnum.SUCCESS.getStatus())
						.eq(MqMessage::getId, correlationDataId)
				);
			} else {
				System.out.println("消息[{}]投递失败,cause:{}");

				log.debug("消息[{}]投递失败,cause:{}", correlationDataId, cause);
				//NACK，消息重发
				MqMessage message = mqMessageMapper.selectById(correlationDataId);
				if (message.getRetryTimes() < maxRetryTimes) {
					//进行重试
					serverRabbitTemplate.convertAndSend(message.getExchangeName(), message.getRoutingKey(), message.getMsgData(), new CorrelationData(correlationDataId));
					//更新DB消息状态
					mqMessageMapper.update(null,
						Wrappers.<MqMessage>lambdaUpdate()
							.set(MqMessage::getStatus, MessageStatusEnum.SENDING.getStatus())
							.set(MqMessage::getNextRetryDateTime, LocalDateTime.now(ZoneOffset.ofHours(8)).plus(retryInterval))
							.set(MqMessage::getRetryTimes, message.getRetryTimes() + 1)
							.eq(MqMessage::getId, correlationDataId)
					);
				}
			}
		});


		return serverRabbitTemplate;
	}


}
