DROP TABLE IF EXISTS blade_mq_message;
CREATE TABLE blade_mq_message (
                                  ID bigserial NOT NULL,
                                  msg_data VARCHAR ( 255 ) DEFAULT NULL,
                                  exchange_name VARCHAR ( 64 ) DEFAULT NULL,
                                  routing_key VARCHAR ( 64 ) DEFAULT NULL,
                                  status INT DEFAULT NULL,
                                  retry_times INT DEFAULT NULL,
                                  next_retry_date_time TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
                                  PRIMARY KEY ( ID )
);
COMMENT ON TABLE blade_mq_message IS 'mq 可靠消息记录 ';
COMMENT ON COLUMN blade_mq_message.msg_data IS ' 业务数据 ';
COMMENT ON COLUMN blade_mq_message.exchange_name IS ' 交换机名称 ';
COMMENT ON COLUMN blade_mq_message.routing_key IS ' 路由键 ';
COMMENT ON COLUMN blade_mq_message.status IS ' 消息状态 ';
COMMENT ON COLUMN blade_mq_message.retry_times IS ' 重试次数 ';
COMMENT ON COLUMN blade_mq_message.next_retry_date_time IS ' 下一次重试时间 ';
