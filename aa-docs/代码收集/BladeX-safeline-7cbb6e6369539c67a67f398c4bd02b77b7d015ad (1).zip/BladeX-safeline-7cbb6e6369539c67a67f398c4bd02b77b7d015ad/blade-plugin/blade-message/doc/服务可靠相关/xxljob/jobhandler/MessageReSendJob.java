package org.springblade.job.executor.jobhandler;

import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.IJobHandler;
import com.xxl.job.core.handler.annotation.XxlJob;
import com.xxl.job.core.log.XxlJobLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springblade.plugin.message.feign.IMessageClient;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author weikun
 */
@Component
public class MessageReSendJob extends IJobHandler {
	private static final Logger log = LoggerFactory.getLogger(SampleXxlJob.class);

	@Resource
	private IMessageClient messageClient;



	@XxlJob(value = "MessageReSendJob", init = "jobHandlerInit", destroy = "jobHandlerDestroy")
	@Override
	public ReturnT<String> execute(String s) {

		long startTime = System.currentTimeMillis();
		log.info("开始扫描需要进行重试投递的消息");
		XxlJobLogger.log("开始扫描需要进行重试投递的消息");
		messageClient.reSend();
		log.info("扫描需要进行重试投递的消息任务结束，耗时[{}]ms", System.currentTimeMillis() - startTime);
		XxlJobLogger.log("扫描需要进行重试投递的消息任务结束，耗时[{}]ms", System.currentTimeMillis() - startTime);
		return ReturnT.SUCCESS;
	}


	public void jobHandlerInit() {
		log.info("before job execute...");
		XxlJobLogger.log("before job handler init...");
	}

	public void jobHandlerDestroy() {
		log.info("after job execute...");
		XxlJobLogger.log("after job execute...");
	}
}
