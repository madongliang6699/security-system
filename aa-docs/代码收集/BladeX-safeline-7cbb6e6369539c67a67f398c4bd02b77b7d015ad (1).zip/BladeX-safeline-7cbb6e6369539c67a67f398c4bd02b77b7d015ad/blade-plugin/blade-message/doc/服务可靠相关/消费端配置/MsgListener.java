package org.springblade.system.user.service;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @author weikun
 */
@Component
public class MsgListener {

	@RabbitListener(
		bindings ={@QueueBinding(value = @Queue(value = "blade-user-queue",durable = "true"),
		exchange =@Exchange(value = "serve-exchange"), key = "blade-user")})
	public void consumer(Channel channel, Message message) throws IOException {
		System.out.println("收到消息: " + message);

		channel.basicAck(message.getMessageProperties().getDeliveryTag(),false);
	}
}
