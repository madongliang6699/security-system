DROP TABLE IF EXISTS "blade_message";
CREATE TABLE blade_message
(
    id             BIGSERIAL NOT NULL,
    message_log_id BIGINT       DEFAULT NULL,
    type           INT          DEFAULT NULL,
    title          VARCHAR(64)  DEFAULT NULL,
    content        VARCHAR(255) DEFAULT NULL,
    receive_user   BIGINT       DEFAULT NULL,
    create_user    BIGINT       DEFAULT NULL,
    create_time    TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
    read_time      TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
    is_read        INT          DEFAULT '1',
    status         INT          DEFAULT NULL,
    is_deleted     INT          DEFAULT NULL,
    create_dept    BIGINT       DEFAULT NULL,
    update_user    BIGINT       DEFAULT NULL,
    update_time    TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
    PRIMARY KEY ("id")
);
DROP TABLE IF EXISTS "blade_message_log";
CREATE TABLE blade_message_log
(
    id            BIGINT NOT NULL,
    title         VARCHAR(64)   DEFAULT NULL,
    content       VARCHAR(255)  DEFAULT NULL,
    receive_user  BIGINT        DEFAULT NULL,
    receive_group VARCHAR(1000) DEFAULT NULL,
    type          INT           DEFAULT NULL,
    create_user   BIGINT        DEFAULT NULL,
    create_time   TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
    status        INT           DEFAULT NULL,
    update_user   BIGINT        DEFAULT NULL,
    update_time   TIMESTAMP WITHOUT TIME ZONE DEFAULT NULL,
    create_dept   BIGINT        DEFAULT NULL,
    is_deleted    INT           DEFAULT NULL,
    PRIMARY KEY ("id")
);
COMMENT
ON TABLE blade_message IS ' 消息详情表 ';
COMMENT
ON COLUMN blade_message.message_log_id IS ' 消息发送记录 id';
COMMENT
ON COLUMN blade_message.type IS ' 类型 1 单发 2 群发 3 审批通知 ';
COMMENT
ON COLUMN blade_message.title IS ' 标题 ';
COMMENT
ON COLUMN blade_message.content IS ' 内容 ';
COMMENT
ON COLUMN blade_message.receive_user IS ' 接收人 ';
COMMENT
ON COLUMN blade_message.create_user IS ' 创建人 ';
COMMENT
ON COLUMN blade_message.create_time IS ' 创建时间 ';
COMMENT
ON COLUMN blade_message.read_time IS ' 已读时间 ';
COMMENT
ON COLUMN blade_message.is_read IS ' 是否已读 0 已读 1 未读 ';
COMMENT
ON COLUMN blade_message.status IS ' 状态 ';
COMMENT
ON COLUMN blade_message.is_deleted IS ' 是否已删除 ';
COMMENT
ON TABLE blade_message_log IS ' 消息发送记录 ';
COMMENT
ON COLUMN blade_message_log.title IS ' 标题 ';
COMMENT
ON COLUMN blade_message_log.content IS ' 内容 ';
COMMENT
ON COLUMN blade_message_log.receive_user IS ' 接收人 ';
COMMENT
ON COLUMN blade_message_log.receive_group IS ' 接收角色 ';
COMMENT
ON COLUMN blade_message_log.type IS ' 类型 1 单发 2 群发 ';
COMMENT
ON COLUMN blade_message_log.create_user IS ' 创建人 ';
COMMENT
ON COLUMN blade_message_log.create_time IS ' 创建时间 ';