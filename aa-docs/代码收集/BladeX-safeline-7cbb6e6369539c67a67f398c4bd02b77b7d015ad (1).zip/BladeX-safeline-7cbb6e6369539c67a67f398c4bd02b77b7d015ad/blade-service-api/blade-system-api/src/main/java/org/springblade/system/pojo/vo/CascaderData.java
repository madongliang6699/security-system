package org.springblade.system.pojo.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * 提供一个与前端一致的存放级联数据的类
 */
@Data
@Schema(description = "提供一个与前端一致的存放级联数据的类")
public class CascaderData {

	/**
	 * id
	 */
	private String value;

	/**
	 * 名称
	 */
	private String title;

	/**
	 * 子级
	 */
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<CascaderData> children;

}
