/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.system.cache;

import org.springblade.core.cache.utils.CacheUtil;
import org.springblade.core.mp.enums.StatusType;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.SpringUtil;
import org.springblade.core.tool.utils.StringPool;
import org.springblade.system.feign.ISysClient;
import org.springblade.system.pojo.entity.*;
import org.springblade.system.pojo.vo.TenantVO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.springblade.core.cache.constant.CacheConstant.SYS_CACHE;

/**
 * 系统缓存
 *
 * @author Chill
 */
public class SysCache {
	private static final String MENU_ID = "menu:id:";
	private static final String DEPT_ID = "dept:id:";
	private static final String DEPT_NAME = "dept:name:";
	private static final String DEPT_NAME_FUZZY = "dept:nameFuzzy:";
	private static final String DEPT_NAME_ID = "deptName:id:";
	private static final String DEPT_NAMES_ID = "deptNames:id:";
	private static final String DEPT_CHILD_ID = "deptChild:id:";
	private static final String DEPT_CHILDIDS_ID = "deptChildIds:id:";
	private static final String POST_ID = "post:id:";
	private static final String POST_NAME = "post:name:";
	private static final String POST_NAME_FUZZY = "post:nameFuzzy:";
	private static final String POST_NAME_ID = "postName:id:";
	private static final String POST_NAMES_ID = "postNames:id:";
	private static final String ROLE_ID = "role:id:";
	private static final String ROLE_NAME = "role:name:";
	private static final String ROLE_NAME_ID = "roleName:id:";
	private static final String ROLE_NAMES_ID = "roleNames:id:";
	private static final String ROLE_ALIAS_ID = "roleAlias:id:";
	private static final String ROLE_ALIASES_ID = "roleAliases:id:";
	public static final String TENANT_ID = "tenant:id:";
	public static final String TENANT_TENANT_ID = "tenant:tenantId:";
	public static final String TENANT_PACKAGE_ID = "tenant:packageId:";
	private static final String DEPTS_TENANT = "depts:tenant:";
	private static final String POSTS_CODES = "posts:codes:";
	private static final String TENANT_ALL_IDS = "tenant:allIds:";
	private static final String TENANT_ALL_LIST = "tenant:allList:";
	private static final String TENANT_ALL_TREE = "tenant:allTree:";
	private static final String TENANT_CHILDREN = "tenant:children:";
	private static final String TENANT_CHILDREN_TENANT_IDS = "tenant:childrenTenantIds:";
	private static final String TENANT_DESCENDENTS = "tenant:descendents:";
	private static final String TENANT_DESCENDENT_TENANT_IDS = "tenant:descendentTenantIds:";
	private static final String TENANT_DESCENDENT_TREE = "tenant:descendent_tree:";

	private static ISysClient sysClient;

	private static ISysClient getSysClient() {
		if (sysClient == null) {
			sysClient = SpringUtil.getBean(ISysClient.class);
		}
		return sysClient;
	}

	/**
	 * 获取菜单
	 *
	 * @param id 主键
	 * @return 菜单
	 */
	public static Menu getMenu(Long id) {
		return CacheUtil.get(SYS_CACHE, MENU_ID, id, () -> {
			R<Menu> result = getSysClient().getMenu(id);
			return result.getData();
		});
	}

	/**
	 * 获取部门
	 *
	 * @param id 主键
	 * @return 部门
	 */
	public static Dept getDept(Long id) {
		return CacheUtil.get(SYS_CACHE, DEPT_ID, id, () -> {
			R<Dept> result = getSysClient().getDept(id);
			return result.getData();
		});
	}

	/**
	 * 获取部门id
	 *
	 * @param tenantId  租户id
	 * @param deptNames 部门名
	 * @return 部门id
	 */
	public static String getDeptIds(String tenantId, String deptNames) {
		return CacheUtil.get(SYS_CACHE, DEPT_NAME, tenantId + StringPool.DASH + deptNames, () -> {
			R<String> result = getSysClient().getDeptIds(tenantId, deptNames);
			return result.getData();
		});
	}

	/**
	 * 获取部门id
	 *
	 * @param tenantId  租户id
	 * @param deptNames 部门名模糊查询
	 * @return 部门id
	 */
	public static String getDeptIdsByFuzzy(String tenantId, String deptNames) {
		return CacheUtil.get(SYS_CACHE, DEPT_NAME_FUZZY, tenantId + StringPool.DASH + deptNames, () -> {
			R<String> result = getSysClient().getDeptIdsByFuzzy(tenantId, deptNames);
			return result.getData();
		});
	}

	/**
	 * 获取部门名
	 *
	 * @param id 主键
	 * @return 部门名
	 */
	public static String getDeptName(Long id) {
		return CacheUtil.get(SYS_CACHE, DEPT_NAME_ID, id, () -> {
			R<String> result = getSysClient().getDeptName(id);
			return result.getData();
		});
	}


	/**
	 * 获取部门名集合
	 *
	 * @param deptIds 主键集合
	 * @return 部门名
	 */
	public static List<String> getDeptNames(String deptIds) {
		return CacheUtil.get(SYS_CACHE, DEPT_NAMES_ID, deptIds, () -> {
			R<List<String>> result = getSysClient().getDeptNames(deptIds);
			return result.getData();
		});
	}

	/**
	 * 获取子部门集合
	 *
	 * @param deptId 主键
	 * @return 子部门
	 */
	public static List<Dept> getDeptChild(Long deptId) {
		return CacheUtil.get(SYS_CACHE, DEPT_CHILD_ID, deptId, () -> {
			R<List<Dept>> result = getSysClient().getDeptChild(deptId);
			return result.getData();
		});
	}

	/**
	 * 获取子部门ID集合
	 *
	 * @param deptId 主键
	 * @return 子部门ID
	 */
	public static List<Long> getDeptChildIds(Long deptId) {
		if (deptId == null) {
			return null;
		}
		List<Long> deptIdList = CacheUtil.get(SYS_CACHE, DEPT_CHILDIDS_ID, deptId, List.class);
		if (deptIdList == null) {
			deptIdList = new ArrayList<>();
			List<Dept> deptChild = getDeptChild(deptId);
			if (deptChild != null) {
				List<Long> collect = deptChild.stream().map(Dept::getId).collect(Collectors.toList());
				deptIdList.addAll(collect);
			}
			deptIdList.add(deptId);
			CacheUtil.put(SYS_CACHE, DEPT_CHILDIDS_ID, deptId, deptIdList);
		}
		return deptIdList;
	}

	/**
	 * 获取岗位
	 *
	 * @param id 主键
	 * @return
	 */
	public static Post getPost(Long id) {
		return CacheUtil.get(SYS_CACHE, POST_ID, id, () -> {
			R<Post> result = getSysClient().getPost(id);
			return result.getData();
		});
	}

	/**
	 * 获取岗位id
	 *
	 * @param tenantId  租户id
	 * @param postNames 岗位名
	 * @return
	 */
	public static String getPostIds(String tenantId, String postNames) {
		return CacheUtil.get(SYS_CACHE, POST_NAME, tenantId + StringPool.DASH + postNames, () -> {
			R<String> result = getSysClient().getPostIds(tenantId, postNames);
			return result.getData();
		});
	}

	/**
	 * 获取岗位id
	 *
	 * @param tenantId  租户id
	 * @param postNames 岗位名模糊查询
	 * @return
	 */
	public static String getPostIdsByFuzzy(String tenantId, String postNames) {
		return CacheUtil.get(SYS_CACHE, POST_NAME_FUZZY, tenantId + StringPool.DASH + postNames, () -> {
			R<String> result = getSysClient().getPostIdsByFuzzy(tenantId, postNames);
			return result.getData();
		});
	}

	/**
	 * 获取岗位名
	 *
	 * @param id 主键
	 * @return 岗位名
	 */
	public static String getPostName(Long id) {
		return CacheUtil.get(SYS_CACHE, POST_NAME_ID, id, () -> {
			R<String> result = getSysClient().getPostName(id);
			return result.getData();
		});
	}

	/**
	 * 获取岗位名集合
	 *
	 * @param postIds 主键集合
	 * @return 岗位名
	 */
	public static List<String> getPostNames(String postIds) {
		return CacheUtil.get(SYS_CACHE, POST_NAMES_ID, postIds, () -> {
			R<List<String>> result = getSysClient().getPostNames(postIds);
			return result.getData();
		});
	}

	/**
	 * 获取角色
	 *
	 * @param id 主键
	 * @return Role
	 */
	public static Role getRole(Long id) {
		return CacheUtil.get(SYS_CACHE, ROLE_ID, id, () -> {
			R<Role> result = getSysClient().getRole(id);
			return result.getData();
		});
	}

	/**
	 * 获取角色id
	 *
	 * @param tenantId  租户id
	 * @param roleNames 角色名
	 * @return
	 */
	public static String getRoleIds(String tenantId, String roleNames) {
		return CacheUtil.get(SYS_CACHE, ROLE_NAME, tenantId + StringPool.DASH + roleNames, () -> {
			R<String> result = getSysClient().getRoleIds(tenantId, roleNames);
			return result.getData();
		});
	}

	/**
	 * 获取角色名
	 *
	 * @param id 主键
	 * @return 角色名
	 */
	public static String getRoleName(Long id) {
		return CacheUtil.get(SYS_CACHE, ROLE_NAME_ID, id, () -> {
			R<String> result = getSysClient().getRoleName(id);
			return result.getData();
		});
	}

	/**
	 * 获取角色别名
	 *
	 * @param id 主键
	 * @return 角色别名
	 */
	public static String getRoleAlias(Long id) {
		return CacheUtil.get(SYS_CACHE, ROLE_ALIAS_ID, id, () -> {
			R<String> result = getSysClient().getRoleAlias(id);
			return result.getData();
		});
	}

	/**
	 * 获取角色名集合
	 *
	 * @param roleIds 主键集合
	 * @return 角色名
	 */
	public static List<String> getRoleNames(String roleIds) {
		return CacheUtil.get(SYS_CACHE, ROLE_NAMES_ID, roleIds, () -> {
			R<List<String>> result = getSysClient().getRoleNames(roleIds);
			return result.getData();
		});
	}

	/**
	 * 获取角色别名集合
	 *
	 * @param roleIds 主键集合
	 * @return 角色别名
	 */
	public static List<String> getRoleAliases(String roleIds) {
		return CacheUtil.get(SYS_CACHE, ROLE_ALIASES_ID, roleIds, () -> {
			R<List<String>> result = getSysClient().getRoleAliases(roleIds);
			return result.getData();
		});
	}

	/**
	 * 获取租户
	 *
	 * @param id 主键
	 * @return Tenant
	 */
	public static Tenant getTenant(Long id) {
		return CacheUtil.get(SYS_CACHE, TENANT_ID, id, () -> Optional.ofNullable(getSysClient().getTenant(id).getData())
			.filter(tenant -> tenant.getStatus() != null)
			.filter(tenant -> tenant.getStatus() == StatusType.ACTIVE.getType())
			.orElse(null), Boolean.FALSE);
	}

	/**
	 * 获取租户
	 *
	 * @param tenantId 租户id
	 * @return Tenant
	 */
	public static Tenant getTenant(String tenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_TENANT_ID, tenantId, () -> Optional.ofNullable(getSysClient().getTenant(tenantId).getData())
			.filter(tenant -> tenant.getStatus() != null)
			.filter(tenant -> tenant.getStatus() == StatusType.ACTIVE.getType())
			.orElse(null), Boolean.FALSE);
	}

	/**
	 * 获取租户产品包
	 *
	 * @param tenantId 租户id
	 * @return Tenant
	 */
	public static TenantPackage getTenantPackage(String tenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_PACKAGE_ID, tenantId, () -> {
			R<TenantPackage> result = getSysClient().getTenantPackage(tenantId);
			return result.getData();
		}, Boolean.FALSE);
	}

	/**
	 * 获取租户下部门集合
	 *
	 * @param tenantId 租户id
	 * @return 部门集合
	 */
	public static List<Dept> getDeptsByTenantId(String tenantId) {
		return CacheUtil.get(SYS_CACHE, DEPTS_TENANT, tenantId, () -> {
			R<List<Dept>> result = getSysClient().getDeptsByTenantId(tenantId);
			return result.getData();
		});
	}

	/**
	 * 获取租户下部门集合
	 *
	 * @param tenantId 租户id
	 * @return 部门集合
	 */
	public static List<Post> getPostsByCodes(String tenantId, String postCodes) {
		return CacheUtil.get(SYS_CACHE, POSTS_CODES, tenantId+postCodes, () -> {
			R<List<Post>> result = getSysClient().getPostsByCodes(tenantId, postCodes);
			return result.getData();
		});
	}

	/**
	 * 获取所有租户id
	 */
	public static List<String> getAllTenantIds() {
		return CacheUtil.get(SYS_CACHE, TENANT_ALL_IDS, "allTenantIds", () -> {
			R<List<String>> result = getSysClient().getAllTenantIds();
			return result.getData();
		}, false);
	}

	/**
	 * 获取所有租户列表
	 */
	public static List<Tenant> getAllTenants() {
		return CacheUtil.get(SYS_CACHE, TENANT_ALL_LIST, "allTenants", () -> {
			R<List<Tenant>> result = getSysClient().getAllTenants();
			return result.getData();
		}, false);
	}

	/**
	 * 获取所有租户树
	 */
	public static List<TenantVO> getAllTenantsTree() {
		return CacheUtil.get(SYS_CACHE, TENANT_ALL_TREE, "allTenantTree", () -> {
			R<List<TenantVO>> result = getSysClient().getAllTenantsTree();
			return result.getData();
		}, false);
	}

	/**
	 * 获取指定租户的子租户列表，只有子一级
	 */
	public static List<TenantVO> getTenantChildren(String tenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_CHILDREN, tenantId, () -> {
			R<List<TenantVO>> result = getSysClient().getTenantChildren(tenantId);
			return result.getData();
		}, false);
	}

	/**
	 * 获取指定租户的子租户id列表，只有子一级
	 */
	public static List<String> getChildrenTenantIds(String tenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_CHILDREN_TENANT_IDS, tenantId, () -> {
			R<List<TenantVO>> result = getSysClient().getTenantChildren(tenantId);
			return result.getData().stream().map(TenantVO::getTenantId).collect(Collectors.toList());
		}, false);
	}

	/**
	 * 获取后辈所有租户列表，平铺
	 */
	public static List<TenantVO> getTenantFlattenDescendents(String parentTenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_DESCENDENTS, parentTenantId, () -> {
			R<List<TenantVO>> result = getSysClient().getTenantFlattenDescendents(parentTenantId);
			return result.getData();
		}, false);
	}

	/**
	 * 获取后辈所有租户的id列表
	 */
	public static List<String> getDescendentTenantIds(String parentTenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_DESCENDENT_TENANT_IDS, parentTenantId, () -> {
			R<List<TenantVO>> result = getSysClient().getTenantFlattenDescendents(parentTenantId);
			return result.getData().stream().map(TenantVO::getTenantId).collect(Collectors.toList());
		}, false);
	}

	/**
	 * 获取后辈所有租户的树
	 */
	public static List<TenantVO> getTenantDescendentTree(String parentTenantId) {
		return CacheUtil.get(SYS_CACHE, TENANT_DESCENDENT_TREE, parentTenantId, () -> {
			R<List<TenantVO>> result = getSysClient().getTenantDescendentTree(parentTenantId);
			return result.getData();
		}, false);
	}
}
