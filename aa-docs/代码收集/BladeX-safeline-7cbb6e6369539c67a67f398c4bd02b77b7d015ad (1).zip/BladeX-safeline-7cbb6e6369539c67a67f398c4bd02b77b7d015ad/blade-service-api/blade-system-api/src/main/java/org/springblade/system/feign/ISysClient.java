/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.system.feign;

import org.springblade.core.launch.constant.AppConstant;
import org.springblade.core.tool.api.R;
import org.springblade.system.pojo.entity.*;
import org.springblade.system.pojo.vo.TenantVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * Feign接口类
 *
 * @author Chill
 */
@FeignClient(
	value = AppConstant.APPLICATION_SYSTEM_NAME,
	fallback = ISysClientFallback.class
)
public interface ISysClient {

	String API_PREFIX = "/feign/client/system";
	String MENU = API_PREFIX + "/menu";
	String DEPT = API_PREFIX + "/dept";
	String DEPT_IDS = API_PREFIX + "/dept-ids";
	String DEPT_IDS_FUZZY = API_PREFIX + "/dept-ids-fuzzy";
	String DEPT_NAME = API_PREFIX + "/dept-name";
	String DEPT_NAMES = API_PREFIX + "/dept-names";
	String DEPT_CHILD = API_PREFIX + "/dept-child";
	String POST = API_PREFIX + "/post";
	String POST_IDS = API_PREFIX + "/post-ids";
	String POST_IDS_FUZZY = API_PREFIX + "/post-ids-fuzzy";
	String POST_NAME = API_PREFIX + "/post-name";
	String POST_NAMES = API_PREFIX + "/post-names";
	String ROLE = API_PREFIX + "/role";
	String ROLE_IDS = API_PREFIX + "/role-ids";
	String ROLE_NAME = API_PREFIX + "/role-name";
	String ROLE_NAMES = API_PREFIX + "/role-names";
	String ROLE_ALIAS = API_PREFIX + "/role-alias";
	String ROLE_ALIASES = API_PREFIX + "/role-aliases";
	String TENANT = API_PREFIX + "/tenant";
	String TENANT_ID = API_PREFIX + "/tenant-id";
	String TENANT_ALL_LIST = API_PREFIX + "/tenant-all-list";
	String TENANT_ALL_TREE = API_PREFIX + "/tenant-all-tree";
	String TENANT_CHILDREN = API_PREFIX + "/tenant-children";
	String TENANT_DESCENDENTS = API_PREFIX + "/tenant-descendents";
	String TENANT_DESCENDENT_TREE = API_PREFIX + "/tenant-descendent-tree";
	String TENANT_ALL_IDS = API_PREFIX + "/tenant-all-ids";
	String TENANT_PACKAGE = API_PREFIX + "/tenant-package";
	String PARAM = API_PREFIX + "/param";
	String PARAM_VALUE = API_PREFIX + "/param-value";
	String REGION = API_PREFIX + "/region";
	String DEPTS_BY_TENANT = API_PREFIX + "/depts-by-tenant";
	String POSTS = API_PREFIX + "/posts";

	/**
	 * 获取菜单
	 *
	 * @param id 主键
	 * @return Menu
	 */
	@GetMapping(MENU)
	R<Menu> getMenu(@RequestParam("id") Long id);

	/**
	 * 获取部门
	 *
	 * @param id 主键
	 * @return Dept
	 */
	@GetMapping(DEPT)
	R<Dept> getDept(@RequestParam("id") Long id);

	/**
	 * 获取部门id
	 *
	 * @param tenantId  租户id
	 * @param deptNames 部门名
	 * @return 部门id
	 */
	@GetMapping(DEPT_IDS)
	R<String> getDeptIds(@RequestParam("tenantId") String tenantId, @RequestParam("deptNames") String deptNames);

	/**
	 * 获取部门id
	 *
	 * @param tenantId  租户id
	 * @param deptNames 部门名
	 * @return 部门id
	 */
	@GetMapping(DEPT_IDS_FUZZY)
	R<String> getDeptIdsByFuzzy(@RequestParam("tenantId") String tenantId, @RequestParam("deptNames") String deptNames);

	/**
	 * 获取部门名
	 *
	 * @param id 主键
	 * @return 部门名
	 */
	@GetMapping(DEPT_NAME)
	R<String> getDeptName(@RequestParam("id") Long id);

	/**
	 * 获取部门名
	 *
	 * @param deptIds 主键
	 * @return
	 */
	@GetMapping(DEPT_NAMES)
	R<List<String>> getDeptNames(@RequestParam("deptIds") String deptIds);

	/**
	 * 获取子部门ID
	 *
	 * @param deptId
	 * @return
	 */
	@GetMapping(DEPT_CHILD)
	R<List<Dept>> getDeptChild(@RequestParam("deptId") Long deptId);

	/**
	 * 获取岗位
	 *
	 * @param id 主键
	 * @return Post
	 */
	@GetMapping(POST)
	R<Post> getPost(@RequestParam("id") Long id);

	/**
	 * 获取岗位id
	 *
	 * @param tenantId  租户id
	 * @param postNames 岗位名
	 * @return 岗位id
	 */
	@GetMapping(POST_IDS)
	R<String> getPostIds(@RequestParam("tenantId") String tenantId, @RequestParam("postNames") String postNames);

	/**
	 * 获取岗位id
	 *
	 * @param tenantId  租户id
	 * @param postNames 岗位名
	 * @return 岗位id
	 */
	@GetMapping(POST_IDS_FUZZY)
	R<String> getPostIdsByFuzzy(@RequestParam("tenantId") String tenantId, @RequestParam("postNames") String postNames);

	/**
	 * 获取岗位名
	 *
	 * @param id 主键
	 * @return 岗位名
	 */
	@GetMapping(POST_NAME)
	R<String> getPostName(@RequestParam("id") Long id);

	/**
	 * 获取岗位名
	 *
	 * @param postIds 主键
	 * @return
	 */
	@GetMapping(POST_NAMES)
	R<List<String>> getPostNames(@RequestParam("postIds") String postIds);

	/**
	 * 获取角色
	 *
	 * @param id 主键
	 * @return Role
	 */
	@GetMapping(ROLE)
	R<Role> getRole(@RequestParam("id") Long id);

	/**
	 * 获取角色id
	 *
	 * @param tenantId  租户id
	 * @param roleNames 角色名
	 * @return 角色id
	 */
	@GetMapping(ROLE_IDS)
	R<String> getRoleIds(@RequestParam("tenantId") String tenantId, @RequestParam("roleNames") String roleNames);

	/**
	 * 获取角色名
	 *
	 * @param id 主键
	 * @return 角色名
	 */
	@GetMapping(ROLE_NAME)
	R<String> getRoleName(@RequestParam("id") Long id);

	/**
	 * 获取角色别名
	 *
	 * @param id 主键
	 * @return 角色别名
	 */
	@GetMapping(ROLE_ALIAS)
	R<String> getRoleAlias(@RequestParam("id") Long id);

	/**
	 * 获取角色名
	 *
	 * @param roleIds 主键
	 * @return
	 */
	@GetMapping(ROLE_NAMES)
	R<List<String>> getRoleNames(@RequestParam("roleIds") String roleIds);

	/**
	 * 获取角色别名
	 *
	 * @param roleIds 主键
	 * @return 角色别名
	 */
	@GetMapping(ROLE_ALIASES)
	R<List<String>> getRoleAliases(@RequestParam("roleIds") String roleIds);

	/**
	 * 获取租户
	 *
	 * @param id 主键
	 * @return Tenant
	 */
	@GetMapping(TENANT)
	R<Tenant> getTenant(@RequestParam("id") Long id);

	/**
	 * 获取租户
	 *
	 * @param tenantId 租户id
	 * @return Tenant
	 */
	@GetMapping(TENANT_ID)
	R<Tenant> getTenant(@RequestParam("tenantId") String tenantId);

	/**
	 * 获取租户产品包
	 *
	 * @param tenantId 租户id
	 * @return Tenant
	 */
	@GetMapping(TENANT_PACKAGE)
	R<TenantPackage> getTenantPackage(@RequestParam("tenantId") String tenantId);

	/**
	 * 获取参数
	 *
	 * @param id 主键
	 * @return Param
	 */
	@GetMapping(PARAM)
	R<Param> getParam(@RequestParam("id") Long id);

	/**
	 * 获取参数配置
	 *
	 * @param paramKey 参数key
	 * @return String
	 */
	@GetMapping(PARAM_VALUE)
	R<String> getParamValue(@RequestParam("paramKey") String paramKey);

	/**
	 * 获取行政区划
	 *
	 * @param code 主键
	 * @return Region
	 */
	@GetMapping(REGION)
	R<Region> getRegion(@RequestParam("code") String code);

	/**
	 * 列出租户下的所有部门
	 * @param tenantId 租户id
	 * @return 部门列表
	 */
	@GetMapping(DEPTS_BY_TENANT)
	R<List<Dept>> getDeptsByTenantId(@RequestParam String tenantId);

	/**
	 * 获取岗位id
	 *
	 * @param tenantId  租户id
	 * @param postCodes 岗位编码
	 * @return 岗位id
	 */
	@GetMapping(POSTS)
	R<List<Post>> getPostsByCodes(@RequestParam("tenantId") String tenantId, @RequestParam("postCodes") String postCodes);

	/**
	 * 获取所有租户ID
	 */
	@GetMapping(TENANT_ALL_IDS)
	R<List<String>> getAllTenantIds();

	/**
	 * 获取所有租户的列表
	 */
	@GetMapping(TENANT_ALL_LIST)
	R<List<Tenant>> getAllTenants();

	/**
	 * 获取所有租户的树
	 */
	@GetMapping(TENANT_ALL_TREE)
	R<List<TenantVO>> getAllTenantsTree();

	/**
	 * 获取租户下的所有子租户列表(树展开）
	 * @param tenantId 租户id
	 * @return 租户列表
	 */
	@GetMapping(TENANT_DESCENDENTS)
	R<List<TenantVO>> getTenantFlattenDescendents(@RequestParam String tenantId);

	/**
	 * 获取租户下直接子租户列表
	 * @param tenantId 租户id
	 * @return 租户列表
	 */
	@GetMapping(TENANT_CHILDREN)
	R<List<TenantVO>> getTenantChildren(@RequestParam String tenantId);

	/**
	 * 获取租户下的所有子租户树
	 * @param tenantId 租户id
	 * @return 租户列表
	 */
	@GetMapping(TENANT_DESCENDENT_TREE)
	R<List<TenantVO>> getTenantDescendentTree(@RequestParam String tenantId);
}
