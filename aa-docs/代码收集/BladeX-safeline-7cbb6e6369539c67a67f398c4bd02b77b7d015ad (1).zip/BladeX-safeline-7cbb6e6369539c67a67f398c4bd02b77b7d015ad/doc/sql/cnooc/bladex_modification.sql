BEGIN;

-- 修改默认租户的机构名
UPDATE blade_dept t SET t.dept_name = 'QHSE开发分部门1', t.full_name = 'QHSE开发分部门1' WHERE t.id = 1123598813738675203
UPDATE blade_dept t SET t.dept_name = 'QHSE开发分部门2', t.full_name = 'QHSE开发分部门2' WHERE t.id = 1123598813738675202
UPDATE blade_dept t SET t.dept_name = 'QHSE开发', t.full_name = 'QHSE开发' WHERE t.id = 1123598813738675201

-- 租户加入父租户id及简称字段
-- 租户名称变大
ALTER TABLE blade_tenant ALTER COLUMN tenant_name TYPE VARCHAR(100);
ALTER TABLE blade_tenant ADD parent_tenant_id VARCHAR(12) NULL DEFAULT NULL;
ALTER TABLE blade_tenant ADD tenant_alias VARCHAR(100) NULL DEFAULT '';
ALTER TABLE blade_tenant ADD tenant_level TINYINT NOT NULL DEFAULT 1;
UPDATE blade_tenant SET tenant_alias = tenant_name where 1 = 1;
CREATE UNIQUE INDEX blade_tenant_name_uindex ON blade_tenant (tenant_name, is_deleted);
CREATE UNIQUE INDEX blade_tenant_alias_uindex ON blade_tenant (tenant_alias, is_deleted);

-- 部门名称数据变长
ALTER TABLE blade_dept ALTER COLUMN full_name TYPE VARCHAR(100);

-- 岗位数据变大
ALTER TABLE blade_post ALTER COLUMN post_code TYPE VARCHAR(100);
ALTER TABLE blade_post ALTER COLUMN post_name TYPE VARCHAR(100);

-- 岗位编码不允许重复
CREATE UNIQUE INDEX blade_post_tenant_id_post_code_is_deleted_uindex ON blade_post (tenant_id, post_code, is_deleted);
-- 岗位中加入部门id
ALTER TABLE blade_post ADD dept_id bigint NULL;

-- 业务字典加入是否默认字段
ALTER TABLE blade_dict_biz
    ADD as_default BOOLEAN DEFAULT FALSE NOT NULL;

-- 租户部门全称加入唯一性校验
CREATE UNIQUE INDEX dept_full_name_tenant ON blade_dept (tenant_id, full_name);

-- 管理员密码重置
-- UPDATE blade_user SET password = '05179ef0c47284e613271676ce1ed1760bc061c4' WHERE account = 'admin' AND tenant_id = '000000';

-- app 客户端参数
-- saber token有效期
UPDATE blade_client SET access_token_validity = 604800, refresh_token_validity = 2592000 WHERE id = '1123598811738675202';

-- 添加客户端
-- DELETE FROM blade_client WHERE id IN (1203865424311115777);
-- INSERT INTO blade_client (id, client_id, client_secret, resource_ids, scope, authorized_grant_types, web_server_redirect_uri, authorities, access_token_validity, refresh_token_validity, additional_information, autoapprove, create_user, create_dept, create_time, update_user, update_time, status, is_deleted)
-- VALUES (1203865424311115777, 'earnest', 'NukolYTVvzEa', '', 'all', 'refresh_token,authorization_code,totp,face', 'http://localhost:8888', '', 604800, 2592000, NULL, NULL, 1123598821738675201, 1123598813738675201, '2019-12-09 10:34:19', 1123598821738675201, '2019-12-09 10:34:19', 1, 0);

-- saber添加totp登陆方式，去除其他登陆方式
-- UPDATE blade_client SET authorized_grant_types = 'refresh_token,authorization_code,totp' WHERE id = '1123598811738675202';
-- UPDATE blade_client SET authorized_grant_types = 'refresh_token,authorization_code,totp' WHERE id = '1123598811738675201';

-- 用户默认密码
UPDATE blade_param SET param_value = '4a#nVr7kVT87' WHERE id = 1123598819738675202;

-- 用户姓名长度加长
ALTER TABLE blade_user ALTER COLUMN name TYPE VARCHAR(60);
ALTER TABLE blade_user ALTER COLUMN real_name TYPE VARCHAR(60);

-- 用户表加入userSource字段
ALTER TABLE blade_user ADD user_source varchar(12) NOT NULL DEFAULT 'OUTER';

COMMIT;
