-- 在按钮中加入表单key,以便于直接通过按钮获取表单
ALTER TABLE blade_wf_button ADD form_key VARCHAR(100);
ALTER TABLE blade_wf_button ADD finished BOOLEAN DEFAULT TRUE NOT NULL;


-- 流程表达式与人员配置
delete from blade_wf_condition where id in
                                     (
                                      1497074772303708162,
                                      1497074772303708163,
                                      1497074772303708164,
                                      1497074772303708165,
                                      1497074772303708166
                                         );
INSERT INTO blade_wf_condition (id, name, expression, type, status, is_deleted, tenant_id)
VALUES
    (1497074772303708163, '任务节点人员', 'taskPeople', 'user', '1', 0, '000000');
