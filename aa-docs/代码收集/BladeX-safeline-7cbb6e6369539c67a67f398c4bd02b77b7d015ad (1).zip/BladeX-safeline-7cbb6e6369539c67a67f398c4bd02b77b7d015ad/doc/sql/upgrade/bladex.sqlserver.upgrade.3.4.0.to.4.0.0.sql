-- -----------------------------------
-- 修改应用表saber的访问地址
-- -----------------------------------
UPDATE [dbo].[blade_client] SET [authorized_grant_types] = 'authorization_code,password,refresh_token,captcha,social,register' WHERE id < '1123598811738675203';

-- -----------------------------------
-- 删除可能重复的菜单
-- -----------------------------------
DELETE FROM [dbo].[blade_client] WHERE client_id = 'saber3';
DELETE FROM [dbo].[blade_client] WHERE client_id = 'rider';

-- -----------------------------------
-- 新增模型设计菜单
-- -----------------------------------
INSERT INTO [dbo].[blade_client] ([id], [client_id], [client_secret], [resource_ids], [scope], [authorized_grant_types], [web_server_redirect_uri], [authorities], [access_token_validity], [refresh_token_validity], [additional_information], [autoapprove], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted]) VALUES (1123598811738675203, N'saber3', N'saber3_secret', NULL, N'all', N'authorization_code,password,refresh_token,captcha,social,register', N'http://localhost:2888/login', NULL, 3600, 604800, NULL, NULL, 1123598815738675201, 1123598813738675201, '2024-04-01 00:00:00', 1123598815738675201, '2024-04-01 00:00:00', 1, 0);
INSERT INTO [dbo].[blade_client] ([id], [client_id], [client_secret], [resource_ids], [scope], [authorized_grant_types], [web_server_redirect_uri], [authorities], [access_token_validity], [refresh_token_validity], [additional_information], [autoapprove], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted]) VALUES (1123598811738675204, N'rider', N'rider_secret', NULL, N'all', N'authorization_code,password,refresh_token,captcha,social,register', N'http://localhost:88', NULL, 3600, 604800, NULL, NULL, 1123598815738675201, 1123598813738675201, '2024-04-01 00:00:00', 1123598815738675201, '2024-04-01 00:00:00', 1, 0);
