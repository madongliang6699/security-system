-- -----------------------------------
-- 修改应用表的授权集合
-- -----------------------------------
UPDATE "BLADEX"."BLADE_CLIENT" SET AUTHORIZED_GRANT_TYPES = 'authorization_code,password,refresh_token,captcha,social,register' where ID < 1123598811738675203;

-- -----------------------------------
-- 删除可能重复的菜单
-- -----------------------------------
DELETE FROM "BLADEX"."BLADE_CLIENT" WHERE "CLIENT_ID" = 'saber3';
DELETE FROM "BLADEX"."BLADE_CLIENT" WHERE "CLIENT_ID" = 'rider';

-- -----------------------------------
-- 新增客户端记录
-- -----------------------------------
INSERT INTO "BLADEX"."BLADE_CLIENT" ("ID", "CLIENT_ID", "CLIENT_SECRET", "RESOURCE_IDS", "SCOPE", "AUTHORIZED_GRANT_TYPES", "WEB_SERVER_REDIRECT_URI", "AUTHORITIES", "ACCESS_TOKEN_VALIDITY", "REFRESH_TOKEN_VALIDITY", "ADDITIONAL_INFORMATION", "AUTOAPPROVE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED") VALUES ('1123598811738675203', 'saber3', 'saber3_secret', NULL, 'all', 'authorization_code,password,refresh_token,captcha,social,register', 'http://localhost:2888/login', NULL, '3600', '604800', NULL, NULL, '1123598815738675201', '1123598813738675201', '2024-04-01 00:00:00', '1123598815738675201', '2024-04-01 00:00:00', '1', '0');
INSERT INTO "BLADEX"."BLADE_CLIENT" ("ID", "CLIENT_ID", "CLIENT_SECRET", "RESOURCE_IDS", "SCOPE", "AUTHORIZED_GRANT_TYPES", "WEB_SERVER_REDIRECT_URI", "AUTHORITIES", "ACCESS_TOKEN_VALIDITY", "REFRESH_TOKEN_VALIDITY", "ADDITIONAL_INFORMATION", "AUTOAPPROVE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED") VALUES ('1123598811738675204', 'rider', 'rider_secret', NULL, 'all', 'authorization_code,password,refresh_token,captcha,social,register', 'http://localhost:88', NULL, '3600', '604800', NULL, NULL, '1123598815738675201', '1123598813738675201', '2024-04-01 00:00:00', '1123598815738675201', '2024-04-01 00:00:00', '1', '0');
