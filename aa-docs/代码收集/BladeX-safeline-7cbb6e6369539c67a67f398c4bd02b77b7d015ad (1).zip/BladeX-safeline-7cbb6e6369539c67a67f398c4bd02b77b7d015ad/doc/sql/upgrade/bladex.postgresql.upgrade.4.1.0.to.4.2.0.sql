-- -----------------------------------
-- 创建一个新的租户数据源表，与原数据源表结构一致
-- -----------------------------------
-- 复制表结构
CREATE TABLE "blade_tenant_datasource" AS TABLE blade_datasource WITH NO DATA;

-- 复制表数据
INSERT INTO "blade_tenant_datasource" SELECT * FROM blade_datasource;

-- -----------------------------------
-- 修改菜单名称避免重名
-- -----------------------------------
UPDATE "blade_menu" SET name='流程状态' WHERE code='flow_manager';

-- -----------------------------------
-- 新增本地存储字典
-- -----------------------------------
INSERT INTO "blade_dict" ("id", "parent_id", "code", "dict_key", "dict_value", "sort", "remark", "is_sealed", "status", "is_deleted") VALUES (1123598814738676231, 1123598814738676224, 'oss', '7', '本地存储', 7, '', 0, 1, 0);

-- -----------------------------------
-- 代码生成新增字段
-- -----------------------------------
ALTER TABLE "blade_code"
    ADD COLUMN "menu_id" int8;

COMMENT ON COLUMN "blade_code"."menu_id" IS '上级菜单主键';

-- -----------------------------------
-- 代码生成配置表
-- -----------------------------------
CREATE TABLE "blade_code_setting" (
   "id" int8 NOT NULL,
   "settings" text,
   "status" int4 DEFAULT 1,
   "is_deleted" int4 DEFAULT 0,
   PRIMARY KEY ("id")
);

COMMENT ON COLUMN "blade_code_setting"."id" IS '主键';

COMMENT ON COLUMN "blade_code_setting"."settings" IS '配置项';

COMMENT ON COLUMN "blade_code_setting"."status" IS '状态';

COMMENT ON COLUMN "blade_code_setting"."is_deleted" IS '是否已删除';

COMMENT ON TABLE "blade_code_setting" IS '代码生成器配置表';

-- -----------------------------------
-- 更新菜单图标
-- -----------------------------------
UPDATE "blade_menu" SET source='iconfont icon-yonghu' WHERE id='1123598815738675204';
UPDATE "blade_menu" SET source='iconfont icon-quanxianshenpi' WHERE id='1164733389668962251';
UPDATE "blade_menu" SET source='iconfont icon-xiaoxitongzhi' WHERE id='1164733389658962251';
UPDATE "blade_menu" SET source='iconfont icon-xingzhuang-tupian' WHERE id='1123598815738675299';
UPDATE "blade_menu" SET source='iconfont icon-yingjian' WHERE id='1123598815738675298';
UPDATE "blade_menu" SET source='iconfont icon-shoucang' WHERE id='1123598815738675209';
UPDATE "blade_menu" SET source='iconfont icon-shouji' WHERE id='1123598815738675261';
UPDATE "blade_menu" SET source='iconfont icon-peiwangyindao' WHERE id='1164733399668962201';
UPDATE "blade_menu" SET source='iconfont icon-fuwudiqiu' WHERE id='1164733399668962202';
UPDATE "blade_menu" SET source='iconfont icon-liujisuan' WHERE id='1164733399669962601';
UPDATE "blade_menu" SET source='iconfont icon-PIR' WHERE id='1164733399669962501';
UPDATE "blade_menu" SET source='iconfont icon-shebeizhuangtai' WHERE id='1123598815738675201';
UPDATE "blade_menu" SET source='iconfont icon-guize' WHERE id='1123598815738675266';
UPDATE "blade_menu" SET source='iconfont icon-shujukanban' WHERE id='1164733399669962301';
UPDATE "blade_menu" SET source='iconfont icon-yishouquan' WHERE id='1123598815738675307';
UPDATE "blade_menu" SET source='iconfont icon-huowudui' WHERE id='1123598815738675267';
UPDATE "blade_menu" SET source='iconfont icon-shebeikaifa' WHERE id='1123598815738675217';
UPDATE "blade_menu" SET source='iconfont icon-gaojing' WHERE id='1123598815738675210';
UPDATE "blade_menu" SET source='iconfont icon-lianjieliu' WHERE id='1123598815738675280';
UPDATE "blade_menu" SET source='iconfont icon-guanlianshebei' WHERE id='1164733399669962401';
UPDATE "blade_menu" SET source='iconfont icon-hezuohuobanmiyueguanli' WHERE id='1123598815738675308';
UPDATE "blade_menu" SET source='iconfont icon-ceshishenqing' WHERE id='1123598815738675309';
UPDATE "blade_menu" SET source='iconfont icon-renjijiaohu' WHERE id='1123598815738675311';
