-- -----------------------------------
-- 创建一个新的租户数据源表，与原数据源表结构一致
-- -----------------------------------
-- 复制表结构和数据
CREATE TABLE BLADE_TENANT_DATASOURCE AS SELECT * FROM BLADE_DATASOURCE WHERE 1=0;

-- 插入数据
INSERT INTO BLADE_TENANT_DATASOURCE SELECT * FROM BLADE_DATASOURCE;

-- -----------------------------------
-- 修改菜单名称避免重名
-- -----------------------------------
UPDATE BLADE_MENU SET NAME='流程状态' WHERE CODE='flow_manager';

-- -----------------------------------
-- 新增本地存储字典
-- -----------------------------------
INSERT INTO "BLADE_DICT" ("ID", "PARENT_ID", "CODE", "DICT_KEY", "DICT_VALUE", "SORT", "REMARK", "IS_SEALED", "STATUS", "IS_DELETED") VALUES (1123598814738676231, 1123598814738676224, 'oss', '7', '本地存储', 7, '', 0, 1, 0);

-- -----------------------------------
-- 代码生成新增字段
-- -----------------------------------
ALTER TABLE "BLADE_CODE"
    ADD ("MENU_ID" NUMBER(20,0));

COMMENT ON COLUMN "BLADE_CODE"."MENU_ID" IS '上级菜单主键';

-- -----------------------------------
-- 代码生成配置表
-- -----------------------------------
CREATE TABLE "BLADE_CODE_SETTING" (
       "ID" NUMBER(20,0) NOT NULL,
       "SETTINGS" CLOB,
       "STATUS" NUMBER(11,0) DEFAULT 1,
       "IS_DELETED" NUMBER(11,0) DEFAULT 0,
       PRIMARY KEY ("ID")
);

COMMENT ON COLUMN "BLADE_CODE_SETTING"."ID" IS '主键';

COMMENT ON COLUMN "BLADE_CODE_SETTING"."SETTINGS" IS '配置项';

COMMENT ON COLUMN "BLADE_CODE_SETTING"."STATUS" IS '状态';

COMMENT ON COLUMN "BLADE_CODE_SETTING"."IS_DELETED" IS '是否已删除';

COMMENT ON TABLE "BLADE_CODE_SETTING" IS '代码生成器配置表';

-- -----------------------------------
-- 更新菜单图标
-- -----------------------------------
UPDATE BLADE_MENU SET SOURCE='iconfont icon-yonghu' WHERE ID='1123598815738675204';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-quanxianshenpi' WHERE ID='1164733389668962251';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-xiaoxitongzhi' WHERE ID='1164733389658962251';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-xingzhuang-tupian' WHERE ID='1123598815738675299';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-yingjian' WHERE ID='1123598815738675298';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-shoucang' WHERE ID='1123598815738675209';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-shouji' WHERE ID='1123598815738675261';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-peiwangyindao' WHERE ID='1164733399668962201';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-fuwudiqiu' WHERE ID='1164733399668962202';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-liujisuan' WHERE ID='1164733399669962601';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-PIR' WHERE ID='1164733399669962501';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-shebeizhuangtai' WHERE ID='1123598815738675201';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-guize' WHERE ID='1123598815738675266';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-shujukanban' WHERE ID='1164733399669962301';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-yishouquan' WHERE ID='1123598815738675307';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-huowudui' WHERE ID='1123598815738675267';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-shebeikaifa' WHERE ID='1123598815738675217';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-gaojing' WHERE ID='1123598815738675210';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-lianjieliu' WHERE ID='1123598815738675280';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-guanlianshebei' WHERE ID='1164733399669962401';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-hezuohuobanmiyueguanli' WHERE ID='1123598815738675308';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-ceshishenqing' WHERE ID='1123598815738675309';
UPDATE BLADE_MENU SET SOURCE='iconfont icon-renjijiaohu' WHERE ID='1123598815738675311';
