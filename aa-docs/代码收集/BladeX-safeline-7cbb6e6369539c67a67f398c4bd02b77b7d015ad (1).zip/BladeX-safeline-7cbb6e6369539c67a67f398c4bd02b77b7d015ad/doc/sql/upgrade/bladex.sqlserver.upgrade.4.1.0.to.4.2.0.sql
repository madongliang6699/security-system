-- -----------------------------------
-- 创建一个新的租户数据源表，与原数据源表结构一致
-- -----------------------------------
-- 复制表结构和数据
SELECT * INTO [blade_tenant_datasource] FROM [blade_datasource];

-- -----------------------------------
-- 修改菜单名称避免重名
-- -----------------------------------
UPDATE [blade_menu] SET name='流程状态' WHERE code='flow_manager';

-- -----------------------------------
-- 新增本地存储字典
-- -----------------------------------
INSERT INTO [blade_dict] ([id], [parent_id], [code], [dict_key], [dict_value], [sort], [remark], [is_sealed], [status], [is_deleted])
VALUES (1123598814738676231, 1123598814738676224, 'oss', '7', '本地存储', 7, '', 0, 1, 0);

-- -----------------------------------
-- 代码生成新增字段
-- -----------------------------------
ALTER TABLE [blade_code] ADD [menu_id] bigint
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'上级菜单主键',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code',
    'COLUMN', N'menu_id';

-- -----------------------------------
-- 代码生成配置表
-- -----------------------------------
CREATE TABLE [blade_code_setting] (
    [id] bigint NOT NULL,
    [settings] text,
    [status] int DEFAULT 1 NOT NULL,
    [is_deleted] int DEFAULT 0 NOT NULL,
     PRIMARY KEY CLUSTERED ([id] ASC)
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    )
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'主键',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code_setting',
    'COLUMN', N'id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'配置项',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code_setting',
    'COLUMN', N'settings'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code_setting',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code_setting',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'代码生成器配置表',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_code_setting';

-- -----------------------------------
-- 更新菜单图标
-- -----------------------------------
UPDATE [blade_menu] SET source='iconfont icon-yonghu' WHERE id='1123598815738675204';
UPDATE [blade_menu] SET source='iconfont icon-quanxianshenpi' WHERE id='1164733389668962251';
UPDATE [blade_menu] SET source='iconfont icon-xiaoxitongzhi' WHERE id='1164733389658962251';
UPDATE [blade_menu] SET source='iconfont icon-xingzhuang-tupian' WHERE id='1123598815738675299';
UPDATE [blade_menu] SET source='iconfont icon-yingjian' WHERE id='1123598815738675298';
UPDATE [blade_menu] SET source='iconfont icon-shoucang' WHERE id='1123598815738675209';
UPDATE [blade_menu] SET source='iconfont icon-shouji' WHERE id='1123598815738675261';
UPDATE [blade_menu] SET source='iconfont icon-peiwangyindao' WHERE id='1164733399668962201';
UPDATE [blade_menu] SET source='iconfont icon-fuwudiqiu' WHERE id='1164733399668962202';
UPDATE [blade_menu] SET source='iconfont icon-liujisuan' WHERE id='1164733399669962601';
UPDATE [blade_menu] SET source='iconfont icon-PIR' WHERE id='1164733399669962501';
UPDATE [blade_menu] SET source='iconfont icon-shebeizhuangtai' WHERE id='1123598815738675201';
UPDATE [blade_menu] SET source='iconfont icon-guize' WHERE id='1123598815738675266';
UPDATE [blade_menu] SET source='iconfont icon-shujukanban' WHERE id='1164733399669962301';
UPDATE [blade_menu] SET source='iconfont icon-yishouquan' WHERE id='1123598815738675307';
UPDATE [blade_menu] SET source='iconfont icon-huowudui' WHERE id='1123598815738675267';
UPDATE [blade_menu] SET source='iconfont icon-shebeikaifa' WHERE id='1123598815738675217';
UPDATE [blade_menu] SET source='iconfont icon-gaojing' WHERE id='1123598815738675210';
UPDATE [blade_menu] SET source='iconfont icon-lianjieliu' WHERE id='1123598815738675280';
UPDATE [blade_menu] SET source='iconfont icon-guanlianshebei' WHERE id='1164733399669962401';
UPDATE [blade_menu] SET source='iconfont icon-hezuohuobanmiyueguanli' WHERE id='1123598815738675308';
UPDATE [blade_menu] SET source='iconfont icon-ceshishenqing' WHERE id='1123598815738675309';
UPDATE [blade_menu] SET source='iconfont icon-renjijiaohu' WHERE id='1123598815738675311';
