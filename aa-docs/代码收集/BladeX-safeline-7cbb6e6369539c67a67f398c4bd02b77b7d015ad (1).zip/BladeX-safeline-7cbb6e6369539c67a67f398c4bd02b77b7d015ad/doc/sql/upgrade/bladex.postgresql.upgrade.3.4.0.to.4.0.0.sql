-- -----------------------------------
-- 修改应用表的授权集合
-- -----------------------------------
UPDATE blade_client SET authorized_grant_types = 'authorization_code,password,refresh_token,captcha,social,register' WHERE client_id = 'saber';

-- -----------------------------------
-- 删除可能重复的菜单
-- -----------------------------------
DELETE FROM "blade_client" WHERE "client_id" = 'saber3';
DELETE FROM "blade_client" WHERE "client_id" = 'rider';

-- -----------------------------------
-- 新增客户端记录
-- -----------------------------------
INSERT INTO "blade_client" ("id", "client_id", "client_secret", "resource_ids", "scope", "authorized_grant_types", "web_server_redirect_uri", "authorities", "access_token_validity", "refresh_token_validity", "additional_information", "autoapprove", "create_user", "create_dept", "create_time", "update_user", "update_time", "status", "is_deleted") VALUES (1123598811738675203, 'saber3', 'saber3_secret', NULL, 'all', 'authorization_code,password,refresh_token,captcha,social,register', 'http://localhost:2888/login', NULL, 3600, 604800, NULL, NULL, 1123598815738675201, 1123598813738675201, '2024-04-01 00:00:00', 1123598815738675201, '2024-04-01 00:00:00', 1, 0);
INSERT INTO "blade_client" ("id", "client_id", "client_secret", "resource_ids", "scope", "authorized_grant_types", "web_server_redirect_uri", "authorities", "access_token_validity", "refresh_token_validity", "additional_information", "autoapprove", "create_user", "create_dept", "create_time", "update_user", "update_time", "status", "is_deleted") VALUES (1123598811738675204, 'rider', 'rider_secret', NULL, 'all', 'authorization_code,password,refresh_token,captcha,social,register', 'http://localhost:88', NULL, 3600, 604800, NULL, NULL, 1123598815738675201, 1123598813738675201, '2024-04-01 00:00:00', 1123598815738675201, '2024-04-01 00:00:00', 1, 0);
