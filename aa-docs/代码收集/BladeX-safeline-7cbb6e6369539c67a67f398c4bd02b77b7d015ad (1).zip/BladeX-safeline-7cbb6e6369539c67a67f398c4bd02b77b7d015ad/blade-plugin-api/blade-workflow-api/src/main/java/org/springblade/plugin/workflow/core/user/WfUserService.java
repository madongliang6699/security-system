package org.springblade.plugin.workflow.core.user;

import lombok.RequiredArgsConstructor;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.system.pojo.entity.User;
import org.springblade.system.feign.IUserSearchClient;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 系统用户
 * 统一用户入口，防止更改包名的情况再次出现
 *
 * @author ssc
 */
@Service
@RequiredArgsConstructor
public class WfUserService {

    private final IUserSearchClient userSearchService;

    public List<WfUser> listByUser(List<Long> userId) {
        R<List<User>> r = userSearchService.listByUser(Func.join(userId));
        if (r == null) {
            return new ArrayList<>();
        }
        return BeanUtil.copyProperties(r.getData(), WfUser.class);
    }

    public List<WfUser> listByDept(List<Long> deptId) {
        R<List<User>> r = userSearchService.listByDept(Func.join(deptId));
        if (r == null) {
            return new ArrayList<>();
        }
        return BeanUtil.copyProperties(r.getData(), WfUser.class);
    }

    public List<WfUser> listByPost(List<Long> postId) {
        R<List<User>> r = userSearchService.listByPost(Func.join(postId));
        if (r == null) {
            return new ArrayList<>();
        }
        return BeanUtil.copyProperties(r.getData(), WfUser.class);
    }

    public List<WfUser> listByRole(List<Long> roleId) {
        R<List<User>> r = userSearchService.listByRole(Func.join(roleId));
        if (r == null) {
            return new ArrayList<>();
        }
        return BeanUtil.copyProperties(r.getData(), WfUser.class);
    }
}
