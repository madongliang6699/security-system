package org.springblade.plugin.workflow.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
	* 调用者应该实现一个feign接口，其url为下面的参数endpoint。方法的类似：
	* ```
	* @PostMapping("/hazard/task-listener")
	* @Param task 简化的当前任务信息
    * public R<Boolean> taskListener(@RequestBody SimpleTask task) {
 	* 				...
	*     return R.data(true);
	* }
	* ```
**/
@Data
@AllArgsConstructor
public class TaskListenerInfo {
	/**
	 * 流程定义的key
	 */
	private String processDefKey;
	/**
	 * 微服务的名称，如cnooc-qhse-hazard
	 */
	private String applicationName;
	/**
	 * 实现的接口的url
	 */
	private String endpoint;
}
