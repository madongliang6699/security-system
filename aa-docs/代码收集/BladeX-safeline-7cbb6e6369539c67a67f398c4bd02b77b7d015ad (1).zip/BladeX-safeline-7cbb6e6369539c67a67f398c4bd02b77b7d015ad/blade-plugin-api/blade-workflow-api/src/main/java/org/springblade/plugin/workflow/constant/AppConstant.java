package org.springblade.plugin.workflow.constant;

public class AppConstant {
	public static final String APPLICATION_WORKFLOW_NAME = "cnooc-qhse-workflow";
	public static final String TASK_USER_PARSER_KEY = "workflow:task:user:parser";
	public static final String TASK_LISTENER_KEY = "workflow:task:listener";

	public AppConstant() {
	}
}
