package org.springblade.plugin.workflow.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.plugin.workflow.process.model.WfProcess;

/**
 * 任务的操作动作
 */
@Data
@Schema(description = "任务操作")
public class TaskAction extends WfProcess {
	@Schema(description = "执行的操作")
	private String button;

	public static TaskAction from(WfProcess wfProcess) {
		return BeanUtil.copy(wfProcess, TaskAction.class);
	}
}
