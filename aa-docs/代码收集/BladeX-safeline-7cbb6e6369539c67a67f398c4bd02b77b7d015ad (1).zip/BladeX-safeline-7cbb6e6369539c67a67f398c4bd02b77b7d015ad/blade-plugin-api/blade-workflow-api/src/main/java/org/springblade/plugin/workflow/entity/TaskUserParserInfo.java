package org.springblade.plugin.workflow.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
	* 调用者应该实现一个feign接口，其url为下面的参数endpoint。方法的类似：
	* ```
	* @GetMapping("/hazard/parse-task-user")
	* @Param processInstanceId 流程实例id
	* @Param nodeId 节点或任务的id，此为流程图中任务的基本配置中的节点id
	* @Param userOrGroupCategory 用户组或用户的类型，此为流程图中人员配置的类型，比如dept, user, 以及自定义的taskPeople等
	* public R<WfTaskUser> parseTaskUser(@RequestParam String processInstanceId, @RequestParam String nodeId, @RequestParam String userOrGroupCategory);
	*
		 * R<WfTaskUser> parseTaskUser(@RequestParam String processInstanceId, @RequestParam String nodeId, @RequestParam String userOrGroupCode) {
	*     WfTaskUser taskUser = new WfTaskUser();
	*     switch (userOrGroupCode) {
	*         case "taskPeople":
	*         		...getTaskUser(nodeId)...
	*         		taskUser.setAssignee(1111);
	*         		taskUser.setCandidateGroupIds(2222);
	*         		return taskUser;
	*         	...
	*     }
	*     return null;
	* }
	* ```
**/
@Data
@AllArgsConstructor
public class TaskUserParserInfo {
	/**
	 * 流程定义的key
	 */
	private String processDefKey;
	/**
	 * 微服务的名称，如cnooc-qhse-hazard
	 */
	private String applicationName;
	/**
	 * 实现的接口的url
	 */
	private String endpoint;
}
