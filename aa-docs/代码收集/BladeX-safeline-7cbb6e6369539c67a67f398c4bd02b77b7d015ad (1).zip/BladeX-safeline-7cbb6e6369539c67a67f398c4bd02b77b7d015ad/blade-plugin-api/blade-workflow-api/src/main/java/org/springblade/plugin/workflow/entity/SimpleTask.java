package org.springblade.plugin.workflow.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springblade.core.tool.utils.DateUtil;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

/**
 * 简化流程任务传输对象
 */
@Data
@Schema(description = "简化流程任务传输对象")
public class SimpleTask {
	private String id;
	private String processInstanceId;
	private String processDefinitionId;
	private String name;
	private String assignee;
	private List<String> candidateUsers;
	private List<String> candidateGroups;
	private String description;
	private String formKey;
	private String category;
	private String owner;
	private String parentTaskId;
	private String executionId;
	private String taskDefinitionKey;
	private String tenantId;
	@DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
	@JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
	private Date createTime;
	@DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
	@JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
	private Date dueDate;
	@DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
	@JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
	private Date claimTime;
}
