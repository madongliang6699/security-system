package org.springblade.plugin.workflow.wrapper;

import org.flowable.task.api.Task;
import org.flowable.task.service.delegate.DelegateTask;
import org.springblade.plugin.workflow.entity.SimpleTask;

/**
 * 简化Flowable的各种对象，方便数据传输
 */
public class FlowableSimplify {
	public FlowableSimplify() {
	}

	public static SimpleTask simplifyTask(Task task) {
		if (task == null) {
			return null;
		} else {
			SimpleTask simpleTask = new SimpleTask();
			simpleTask.setId(task.getId());
			simpleTask.setProcessInstanceId(task.getProcessInstanceId());
			simpleTask.setProcessDefinitionId(task.getProcessDefinitionId());
			simpleTask.setName(task.getName());
			simpleTask.setAssignee(task.getAssignee());
			simpleTask.setDescription(task.getDescription());
			simpleTask.setFormKey(task.getFormKey());
			simpleTask.setCategory(task.getCategory());
			simpleTask.setOwner(task.getOwner());
			simpleTask.setParentTaskId(task.getParentTaskId());
			simpleTask.setExecutionId(task.getExecutionId());
			simpleTask.setTaskDefinitionKey(task.getTaskDefinitionKey());
			simpleTask.setTenantId(task.getTenantId());
			simpleTask.setCreateTime(task.getCreateTime());
			simpleTask.setDueDate(task.getDueDate());
			simpleTask.setClaimTime(task.getClaimTime());
			return simpleTask;
		}
	}

	public static SimpleTask simpleDelegateTask(DelegateTask task) {
		if (task == null) {
			return null;
		} else {
			SimpleTask simpleTask = new SimpleTask();
			simpleTask.setId(task.getId());
			simpleTask.setProcessInstanceId(task.getProcessInstanceId());
			simpleTask.setProcessDefinitionId(task.getProcessDefinitionId());
			simpleTask.setName(task.getName());
			simpleTask.setAssignee(task.getAssignee());
			simpleTask.setDescription(task.getDescription());
			simpleTask.setFormKey(task.getFormKey());
			simpleTask.setCategory(task.getCategory());
			simpleTask.setOwner(task.getOwner());
			simpleTask.setExecutionId(task.getExecutionId());
			simpleTask.setTaskDefinitionKey(task.getTaskDefinitionKey());
			simpleTask.setTenantId(task.getTenantId());
			simpleTask.setCreateTime(task.getCreateTime());
			simpleTask.setDueDate(task.getDueDate());
			simpleTask.setClaimTime(task.getClaimTime());
			return simpleTask;
		}
	}
}
