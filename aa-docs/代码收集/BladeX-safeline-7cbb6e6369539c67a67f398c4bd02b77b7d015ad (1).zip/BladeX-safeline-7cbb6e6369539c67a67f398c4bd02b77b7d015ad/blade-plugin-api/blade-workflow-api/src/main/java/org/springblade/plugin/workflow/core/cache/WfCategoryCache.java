package org.springblade.plugin.workflow.core.cache;

import org.springblade.core.cache.utils.CacheUtil;
import org.springblade.core.tool.utils.SpringUtil;
import org.springblade.plugin.workflow.design.entity.WfCategory;
import org.springblade.plugin.workflow.design.vo.WfCategoryVO;
import org.springblade.plugin.workflow.feign.IWorkflowClient;

import java.util.List;

/**
 * 流程分类缓存
 *
 * @author ssc
 */
public class WfCategoryCache {

	private static final String WORKFLOW_CATEGORY_CACHE = "category:";
	private static IWorkflowClient workflowClient;

	private static IWorkflowClient getWorkflowClient() {
		if (workflowClient == null) {
			workflowClient = SpringUtil.getBean(IWorkflowClient.class);
		}
		return workflowClient;
	}

	public static WfCategory getById(Long id) {
		return CacheUtil.get(WfCacheConstant.WORKFLOW_CACHE, WORKFLOW_CATEGORY_CACHE, id, () ->
			getWorkflowClient().getCategoryById(id).getData());
	}

	public static void removeById(Long id) {
		if (id != null) {
			CacheUtil.evict(WfCacheConstant.WORKFLOW_CACHE, WORKFLOW_CATEGORY_CACHE, id);
		}
	}

	public static List<WfCategoryVO> tree() {
		return CacheUtil.get(WfCacheConstant.WORKFLOW_CACHE, WORKFLOW_CATEGORY_CACHE, "tree", () ->
			getWorkflowClient().getCategoryTree().getData());
	}

	public static Long getCategoryIdByName(String name) {
		return CacheUtil.get(WfCacheConstant.WORKFLOW_CACHE, WORKFLOW_CATEGORY_CACHE, name, () -> {
			List<WfCategoryVO> tree= tree();
			return findInTree(tree, name);
		});
	}

	private static Long findInTree(List<WfCategoryVO> roots, String name) {
		for (WfCategoryVO node: roots) {
			if (node.getName().equals(name)) {
				return node.getId();
			}
			if (node.getChildren() != null) {
				Long result = findInTree(node.getChildren(), name);
				if (result != null) {
					return result;
				}
			}
		}
		return null;
	}

	public static void removeTreeCache() {
		CacheUtil.evict(WfCacheConstant.WORKFLOW_CACHE, WORKFLOW_CATEGORY_CACHE, "tree");
	}

}
