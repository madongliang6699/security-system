
package org.springblade.plugin.workflow.core.utils;

import cnooc.qhse.base.assign.AssigneeGroupGetter;
import cnooc.qhse.base.assign.AssigneeGetterRegister;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.plugin.workflow.core.user.WfTokenUser;

import java.util.*;

import org.springblade.plugin.workflow.process.model.WfProcess;
import org.springblade.system.cache.SysCache;
import org.springblade.system.cache.UserCache;
import org.springblade.system.pojo.entity.Dept;
import org.springblade.system.pojo.entity.Post;
import org.springblade.system.pojo.entity.Role;
import org.springblade.system.pojo.entity.User;

import static cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUPS_AND_SPLITTER;
import static cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUPS_OR_SPLITTER;
import static java.util.stream.Collectors.toSet;

/**
 * 工作流任务工具类
 *
 * @author Chill
 */
public class WfTaskUtil {

	/**
	 * 获取任务用户格式
	 *
	 * @return taskUser
	 */
	public static String getTaskUser() {
		return AuthUtil.getUserId() + "";
	}


	/**
	 * 获取用户主键
	 *
	 * @param taskUser 任务用户
	 * @return userId
	 */
	public static Long getUserId(String taskUser) {
		return Func.toLong(taskUser);
	}

	/**
	 * 获取用户组格式
	 *
	 * @return candidateGroup
	 */
	public static String getCandidateGroup() {
		// 候选组支持角色、部门、岗位
		BladeUser user = AuthUtil.getUser();
		if (user == null) return "";
		String roleId = user.getRoleId();
		String deptId = user.getDeptId();
		String postId = user.getPostId();
		List<String> list = new ArrayList<>();
		if (StringUtil.isNotBlank(roleId)) list.addAll(Arrays.asList(roleId.split(",")));
		if (StringUtil.isNotBlank(deptId)) list.addAll(Arrays.asList(deptId.split(",")));
		if (StringUtil.isNotBlank(postId)) list.addAll(Arrays.asList(postId.split(",")));
		List<String> extraGroups = AssigneeGroupGetter.INSTANCE.getUserCandidateGroups(user.getUserId());
		list.addAll(extraGroups);
		return StringUtil.join(list, ",");
	}

	/**
	 * 获取用户昵称
	 *
	 * @return nickName
	 */
	public static String getNickName() {
		return AuthUtil.getNickName();
	}

	/**
	 * 获取租户id
	 *
	 * @return tenantId
	 */
	public static String getTenantId() {
		return AuthUtil.getTenantId();
	}

	/**
	 * 获取当前登录用户
	 *
	 * @return 登录用户信息
	 */
	public static WfTokenUser getTokenUser() {
		return BeanUtil.copyProperties(AuthUtil.getUser(), WfTokenUser.class);
	}

	public static void fillProcessUserNames(List<WfProcess> processes, String tenantId) {
		for (WfProcess process : processes) {
			if (StringUtil.isNotBlank(process.getAssignee()) && StringUtil.isBlank(process.getAssigneeName())) {
				long userId = Func.toLong(process.getAssignee());
				if (userId != 0) {
					User user = UserCache.getUser(userId);
					if (user != null) {
						process.setAssigneeName(user.getRealName());
					}
				}
			}
			if (Func.isNotEmpty(process.getCandidateUserIds()) && Func.isEmpty(process.getCandidateUserNames())) {
				Set<Long> userIds = process.getCandidateUserIds().stream().map(Func::toLong).filter(id -> id == 0).collect(toSet());
				process.setCandidateUserNames(
					userIds.stream().map(
						userId -> {
							User user = UserCache.getUser(userId);
							return user == null ? null : user.getRealName();
						}
					).filter(Func::isNotBlank).collect(toSet())
				);
			}
			if (Func.isNotEmpty(process.getCandidateGroupIds()) && Func.isEmpty(process.getCandidateGroupNames())) {
				List<String> groupIds = process.getCandidateGroupIds();
				Set<String> candidateGroupNames = groupIds.stream().map((String groupId) -> {
					// 如果不是分组，则是直接在流程上选择的各种角色、部门、岗位
					if (!AssigneeGetterRegister.INSTANCE.isValidAssigneeGroups(groupId)) {
						long bareLongId = Func.toLong(groupId);
						if (bareLongId != 0) {
							return findAssignNameById(bareLongId);
						}
					} else {
						return Func.join(AssigneeGetterRegister.INSTANCE.getUserNamesByCondition(groupId, tenantId));
					}
					return null;
				}).filter(Func::isNotBlank).collect(toSet());
				process.setCandidateGroupNames(candidateGroupNames);
			}
		}
	}

	// 给一个id，有可能是岗位、用户、部门、角色，返回对应的名称
	private static String findAssignNameById(Long id) {
		Post post = SysCache.getPost(id);
		if (post != null) {
			return "岗位：${post.postName}";
		}
		Dept dept = SysCache.getDept(id);
		if (dept != null) {
			return "部门：${dept.deptName}";
		}
		User user = UserCache.getUser(id);
		if (user != null) {
			return "用户：${user.realName}";
		}
		Role role = SysCache.getRole(id);
		if (role != null) {
			return "角色：${role.roleName}";
		}
		return null;
	}

	/**
	 * 获取流程定义key. 例如：process:1:123456，返回process
	 * @param processDefinitionId 流程定义id
	 * @return 流程定义key
	 */
	public static String getProcessDefKeyByDefId(String processDefinitionId) {
		return processDefinitionId.split(":")[0];
	}


	/**
	 * 为防止流程图中的任务id重名，可以在规定的任务id后添加"__数字"来区分。但可以通过此函数来获取与标准匹配的任务id
	 *
	 * @param taskDefinitionKey 流程图中定义的任务定义名称，有时候会带__数字
	 * @return 标准任务定义名称
	 */
	public static String getTaskKey(String taskDefinitionKey) {
		return Func.isBlank(taskDefinitionKey) ? "" : taskDefinitionKey.split("__")[0];
	}


	/**
	 * 解析TaskPeople中的分组
	 * 解析的时候，用户变量以变量类型|变量为基础元素，不同分组之间用,分隔，在分组内也会有;分隔的元素，表示在此组内用户二选一。
	 * 这个主要是为了在工作流时使同一个任务多个人只有一个人完成。举例说明：
	 * • USER_ID|1022342: 表示只有一个分组
	 * • USER_ID|1022342,USER_ID|1022343: 表示有两个分组
	 * • USER_ID|1022342,USER_ID|1022343;USER_ID|1022344: 表示有两个分组，第二个分组下的用户二选一
	 * 此方法将各个,分开为一组，再将;替换为,
	 */
	public static List<String> getTaskPeopleGroups(String taskPeople) {
		return Arrays.stream(taskPeople.split(ASSIGN_GROUPS_AND_SPLITTER))
			.map(p -> p.trim().replace(ASSIGN_GROUPS_OR_SPLITTER, ASSIGN_GROUPS_AND_SPLITTER))
			.toList();
	}


	/**
	 * 判断当前用户是否在指定的用户组中
	 *
	 * @param groups: 多个用户组，用,分隔，也可以用;分隔
	 */
	public static Boolean isUserInGroup(String groups) {
		Set<String> groupSet = Arrays.stream(groups.split("[" + ASSIGN_GROUPS_AND_SPLITTER + ASSIGN_GROUPS_OR_SPLITTER + "]"))
			.map(String::trim).collect(toSet());
		Set<String> userGroups = Arrays.stream(WfTaskUtil.getCandidateGroup().split(ASSIGN_GROUPS_AND_SPLITTER))
			.map(String::trim).collect(toSet());
		groupSet.retainAll(userGroups);
		return !groupSet.isEmpty();
	}
}
