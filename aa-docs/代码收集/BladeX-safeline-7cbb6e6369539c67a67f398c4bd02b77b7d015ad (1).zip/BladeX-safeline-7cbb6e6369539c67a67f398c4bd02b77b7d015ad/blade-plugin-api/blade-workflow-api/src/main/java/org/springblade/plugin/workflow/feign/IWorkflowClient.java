package org.springblade.plugin.workflow.feign;

import org.springblade.core.mp.support.BladePage;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.workflow.app.entity.WfAppProcess;
import org.springblade.plugin.workflow.constant.AppConstant;
import org.springblade.plugin.workflow.design.entity.WfButton;
import org.springblade.plugin.workflow.design.entity.WfCategory;
import org.springblade.plugin.workflow.design.vo.WfCategoryVO;
import org.springblade.plugin.workflow.entity.SimpleTask;
import org.springblade.plugin.workflow.entity.TaskAction;
import org.springblade.plugin.workflow.entity.TaskListenerInfo;
import org.springblade.plugin.workflow.entity.TaskUserParserInfo;
import org.springblade.plugin.workflow.process.model.WfProcess;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(
	value = AppConstant.APPLICATION_WORKFLOW_NAME
)
public interface IWorkflowClient {

	String API_PREFIX = "/feign/client/flow";
	String TODO_LIST = API_PREFIX + "/todos";
	String DONE_LIST = API_PREFIX + "/done-list";
	String GET_PROCESS_DEFINITION_BY_KEY = API_PREFIX + "/process-definition/{flowKey}";
	String START_PROCESS_BY_KEY = API_PREFIX + "/start-process-by-key";
	String TRANSFER_TASK = API_PREFIX + "/transfer-task";
	String DELEGATE_TASK = API_PREFIX + "/delegate-task";
	String TERMINATE_PROCESS = API_PREFIX + "/terminate-process";
	String ADD_MULTI_INSTANCE = API_PREFIX + "/add-multi-instance";
	String COMPLETE_TASK = API_PREFIX + "/complete-task";
	String SET_TASK_VARIABLE = API_PREFIX + "/set-task-variable/{taskId}";
	String SET_RUNTIME_VARIABLE = API_PREFIX + "/set-runtime-variable/{processInstanceId}";
	String BUTTONS_BY_TASK_ID = API_PREFIX + "/buttons-by-task-id";
	String CURRENT_USER_CANDIDATE_GROUPS = API_PREFIX + "/current-user-candidate-groups";
	String FLOW_DETAIL = API_PREFIX + "/flow-detail";
	String COMPLETE_TASK_WITH_ACTION = API_PREFIX + "/complete-task-with-action";
	String IS_TASK_EXIST = API_PREFIX + "/is-task-exist/{taskId}";
	String RUNTIME_VARIABLE_VALUE = API_PREFIX + "/runtime-variable-value/{processInstanceId}/{variable}";
	String DEPLOY_MODEL = API_PREFIX + "/deploy-model";
	String GET_TASK = API_PREFIX + "/task/{taskId}";
	String GET_TASKS = API_PREFIX + "/tasks/{processInstanceId}";
	String GET_CATEGORY_BY_ID = API_PREFIX + "/category/{id}";
	String GET_CATEGORY_TREE = API_PREFIX + "/category-tree";
	String COMMON_TASK_OPERATION = API_PREFIX + "/common-task-operation";
	String DELETE_PROCESS_INSTANCE = API_PREFIX + "/delete-process-instance";
	String SET_CURRENT_TASK_ASSIGNEE = API_PREFIX + "/set-current-task-assignee";
	String GET_BUSINESS_KEY = API_PREFIX + "/get-business-key";
	String REGISTER_TASK_USER_PARSER = API_PREFIX + "/register-task-user-parser";
	String STATUS_OF_TASK_USER_PARSER = API_PREFIX + "/status-of-task-user-parser";
	String REGISTER_TASK_LISTENER = API_PREFIX + "/register-task-listener";
	String STATUS_OF_TASK_LISTENER = API_PREFIX + "/status-of-task-listener";

	/**
	 * 获取当前用户待办列表
	 *
	 * @param wfAppProcess 流程定义
	 * @param current      当前页
	 * @param size         每页显示条数
	 * @return 待办列表
	 */
	@GetMapping(TODO_LIST)
	R<BladePage<WfAppProcess>> todoList(@SpringQueryMap WfAppProcess wfAppProcess,
										@RequestParam Integer current, @RequestParam Integer size);

	/**
	 * 获取当前用户办结列表
	 *
	 * @param wfAppProcess 流程定义
	 * @param current      当前页
	 * @param size         每页显示条数
	 * @return 办结列表
	 */
	@GetMapping(DONE_LIST)
	R<BladePage<WfAppProcess>> doneList(@SpringQueryMap WfAppProcess wfAppProcess,
										@RequestParam Integer current, @RequestParam Integer size);

	/**
	 * 通过流程定义key启动流程
	 *
	 * @param processDefKey   流程定义key
	 * @param businessKey 业务主键
	 * @param variables 变量
	 * @return 流程定义id
	 */
	@PostMapping(START_PROCESS_BY_KEY)
	R<String> startProcessInstanceByKey(@RequestParam(value = "processDefKey") String processDefKey,
										@RequestParam("businessKey") String businessKey,
										@RequestBody Map<String, Object> variables);

	/**
	 * 通过流程定义key获取流程定义id
	 *
	 * @param flowKey  流程定义key
	 * @param tenantId 租户id
	 * @return 流程定义id
	 */
	@GetMapping(GET_PROCESS_DEFINITION_BY_KEY)
	R<String> getProcessDefinitionByKey(@PathVariable String flowKey, @RequestParam String tenantId);

	/**
	 * 转办任务
	 *
	 * @param wfProcess
	 * @return
	 */
	@PostMapping(TRANSFER_TASK)
	R transferTask(@RequestBody WfProcess wfProcess);

	/**
	 * 委托任务
	 *
	 * @param wfProcess
	 * @return
	 */
	@PostMapping(DELEGATE_TASK)
	R delegateTask(@RequestBody WfProcess wfProcess);

	/**
	 * 终止流程
	 *
	 * @param wfProcess
	 * @return
	 */
	@PostMapping(TERMINATE_PROCESS)
	R terminateProcess(@RequestBody WfProcess wfProcess);

	/**
	 * 加签
	 *
	 * @param wfProcess
	 * @return
	 */
	@PostMapping(ADD_MULTI_INSTANCE)
	R addMultiInstance(@RequestBody WfProcess wfProcess);

	/**
	 * 完成任务
	 *
	 * @param wfProcess
	 * @return
	 */
	@PostMapping(COMPLETE_TASK)
	R completeTask(@RequestBody WfProcess wfProcess);

	/**
	 * 设置任务变量
	 *
	 * @param taskId    任务id
	 * @param variables 变量
	 * @return
	 */
	@PostMapping(SET_TASK_VARIABLE)
	R<Boolean> setTaskVariable(@PathVariable(value = "taskId") String taskId, @RequestBody Map<String, Object> variables);

	/**
	 * 设置任务变量
	 *
	 * @param processInstanceId 流程id
	 * @param variables         变量
	 * @return
	 */
	@PostMapping(SET_RUNTIME_VARIABLE)
	R<Boolean> setRuntimeVariables(@PathVariable(value = "processInstanceId") String processInstanceId,
								   @RequestBody Map<String, Object> variables);

	/**
	 * 根据任务获取按钮列表
	 *
	 * @param taskId 任务id
	 * @return 按钮列表
	 */
	@GetMapping(BUTTONS_BY_TASK_ID)
	R<List<WfButton>> buttonsByTaskId(@RequestParam String taskId);

	/**
	 * 根据当前用户的用户组
	 *
	 * @return 用, 连接的用户组
	 */
	@GetMapping(CURRENT_USER_CANDIDATE_GROUPS)
	R<String> getCurrentUserCandidateGroups();

	/**
	 * 获取流程详情，需要匹配执行人或候选组
	 *
	 * @param taskId         任务id
	 * @param assignee       任务执行人
	 * @param candidateGroup 候选组
	 */
	@GetMapping(FLOW_DETAIL)
	R<WfProcess> getProcessDetail(@RequestParam String taskId, @RequestParam String assignee,
								  @RequestParam String candidateGroup);

	/**
	 * 检查任务是否存在
	 */
	@GetMapping(IS_TASK_EXIST)
	R<Boolean> isTaskExist(@PathVariable String taskId);

	/**
	 * 获取流程变量的值
	 */
	@GetMapping(RUNTIME_VARIABLE_VALUE)
	R<Object> getRuntimeVariableValue(@PathVariable String processInstanceId, @PathVariable String variable);

	/**
	 * 部署流程
	 *
	 * @param modelId  模型id
	 * @param category 流程分类
	 */
	@PostMapping(DEPLOY_MODEL)
	R<Boolean> deployModel(@RequestParam String modelId, @RequestParam String category);

	/**
	 * 通过任务id获取任务
	 *
	 * @param taskId 任务id
	 */
	@PostMapping(GET_TASK)
	R<SimpleTask> getTask(@PathVariable String taskId);

	/**
	 * 获取流程id获取所有任务
	 *
	 * @param processInstanceId 任务id
	 */
	@PostMapping(GET_TASKS)
	R<List<SimpleTask>> getTasksByProcessInstanceId(@PathVariable String processInstanceId);

	/**
	 * 根据id获取流程分类
	 */
	@GetMapping(GET_CATEGORY_BY_ID)
	R<WfCategory> getCategoryById(@RequestParam Long id);

	/**
	 * 获取流程分类树
	 */
	@GetMapping(GET_CATEGORY_TREE)
	R<List<WfCategoryVO>> getCategoryTree();

	/**
	 * 流程通用操作，通用操作参见：CommonTaskButton。传递任意button操作，如果这些操作是在通用操作中，则流程将被处理，并返回是否被处理了。
	 * 这个操作主要用于先过滤通用操作，如果已经被处理了，业务自己的操作一般不需要再处理
	 * @param action 通用操作，其中包括了button，要执行的操作
	 */
	@PostMapping(COMMON_TASK_OPERATION)
	R<Boolean> commonTaskOperation(@RequestBody TaskAction action);

	/**
	 * 根据操作完成任务。
	 * 这个与Blade-Workflow的机制是不一样的，参数中有一个action，表示在此节点执行的操作，需要将此操作设为任务的参数以便于决定下一步怎么走
	 */
	@PostMapping(COMPLETE_TASK_WITH_ACTION)
	R<Boolean> completeTaskWithAction(@RequestParam String action, @RequestBody WfProcess process);

	/**
	 * 删除流程
	 */
	@DeleteMapping(DELETE_PROCESS_INSTANCE)
	R<Boolean> deleteProcess(@RequestParam String processInstanceId);

	/**
	 * 强制设置流程当前任务的执行人
	 */
	@PostMapping(SET_CURRENT_TASK_ASSIGNEE)
	R<Boolean> setCurrentTaskAssignee(@RequestParam String processInstanceId, @RequestParam Long userId);

	/**
	 * 根据流程id获取业务主键
	 */
	@GetMapping(GET_BUSINESS_KEY)
	R<String> getBusinessKey(@RequestParam String processInstanceId);


	/**
	 * 注册一个任务用户解析的方法。此方法需要在系统启动时调用，工作流引擎在寻找任务用户或用户组时会寻找此方法
	 * 注册此方法前，调用者应该实现一个feign接口，其url为下面的参数feignUrl。方法的类似：
	 * ```
	 * @PostMapping("/hazard/parse-task-user")
	 * @Param processInstanceId 流程实例id
	 * @Param nodeId 节点或任务的id，此为流程图中任务的基本配置中的节点id
	 * @Param userOrGroupCategory 用户组或用户的类型，此为流程图中人员配置的类型，比如dept, user, 以及自定义的taskPeople等
	 * public R<WfTaskUser> parseTaskUser(@RequestParam String processInstanceId, @RequestParam String nodeId, @RequestParam String userOrGroupCategory);
	 *
	 * R<WfTaskUser> parseTaskUser(@RequestParam String processInstanceId, @RequestParam String nodeId, @RequestParam String userOrGroupCode) {
	 *     WfTaskUser taskUser = new WfTaskUser();
	 *     switch (userOrGroupCode) {
	 *         case "taskPeople":
	 *         		...getTaskUser(nodeId)...
	 *         		taskUser.setAssignee(1111);
	 *         		taskUser.setCandidateGroupIds(2222);
	 *         		return taskUser;
	 *         	...
	 *     }
	 *     return null;
	 * }
	 * ```
	 * @param parserInfo 解析方法信息，参见TaskUserParserInfo
	 */
	@PostMapping(REGISTER_TASK_USER_PARSER)
	R<Boolean> registerTaskUserParser(@RequestBody TaskUserParserInfo parserInfo);

	@PostMapping(REGISTER_TASK_LISTENER)
	R<Boolean> registerTaskListener(@RequestBody TaskListenerInfo taskListenerInfo);

	@GetMapping(STATUS_OF_TASK_USER_PARSER)
	R<Boolean> statusOfTaskUserParser(@RequestParam String processDefKey);

	@GetMapping(STATUS_OF_TASK_LISTENER)
	R<Boolean> statusOfTaskListener(@RequestParam String processDefKey);
}
