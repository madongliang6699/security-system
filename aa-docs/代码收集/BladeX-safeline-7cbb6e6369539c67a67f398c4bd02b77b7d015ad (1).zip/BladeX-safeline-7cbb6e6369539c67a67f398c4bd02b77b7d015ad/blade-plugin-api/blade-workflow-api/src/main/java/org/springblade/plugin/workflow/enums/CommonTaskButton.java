package org.springblade.plugin.workflow.enums;

public enum CommonTaskButton {
	COMMON_CLAIM("ActionCommonClaim", "任务签收"),
	COMMON_CONFIRM("ActionCommonConfirm", "确认"),
	COMMON_EDIT("ActionCommonEdit", "编辑"),
	COMMON_CANCEL("ActionCommonCancel", "驳回"),
	WF_TRANSFER("wf_transfer", "转办"),
	WF_DELEGATE("wf_delegate", "委托"),
	WF_TERMINATE("wf_terminate", "终止"),
	WF_ADD_INSTANCE("wf_add_instance", "加签"),
	WF_DEL_INSTANCE("wf_del_instance", "减签"),
	WF_PRINT("wf_print", "打印");

	public final String value;
	public final String title;

    CommonTaskButton(String value, String title) {
		this.value = value;
		this.title = title;
	}

	public static CommonTaskButton getByValue(String value) {
		for (CommonTaskButton commonTaskButton : CommonTaskButton.values()) {
			if (commonTaskButton.value.equals(value)) {
				return commonTaskButton;
			}
		}
		return null;
	}
}
