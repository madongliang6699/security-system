package org.springblade.plugin.message.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * mq消息可靠记录
 *
 * @author weikun
 * @since 2021-06-08
 */
@Data
@TableName("blade_mq_message")
@Schema(description = "mq消息可靠记录表")
@Builder
public class MqMessage{

	private static final long serialVersionUID = 1L;


	@Schema(description ="主键id")
	@TableId(value = "id", type = IdType.ASSIGN_ID)
	private Long id;

	/**
	 * 消息承载的业务数据
	 */
	@TableField("msg_data")
	private String msgData;

	/**
	 * 交换机名称
	 */
	@TableField("exchange_name")
	private String exchangeName;

	/**
	 * 路由键
	 */
	@TableField("routing_key")
	private String routingKey;

	/**
	 * 消息状态
	 *
	 * @see org.springblade.plugin.message.enums.MessageStatusEnum
	 */
	@TableField("status")
	private int status;

	/**
	 * 重试次数
	 */
	@TableField("retry_times")
	private int retryTimes;

	/**
	 * 下一次重试时间
	 */
	@TableField("next_retry_date_time")
	private LocalDateTime nextRetryDateTime;

}
