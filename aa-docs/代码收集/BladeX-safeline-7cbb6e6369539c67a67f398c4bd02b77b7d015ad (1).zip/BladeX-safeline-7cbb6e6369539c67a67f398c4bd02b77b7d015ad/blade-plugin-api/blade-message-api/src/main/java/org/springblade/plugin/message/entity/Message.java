package org.springblade.plugin.message.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springblade.core.mp.base.BaseEntity;

import java.time.LocalDateTime;

/**
 * 消息详情表实体类
 *
 * @author weikun
 * @since 2021-05-08
 */
@Data
@TableName("blade_message")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "消息详情表")
public class Message extends BaseEntity {

	private static final long serialVersionUID = 1L;



	/**
	 * 消息发送记录id
	 */
	@Schema(description = "消息发送记录id")
	private Long messageLogId;

	/**
	 * 类型
	 */
	@Schema(description ="类型")
	private Integer type;

	/**
	 * 标题
	 */
	@Schema(description = "标题")
	private String title;

	/**
	 * 内容
	 */
	@Schema(description = "内容")
	private String content;

	/**
	 * 接收人
	 */
	@Schema(description = "接收人id")
	private Long receiveUser;


	/**
	 * 是否已读
	 */
	@Schema(description = "是否已读")
	private Integer isRead;

	/**
	 * 已读时间
	 */
	@Schema(description = "已读时间")
	private LocalDateTime readTime;

	/**
	 * 接收群
	 */
	@TableField(exist = false)
	@Schema(description = "接收群")
	private Long receiveGroup;

	/**
	 * 创建人姓名
	 */
	@TableField(exist = false)
	@Schema(description = "创建人姓名")
	private String createUserName;

	public Message(){}

	public Message(MessageLog messageLog) {
		this.type=messageLog.getType();
		this.title= messageLog.getTitle();
		this.messageLogId=messageLog.getId();
		this.content= messageLog.getContent();
		this.receiveUser=messageLog.getReceiveUser();
		super.setCreateTime(messageLog.getCreateTime());
		super.setCreateUser(messageLog.getCreateUser());
	}
}
