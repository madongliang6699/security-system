package org.springblade.plugin.message.params;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * 消息详情表实体类
 *
 * @author weikun
 * @since 2021-05-08
 */
@Data
@Schema(description = "Message接收参数")
public class ServeMessageParams {

	private static final long serialVersionUID = 1L;

	/**
	 * 内容
	 */
	@Schema(description = "内容")
	private String content;


	/**
	 * 路由键
	 */
	@Schema(description = "路由键")
	private String routingKey;



}
