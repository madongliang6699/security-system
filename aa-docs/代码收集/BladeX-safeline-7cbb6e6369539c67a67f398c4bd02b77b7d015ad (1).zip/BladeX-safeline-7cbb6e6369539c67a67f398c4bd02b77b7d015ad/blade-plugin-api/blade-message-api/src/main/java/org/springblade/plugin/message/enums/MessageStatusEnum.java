package org.springblade.plugin.message.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 消息状态枚举
 * @author weikun
 */

@Getter
@AllArgsConstructor
public enum MessageStatusEnum {

	/**
	 * 1=发送中
	 */
	SENDING(1, "发送中"),

	/**
	 * 2=发送成功
	 */
	SUCCESS(2, "发送成功"),

	/**
	 * 3=发送失败
	 */
	FAIL(3, "发送失败");

	private final int status;
	private final String description;
}
