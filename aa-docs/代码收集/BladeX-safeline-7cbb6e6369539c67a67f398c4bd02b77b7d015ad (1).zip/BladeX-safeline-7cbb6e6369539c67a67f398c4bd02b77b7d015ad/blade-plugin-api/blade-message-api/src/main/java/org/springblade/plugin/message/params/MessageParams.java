package org.springblade.plugin.message.params;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * 消息详情表实体类
 *
 * @author weikun
 * @since 2021-05-08
 */
@Data
@Schema(description = "Message接收参数")
public class MessageParams {

	private static final long serialVersionUID = 1L;

	/**
	 * 标题
	 */
	@Schema(description = "标题")
	private String title;

	/**
	 * 内容
	 */
	@Schema(description = "内容")
	private String content;

	/**
	 * 类型
	 */
	@Schema(description ="类型")
	private Integer type;

	/**
	 * 接收人id
	 */
	@Schema(description = "接收人id")
	private Long receiveUser;

	/**
	 * 接收群id列表
	 */
	@Schema(description = "接收群id列表")
	private List<Long> receiveGroupList;

	public MessageParams(){}


	public static Builder builder() {
		return new Builder();
	}

	private MessageParams(Builder builder) {
		this.title = builder.title;
		this.content = builder.content;
		this.type = builder.type;
		this.receiveUser = builder.receiveUser;
		this.receiveGroupList = builder.receiveGroupList;
	}

	public static class Builder {
		private String title;
		private String content;
		private Integer type;
		private Long receiveUser;
		private List<Long> receiveGroupList;

		public Builder title(String title) {
			if (StringUtils.isBlank(title)) {
				throw new IllegalArgumentException("title不能为空");
			}
			this.title = title;
			return this;
		}
		public Builder content(String content) {
			if (StringUtils.isBlank(content)) {
				throw new IllegalArgumentException("content不能为空");
			}
			this.content = content;
			return this;
		}
		public Builder type(Integer type) {
			if (type==null) {
				throw new IllegalArgumentException("type不能为空");
			}
			this.type = type;
			return this;
		}
		public Builder receiveUser(Long receiveUser) {
			this.receiveUser = receiveUser;
			return this;
		}

		public Builder receiveGroupList(List<Long> receiveGroupList) {
			this.receiveGroupList = receiveGroupList;
			return this;
		}

		public MessageParams build() {
			if (receiveUser==null) {
				if(receiveGroupList==null||receiveGroupList.size()==0){
					throw new IllegalArgumentException("接收人和接收部门不能同时为空");
				}
			}
			return new MessageParams(this);
		}
	}

}
