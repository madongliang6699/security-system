package org.springblade.plugin.message.feign;


import org.springblade.core.tool.api.R;
import org.springblade.plugin.message.params.MessageParams;
import org.springblade.plugin.message.params.ServeMessageParams;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Message Feign接口类
 *
 * @author weikun
 */
@FeignClient(
	value = "blade-message"
)
public interface IMessageClient {

	String API_PREFIX = "/feign/client";
	String SEND_MSG = API_PREFIX + "/send-msg";
	String SEND_SERVE_MSG = API_PREFIX + "/send-serve-msg";
	String RESEND_MSG = API_PREFIX + "/resend-serve-msg";

	/**
	 * 发送消息
	 *
	 * @param msgParams 消息实体
	 * @return
	 */
	@PostMapping(SEND_MSG)
	R<Boolean> sendMsg(@RequestBody MessageParams msgParams);


	/**
	 * 发送服务端可靠消息
	 * @return
	 */
	@PostMapping(SEND_SERVE_MSG)
	R<Boolean> sendServeMsg(@RequestBody ServeMessageParams msgParams);


	/**
	 * 重新投递消息
	 * @return
	 */
	@GetMapping(RESEND_MSG)
	R<Boolean> reSend();





}
