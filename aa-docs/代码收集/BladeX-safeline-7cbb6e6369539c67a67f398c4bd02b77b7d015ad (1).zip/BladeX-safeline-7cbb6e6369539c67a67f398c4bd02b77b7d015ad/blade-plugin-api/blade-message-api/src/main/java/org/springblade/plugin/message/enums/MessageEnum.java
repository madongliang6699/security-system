package org.springblade.plugin.message.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 消息相关枚举
 *
 * @author weikun
 */
@Getter
@AllArgsConstructor
public enum MessageEnum {

	/**
	 * 单发
	 */
	SINGLE(1),

	/**
	 * 按组群发
	 */
	GROUP(2),

	/**
	 * 审批流
	 */
	APPROVAL(3),
	/**
	 * 按角色群发
	 */
	ROLE(4),

	/**
	 * 已读
	 */
	READ(0),

	/**
	 * 未读
	 */
	UNREAD(1),

	;

	final int code;

}
