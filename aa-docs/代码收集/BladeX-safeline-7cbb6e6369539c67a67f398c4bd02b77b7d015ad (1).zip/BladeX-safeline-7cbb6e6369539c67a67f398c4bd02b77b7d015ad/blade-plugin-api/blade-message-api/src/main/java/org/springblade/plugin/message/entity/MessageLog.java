package org.springblade.plugin.message.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springblade.core.mp.base.BaseEntity;
import org.springblade.plugin.message.enums.MessageEnum;
import org.springblade.plugin.message.params.MessageParams;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;


/**
 * 消息详情表实体类
 *
 * @author weikun
 * @since 2021-05-08
 */
@Data
@TableName("blade_message_log")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "消息记录表")
public class MessageLog extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Schema(description ="主键id")
	@TableId(value = "id", type = IdType.ASSIGN_ID)
	private Long id;

	/**
	 * 标题
	 */
	@Schema(description = "标题")
	private String title;

	/**
	 * 内容
	 */
	@Schema(description = "内容")
	private String content;

	/**
	 * 类型
	 */
	@Schema(description ="类型")
	private Integer type;

	/**
	 * 接收人id
	 */
	@Schema(description = "接收人id")
	private Long receiveUser;

	/**
	 * 接收群id
	 */
	@Schema(description = "接收群id 逗号分隔数组")
	private String receiveGroup;


	/**
	 * 接收人名称
	 */
	@TableField(exist = false)
	@Schema(description = "接收人名称")
	private String receiveUserName;

	/**
	 * 接收部门名称
	 */
	@TableField(exist = false)
	@Schema(description = "接收部门/角色 名称")
	private List<String> receiveGroupName;


	/**
	 * 接收部门id集合
	 */
	@TableField(exist = false)
	@Schema(description = "接收部门/角色 id集合")
	private List<Long> receiveGroupList;

	public MessageLog(){}


	public MessageLog(MessageParams messageParams) {
		this.title = messageParams.getTitle();
		//群消息记录数据库寸逗号分隔字符串
		if (messageParams.getType().equals(MessageEnum.GROUP.getCode())||messageParams.getType().equals(MessageEnum.ROLE.getCode())) {
			this.receiveGroup = StringUtils.arrayToDelimitedString(messageParams.getReceiveGroupList().toArray(), ",");
			this.receiveGroupList = messageParams.getReceiveGroupList();
		}
		this.content = messageParams.getContent();
		this.type = messageParams.getType();
		this.receiveUser = messageParams.getReceiveUser();
		super.setCreateTime(new Date());
	}
}
