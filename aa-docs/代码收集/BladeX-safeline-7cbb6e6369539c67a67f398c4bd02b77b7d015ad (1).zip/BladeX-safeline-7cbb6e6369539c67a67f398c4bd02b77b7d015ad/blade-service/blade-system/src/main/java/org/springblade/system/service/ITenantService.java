/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.system.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseService;
import org.springblade.system.pojo.entity.Tenant;
import org.springblade.system.pojo.vo.CascaderData;
import org.springblade.system.pojo.vo.TenantVO;

import java.util.Date;
import java.util.List;

/**
 * 服务类
 *
 * @author Chill
 */
public interface ITenantService extends BaseService<Tenant> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param tenant
	 * @return
	 */
	IPage<Tenant> selectTenantPage(IPage<Tenant> page, Tenant tenant);

	/**
	 * 根据租户编号获取实体
	 *
	 * @param tenantId
	 * @return
	 */
	Tenant getByTenantId(String tenantId);

	/**
	 * 新增
	 *
	 * @param tenant
	 * @return
	 */
	boolean submitTenant(Tenant tenant);

	/**
	 * 删除
	 *
	 * @param ids
	 * @return
	 */
	boolean removeTenant(List<Long> ids);

	/**
	 * 配置租户授权
	 *
	 * @param accountNumber
	 * @param expireTime
	 * @param ids
	 * @return
	 */
	boolean setting(Integer accountNumber, Date expireTime, String ids);

	/**
	 * 获取所有租户列表，忽略租户限制
	 */
	List<Tenant> getAllTenants();

	/**
	 * 获取所有租户的树列表，忽略租户限制
	 * @return 租户树
	 */
	List<TenantVO> getAllTenantsTree();

	/**
	 * 获取指定租户下的所有子租户，不是树，只包含一级
	 * @param tenantId 指定租户
	 * @return 子租户列表
	 */
	List<TenantVO> getTenantChildren(String tenantId);

	/**
	 * 获取指定租户下的所有子租户
	 * @param tenantId 指定租户
	 * @return 子租户列表
	 */
	List<TenantVO> getTenantFlattenDescendents(String tenantId);

	/**
	 * 获取指定租户下的所有子租户树
	 * @param tenantId 指定租户
	 * @return 子租户树
	 */
	List<TenantVO> getTenantDescendentTree(String tenantId);

	/**
	 * 获取指定租户下的所有子租户
	 * @param tenantId 指定租户
	 * @return 子租户列表
	 */
	List<CascaderData> getTenantFlattenDescendentsCascaderData(String tenantId);

	/**
	 * 获取指定租户下的所有子租户，不是树，只包含一级
	 * @param tenantId 指定租户
	 * @return 子租户列表
	 */
	List<CascaderData> getTenantChildrenCascaderData(String tenantId);

	/**
	 * 获取指定租户下的所有子租户树
	 * @param tenantId 指定租户
	 * @return 子租户树
	 */
	List<CascaderData> getTenantDescendentTreeCascaderData(String tenantId);

}
