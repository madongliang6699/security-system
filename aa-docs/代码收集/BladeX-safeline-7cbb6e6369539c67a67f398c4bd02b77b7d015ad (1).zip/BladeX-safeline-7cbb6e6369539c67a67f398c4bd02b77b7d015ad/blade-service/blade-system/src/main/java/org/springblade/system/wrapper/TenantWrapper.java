package org.springblade.system.wrapper;

import org.springblade.core.mp.support.BaseEntityWrapper;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.core.tool.node.ForestNodeMerger;
import org.springblade.core.tool.utils.BeanUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.system.cache.SysCache;
import org.springblade.system.pojo.entity.Tenant;
import org.springblade.system.pojo.vo.TenantVO;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 包装类,返回视图层所需的字段
 *
 * @author Chill
 */
public class TenantWrapper extends BaseEntityWrapper<Tenant, TenantVO> {

	public static TenantWrapper build() {
		return new TenantWrapper();
	}

	@Override
	public TenantVO entityVO(Tenant tenant) {
		TenantVO tenantVO = Objects.requireNonNull(BeanUtil.copyProperties(tenant, TenantVO.class));
		if (Func.isBlank(tenant.getParentTenantId())) {
			tenantVO.setParentName(BladeConstant.TOP_PARENT_NAME);
		} else {
			Tenant parent = SysCache.getTenant(tenant.getParentTenantId());
			if (!Func.isNotBlank(parent.getTenantAlias())) {
				tenantVO.setParentName(parent.getTenantAlias());
			} else {
				tenantVO.setParentName(parent.getTenantName());
			}
		}
		return tenantVO;
	}


	public List<TenantVO> listNodeVO(List<Tenant> list) {
		List<TenantVO> collect = list.stream().map(this::entityVO).collect(Collectors.toList());
		// 填充parentId，不然没法合并
		Map<String, TenantVO> tenantId2Tenant = collect.stream().collect(Collectors.toMap(TenantVO::getTenantId, tenantVO -> tenantVO));
		for (TenantVO tenantVO : collect) {
			if (Func.isNotBlank(tenantVO.getParentTenantId())) {
				TenantVO parent = tenantId2Tenant.get(tenantVO.getParentTenantId());
				if (parent != null) {
					tenantVO.setParentId(parent.getId());
				} else {
					tenantVO.setParentId(0L);
				}
			} else {
				tenantVO.setParentId(0L);
			}
		}
		return ForestNodeMerger.merge(collect);
	}
}
