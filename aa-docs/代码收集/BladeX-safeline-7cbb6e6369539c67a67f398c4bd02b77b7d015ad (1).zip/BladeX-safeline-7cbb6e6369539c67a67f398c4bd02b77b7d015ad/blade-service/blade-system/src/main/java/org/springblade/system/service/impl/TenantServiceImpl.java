/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.system.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.yomahub.liteflow.core.FlowExecutor;
import com.yomahub.liteflow.flow.LiteflowResponse;
import lombok.AllArgsConstructor;
import org.springblade.core.cache.utils.CacheUtil;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.tenant.TenantId;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.support.Kv;
import org.springblade.core.tool.utils.DesUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.system.cache.SysCache;
import org.springblade.system.mapper.TenantMapper;
import org.springblade.system.pojo.entity.*;
import org.springblade.system.pojo.vo.CascaderData;
import org.springblade.system.pojo.vo.TenantVO;
import org.springblade.system.rule.TenantContext;
import org.springblade.system.service.*;
import org.springblade.system.wrapper.TenantWrapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

import static org.springblade.common.constant.TenantConstant.DES_KEY;
import static org.springblade.core.cache.constant.CacheConstant.SYS_CACHE;

/**
 * 服务实现类
 *
 * @author Chill
 */
@Service
@AllArgsConstructor
public class TenantServiceImpl extends BaseServiceImpl<TenantMapper, Tenant> implements ITenantService {

	private final TenantId tenantIdGenerator;
	private final IRoleService roleService;
	private final IMenuService menuService;
	private final IDeptService deptService;
	private final IPostService postService;
	private final IRoleMenuService roleMenuService;
	private final IDictBizService dictBizService;
	private final IUserService userService;
	private final FlowExecutor flowExecutor;

	@Override
	public IPage<Tenant> selectTenantPage(IPage<Tenant> page, Tenant tenant) {
		return page.setRecords(baseMapper.selectTenantPage(page, tenant));
	}

	@Override
	public Tenant getByTenantId(String tenantId) {
		return getOne(Wrappers.<Tenant>query().lambda().eq(Tenant::getTenantId, tenantId));
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean submitTenant(Tenant tenant) {
		if (Func.isEmpty(tenant.getId())) {
			TenantContext tenantContext = new TenantContext();
			tenantContext.setTenantIdGenerator(tenantIdGenerator);
			tenantContext.setTenant(tenant);
			tenantContext.setMenuService(menuService);
			tenantContext.setDictBizService(dictBizService);
			tenantContext.setTenantService(this);

			LiteflowResponse resp = flowExecutor.execute2Resp("tenantChain", null, tenantContext);
			if (resp.isSuccess()) {
				Role role = tenantContext.getRole();
				roleService.save(role);

				Long roleId = role.getId();
				List<RoleMenu> roleMenuList = tenantContext.getRoleMenuList();
				roleMenuList.forEach(roleMenu -> roleMenu.setRoleId(roleId));
				roleMenuService.saveBatch(roleMenuList);

				Dept dept = tenantContext.getDept();
				deptService.save(dept);

				Post post = tenantContext.getPost();
				postService.save(post);

				List<DictBiz> dictBizList = tenantContext.getDictBizList();
				dictBizService.saveBatch(dictBizList);

				User user = tenantContext.getUser();
				user.setRoleId(String.valueOf(role.getId()));
				user.setDeptId(String.valueOf(dept.getId()));
				user.setPostId(String.valueOf(post.getId()));
				userService.submit(user);
			} else {
				throw new ServiceException("租户业务数据构建异常");
			}
		}
		CacheUtil.clear(SYS_CACHE, tenant.getTenantId());
		return super.saveOrUpdate(tenant);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean removeTenant(List<Long> ids) {
		List<String> tenantIds = this.list(Wrappers.<Tenant>query().lambda().in(Tenant::getId, ids))
			.stream().map(tenant -> Func.toStr(tenant.getTenantId())).distinct().collect(Collectors.toList());
		CacheUtil.clear(SYS_CACHE, tenantIds);
		if (tenantIds.contains(BladeConstant.ADMIN_TENANT_ID)) {
			throw new ServiceException("不可删除管理租户!");
		}
		boolean tenantTemp = this.deleteLogic(ids);
		boolean userTemp = userService.remove(Wrappers.<User>query().lambda().in(User::getTenantId, tenantIds));
		return tenantTemp && userTemp;
	}

	@Override
	public boolean setting(Integer accountNumber, Date expireTime, String ids) {
		List<String> tenantIds = this.list(Wrappers.<Tenant>query().lambda().in(Tenant::getId, ids))
			.stream().map(tenant -> Func.toStr(tenant.getTenantId())).distinct().collect(Collectors.toList());
		CacheUtil.clear(SYS_CACHE, tenantIds);
		Func.toLongList(ids).forEach(id -> {
			Kv kv = Kv.create().set("accountNumber", accountNumber).set("expireTime", expireTime).set("id", id);
			String licenseKey = DesUtil.encryptToHex(JsonUtil.toJson(kv), DES_KEY);
			update(
				Wrappers.<Tenant>update().lambda()
					.set(Tenant::getAccountNumber, accountNumber)
					.set(Tenant::getExpireTime, expireTime)
					.set(Tenant::getLicenseKey, licenseKey)
					.eq(Tenant::getId, id)
			);
		});
		return true;
	}

	@Override
	public List<Tenant> getAllTenants() {
		return this.getBaseMapper().selectAllTenants();
	}

	@Override
	public List<TenantVO> getAllTenantsTree() {
		List<Tenant> tenants = SysCache.getAllTenants();
		return TenantWrapper.build().listNodeVO(tenants);
	}

	@Override
	public List<TenantVO> getTenantChildren(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO parent = getTenantInTree(allTenantsTree, tenantId);
		List<TenantVO> children = parent.getChildren();
		if (children == null) {
			return new ArrayList<>();
		}
		children.forEach(tenantVO -> tenantVO.setChildren(null));
		return children;
	}

	@Override
	public List<TenantVO> getTenantFlattenDescendents(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO parent = getTenantInTree(allTenantsTree, tenantId);
		List<TenantVO> result = new ArrayList<>();
		if (parent == null || parent.getChildren() == null) {
			return result;
		}
		Queue<TenantVO> tenants = new LinkedList<>(parent.getChildren());
		while (!tenants.isEmpty()) {
			TenantVO tenantVO = tenants.poll();
			result.add(tenantVO);
			tenants.addAll(tenantVO.getChildren());
			tenantVO.setChildren(null);
		}
		return result;
	}

	// find tree in all tenants tree
	TenantVO getTenantInTree(List<TenantVO> allTenantsTree, String tenantId) {
		Queue<TenantVO> tenants = new LinkedList<>(allTenantsTree);
		// find the parent node
		while (!tenants.isEmpty()) {
			TenantVO tenantVO = tenants.poll();
			if (tenantVO.getTenantId().equals(tenantId)) {
				return tenantVO;
			} else {
				tenants.addAll(tenantVO.getChildren());
			}
		}
		return null;
	}

	@Override
	public List<TenantVO> getTenantDescendentTree(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO tree = getTenantInTree(allTenantsTree, tenantId);
		if (tree == null) {
			return new ArrayList<>();
		}
		return tree.getChildren();
	}

	@Override
	public List<CascaderData> getTenantFlattenDescendentsCascaderData(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO parent = getTenantInTree(allTenantsTree, tenantId);
		List<CascaderData> result = new ArrayList<>();
		if (parent == null || parent.getChildren() == null) {
			return result;
		}
		CascaderData cascaderData;
		Queue<TenantVO> tenants = new LinkedList<>(parent.getChildren());
		while (!tenants.isEmpty()) {
			TenantVO tenantVO = tenants.poll();
			cascaderData = new CascaderData();
			cascaderData.setValue(tenantVO.getTenantId());
			cascaderData.setTitle(tenantVO.getTenantName());
			result.add(cascaderData);
			tenants.addAll(tenantVO.getChildren());
			tenantVO.setChildren(null);
		}
		return result;
	}

	@Override
	public List<CascaderData> getTenantChildrenCascaderData(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO parent = getTenantInTree(allTenantsTree, tenantId);
		List<TenantVO> children = parent.getChildren();
		if (children == null) {
			return new ArrayList<>();
		}
		children.forEach(tenantVO -> tenantVO.setChildren(null));
		return children.stream().map(c -> {
			CascaderData cascaderData = new CascaderData();
			cascaderData.setValue(c.getTenantId());
			cascaderData.setTitle(c.getTenantName());
			return cascaderData;
		}).collect(Collectors.toList());
	}

	@Override
	public List<CascaderData> getTenantDescendentTreeCascaderData(String tenantId) {
		List<TenantVO> allTenantsTree = SysCache.getAllTenantsTree();
		TenantVO tree = getTenantInTree(allTenantsTree, tenantId);
		if (tree == null) {
			return new ArrayList<>();
		}
		List<TenantVO> children = tree.getChildren();
		return children.stream().map(c -> {
			CascaderData cascaderData = new CascaderData();
			cascaderData.setValue(c.getTenantId());
			cascaderData.setTitle(c.getTenantName());
			cascaderData.setChildren(convertTree(c.getChildren()));
			return cascaderData;
		}).collect(Collectors.toList());
	}

	public static List<CascaderData> convertTree(List<TenantVO> children) {
		if (children == null) {
			return new ArrayList<>();
		}

		return children.stream().map(c -> {
			CascaderData cascaderData = new CascaderData();
			cascaderData.setValue(c.getTenantId());
			cascaderData.setTitle(c.getTenantName());

			// 这里对获取子节点进行转换并赋值给CascaderData的children属性
			List<CascaderData> cascaderChildren = convertTree(c.getChildren());
			cascaderData.setChildren(cascaderChildren);

			return cascaderData;
		}).collect(Collectors.toList());
	}

}
