package com.xxl.job.core.util;

public class StrUtils {
    public static String replaceCRLF(String message) {
        if (message == null) {
            return "";
        }
        return message.replace('\n', '_').replace('\r', '_');
    }
}
