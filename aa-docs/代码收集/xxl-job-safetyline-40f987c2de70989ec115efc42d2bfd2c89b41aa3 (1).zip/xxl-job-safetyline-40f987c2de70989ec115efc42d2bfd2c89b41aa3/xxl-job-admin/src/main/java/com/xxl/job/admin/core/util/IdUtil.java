package com.xxl.job.admin.core.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class IdUtil {

    /**
     * 生成主键(19位数字)
     * 主键生成方式,年月日时分秒毫秒的时间戳 例如：1810311557430000845
     */
    public static synchronized Long getUUIDTOLongNew() {
        try {
            TimeUnit.NANOSECONDS.sleep(1000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMddHHmmssSSSSSSS"); //1810311557430000845
        return Long.parseLong(sdf.format(date));
    }
}
