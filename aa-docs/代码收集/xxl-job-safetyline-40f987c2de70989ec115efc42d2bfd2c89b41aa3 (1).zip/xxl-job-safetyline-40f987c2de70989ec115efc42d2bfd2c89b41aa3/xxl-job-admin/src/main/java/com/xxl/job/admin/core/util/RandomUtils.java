package com.xxl.job.admin.core.util;

import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

public class RandomUtils {

    public static int getRandom(int count) {
        try {
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
            random.setSeed(random.generateSeed(12));
            return random.nextInt(100);
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            e.printStackTrace();
            return count / 2;
        }
    }

}
