CREATE TABLE "ACT_DE_MODEL" (
                                "ID" NVARCHAR2(255) NOT NULL,
                                "NAME" NVARCHAR2(400) NOT NULL,
                                "MODEL_KEY" NVARCHAR2(400) NOT NULL,
                                "FORM_KEY" NVARCHAR2(255),
                                "CATEGORY_ID" NUMBER(20,0),
                                "DESCRIPTION" NCLOB,
                                "MODEL_COMMENT" NCLOB,
                                "CREATED" DATE,
                                "CREATED_BY" NVARCHAR2(255),
                                "LAST_UPDATED" DATE,
                                "LAST_UPDATED_BY" NVARCHAR2(255),
                                "VERSION" NUMBER(11,0),
                                "MODEL_XML" NCLOB,
                                "MODEL_EDITOR_JSON" NCLOB,
                                "THUMBNAIL" BLOB,
                                "MODEL_TYPE" NUMBER(11,0),
                                "TENANT_ID" NVARCHAR2(255),
                                "ICON" NVARCHAR2(255)
)
;
COMMENT ON COLUMN "ACT_DE_MODEL"."NAME" IS '名称';
COMMENT ON COLUMN "ACT_DE_MODEL"."MODEL_KEY" IS '模型标识';
COMMENT ON COLUMN "ACT_DE_MODEL"."FORM_KEY" IS '表单标识';
COMMENT ON COLUMN "ACT_DE_MODEL"."CATEGORY_ID" IS '分类id';
COMMENT ON COLUMN "ACT_DE_MODEL"."DESCRIPTION" IS '描述';
COMMENT ON COLUMN "ACT_DE_MODEL"."MODEL_COMMENT" IS '评论';
COMMENT ON COLUMN "ACT_DE_MODEL"."CREATED" IS '创建时间';
COMMENT ON COLUMN "ACT_DE_MODEL"."CREATED_BY" IS '创建人';
COMMENT ON COLUMN "ACT_DE_MODEL"."LAST_UPDATED" IS '最后更新时间';
COMMENT ON COLUMN "ACT_DE_MODEL"."LAST_UPDATED_BY" IS '最后更新人';
COMMENT ON COLUMN "ACT_DE_MODEL"."VERSION" IS '版本';
COMMENT ON COLUMN "ACT_DE_MODEL"."MODEL_XML" IS '模型XML';
COMMENT ON COLUMN "ACT_DE_MODEL"."MODEL_EDITOR_JSON" IS 'flowable-ui编辑器json';
COMMENT ON COLUMN "ACT_DE_MODEL"."THUMBNAIL" IS '缩略图';
COMMENT ON COLUMN "ACT_DE_MODEL"."MODEL_TYPE" IS '类型';
COMMENT ON COLUMN "ACT_DE_MODEL"."TENANT_ID" IS '租户id';
COMMENT ON COLUMN "ACT_DE_MODEL"."ICON" IS '图标';
COMMENT ON TABLE "ACT_DE_MODEL" IS '流程 - 定义 - 模型';

-- ----------------------------
-- Table structure for ACT_DE_MODEL_HISTORY
-- ----------------------------
CREATE TABLE "ACT_DE_MODEL_HISTORY" (
                                        "ID" NVARCHAR2(255) NOT NULL,
                                        "NAME" NVARCHAR2(400) NOT NULL,
                                        "MODEL_KEY" NVARCHAR2(400) NOT NULL,
                                        "FORM_KEY" NVARCHAR2(255),
                                        "CATEGORY_ID" NUMBER(20,0),
                                        "DESCRIPTION" NCLOB,
                                        "MODEL_COMMENT" NCLOB,
                                        "CREATED" DATE,
                                        "CREATED_BY" NVARCHAR2(255),
                                        "LAST_UPDATED" DATE,
                                        "LAST_UPDATED_BY" NVARCHAR2(255),
                                        "REMOVAL_DATE" DATE,
                                        "VERSION" NUMBER(11,0),
                                        "MODEL_XML" NCLOB,
                                        "MODEL_EDITOR_JSON" NCLOB,
                                        "MODEL_ID" NVARCHAR2(255) NOT NULL,
                                        "MODEL_TYPE" NUMBER(11,0),
                                        "TENANT_ID" NVARCHAR2(255),
                                        "ICON" NVARCHAR2(255)
)
;
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."NAME" IS '名称';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_KEY" IS '模型标识';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."FORM_KEY" IS '表单标识';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."CATEGORY_ID" IS '分类id';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."DESCRIPTION" IS '描述';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_COMMENT" IS '注释';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."CREATED" IS '创建时间';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."CREATED_BY" IS '创建人';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."LAST_UPDATED" IS '最后更新时间';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."LAST_UPDATED_BY" IS '最后更新人';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."REMOVAL_DATE" IS '移除时间';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."VERSION" IS '版本';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_XML" IS '模型XML';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_EDITOR_JSON" IS 'flowable-ui编辑器json';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_ID" IS 'modelId';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."MODEL_TYPE" IS '类型';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."TENANT_ID" IS '租户id';
COMMENT ON COLUMN "ACT_DE_MODEL_HISTORY"."ICON" IS '图标';
COMMENT ON TABLE "ACT_DE_MODEL_HISTORY" IS '流程 - 定义 - 模型历史';

-- ----------------------------
-- Records of ACT_DE_MODEL_HISTORY
-- ----------------------------

-- ----------------------------
-- Table structure for BLADE_WF_BUTTON
-- ----------------------------
CREATE TABLE "BLADE_WF_BUTTON" (
                                   "ID" NUMBER(20,0) NOT NULL,
                                   "BUTTON_KEY" NVARCHAR2(255),
                                   "NAME" NVARCHAR2(255),
                                   "DISPLAY" NUMBER(4,0),
                                   "SORT" NUMBER(11,0),
                                   "CREATE_USER" NUMBER(20,0),
                                   "CREATE_DEPT" NUMBER(20,0),
                                   "CREATE_TIME" DATE,
                                   "UPDATE_USER" NUMBER(20,0),
                                   "UPDATE_TIME" DATE,
                                   "STATUS" NVARCHAR2(255),
                                   "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                   "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_BUTTON"."BUTTON_KEY" IS '按钮key';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."DISPLAY" IS '默认是否显示';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."SORT" IS '排序';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_BUTTON"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_BUTTON" IS '流程按钮';

-- ----------------------------
-- Records of BLADE_WF_BUTTON
-- ----------------------------
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394176899911041025', 'wf_pass', '通过', '1', '1', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 14:24:10', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 14:24:10', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394177198465794050', 'wf_reject', '驳回', '1', '2', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 14:25:21', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 14:25:21', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394179125421326337', 'wf_print', '打印', '1', '3', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 14:33:01', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 14:33:01', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394609969089761281', 'wf_transfer', '转办', '1', '4', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 19:05:02', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 19:05:02', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394610036672581634', 'wf_delegate', '委托', '1', '5', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 19:05:18', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 19:05:18', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1395271519601426433', 'wf_terminate', '终止', '1', '6', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-20 14:53:48', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-20 14:53:48', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1395274709692579841', 'wf_add_instance', '加签', '1', '7', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-20 15:06:28', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-20 15:06:28', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1395274774674931713', 'wf_del_instance', '减签', '1', '8', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-20 15:06:44', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-20 15:06:44', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_BUTTON" ("ID", "BUTTON_KEY", "NAME", "DISPLAY", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1395274955986305025', 'wf_rollback', '指定回退', '1', '9', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-20 15:07:27', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-20 15:07:27', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');

-- ----------------------------
-- Table structure for BLADE_WF_CATEGORY
-- ----------------------------
CREATE TABLE "BLADE_WF_CATEGORY" (
                                     "ID" NUMBER(20,0) NOT NULL,
                                     "NAME" NVARCHAR2(255),
                                     "PID" NUMBER(20,0) DEFAULT 0,
                                     "SORT" NUMBER(11,0),
                                     "CREATE_USER" NUMBER(20,0),
                                     "CREATE_DEPT" NUMBER(20,0),
                                     "CREATE_TIME" DATE,
                                     "UPDATE_USER" NUMBER(20,0),
                                     "UPDATE_TIME" DATE,
                                     "STATUS" NVARCHAR2(255),
                                     "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                     "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."NAME" IS '分类名称';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."PID" IS '上级id';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."SORT" IS '排序';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_CATEGORY"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_CATEGORY" IS '流程分类';

-- ----------------------------
-- Records of BLADE_WF_CATEGORY
-- ----------------------------
INSERT INTO "BLADE_WF_CATEGORY" ("ID", "NAME", "PID", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394133715940073474', '请假流程', '0', '1', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 11:32:34', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-25 20:37:49', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_CATEGORY" ("ID", "NAME", "PID", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394158934813609986', '财务流程', '0', '2', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 13:12:47', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 13:13:07', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_CATEGORY" ("ID", "NAME", "PID", "SORT", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1394159147934584833', '报销流程', '1394158934813609986', '1', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-16 13:13:38', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-16 13:13:38', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');

-- ----------------------------
-- Table structure for BLADE_WF_CONDITION
-- ----------------------------
CREATE TABLE "BLADE_WF_CONDITION" (
                                      "ID" NUMBER(20,0) NOT NULL,
                                      "NAME" NVARCHAR2(255),
                                      "EXPRESSION" NVARCHAR2(255),
                                      "TYPE" NVARCHAR2(255),
                                      "CREATE_USER" NUMBER(20,0),
                                      "CREATE_DEPT" NUMBER(20,0),
                                      "CREATE_TIME" DATE,
                                      "UPDATE_USER" NUMBER(20,0),
                                      "UPDATE_TIME" DATE,
                                      "STATUS" NVARCHAR2(255),
                                      "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                      "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_CONDITION"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."EXPRESSION" IS '表达式';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."TYPE" IS '类型';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_CONDITION"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_CONDITION" IS '流程表达式';

-- ----------------------------
-- Records of BLADE_WF_CONDITION
-- ----------------------------
INSERT INTO "BLADE_WF_CONDITION" ("ID", "NAME", "EXPRESSION", "TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1408267023015739393', '流程发起人', 'applyUser', 'user', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-25 11:33:17', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-25 11:33:17', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_CONDITION" ("ID", "NAME", "EXPRESSION", "TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1408267100878798850', '当前操作人', 'currentUser', 'user', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-25 11:33:36', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-25 11:33:36', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_CONDITION" ("ID", "NAME", "EXPRESSION", "TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1408305933398896641', '上级部门领导', 'leader', 'user', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-25 14:07:54', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-25 14:07:54', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');

-- ----------------------------
-- Table structure for BLADE_WF_COPY
-- ----------------------------
CREATE TABLE "BLADE_WF_COPY" (
                                 "ID" NUMBER(20,0) NOT NULL,
                                 "USER_ID" NUMBER(20,0),
                                 "TITLE" NVARCHAR2(255),
                                 "INITIATOR" NVARCHAR2(255),
                                 "TASK_ID" NVARCHAR2(255),
                                 "PROCESS_ID" NVARCHAR2(255),
                                 "DEPLOYMENT_ID" NVARCHAR2(255),
                                 "FORM_KEY" NVARCHAR2(255),
                                 "FORM_URL" NVARCHAR2(255),
                                 "CREATE_USER" NUMBER(20,0),
                                 "CREATE_DEPT" NUMBER(20,0),
                                 "CREATE_TIME" DATE,
                                 "UPDATE_USER" NUMBER(20,0),
                                 "UPDATE_TIME" DATE,
                                 "STATUS" NVARCHAR2(255),
                                 "IS_DELETED" NUMBER(11,0) DEFAULT 0
)
;
COMMENT ON COLUMN "BLADE_WF_COPY"."USER_ID" IS '用户id';
COMMENT ON COLUMN "BLADE_WF_COPY"."TITLE" IS '标题';
COMMENT ON COLUMN "BLADE_WF_COPY"."INITIATOR" IS '发起者';
COMMENT ON COLUMN "BLADE_WF_COPY"."TASK_ID" IS '任务id';
COMMENT ON COLUMN "BLADE_WF_COPY"."PROCESS_ID" IS '流程实例id';
COMMENT ON COLUMN "BLADE_WF_COPY"."DEPLOYMENT_ID" IS '流程部署id';
COMMENT ON COLUMN "BLADE_WF_COPY"."FORM_KEY" IS '外置表单key';
COMMENT ON COLUMN "BLADE_WF_COPY"."FORM_URL" IS '外置表单url';
COMMENT ON COLUMN "BLADE_WF_COPY"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_COPY"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_COPY"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_COPY"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_COPY"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_COPY"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_COPY"."IS_DELETED" IS '是否已删除';
COMMENT ON TABLE "BLADE_WF_COPY" IS '流程抄送';

-- ----------------------------
-- Records of BLADE_WF_COPY
-- ----------------------------

-- ----------------------------
-- Table structure for BLADE_WF_DEPLOYMENT_FORM
-- ----------------------------
CREATE TABLE "BLADE_WF_DEPLOYMENT_FORM" (
                                            "ID" NUMBER(20,0) NOT NULL,
                                            "DEPLOYMENT_ID" NVARCHAR2(255),
                                            "FORM_KEY" NVARCHAR2(255),
                                            "CONTENT" NCLOB,
                                            "APP_CONTENT" NCLOB,
                                            "TASK_KEY" NVARCHAR2(255),
                                            "TASK_NAME" NVARCHAR2(255),
                                            "CREATE_USER" NUMBER(20,0),
                                            "CREATE_DEPT" NUMBER(20,0),
                                            "CREATE_TIME" DATE,
                                            "UPDATE_USER" NUMBER(20,0),
                                            "UPDATE_TIME" DATE,
                                            "STATUS" NVARCHAR2(255),
                                            "IS_DELETED" NUMBER(11,0) DEFAULT 0
)
;
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."DEPLOYMENT_ID" IS '流程部署id';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."FORM_KEY" IS '表单key';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."CONTENT" IS '表单内容';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."APP_CONTENT" IS 'app表单内容';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."TASK_KEY" IS '节点key';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."TASK_NAME" IS '节点名称';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_DEPLOYMENT_FORM"."IS_DELETED" IS '是否已删除';
COMMENT ON TABLE "BLADE_WF_DEPLOYMENT_FORM" IS '流程部署 - 表单';

-- ----------------------------
-- Records of BLADE_WF_DEPLOYMENT_FORM
-- ----------------------------

-- ----------------------------
-- Table structure for BLADE_WF_DRAFT
-- ----------------------------
CREATE TABLE "BLADE_WF_DRAFT" (
                                  "ID" NUMBER(20,0) NOT NULL,
                                  "USER_ID" NUMBER(20,0),
                                  "FORM_KEY" NVARCHAR2(255),
                                  "PROCESS_DEF_ID" NVARCHAR2(255),
                                  "VARIABLES" NCLOB,
                                  "PLATFORM" NVARCHAR2(255)
)
;
COMMENT ON COLUMN "BLADE_WF_DRAFT"."USER_ID" IS '用户id';
COMMENT ON COLUMN "BLADE_WF_DRAFT"."FORM_KEY" IS '表单key';
COMMENT ON COLUMN "BLADE_WF_DRAFT"."PROCESS_DEF_ID" IS '流程定义id';
COMMENT ON COLUMN "BLADE_WF_DRAFT"."VARIABLES" IS '表单变量';
COMMENT ON COLUMN "BLADE_WF_DRAFT"."PLATFORM" IS '平台 pc/app';
COMMENT ON TABLE "BLADE_WF_DRAFT" IS '流程草稿箱';

-- ----------------------------
-- Records of BLADE_WF_DRAFT
-- ----------------------------

-- ----------------------------
-- Table structure for BLADE_WF_FORM
-- ----------------------------
CREATE TABLE "BLADE_WF_FORM" (
                                 "ID" NUMBER(20,0) NOT NULL,
                                 "FORM_KEY" NVARCHAR2(255),
                                 "NAME" NVARCHAR2(255),
                                 "CONTENT" NCLOB,
                                 "APP_CONTENT" NCLOB,
                                 "VERSION" NUMBER(11,0),
                                 "CATEGORY_ID" NUMBER(20,0),
                                 "REMARK" NVARCHAR2(255),
                                 "CREATE_USER" NUMBER(20,0),
                                 "CREATE_DEPT" NUMBER(20,0),
                                 "CREATE_TIME" DATE,
                                 "UPDATE_USER" NUMBER(20,0),
                                 "UPDATE_TIME" DATE,
                                 "STATUS" NUMBER(11,0),
                                 "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                 "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_FORM"."FORM_KEY" IS '表单key';
COMMENT ON COLUMN "BLADE_WF_FORM"."NAME" IS '表单名称';
COMMENT ON COLUMN "BLADE_WF_FORM"."CONTENT" IS '表单内容';
COMMENT ON COLUMN "BLADE_WF_FORM"."APP_CONTENT" IS 'app表单内容';
COMMENT ON COLUMN "BLADE_WF_FORM"."VERSION" IS '版本';
COMMENT ON COLUMN "BLADE_WF_FORM"."CATEGORY_ID" IS '分类id';
COMMENT ON COLUMN "BLADE_WF_FORM"."REMARK" IS '备注';
COMMENT ON COLUMN "BLADE_WF_FORM"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM" IS '流程表单';

-- ----------------------------
-- Records of BLADE_WF_FORM
-- ----------------------------
INSERT INTO "BLADE_WF_FORM" ("ID", "FORM_KEY", "NAME", "CONTENT", "APP_CONTENT", "VERSION", "CATEGORY_ID", "REMARK", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399359377009377281', 'default-value', '测试默认值', '{column:[{type:''input'',label:''人事姓名'',span:24,display:true,prop:''1622472547203_21841'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''人事职位'',span:24,display:true,prop:''1622553629767_65211'',value:''${this.$store.getters.userInfo.post_name}''},{type:''input'',label:''人事部门'',span:24,display:true,prop:''1622472547375_86557'',value:''${this.$store.getters.userInfo.dept_name}''},{type:''input'',label:''当前日期'',span:24,display:true,prop:''1622553629949_3168'',value:''${this.dateFormat(new Date(),\"yyyy-MM-dd\")}''},{type:''input'',label:''当前时间'',span:24,display:true,prop:''1622553631752_15562'',value:''${this.dateFormat(new Date(),\"hh:mm:ss\")}''},{type:''input'',label:''人事姓名和日期'',span:24,display:true,prop:''1622553691156_69886'',value:''${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),\"yyyy-MM-dd\")}''},{type:''input'',label:''经理姓名'',span:24,display:true,prop:''1622472547780_5707'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''经理部门'',span:24,display:true,prop:''1622472547975_90560'',value:''${this.$store.getters.userInfo.dept_name}''},{type:''input'',label:''老板姓名'',span:24,display:true,prop:''1622472548372_60141'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''老板部门'',span:24,display:true,prop:''1622472548560_32474'',value:''${this.$store.getters.userInfo.dept_name}''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:140,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', '{"column":[{"type":"input","label":"人事姓名","span":24,"display":true,"prop":"1622472547203_21841","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"人事职位","span":24,"display":true,"prop":"1622553629767_65211","value":"${this.$store.getters.userInfo.post_name}"},{"type":"input","label":"人事部门","span":24,"display":true,"prop":"1622472547375_86557","value":"${this.$store.getters.userInfo.dept_name}"},{"type":"input","label":"当前日期","span":24,"display":true,"prop":"1622553629949_3168","value":"${this.dateFormat(new Date(),\"yyyy-MM-dd\")}"},{"type":"input","label":"当前时间","span":24,"display":true,"prop":"1622553631752_15562","value":"${this.dateFormat(new Date(),\"hh:mm:ss\")}"},{"type":"input","label":"人事姓名和日期","span":24,"display":true,"prop":"1622553691156_69886","value":"${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),\"yyyy-MM-dd\")}"},{"type":"input","label":"经理姓名","span":24,"display":true,"prop":"1622472547780_5707","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"经理部门","span":24,"display":true,"prop":"1622472547975_90560","value":"${this.$store.getters.userInfo.dept_name}"},{"type":"input","label":"老板姓名","span":24,"display":true,"prop":"1622472548372_60141","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"老板部门","span":24,"display":true,"prop":"1622472548560_32474","value":"${this.$store.getters.userInfo.dept_name}"}],"labelPosition":"left","labelSuffix":"：","labelWidth":140,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', '1', '-1', NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-31 21:37:29', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-11-01 09:08:05', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM" ("ID", "FORM_KEY", "NAME", "CONTENT", "APP_CONTENT", "VERSION", "CATEGORY_ID", "REMARK", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1408402768310304770', 'demo-test', '测试简单表单', '{column:[{type:''input'',label:''单行文本'',span:24,display:true,prop:''1624624365132_23209''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', '{"column":[{"type":"input","label":"单行文本","span":24,"display":true,"prop":"1624624365132_23209"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', '1', '-1', NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-25 20:32:41', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-11-01 09:08:09', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM" ("ID", "FORM_KEY", "NAME", "CONTENT", "APP_CONTENT", "VERSION", "CATEGORY_ID", "REMARK", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1429672727182159874', 'field-linkage', '字段联动', '{column:[{type:''switch'',label:''控制显隐'',span:24,display:true,value:''0'',dicData:[{label:'''',value:''0''},{label:'''',value:''1''}],prop:''1629695558953_19833'',change:({value}) => {
    const input = this.findObject(this.option.column, ''input'')
    if(value == 0) {
        input.display = false
    } else {
        input.display = true
    }
}},{type:''input'',label:''单行文本'',span:24,display:true,prop:''input'',change:({value}) => {

}},{type:''select'',label:''值改变'',dicData:[{label:''一天'',value:''1''},{label:''两天'',value:''2''},{label:''三天'',value:''3''}],cascaderItem:[],span:24,display:true,props:{label:''label'',value:''value''},prop:''1629695859796_23456'',change:({value}) => {
    let text = value
    if(value) {
        text = ''请假 '' + value + '' 天''
    }
    this.$set(this.form, ''input2'', text)
}},{type:''input'',label:''单行文本'',span:24,display:true,prop:''input2'',change:({value}) => {

}}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', '{"column":[{"type":"switch","label":"控制显隐","span":24,"display":true,"value":"0","dicData":[{"label":"","value":"0"},{"label":"","value":"1"}],"prop":"1629695558953_19833","change":"({value}) => {\r\n    const input = this.findObject(this.option.column, ''input'')\r\n    if(value == 0) {\r\n        input.display = false\r\n    } else {\r\n        input.display = true\r\n    }\r\n}"},{"type":"input","label":"单行文本","span":24,"display":true,"prop":"input","change":"({value}) => {\r\n\r\n}"},{"type":"select","label":"值改变","dicData":[{"label":"一天","value":"1"},{"label":"两天","value":"2"},{"label":"三天","value":"3"}],"cascaderItem":[],"span":24,"display":true,"props":{"label":"label","value":"value"},"prop":"1629695859796_23456","change":"({value}) => {\r\n    let text = value\r\n    if(value) {\r\n        text = ''请假 '' + value + '' 天''\r\n    }\r\n    this.$set(this.form, ''input2'', text)\r\n}"},{"type":"input","label":"单行文本","span":24,"display":true,"prop":"input2","change":"({value}) => {\r\n\r\n}"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', '1', '-1', '字段联动示例', '1123598821738675201', '1123598813738675201', TO_DATE('2021-08-23 13:11:54', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-11-01 09:08:10', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM" ("ID", "FORM_KEY", "NAME", "CONTENT", "APP_CONTENT", "VERSION", "CATEGORY_ID", "REMARK", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399729025840140290', 'leave', '请假流程表单', '{column:[{type:''input'',label:''创建人'',span:12,display:true,prop:''creator'',value:''${this.$store.getters.userInfo.nick_name}'',readonly:true},{type:''input'',label:''创建部门'',span:12,display:true,prop:''creatorDept'',value:''${this.$store.getters.userInfo.dept_name}'',readonly:true},{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''yyyy-MM-dd HH:mm:ss'',valueFormat:''yyyy-MM-dd HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''请假时间必须填写''}],change:({value}) => {
  if (!value || value.length == 0) {
    this.$set(this.form, ''days'', undefined)
  } else {
    const d1 = Date.parse(value.split('','')[0])
    const d2 = Date.parse(value.split('','')[1])
    const day = (d2-d1)/(1*24*60*60*1000)
    this.$set(this.form, ''days'', Number(day.toFixed(2)))
  }
},dataType:''string''},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
  if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )
  else this.$set(this.form, ''reason'', '''')
}},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]},{label:''附件'',type:''upload'',propsHttp:{res:''data'',url:''link'',name:''originalName''},action:''/api/blade-resource/oss/endpoint/put-file'',display:true,span:24,showFileList:true,multiple:true,limit:10,prop:''attachment'',dataType:''string''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', '{"column":[{"type":"input","label":"创建人","span":12,"display":true,"prop":"creator","value":"${this.$store.getters.userInfo.nick_name}","readonly":true},{"type":"input","label":"创建部门","span":12,"display":true,"prop":"creatorDept","value":"${this.$store.getters.userInfo.dept_name}","readonly":true},{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"yyyy-MM-dd HH:mm:ss","valueFormat":"yyyy-MM-dd HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"请假时间必须填写"}],"change":"({value}) => {\r\n  if (!value || value.length == 0) {\r\n    this.$set(this.form, ''days'', undefined)\r\n  } else {\r\n    const d1 = Date.parse(value.split('','')[0])\r\n    const d2 = Date.parse(value.split('','')[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    this.$set(this.form, ''days'', Number(day.toFixed(2)))\r\n  }\r\n}","dataType":"string"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\n  if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )\n  else this.$set(this.form, ''reason'', '''')\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]},{"label":"附件","type":"upload","propsHttp":{"res":"data","url":"link","name":"originalName"},"action":"/api/blade-resource/oss/endpoint/put-file","display":true,"span":24,"showFileList":true,"multiple":true,"limit":10,"prop":"attachment","dataType":"string"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', '1', '-1', NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-01 22:06:20', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2022-04-12 10:27:07', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');

-- ----------------------------
-- Table structure for BLADE_WF_FORM_DEFAULT_VALUES
-- ----------------------------
CREATE TABLE "BLADE_WF_FORM_DEFAULT_VALUES" (
                                                "ID" NUMBER(20,0) NOT NULL,
                                                "NAME" NVARCHAR2(255),
                                                "CONTENT" NVARCHAR2(255),
                                                "FIELD_TYPE" NVARCHAR2(255),
                                                "CREATE_USER" NUMBER(20,0),
                                                "CREATE_DEPT" NUMBER(20,0),
                                                "CREATE_TIME" DATE,
                                                "UPDATE_USER" NUMBER(20,0),
                                                "UPDATE_TIME" DATE,
                                                "STATUS" NVARCHAR2(255),
                                                "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                                "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."CONTENT" IS '内容';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."FIELD_TYPE" IS '字段类型';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM_DEFAULT_VALUES"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM_DEFAULT_VALUES" IS '流程表单字段默认值';

-- ----------------------------
-- Records of BLADE_WF_FORM_DEFAULT_VALUES
-- ----------------------------
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399346112331087873', '当前操作人姓名', '${this.$store.getters.userInfo.nick_name}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-31 20:44:46', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-31 20:56:32', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399347906465595393', '当前操作人部门', '${this.$store.getters.userInfo.dept_name}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-05-31 20:51:54', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-05-31 20:56:41', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399717069960855553', '当前日期', '${this.dateFormat(new Date(),"yyyy-MM-dd")}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-01 21:18:50', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-01 21:34:25', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399717187904684034', '当前操作人职位', '${this.$store.getters.userInfo.post_name}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-01 21:19:18', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-01 21:19:18', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399717285564858369', '当前时间', '${this.dateFormat(new Date(),"hh:mm:ss")}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-01 21:19:41', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-01 21:34:34', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1399718803940655106', '当前操作人姓名和日期', '${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),"yyyy-MM-dd")}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-01 21:25:43', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-01 21:34:40', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_DEFAULT_VALUES" ("ID", "NAME", "CONTENT", "FIELD_TYPE", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1408401952027443201', '当前操作人姓名', '${this.$store.getters.userInfo.nick_name}', 'input', '1123598821738675201', '1123598813738675201', TO_DATE('2021-06-25 20:29:27', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2021-06-25 20:29:32', 'SYYYY-MM-DD HH24:MI:SS'), '1', '1', '000000');

-- ----------------------------
-- Table structure for BLADE_WF_FORM_HISTORY
-- ----------------------------
CREATE TABLE "BLADE_WF_FORM_HISTORY" (
                                         "ID" NUMBER(20,0) NOT NULL,
                                         "FORM_ID" NUMBER(20,0),
                                         "FORM_KEY" NVARCHAR2(255),
                                         "NAME" NVARCHAR2(255),
                                         "CONTENT" NCLOB,
                                         "APP_CONTENT" NCLOB,
                                         "VERSION" NUMBER(11,0),
                                         "CATEGORY_ID" NUMBER(20,0),
                                         "REMARK" NVARCHAR2(255),
                                         "CREATE_USER" NUMBER(20,0),
                                         "CREATE_DEPT" NUMBER(20,0),
                                         "CREATE_TIME" DATE,
                                         "UPDATE_USER" NUMBER(20,0),
                                         "UPDATE_TIME" DATE,
                                         "STATUS" NUMBER(11,0),
                                         "IS_DELETED" NUMBER(11,0) DEFAULT 0
)
;
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."FORM_ID" IS '表单id';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."FORM_KEY" IS '表单key';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."NAME" IS '表单名称';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."CONTENT" IS '表单内容';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."APP_CONTENT" IS 'app表单内容';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."VERSION" IS '版本';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."CATEGORY_ID" IS '分类id';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."REMARK" IS '备注';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_HISTORY"."IS_DELETED" IS '是否已删除';
COMMENT ON TABLE "BLADE_WF_FORM_HISTORY" IS '流程表单';

-- ----------------------------
-- Records of BLADE_WF_FORM_HISTORY
-- ----------------------------

-- ----------------------------
-- Table structure for BLADE_WF_FORM_THEME
-- ----------------------------
CREATE TABLE "BLADE_WF_FORM_THEME" (
                                       "ID" NUMBER(20,0) NOT NULL,
                                       "NAME" NVARCHAR2(255) NOT NULL,
                                       "THEME_KEY" NVARCHAR2(255) NOT NULL,
                                       "BORDER_WIDTH" NVARCHAR2(255),
                                       "BORDER_COLOR" NVARCHAR2(255),
                                       "LABEL_COLOR" NVARCHAR2(255),
                                       "LABEL_BG" NVARCHAR2(255),
                                       "LABEL_WIDTH" NVARCHAR2(255),
                                       "LABEL_FONT_SIZE" NVARCHAR2(255),
                                       "VALUE_COLOR" NVARCHAR2(255),
                                       "VALUE_BG" NVARCHAR2(255),
                                       "VALUE_FONT_SIZE" NVARCHAR2(255),
                                       "FIELD0" NVARCHAR2(255),
                                       "FIELD1" NVARCHAR2(255),
                                       "FIELD2" NVARCHAR2(255),
                                       "FIELD3" NVARCHAR2(255),
                                       "FIELD4" NVARCHAR2(255),
                                       "FIELD5" NVARCHAR2(255),
                                       "FIELD6" NVARCHAR2(255),
                                       "FIELD7" NVARCHAR2(255),
                                       "FIELD8" NVARCHAR2(255),
                                       "FIELD9" NVARCHAR2(255),
                                       "CREATE_USER" NUMBER(20,0),
                                       "CREATE_DEPT" NUMBER(20,0),
                                       "CREATE_TIME" DATE,
                                       "UPDATE_USER" NUMBER(20,0),
                                       "UPDATE_TIME" DATE,
                                       "STATUS" NUMBER(11,0),
                                       "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                       "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."THEME_KEY" IS '主题key';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."BORDER_WIDTH" IS '边框宽度';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."BORDER_COLOR" IS '边框颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_COLOR" IS 'label字体颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_BG" IS 'label背景颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_WIDTH" IS 'label宽度';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_FONT_SIZE" IS 'label字体大小';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_COLOR" IS 'value字体颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_BG" IS 'value背景颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_FONT_SIZE" IS 'value字体大小';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD0" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD1" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD2" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD3" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD4" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD5" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD6" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD7" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD8" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD9" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM_THEME" IS '流程表单 - 主题';

-- ----------------------------
-- Records of BLADE_WF_FORM_THEME
-- ----------------------------
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1', '蓝色', 'blue', '1px', '#cbdcf0', '#01418a', '#eef6ff', NULL, '14px', NULL, NULL, '14px', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2023-04-04 15:36:46', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-05-04 10:43:18', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('2', '默认', 'default', '1px', 'rgba(235, 238, 245, 1)', 'rgba(144, 147, 153, 1)', 'rgba(250, 250, 250, 1)', NULL, NULL, 'rgba(96, 98, 102, 1)', 'rgba(255, 255, 255, 1)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2023-04-04 15:16:47', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-04-18 11:50:10', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('3', '黑色', 'black', '1px', 'rgba(0, 0, 0, 1)', '#000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598821738675201', TO_DATE('2023-04-04 16:57:35', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-05-04 10:43:44', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_THEME
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011945" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_THEME
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011942" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011943" CHECK ("NAME" IS NOT NULL);
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011944" CHECK ("THEME_KEY" IS NOT NULL);

-- ----------------------------
-- Indexes structure for table BLADE_WF_FORM_THEME
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_THEME_KEY"
    ON "BLADE_WF_FORM_THEME" ("THEME_KEY" ASC);

-- ----------------------------
-- Table structure for BLADE_WF_FORM_VARIABLE
-- ----------------------------
DROP TABLE "BLADE_WF_FORM_VARIABLE";
CREATE TABLE "BLADE_WF_FORM_VARIABLE" (
                                          "ID" NUMBER(20,0) NOT NULL,
                                          "PROCESS_INS_ID" NVARCHAR2(255),
                                          "DEPLOYMENT_ID" NVARCHAR2(255),
                                          "TASK_ID" NVARCHAR2(255),
                                          "TASK_DEF_KEY" NVARCHAR2(255),
                                          "TASK_NAME" NVARCHAR2(255),
                                          "FORM_OPTION" NCLOB,
                                          "FORM_VARIABLE" NCLOB,
                                          "STATUS" NVARCHAR2(255),
                                          "CREATE_USER" NUMBER(20,0),
                                          "CREATE_TIME" DATE,
                                          "CREATE_DEPT" NUMBER(20,0),
                                          "UPDATE_USER" NUMBER(20,0),
                                          "UPDATE_TIME" DATE,
                                          "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                          "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."PROCESS_INS_ID" IS '流程实例id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."DEPLOYMENT_ID" IS '流程部署id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_ID" IS '任务id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_DEF_KEY" IS '任务节点key';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_NAME" IS '任务节点名称';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."FORM_OPTION" IS '表单js';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."FORM_VARIABLE" IS '表单值';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM_VARIABLE" IS '流程表单 - 历史变量';

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_VARIABLE
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_VARIABLE" ADD CONSTRAINT "SYS_C0012109" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_VARIABLE
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_VARIABLE" ADD CONSTRAINT "SYS_C0012108" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Table structure for BLADE_WF_LISTENER
-- ----------------------------
DROP TABLE "BLADE_WF_LISTENER";
CREATE TABLE "BLADE_WF_LISTENER" (
                                     "ID" NUMBER(20,0) NOT NULL,
                                     "NAME" NVARCHAR2(255),
                                     "CATEGORY" NVARCHAR2(255),
                                     "EVENT" NVARCHAR2(255),
                                     "TYPE" NVARCHAR2(255),
                                     "VAL" NVARCHAR2(255),
                                     "CREATE_USER" NUMBER(20,0),
                                     "CREATE_DEPT" NUMBER(20,0),
                                     "CREATE_TIME" DATE,
                                     "UPDATE_USER" NUMBER(20,0),
                                     "UPDATE_TIME" DATE,
                                     "STATUS" NUMBER(11,0),
                                     "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                     "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_LISTENER"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CATEGORY" IS '分类';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."EVENT" IS '事件';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."TYPE" IS '监听类型';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."VAL" IS '值';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_LISTENER" IS '任务/执行监听器';

-- ----------------------------
-- Primary Key structure for table BLADE_WF_LISTENER
-- ----------------------------
ALTER TABLE "BLADE_WF_LISTENER" ADD CONSTRAINT "SYS_C0011312" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_LISTENER
-- ----------------------------
ALTER TABLE "BLADE_WF_LISTENER" ADD CONSTRAINT "SYS_C0011311" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Table structure for BLADE_WF_MODEL_SCOPE
-- ----------------------------
CREATE TABLE "BLADE_WF_MODEL_SCOPE" (
                                        "ID" NUMBER(20,0) NOT NULL,
                                        "MODEL_ID" NVARCHAR2(255),
                                        "MODEL_KEY" NVARCHAR2(255),
                                        "TYPE" NVARCHAR2(255),
                                        "VAL" NVARCHAR2(255),
                                        "TEXT" NVARCHAR2(255)
)
;
COMMENT ON COLUMN "BLADE_WF_MODEL_SCOPE"."MODEL_ID" IS '模型id';
COMMENT ON COLUMN "BLADE_WF_MODEL_SCOPE"."MODEL_KEY" IS '模型key';
COMMENT ON COLUMN "BLADE_WF_MODEL_SCOPE"."TYPE" IS '类型 user用户 role角色 dept部门 post职位';
COMMENT ON COLUMN "BLADE_WF_MODEL_SCOPE"."VAL" IS '用户/角色/部门/职位 id集合';
COMMENT ON COLUMN "BLADE_WF_MODEL_SCOPE"."TEXT" IS '用户/角色/部门/职位 name集合';
COMMENT ON TABLE "BLADE_WF_MODEL_SCOPE" IS '流程模型权限';

-- ----------------------------
-- Records of BLADE_WF_MODEL_SCOPE
-- ----------------------------
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1418455767366799361', '2f6b3b6de24354bb5df5aad3a87789af', 'leave', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1418457955400978434', '0676f2277420b7dc67f69dd3a0ec1164', 'ex-leave', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1418457988913467393', '5b7a367e1139f1ab5cb1e6210685fa91', 'demo-multi-instance', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1418458020752429058', 'fb4c1a6a8c4588779a2519a547966846', 'test-default-values', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1429675430591442946', '89d9c299dfed64a7834fdb7caccc913f', 'field-linkage', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');
INSERT INTO "BLADE_WF_MODEL_SCOPE" ("ID", "MODEL_ID", "MODEL_KEY", "TYPE", "VAL", "TEXT") VALUES ('1447556025547763714', 'd71049b6ba4eda39cacf9baf984274ac', 'indep-form', 'role', '1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', '超级管理员,用户,人事,经理,老板');

-- ----------------------------
-- Table structure for BLADE_WF_PROCESS_LEAVE
-- ----------------------------
CREATE TABLE "BLADE_WF_PROCESS_LEAVE" (
                                          "ID" NUMBER(20,0) NOT NULL,
                                          "PROCESS_INS_ID" NVARCHAR2(64),
                                          "PROCESS_DEF_ID" NVARCHAR2(64),
                                          "CURRENT_NODE" NVARCHAR2(64),
                                          "DATETIME" NVARCHAR2(64),
                                          "DAYS" NUMBER(11,0),
                                          "REASON" NCLOB,
                                          "ATTACHMENT" NCLOB,
                                          "CREATE_USER" NUMBER(20,0),
                                          "CREATE_DEPT" NUMBER(20,0),
                                          "CREATE_TIME" DATE NOT NULL,
                                          "UPDATE_USER" NUMBER(20,0),
                                          "UPDATE_TIME" DATE,
                                          "STATUS" NUMBER(11,0),
                                          "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                          "FORM_KEY" VARCHAR(255),
                                          "FORM_URL" VARCHAR(255)
)
;
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."PROCESS_INS_ID" IS '流程实例id';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."PROCESS_DEF_ID" IS '流程定义id';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CURRENT_NODE" IS '当前节点';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."DATETIME" IS '时间范围';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."DAYS" IS '请假天数';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."REASON" IS '请假理由';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."ATTACHMENT" IS '附件';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."FORM_KEY" IS '外置表单key';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."FORM_URL" IS '外置表单url';
COMMENT ON TABLE "BLADE_WF_PROCESS_LEAVE" IS '请假流程业务示例';

-- ----------------------------
-- Table structure for BLADE_WF_PROXY
-- ----------------------------
CREATE TABLE "BLADE_WF_PROXY" (
                                  "ID" NUMBER(20,0) NOT NULL,
                                  "USER_ID" NUMBER(20,0),
                                  "PROXY_USER_ID" NUMBER(20,0),
                                  "PROCESS_DEF_KEY" NVARCHAR2(750),
                                  "TYPE" NVARCHAR2(255),
                                  "START_TIME" DATE,
                                  "END_TIME" DATE,
                                  "STATUS" NUMBER(11,0)
)
;
COMMENT ON COLUMN "BLADE_WF_PROXY"."USER_ID" IS '委托人';
COMMENT ON COLUMN "BLADE_WF_PROXY"."PROXY_USER_ID" IS '代理人';
COMMENT ON COLUMN "BLADE_WF_PROXY"."PROCESS_DEF_KEY" IS '流程定义key';
COMMENT ON COLUMN "BLADE_WF_PROXY"."TYPE" IS '1永久 2定时';
COMMENT ON COLUMN "BLADE_WF_PROXY"."START_TIME" IS '开始时间';
COMMENT ON COLUMN "BLADE_WF_PROXY"."END_TIME" IS '结束时间';
COMMENT ON COLUMN "BLADE_WF_PROXY"."STATUS" IS '状态';
COMMENT ON TABLE "BLADE_WF_PROXY" IS '流程代理';

-- ----------------------------
-- Table structure for BLADE_WF_SERIAL
-- ----------------------------
CREATE TABLE "BLADE_WF_SERIAL" (
                                   "ID" NUMBER(20,0) NOT NULL,
                                   "DEPLOYMENT_ID" NVARCHAR2(255),
                                   "NAME" NVARCHAR2(255),
                                   "PREFIX" NVARCHAR2(255),
                                   "DATE_FORMAT" NVARCHAR2(255),
                                   "SUFFIX_LENGTH" NUMBER(11,0),
                                   "START_SEQUENCE" NUMBER(11,0),
                                   "CONNECTOR" NVARCHAR2(255),
                                   "CURRENT_SEQUENCE" NUMBER(11,0),
                                   "CYCLE" NVARCHAR2(255),
                                   "CREATE_USER" NUMBER(20,0),
                                   "CREATE_DEPT" NUMBER(20,0),
                                   "CREATE_TIME" DATE,
                                   "UPDATE_USER" NUMBER(20,0),
                                   "UPDATE_TIME" DATE,
                                   "STATUS" NVARCHAR2(255),
                                   "IS_DELETED" NUMBER(11,0) DEFAULT 0
)
;
COMMENT ON COLUMN "BLADE_WF_SERIAL"."DEPLOYMENT_ID" IS '部署id';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."PREFIX" IS '前缀';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."DATE_FORMAT" IS '日期格式化';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."SUFFIX_LENGTH" IS '后缀位数';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."START_SEQUENCE" IS '初始数值';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CONNECTOR" IS '连接符';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CURRENT_SEQUENCE" IS '当前序列';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CYCLE" IS '重置周期 none不重置 day天 week周 month月 year年';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_SERIAL"."IS_DELETED" IS '是否已删除';
COMMENT ON TABLE "BLADE_WF_SERIAL" IS '流程流水号';

-- ----------------------------
-- Records of BLADE_WF_SERIAL
-- ----------------------------

-- ----------------------------
-- Checks structure for table ACT_DE_MODEL
-- ----------------------------
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012501" CHECK ("ID" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012502" CHECK ("NAME" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012503" CHECK ("MODEL_KEY" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012506" CHECK ("ID" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012507" CHECK ("NAME" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL" ADD CONSTRAINT "SYS_C0012508" CHECK ("MODEL_KEY" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table ACT_DE_MODEL_HISTORY
-- ----------------------------
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012382" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table ACT_DE_MODEL_HISTORY
-- ----------------------------
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012364" CHECK ("ID" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012365" CHECK ("NAME" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012366" CHECK ("MODEL_KEY" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012367" CHECK ("MODEL_ID" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012509" CHECK ("ID" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012510" CHECK ("NAME" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012511" CHECK ("MODEL_KEY" IS NOT NULL);
ALTER TABLE "ACT_DE_MODEL_HISTORY" ADD CONSTRAINT "SYS_C0012512" CHECK ("MODEL_ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_BUTTON
-- ----------------------------
ALTER TABLE "BLADE_WF_BUTTON" ADD CONSTRAINT "SYS_C0012384" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_BUTTON
-- ----------------------------
ALTER TABLE "BLADE_WF_BUTTON" ADD CONSTRAINT "SYS_C0012363" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_BUTTON" ADD CONSTRAINT "SYS_C0012513" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_CATEGORY
-- ----------------------------
ALTER TABLE "BLADE_WF_CATEGORY" ADD CONSTRAINT "SYS_C0012385" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_CATEGORY
-- ----------------------------
ALTER TABLE "BLADE_WF_CATEGORY" ADD CONSTRAINT "SYS_C0012371" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_CATEGORY" ADD CONSTRAINT "SYS_C0012514" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_CONDITION
-- ----------------------------
ALTER TABLE "BLADE_WF_CONDITION" ADD CONSTRAINT "SYS_C0012386" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_CONDITION
-- ----------------------------
ALTER TABLE "BLADE_WF_CONDITION" ADD CONSTRAINT "SYS_C0012372" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_CONDITION" ADD CONSTRAINT "SYS_C0012515" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_COPY
-- ----------------------------
ALTER TABLE "BLADE_WF_COPY" ADD CONSTRAINT "SYS_C0012387" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_COPY
-- ----------------------------
ALTER TABLE "BLADE_WF_COPY" ADD CONSTRAINT "SYS_C0012373" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_COPY" ADD CONSTRAINT "SYS_C0012516" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_DEPLOYMENT_FORM
-- ----------------------------
ALTER TABLE "BLADE_WF_DEPLOYMENT_FORM" ADD CONSTRAINT "SYS_C0012388" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_DEPLOYMENT_FORM
-- ----------------------------
ALTER TABLE "BLADE_WF_DEPLOYMENT_FORM" ADD CONSTRAINT "SYS_C0012374" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_DEPLOYMENT_FORM" ADD CONSTRAINT "SYS_C0012517" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_DRAFT
-- ----------------------------
ALTER TABLE "BLADE_WF_DRAFT" ADD CONSTRAINT "SYS_C0012389" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_DRAFT
-- ----------------------------
ALTER TABLE "BLADE_WF_DRAFT" ADD CONSTRAINT "SYS_C0012375" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_DRAFT" ADD CONSTRAINT "SYS_C0012518" CHECK ("ID" IS NOT NULL);

CREATE UNIQUE INDEX "WF_IDX_DRAFT_UNI"
    ON "BLADE_WF_DRAFT" ("USER_ID", "PROCESS_DEF_ID", "PLATFORM");

CREATE UNIQUE INDEX "WF_IDX_DRAFT_UNI2"
    ON "BLADE_WF_DRAFT" ("USER_ID", "TASK_ID", "PLATFORM");

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM" ADD CONSTRAINT "SYS_C0012390" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM" ADD CONSTRAINT "SYS_C0012376" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_FORM" ADD CONSTRAINT "SYS_C0012519" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Indexes structure for table BLADE_WF_FORM
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_FORM_KEY"
    ON "BLADE_WF_FORM" ("FORM_KEY" ASC, "TENANT_ID" ASC);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_DEFAULT_VALUES
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_DEFAULT_VALUES" ADD CONSTRAINT "SYS_C0012391" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_DEFAULT_VALUES
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_DEFAULT_VALUES" ADD CONSTRAINT "SYS_C0012377" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_FORM_DEFAULT_VALUES" ADD CONSTRAINT "SYS_C0012520" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_HISTORY
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_HISTORY" ADD CONSTRAINT "SYS_C0012392" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_HISTORY
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_HISTORY" ADD CONSTRAINT "SYS_C0012378" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_FORM_HISTORY" ADD CONSTRAINT "SYS_C0012521" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_MODEL_SCOPE
-- ----------------------------
ALTER TABLE "BLADE_WF_MODEL_SCOPE" ADD CONSTRAINT "SYS_C0012393" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_MODEL_SCOPE
-- ----------------------------
ALTER TABLE "BLADE_WF_MODEL_SCOPE" ADD CONSTRAINT "SYS_C0012379" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_MODEL_SCOPE" ADD CONSTRAINT "SYS_C0012522" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_PROCESS_LEAVE
-- ----------------------------
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013052" PRIMARY KEY ("ID", "CREATE_TIME");

-- ----------------------------
-- Checks structure for table BLADE_WF_PROCESS_LEAVE
-- ----------------------------
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013050" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013051" CHECK ("CREATE_TIME" IS NOT NULL);

-- ----------------------------
-- Primary Key structure for table BLADE_WF_PROXY
-- ----------------------------
ALTER TABLE "BLADE_WF_PROXY" ADD CONSTRAINT "SYS_C0013053" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_PROXY
-- ----------------------------
ALTER TABLE "BLADE_WF_PROXY" ADD CONSTRAINT "SYS_C0013049" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Indexes structure for table BLADE_WF_PROXY
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_UNI_PROXY"
    ON "BLADE_WF_PROXY" ("USER_ID" ASC, "PROCESS_DEF_KEY" ASC);
-- ----------------------------
-- Primary Key structure for table BLADE_WF_SERIAL
-- ----------------------------
ALTER TABLE "BLADE_WF_SERIAL" ADD CONSTRAINT "SYS_C0012394" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_SERIAL
-- ----------------------------
ALTER TABLE "BLADE_WF_SERIAL" ADD CONSTRAINT "SYS_C0012380" CHECK ("ID" IS NOT NULL);
ALTER TABLE "BLADE_WF_SERIAL" ADD CONSTRAINT "SYS_C0012523" CHECK ("ID" IS NOT NULL);

-- ----------------------------
-- Indexes structure for table BLADE_WF_SERIAL
-- ----------------------------
CREATE UNIQUE INDEX "UNI"
    ON "BLADE_WF_SERIAL" ("DEPLOYMENT_ID" ASC);
