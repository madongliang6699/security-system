-- ----------------------------
-- Table structure for BLADE_WF_LISTENER
-- ----------------------------
DROP TABLE "BLADE_WF_LISTENER";
CREATE TABLE "BLADE_WF_LISTENER" (
                                     "ID" NUMBER(20,0) NOT NULL,
                                     "NAME" NVARCHAR2(255),
                                     "CATEGORY" NVARCHAR2(255),
                                     "EVENT" NVARCHAR2(255),
                                     "TYPE" NVARCHAR2(255),
                                     "VAL" NVARCHAR2(255),
                                     "CREATE_USER" NUMBER(20,0),
                                     "CREATE_DEPT" NUMBER(20,0),
                                     "CREATE_TIME" DATE,
                                     "UPDATE_USER" NUMBER(20,0),
                                     "UPDATE_TIME" DATE,
                                     "STATUS" NUMBER(11,0),
                                     "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                     "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_LISTENER"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CATEGORY" IS '分类';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."EVENT" IS '事件';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."TYPE" IS '监听类型';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."VAL" IS '值';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_LISTENER"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_LISTENER" IS '任务/执行监听器';

-- ----------------------------
-- Primary Key structure for table BLADE_WF_LISTENER
-- ----------------------------
ALTER TABLE "BLADE_WF_LISTENER" ADD CONSTRAINT "SYS_C0011312" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_LISTENER
-- ----------------------------
ALTER TABLE "BLADE_WF_LISTENER" ADD CONSTRAINT "SYS_C0011311" CHECK ("ID" IS NOT NULL);
