-- ----------------------------
-- Table structure for BLADE_WF_FORM_VARIABLE
-- ----------------------------
DROP TABLE "BLADE_WF_FORM_VARIABLE";
CREATE TABLE "BLADE_WF_FORM_VARIABLE" (
                                                        "ID" NUMBER(20,0) NOT NULL,
                                                        "PROCESS_INS_ID" NVARCHAR2(255),
                                                        "DEPLOYMENT_ID" NVARCHAR2(255),
                                                        "TASK_ID" NVARCHAR2(255),
                                                        "TASK_DEF_KEY" NVARCHAR2(255),
                                                        "TASK_NAME" NVARCHAR2(255),
                                                        "FORM_OPTION" NCLOB,
                                                        "FORM_VARIABLE" NCLOB,
                                                        "STATUS" NVARCHAR2(255),
                                                        "CREATE_USER" NUMBER(20,0),
                                                        "CREATE_TIME" DATE,
                                                        "CREATE_DEPT" NUMBER(20,0),
                                                        "UPDATE_USER" NUMBER(20,0),
                                                        "UPDATE_TIME" DATE,
                                                        "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                                        "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
;
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."PROCESS_INS_ID" IS '流程实例id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."DEPLOYMENT_ID" IS '流程部署id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_ID" IS '任务id';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_DEF_KEY" IS '任务节点key';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TASK_NAME" IS '任务节点名称';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."FORM_OPTION" IS '表单js';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."FORM_VARIABLE" IS '表单值';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM_VARIABLE"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM_VARIABLE" IS '流程表单 - 历史变量';

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_VARIABLE
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_VARIABLE" ADD CONSTRAINT "SYS_C0012109" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_VARIABLE
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_VARIABLE" ADD CONSTRAINT "SYS_C0012108" CHECK ("ID" IS NOT NULL);
