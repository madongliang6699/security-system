SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blade_wf_form_theme
-- ----------------------------
DROP TABLE IF EXISTS `blade_wf_form_theme`;
CREATE TABLE `blade_wf_form_theme` (
                                       `id` bigint(64) NOT NULL,
                                       `name` varchar(255) NOT NULL COMMENT '名称',
                                       `theme_key` varchar(255) NOT NULL COMMENT '主题key',
                                       `border_width` varchar(255) DEFAULT NULL COMMENT '边框宽度',
                                       `border_color` varchar(255) DEFAULT NULL COMMENT '边框颜色',
                                       `label_color` varchar(255) DEFAULT NULL COMMENT 'label字体颜色',
                                       `label_bg` varchar(255) DEFAULT NULL COMMENT 'label背景颜色',
                                       `label_width` varchar(255) DEFAULT NULL COMMENT 'label宽度',
                                       `label_font_size` varchar(255) DEFAULT NULL COMMENT 'label字体大小',
                                       `value_color` varchar(255) DEFAULT NULL COMMENT 'value字体颜色',
                                       `value_bg` varchar(255) DEFAULT NULL COMMENT 'value背景颜色',
                                       `value_font_size` varchar(255) DEFAULT NULL COMMENT 'value字体大小',
                                       `field0` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field1` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field2` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field3` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field4` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field5` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field6` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field7` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field8` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `field9` varchar(255) DEFAULT NULL COMMENT '预留字段',
                                       `create_user` bigint(64) DEFAULT NULL COMMENT '创建人',
                                       `create_dept` bigint(64) DEFAULT NULL COMMENT '创建部门',
                                       `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                       `update_user` bigint(64) DEFAULT NULL COMMENT '修改人',
                                       `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                       `status` int(11) DEFAULT NULL COMMENT '状态',
                                       `is_deleted` int(2) DEFAULT '0' COMMENT '是否已删除',
                                       `tenant_id` varchar(12) DEFAULT '000000' COMMENT '租户ID',
                                       PRIMARY KEY (`id`) USING BTREE,
                                       UNIQUE KEY `WF_IDX_THEME_KEY` (`theme_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='流程表单 - 主题';

-- ----------------------------
-- Records of blade_wf_form_theme
-- ----------------------------
BEGIN;
INSERT INTO `blade_wf_form_theme` (`id`, `name`, `theme_key`, `border_width`, `border_color`, `label_color`, `label_bg`, `label_width`, `label_font_size`, `value_color`, `value_bg`, `value_font_size`, `field0`, `field1`, `field2`, `field3`, `field4`, `field5`, `field6`, `field7`, `field8`, `field9`, `create_user`, `create_dept`, `create_time`, `update_user`, `update_time`, `status`, `is_deleted`, `tenant_id`) VALUES (1, '蓝色', 'blue', '1px', '#cbdcf0', '#01418a', '#eef6ff', '', '14px', '', '', '14px', '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598813738675201, '2023-04-04 15:36:46', 1123598821738675201, '2023-05-04 10:43:18', 1, 0, '000000');
INSERT INTO `blade_wf_form_theme` (`id`, `name`, `theme_key`, `border_width`, `border_color`, `label_color`, `label_bg`, `label_width`, `label_font_size`, `value_color`, `value_bg`, `value_font_size`, `field0`, `field1`, `field2`, `field3`, `field4`, `field5`, `field6`, `field7`, `field8`, `field9`, `create_user`, `create_dept`, `create_time`, `update_user`, `update_time`, `status`, `is_deleted`, `tenant_id`) VALUES (2, '默认', 'default', '1px', 'rgba(235, 238, 245, 1)', 'rgba(144, 147, 153, 1)', 'rgba(250, 250, 250, 1)', NULL, NULL, 'rgba(96, 98, 102, 1)', 'rgba(255, 255, 255, 1)', NULL, '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598813738675201, '2023-04-04 15:16:47', 1123598821738675201, '2023-04-18 11:50:10', 1, 0, '000000');
INSERT INTO `blade_wf_form_theme` (`id`, `name`, `theme_key`, `border_width`, `border_color`, `label_color`, `label_bg`, `label_width`, `label_font_size`, `value_color`, `value_bg`, `value_font_size`, `field0`, `field1`, `field2`, `field3`, `field4`, `field5`, `field6`, `field7`, `field8`, `field9`, `create_user`, `create_dept`, `create_time`, `update_user`, `update_time`, `status`, `is_deleted`, `tenant_id`) VALUES (3, '黑色', 'black', '1px', 'rgba(0, 0, 0, 1)', '#000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598821738675201, '2023-04-04 16:57:35', 1123598821738675201, '2023-05-04 10:43:44', 1, 0, '000000');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
