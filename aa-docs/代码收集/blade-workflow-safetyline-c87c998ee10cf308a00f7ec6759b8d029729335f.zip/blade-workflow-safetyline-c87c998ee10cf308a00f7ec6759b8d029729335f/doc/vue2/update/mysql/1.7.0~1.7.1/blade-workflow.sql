ALTER TABLE `blade_wf_copy`
    ADD COLUMN `deployment_id` varchar(255) NULL COMMENT '流程部署id' AFTER `process_id`;

ALTER TABLE `ACT_DE_MODEL`
    CHANGE COLUMN `xml` `model_xml` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '模型XML' AFTER `version`;

ALTER TABLE `ACT_DE_MODEL_HISTORY`
    CHANGE COLUMN `xml` `model_xml` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '模型XML' AFTER `version`;
