SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blade_wf_listener
-- ----------------------------
DROP TABLE IF EXISTS `blade_wf_listener`;
CREATE TABLE `blade_wf_listener` (
                                     `id` bigint(64) NOT NULL,
                                     `name` varchar(255) DEFAULT NULL COMMENT '名称',
                                     `category` varchar(255) DEFAULT NULL COMMENT '分类',
                                     `event` varchar(255) DEFAULT NULL COMMENT '事件',
                                     `type` varchar(255) DEFAULT NULL COMMENT '监听类型',
                                     `val` varchar(255) DEFAULT NULL COMMENT '值',
                                     `create_user` bigint(64) DEFAULT NULL COMMENT '创建人',
                                     `create_dept` bigint(64) DEFAULT NULL COMMENT '创建部门',
                                     `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                     `update_user` bigint(64) DEFAULT NULL COMMENT '修改人',
                                     `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                     `status` int(11) DEFAULT NULL COMMENT '状态',
                                     `is_deleted` int(2) DEFAULT '0' COMMENT '是否已删除',
                                     `tenant_id` varchar(12) DEFAULT '000000' COMMENT '租户ID',
                                     PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='任务/执行监听器';

SET FOREIGN_KEY_CHECKS = 1;
