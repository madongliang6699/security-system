ALTER TABLE `blade_wf_draft`
    ADD COLUMN `task_id` varchar(255) NULL COMMENT '任务id' AFTER `process_def_id`,
ADD UNIQUE INDEX `WF_IDX_DRAFT_UNI2`(`user_id`, `task_id`, `platform`) USING BTREE;
