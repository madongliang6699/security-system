ALTER TABLE `blade_wf_process_leave`
    ADD COLUMN `form_key` varchar(255) NULL COMMENT '外置表单key' AFTER `is_deleted`,
    ADD COLUMN `form_url` varchar(255) NULL COMMENT '外置表单url' AFTER `form_key`;
