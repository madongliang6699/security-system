SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blade_wf_form_variable
-- ----------------------------
DROP TABLE IF EXISTS `blade_wf_form_variable`;
CREATE TABLE `blade_wf_form_variable` (
                                          `id` bigint(64) NOT NULL,
                                          `process_ins_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '流程实例id',
                                          `deployment_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '流程部署id',
                                          `task_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务id',
                                          `task_def_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务节点key',
                                          `task_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务节点名称',
                                          `form_option` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '表单js',
                                          `form_variable` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '表单值',
                                          `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '状态',
                                          `create_user` bigint(64) DEFAULT NULL COMMENT '创建人',
                                          `create_time` datetime DEFAULT NULL COMMENT '创建时间',
                                          `create_dept` bigint(64) DEFAULT NULL COMMENT '创建部门',
                                          `update_user` bigint(64) DEFAULT NULL COMMENT '修改人',
                                          `update_time` datetime DEFAULT NULL COMMENT '修改时间',
                                          `is_deleted` int(2) DEFAULT '0' COMMENT '是否已删除',
                                          `tenant_id` varchar(12) DEFAULT '000000' COMMENT '租户ID',
                                          PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='流程表单 - 历史变量';

-- ----------------------------
-- Records of blade_wf_form_variable
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
