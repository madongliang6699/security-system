-- ----------------------------
-- Table structure for BLADE_WF_FORM_THEME
-- ----------------------------
DROP TABLE "BLADE_WF_FORM_THEME";
CREATE TABLE "BLADE_WF_FORM_THEME" (
                                                     "ID" NUMBER(20,0) NOT NULL,
                                                     "NAME" NVARCHAR2(255) NOT NULL,
                                                     "THEME_KEY" NVARCHAR2(255) NOT NULL,
                                                     "BORDER_WIDTH" NVARCHAR2(255),
                                                     "BORDER_COLOR" NVARCHAR2(255),
                                                     "LABEL_COLOR" NVARCHAR2(255),
                                                     "LABEL_BG" NVARCHAR2(255),
                                                     "LABEL_WIDTH" NVARCHAR2(255),
                                                     "LABEL_FONT_SIZE" NVARCHAR2(255),
                                                     "VALUE_COLOR" NVARCHAR2(255),
                                                     "VALUE_BG" NVARCHAR2(255),
                                                     "VALUE_FONT_SIZE" NVARCHAR2(255),
                                                     "FIELD0" NVARCHAR2(255),
                                                     "FIELD1" NVARCHAR2(255),
                                                     "FIELD2" NVARCHAR2(255),
                                                     "FIELD3" NVARCHAR2(255),
                                                     "FIELD4" NVARCHAR2(255),
                                                     "FIELD5" NVARCHAR2(255),
                                                     "FIELD6" NVARCHAR2(255),
                                                     "FIELD7" NVARCHAR2(255),
                                                     "FIELD8" NVARCHAR2(255),
                                                     "FIELD9" NVARCHAR2(255),
                                                     "CREATE_USER" NUMBER(20,0),
                                                     "CREATE_DEPT" NUMBER(20,0),
                                                     "CREATE_TIME" DATE,
                                                     "UPDATE_USER" NUMBER(20,0),
                                                     "UPDATE_TIME" DATE,
                                                     "STATUS" NUMBER(11,0),
                                                     "IS_DELETED" NUMBER(11,0) DEFAULT 0,
                                                     "TENANT_ID" NVARCHAR2(12) DEFAULT '000000'
)
    LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  INITIAL 65536
  NEXT 1048576
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."NAME" IS '名称';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."THEME_KEY" IS '主题key';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."BORDER_WIDTH" IS '边框宽度';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."BORDER_COLOR" IS '边框颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_COLOR" IS 'label字体颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_BG" IS 'label背景颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_WIDTH" IS 'label宽度';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."LABEL_FONT_SIZE" IS 'label字体大小';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_COLOR" IS 'value字体颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_BG" IS 'value背景颜色';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."VALUE_FONT_SIZE" IS 'value字体大小';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD0" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD1" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD2" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD3" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD4" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD5" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD6" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD7" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD8" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."FIELD9" IS '预留字段';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."IS_DELETED" IS '是否已删除';
COMMENT ON COLUMN "BLADE_WF_FORM_THEME"."TENANT_ID" IS '租户ID';
COMMENT ON TABLE "BLADE_WF_FORM_THEME" IS '流程表单 - 主题';

-- ----------------------------
-- Records of BLADE_WF_FORM_THEME
-- ----------------------------
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('1', '蓝色', 'blue', '1px', '#cbdcf0', '#01418a', '#eef6ff', NULL, '14px', NULL, NULL, '14px', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2023-04-04 15:36:46', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-05-04 10:43:18', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('2', '默认', 'default', '1px', 'rgba(235, 238, 245, 1)', 'rgba(144, 147, 153, 1)', 'rgba(250, 250, 250, 1)', NULL, NULL, 'rgba(96, 98, 102, 1)', 'rgba(255, 255, 255, 1)', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598813738675201', TO_DATE('2023-04-04 15:16:47', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-04-18 11:50:10', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
INSERT INTO "BLADE_WF_FORM_THEME" ("ID", "NAME", "THEME_KEY", "BORDER_WIDTH", "BORDER_COLOR", "LABEL_COLOR", "LABEL_BG", "LABEL_WIDTH", "LABEL_FONT_SIZE", "VALUE_COLOR", "VALUE_BG", "VALUE_FONT_SIZE", "FIELD0", "FIELD1", "FIELD2", "FIELD3", "FIELD4", "FIELD5", "FIELD6", "FIELD7", "FIELD8", "FIELD9", "CREATE_USER", "CREATE_DEPT", "CREATE_TIME", "UPDATE_USER", "UPDATE_TIME", "STATUS", "IS_DELETED", "TENANT_ID") VALUES ('3', '黑色', 'black', '1px', 'rgba(0, 0, 0, 1)', '#000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1123598821738675201', '1123598821738675201', TO_DATE('2023-04-04 16:57:35', 'SYYYY-MM-DD HH24:MI:SS'), '1123598821738675201', TO_DATE('2023-05-04 10:43:44', 'SYYYY-MM-DD HH24:MI:SS'), '1', '0', '000000');
COMMIT;
COMMIT;

-- ----------------------------
-- Primary Key structure for table BLADE_WF_FORM_THEME
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011945" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_FORM_THEME
-- ----------------------------
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011942" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011943" CHECK ("NAME" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
ALTER TABLE "BLADE_WF_FORM_THEME" ADD CONSTRAINT "SYS_C0011944" CHECK ("THEME_KEY" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;

-- ----------------------------
-- Indexes structure for table BLADE_WF_FORM_THEME
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_THEME_KEY"
    ON "BLADE_WF_FORM_THEME" ("THEME_KEY" ASC)
    LOGGING
  VISIBLE
PCTFREE 10
INITRANS 2
STORAGE (
  INITIAL 65536
  NEXT 1048576
  MINEXTENTS 1
  MAXEXTENTS 2147483645
  BUFFER_POOL DEFAULT
);
