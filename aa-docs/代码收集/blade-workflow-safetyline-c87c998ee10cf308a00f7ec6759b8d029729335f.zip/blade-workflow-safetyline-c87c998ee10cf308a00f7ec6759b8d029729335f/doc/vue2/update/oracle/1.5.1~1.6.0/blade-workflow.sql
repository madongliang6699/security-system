
-- 请先查看升级指南1.6，再确定是否执行这一段注释的SQL
-- UPDATE "BLADE_WF_FORM" SET "FORM_KEY" = 'leave', "NAME" = '请假流程表单', "CONTENT" = '{column:[{type:''input'',label:''创建人'',span:12,display:true,prop:''creator'',value:''${this.$store.getters.userInfo.nick_name}'',readonly:true},{type:''input'',label:''创建部门'',span:12,display:true,prop:''creatorDept'',value:''${this.$store.getters.userInfo.dept_name}'',readonly:true},{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''yyyy-MM-dd HH:mm:ss'',valueFormat:''yyyy-MM-dd HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''请假时间必须填写''}],change:({value}) => {
--   if (!value || value.length == 0) {
--     this.$set(this.form, ''days'', undefined)
--   } else {
--     const d1 = Date.parse(value.split('','')[0])
--     const d2 = Date.parse(value.split('','')[1])
--     const day = (d2-d1)/(1*24*60*60*1000)
--     this.$set(this.form, ''days'', Number(day.toFixed(2)))
--   }
-- },dataType:''string''},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
--   if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )
--   else this.$set(this.form, ''reason'', '''')
-- }},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]},{label:''附件'',type:''upload'',propsHttp:{res:''data'',url:''link'',name:''originalName''},action:''/api/blade-resource/oss/endpoint/put-file'',display:true,span:24,showFileList:true,multiple:true,limit:10,prop:''attachment'',dataType:''string''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', "APP_CONTENT" = '{"column":[{"type":"input","label":"创建人","span":12,"display":true,"prop":"creator","value":"${this.$store.getters.userInfo.nick_name}","readonly":true},{"type":"input","label":"创建部门","span":12,"display":true,"prop":"creatorDept","value":"${this.$store.getters.userInfo.dept_name}","readonly":true},{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"yyyy-MM-dd HH:mm:ss","valueFormat":"yyyy-MM-dd HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"请假时间必须填写"}],"change":"({value}) => {\r\n  if (!value || value.length == 0) {\r\n    this.$set(this.form, ''days'', undefined)\r\n  } else {\r\n    const d1 = Date.parse(value.split('','')[0])\r\n    const d2 = Date.parse(value.split('','')[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    this.$set(this.form, ''days'', Number(day.toFixed(2)))\r\n  }\r\n}","dataType":"string"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\n  if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )\n  else this.$set(this.form, ''reason'', '''')\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]},{"label":"附件","type":"upload","propsHttp":{"res":"data","url":"link","name":"originalName"},"action":"/api/blade-resource/oss/endpoint/put-file","display":true,"span":24,"showFileList":true,"multiple":true,"limit":10,"prop":"attachment","dataType":"string"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', "VERSION" = '1', "CATEGORY_ID" = '-1', "REMARK" = NULL, "CREATE_USER" = '1123598821738675201', "CREATE_DEPT" = '1123598813738675201', "CREATE_TIME" = TO_DATE('2021-06-01 22:06:20', 'SYYYY-MM-DD HH24:MI:SS'), "UPDATE_USER" = '1123598821738675201', "UPDATE_TIME" = TO_DATE('2022-04-12 10:27:07', 'SYYYY-MM-DD HH24:MI:SS'), "STATUS" = '1', "IS_DELETED" = '0', "TENANT_ID" = '000000' WHERE "ID" = '1399729025840140290';

-- ----------------------------
-- Table structure for BLADE_WF_PROCESS_LEAVE
-- ----------------------------
DROP TABLE "BLADE_WF_PROCESS_LEAVE";
CREATE TABLE "BLADE_WF_PROCESS_LEAVE" (
                                                        "ID" NUMBER(20,0) NOT NULL,
                                                        "PROCESS_INS_ID" NVARCHAR2(64),
                                                        "PROCESS_DEF_ID" NVARCHAR2(64),
                                                        "CURRENT_NODE" NVARCHAR2(64),
                                                        "DATETIME" NVARCHAR2(64),
                                                        "DAYS" NUMBER(11,0),
                                                        "REASON" NCLOB,
                                                        "ATTACHMENT" NCLOB,
                                                        "CREATE_USER" NUMBER(20,0),
                                                        "CREATE_DEPT" NUMBER(20,0),
                                                        "CREATE_TIME" DATE NOT NULL,
                                                        "UPDATE_USER" NUMBER(20,0),
                                                        "UPDATE_TIME" DATE,
                                                        "STATUS" NUMBER(11,0),
                                                        "IS_DELETED" NUMBER(11,0) DEFAULT 0
)
    LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."PROCESS_INS_ID" IS '流程实例id';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."PROCESS_DEF_ID" IS '流程定义id';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CURRENT_NODE" IS '当前节点';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."DATETIME" IS '时间范围';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."DAYS" IS '请假天数';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."REASON" IS '请假理由';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."ATTACHMENT" IS '附件';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_USER" IS '创建人';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_DEPT" IS '创建部门';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."CREATE_TIME" IS '创建时间';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."UPDATE_USER" IS '修改人';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."UPDATE_TIME" IS '修改时间';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."STATUS" IS '状态';
COMMENT ON COLUMN "BLADE_WF_PROCESS_LEAVE"."IS_DELETED" IS '是否已删除';
COMMENT ON TABLE "BLADE_WF_PROCESS_LEAVE" IS '请假流程业务示例';

-- ----------------------------
-- Table structure for BLADE_WF_PROXY
-- ----------------------------
DROP TABLE "BLADE_WF_PROXY";
CREATE TABLE "BLADE_WF_PROXY" (
                                                "ID" NUMBER(20,0) NOT NULL,
                                                "USER_ID" NUMBER(20,0),
                                                "PROXY_USER_ID" NUMBER(20,0),
                                                "PROCESS_DEF_KEY" NVARCHAR2(750),
                                                "TYPE" NVARCHAR2(255),
                                                "START_TIME" DATE,
                                                "END_TIME" DATE,
                                                "STATUS" NUMBER(11,0)
)
    LOGGING
NOCOMPRESS
PCTFREE 10
INITRANS 1
STORAGE (
  BUFFER_POOL DEFAULT
)
PARALLEL 1
NOCACHE
DISABLE ROW MOVEMENT
;
COMMENT ON COLUMN "BLADE_WF_PROXY"."USER_ID" IS '委托人';
COMMENT ON COLUMN "BLADE_WF_PROXY"."PROXY_USER_ID" IS '代理人';
COMMENT ON COLUMN "BLADE_WF_PROXY"."PROCESS_DEF_KEY" IS '流程定义key';
COMMENT ON COLUMN "BLADE_WF_PROXY"."TYPE" IS '1永久 2定时';
COMMENT ON COLUMN "BLADE_WF_PROXY"."START_TIME" IS '开始时间';
COMMENT ON COLUMN "BLADE_WF_PROXY"."END_TIME" IS '结束时间';
COMMENT ON COLUMN "BLADE_WF_PROXY"."STATUS" IS '状态';
COMMENT ON TABLE "BLADE_WF_PROXY" IS '流程代理';

-- ----------------------------
-- Primary Key structure for table BLADE_WF_PROCESS_LEAVE
-- ----------------------------
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013052" PRIMARY KEY ("ID", "CREATE_TIME");

-- ----------------------------
-- Checks structure for table BLADE_WF_PROCESS_LEAVE
-- ----------------------------
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013050" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;
ALTER TABLE "BLADE_WF_PROCESS_LEAVE" ADD CONSTRAINT "SYS_C0013051" CHECK ("CREATE_TIME" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;

-- ----------------------------
-- Primary Key structure for table BLADE_WF_PROXY
-- ----------------------------
ALTER TABLE "BLADE_WF_PROXY" ADD CONSTRAINT "SYS_C0013053" PRIMARY KEY ("ID");

-- ----------------------------
-- Checks structure for table BLADE_WF_PROXY
-- ----------------------------
ALTER TABLE "BLADE_WF_PROXY" ADD CONSTRAINT "SYS_C0013049" CHECK ("ID" IS NOT NULL) NOT DEFERRABLE INITIALLY IMMEDIATE NORELY VALIDATE;

-- ----------------------------
-- Indexes structure for table BLADE_WF_PROXY
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_UNI_PROXY"
    ON "BLADE_WF_PROXY" ("USER_ID" ASC, "PROCESS_DEF_KEY" ASC)
    LOGGING
  VISIBLE
PCTFREE 10
INITRANS 2
STORAGE (
  BUFFER_POOL DEFAULT
);
CREATE INDEX "WF_IDX_USER_ID"
    ON "BLADE_WF_PROXY" ("USER_ID" ASC)
    LOGGING
  VISIBLE
PCTFREE 10
INITRANS 2
STORAGE (
  BUFFER_POOL DEFAULT
);
