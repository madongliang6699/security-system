ALTER TABLE [dbo].[blade_wf_copy] ADD [deployment_id] nvarchar(255)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'deployment_id';

EXEC sp_rename '[dbo].[ACT_DE_MODEL].[xml]', 'model_xml', 'COLUMN'
GO

IF ((SELECT COUNT(*) FROM ::fn_listextendedproperty('MS_Description',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL',
'COLUMN', N'model_xml')) > 0)
  EXEC sp_updateextendedproperty
'MS_Description', N'模型XML',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL',
'COLUMN', N'model_xml'
ELSE
  EXEC sp_addextendedproperty
'MS_Description', N'模型XML',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL',
'COLUMN', N'model_xml';

EXEC sp_rename '[dbo].[ACT_DE_MODEL_HISTORY].[xml]', 'model_xml', 'COLUMN'
GO

IF ((SELECT COUNT(*) FROM ::fn_listextendedproperty('MS_Description',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL_HISTORY',
'COLUMN', N'model_xml')) > 0)
  EXEC sp_updateextendedproperty
'MS_Description', N'模型XML',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL_HISTORY',
'COLUMN', N'model_xml'
ELSE
  EXEC sp_addextendedproperty
'MS_Description', N'模型XML',
'SCHEMA', N'dbo',
'TABLE', N'ACT_DE_MODEL_HISTORY',
'COLUMN', N'model_xml';
