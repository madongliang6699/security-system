-- ----------------------------
-- Table structure for blade_wf_form_theme
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_theme]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_theme]
    GO

CREATE TABLE [dbo].[blade_wf_form_theme] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [theme_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [border_width] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [border_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_bg] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_width] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_font_size] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_bg] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_font_size] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field0] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field1] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field2] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field3] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field4] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field5] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field6] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field7] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field8] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field9] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_theme] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'主题key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'theme_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'边框宽度',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'border_width'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'边框颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'border_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label字体颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label背景颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_bg'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label宽度',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_width'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label字体大小',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_font_size'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value字体颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value背景颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_bg'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value字体大小',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_font_size'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field0'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field1'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field2'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field3'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field4'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field5'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field6'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field7'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field8'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field9'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单 - 主题',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme'
    GO


-- ----------------------------
-- Records of blade_wf_form_theme
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1', N'蓝色', N'blue', N'1px', N'#cbdcf0', N'#01418a', N'#eef6ff', N'', N'14px', N'', N'', N'14px', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598813738675201', N'2023-04-04 15:36:46.0000000', N'1123598821738675201', N'2023-05-04 10:43:18.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'2', N'默认', N'default', N'1px', N'rgba(235, 238, 245, 1)', N'rgba(144, 147, 153, 1)', N'rgba(250, 250, 250, 1)', NULL, NULL, N'rgba(96, 98, 102, 1)', N'rgba(255, 255, 255, 1)', NULL, N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598813738675201', N'2023-04-04 15:16:47.0000000', N'1123598821738675201', N'2023-04-18 11:50:10.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'3', N'黑色', N'black', N'1px', N'rgba(0, 0, 0, 1)', N'#000', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598821738675201', N'2023-04-04 16:57:35.0000000', N'1123598821738675201', N'2023-05-04 10:43:44.0000000', N'1', N'0', N'000000')
GO

COMMIT
GO


-- ----------------------------
-- Indexes structure for table blade_wf_form_theme
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_THEME_KEY]
ON [dbo].[blade_wf_form_theme] (
  [theme_key] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_theme
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_theme] ADD CONSTRAINT [PK__blade_wf__3213E83FE1B9E59C] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

