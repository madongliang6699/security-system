
-- 请先查看升级指南1.6，再确定是否执行这一段注释的SQL
-- UPDATE [dbo].[blade_wf_form] SET [form_key] = N'leave', [name] = N'请假流程表单', [content] = N'{column:[{type:''input'',label:''创建人'',span:12,display:true,prop:''creator'',value:''${this.$store.getters.userInfo.nick_name}'',readonly:true},{type:''input'',label:''创建部门'',span:12,display:true,prop:''creatorDept'',value:''${this.$store.getters.userInfo.dept_name}'',readonly:true},{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''yyyy-MM-dd HH:mm:ss'',valueFormat:''yyyy-MM-dd HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''请假时间必须填写''}],change:({value}) => {
--   if (!value || value.length == 0) {
--     this.$set(this.form, ''days'', undefined)
--   } else {
--     const d1 = Date.parse(value.split('','')[0])
--     const d2 = Date.parse(value.split('','')[1])
--     const day = (d2-d1)/(1*24*60*60*1000)
--     this.$set(this.form, ''days'', Number(day.toFixed(2)))
--   }
-- },dataType:''string''},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
--   if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )
--   else this.$set(this.form, ''reason'', '''')
-- }},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]},{label:''附件'',type:''upload'',propsHttp:{res:''data'',url:''link'',name:''originalName''},action:''/api/blade-resource/oss/endpoint/put-file'',display:true,span:24,showFileList:true,multiple:true,limit:10,prop:''attachment'',dataType:''string''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', [app_content] = N'{"column":[{"type":"input","label":"创建人","span":12,"display":true,"prop":"creator","value":"${this.$store.getters.userInfo.nick_name}","readonly":true},{"type":"input","label":"创建部门","span":12,"display":true,"prop":"creatorDept","value":"${this.$store.getters.userInfo.dept_name}","readonly":true},{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"yyyy-MM-dd HH:mm:ss","valueFormat":"yyyy-MM-dd HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"请假时间必须填写"}],"change":"({value}) => {\r\n  if (!value || value.length == 0) {\r\n    this.$set(this.form, ''days'', undefined)\r\n  } else {\r\n    const d1 = Date.parse(value.split('','')[0])\r\n    const d2 = Date.parse(value.split('','')[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    this.$set(this.form, ''days'', Number(day.toFixed(2)))\r\n  }\r\n}","dataType":"string"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\n  if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )\n  else this.$set(this.form, ''reason'', '''')\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]},{"label":"附件","type":"upload","propsHttp":{"res":"data","url":"link","name":"originalName"},"action":"/api/blade-resource/oss/endpoint/put-file","display":true,"span":24,"showFileList":true,"multiple":true,"limit":10,"prop":"attachment","dataType":"string"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', [version] = 1, [category_id] = -1, [remark] = N'', [create_user] = 1123598821738675201, [create_dept] = 1123598813738675201, [create_time] = N'2021-06-01 22:06:20.0000000', [update_user] = 1123598821738675201, [update_time] = N'2022-04-12 10:27:07.0000000', [status] = 1, [is_deleted] = 0, [tenant_id] = N'000000' WHERE [id] = 1399729025840140290;

-- ----------------------------
-- Table structure for blade_wf_process_leave
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_process_leave]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_process_leave]
    GO

CREATE TABLE [dbo].[blade_wf_process_leave] (
    [id] bigint  NOT NULL,
    [process_ins_id] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [process_def_id] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [current_node] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [datetime] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [days] int  NULL,
    [reason] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [attachment] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NOT NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_process_leave] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程实例id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'process_ins_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程定义id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'process_def_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'当前节点',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'current_node'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'时间范围',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'datetime'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假天数',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'days'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假理由',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'reason'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'附件',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'attachment'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假流程业务示例',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave'
    GO


    -- ----------------------------
-- Table structure for blade_wf_proxy
-- ----------------------------
    IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_proxy]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_proxy]
    GO

CREATE TABLE [dbo].[blade_wf_proxy] (
    [id] bigint  NOT NULL,
    [user_id] bigint  NULL,
    [proxy_user_id] bigint  NULL,
    [process_def_key] nvarchar(750) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [start_time] datetime2(7)  NULL,
    [end_time] datetime2(7)  NULL,
    [status] int  NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_proxy] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'委托人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'代理人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'proxy_user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程定义key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'process_def_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'1永久 2定时',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'开始时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'start_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'结束时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'end_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程代理',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy'
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_process_leave
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_process_leave] ADD CONSTRAINT [PK__blade_wf__639A04C108BAB258] PRIMARY KEY CLUSTERED ([id], [create_time])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table blade_wf_proxy
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_UNI_PROXY]
ON [dbo].[blade_wf_proxy] (
  [user_id] ASC,
  [process_def_key] ASC
)
GO

CREATE NONCLUSTERED INDEX [WF_IDX_USER_ID]
ON [dbo].[blade_wf_proxy] (
  [user_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_proxy
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_proxy] ADD CONSTRAINT [PK__blade_wf__3213E83F8DB1B00B] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

