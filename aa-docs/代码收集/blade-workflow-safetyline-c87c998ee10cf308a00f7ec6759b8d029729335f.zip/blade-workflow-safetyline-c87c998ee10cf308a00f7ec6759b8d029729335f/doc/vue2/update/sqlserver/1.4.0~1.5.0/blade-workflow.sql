ALTER TABLE [dbo].[ACT_DE_MODEL] ADD [icon] varchar(255)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'图标',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'icon'
