ALTER TABLE [dbo].[blade_wf_draft] ADD [task_id] nvarchar(255)
    GO

CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_DRAFT_UNI2]
ON [dbo].[blade_wf_draft] (
  [user_id],
  [task_id],
  [platform]
)
GO

EXEC sp_addextendedproperty
'MS_Description', N'任务id',
'SCHEMA', N'dbo',
'TABLE', N'blade_wf_draft',
'COLUMN', N'task_id'
