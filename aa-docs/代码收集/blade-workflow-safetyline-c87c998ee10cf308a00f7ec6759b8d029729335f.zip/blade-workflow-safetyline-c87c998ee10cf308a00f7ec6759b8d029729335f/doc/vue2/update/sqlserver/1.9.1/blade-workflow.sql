-- ----------------------------
-- Table structure for blade_wf_listener
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_listener]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_listener]
    GO

CREATE TABLE [dbo].[blade_wf_listener] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [category] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [event] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [val] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_listener] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'category'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'事件',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'event'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'监听类型',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'val'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务/执行监听器',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener'
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_listener
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_listener] ADD CONSTRAINT [PK__blade_wf__3213E83FF80DDE18] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

