ALTER TABLE [dbo].[blade_wf_process_leave] ADD [form_key] nvarchar(255)
    GO

ALTER TABLE [dbo].[blade_wf_process_leave] ADD [form_url] nvarchar(255)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单url',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'form_url'
