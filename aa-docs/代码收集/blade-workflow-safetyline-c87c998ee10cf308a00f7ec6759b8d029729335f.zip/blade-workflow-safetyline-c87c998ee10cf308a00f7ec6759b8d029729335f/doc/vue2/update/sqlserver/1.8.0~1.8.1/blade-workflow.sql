-- ----------------------------
-- Table structure for blade_wf_form_variable
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_variable]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_variable]
    GO

CREATE TABLE [dbo].[blade_wf_form_variable] (
    [id] bigint  NOT NULL,
    [process_ins_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [deployment_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_def_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_option] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_variable] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [create_dept] bigint  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_variable] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程实例id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'process_ins_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'deployment_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务节点key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_def_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务节点名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单js',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'form_option'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'form_variable'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单 - 历史变量',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable'
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_variable
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_variable] ADD CONSTRAINT [PK__blade_wf__3213E83F21E7286A] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO
