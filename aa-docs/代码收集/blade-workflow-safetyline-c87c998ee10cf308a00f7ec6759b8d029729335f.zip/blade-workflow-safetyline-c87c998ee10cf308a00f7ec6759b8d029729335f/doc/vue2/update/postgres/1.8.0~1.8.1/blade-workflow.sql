-- ----------------------------
-- Table structure for blade_wf_form_variable
-- ----------------------------
DROP TABLE IF EXISTS "blade_wf_form_variable";
CREATE TABLE "blade_wf_form_variable" (
                                                   "id" int8 NOT NULL,
                                                   "process_ins_id" varchar(255) COLLATE "pg_catalog"."default",
                                                   "deployment_id" varchar(255) COLLATE "pg_catalog"."default",
                                                   "task_id" varchar(255) COLLATE "pg_catalog"."default",
                                                   "task_def_key" varchar(255) COLLATE "pg_catalog"."default",
                                                   "task_name" varchar(255) COLLATE "pg_catalog"."default",
                                                   "form_option" text COLLATE "pg_catalog"."default",
                                                   "form_variable" text COLLATE "pg_catalog"."default",
                                                   "status" varchar(255) COLLATE "pg_catalog"."default",
                                                   "create_user" int8,
                                                   "create_time" timestamp(6),
                                                   "create_dept" int8,
                                                   "update_user" int8,
                                                   "update_time" timestamp(6),
                                                   "is_deleted" int4 DEFAULT 0,
                                                   "tenant_id" varchar(12) COLLATE "pg_catalog"."default" DEFAULT '000000'::character varying
)
;
ALTER TABLE "blade_wf_form_variable" OWNER TO "postgres";
COMMENT ON COLUMN "blade_wf_form_variable"."process_ins_id" IS '流程实例id';
COMMENT ON COLUMN "blade_wf_form_variable"."deployment_id" IS '流程部署id';
COMMENT ON COLUMN "blade_wf_form_variable"."task_id" IS '任务id';
COMMENT ON COLUMN "blade_wf_form_variable"."task_def_key" IS '任务节点key';
COMMENT ON COLUMN "blade_wf_form_variable"."task_name" IS '任务节点名称';
COMMENT ON COLUMN "blade_wf_form_variable"."form_option" IS '表单js';
COMMENT ON COLUMN "blade_wf_form_variable"."form_variable" IS '表单值';
COMMENT ON COLUMN "blade_wf_form_variable"."status" IS '状态';
COMMENT ON COLUMN "blade_wf_form_variable"."create_user" IS '创建人';
COMMENT ON COLUMN "blade_wf_form_variable"."create_time" IS '创建时间';
COMMENT ON COLUMN "blade_wf_form_variable"."create_dept" IS '创建部门';
COMMENT ON COLUMN "blade_wf_form_variable"."update_user" IS '修改人';
COMMENT ON COLUMN "blade_wf_form_variable"."update_time" IS '修改时间';
COMMENT ON COLUMN "blade_wf_form_variable"."is_deleted" IS '是否已删除';
COMMENT ON COLUMN "blade_wf_form_variable"."tenant_id" IS '租户ID';
COMMENT ON TABLE "blade_wf_form_variable" IS '流程表单 - 历史变量';

-- ----------------------------
-- Primary Key structure for table blade_wf_form_variable
-- ----------------------------
ALTER TABLE "blade_wf_form_variable" ADD CONSTRAINT "blade_wf_form_variable_pkey" PRIMARY KEY ("id");
