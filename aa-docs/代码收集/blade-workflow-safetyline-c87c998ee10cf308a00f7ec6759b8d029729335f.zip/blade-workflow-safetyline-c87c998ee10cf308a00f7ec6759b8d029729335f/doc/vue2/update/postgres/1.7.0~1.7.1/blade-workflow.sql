ALTER TABLE "blade_wf_copy"
    ADD COLUMN "deployment_id" varchar(255);
COMMENT ON COLUMN "blade_wf_copy"."deployment_id" IS '流程部署id';

ALTER TABLE "act_de_model" RENAME COLUMN "xml" TO "model_xml";
COMMENT ON COLUMN "act_de_model"."model_xml" IS '模型XML';

ALTER TABLE "act_de_model_history" RENAME COLUMN "xml" TO "model_xml";
COMMENT ON COLUMN "act_de_model_history"."model_xml" IS '模型XML';
