ALTER TABLE "blade_wf_process_leave"
    ADD COLUMN "form_key" varchar(255),
  ADD COLUMN "form_url" varchar(255);

COMMENT ON COLUMN "blade_wf_process_leave"."form_key" IS '外置表单key';

COMMENT ON COLUMN "blade_wf_process_leave"."form_url" IS '外置表单url';
