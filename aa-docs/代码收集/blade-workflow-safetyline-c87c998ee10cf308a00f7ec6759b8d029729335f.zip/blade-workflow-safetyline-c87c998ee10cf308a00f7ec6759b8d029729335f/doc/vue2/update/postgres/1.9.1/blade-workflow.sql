-- ----------------------------
-- Table structure for blade_wf_listener
-- ----------------------------
DROP TABLE IF EXISTS "blade_wf_listener";
CREATE TABLE "blade_wf_listener" (
                                     "id" int8 NOT NULL,
                                     "name" varchar(255) COLLATE "pg_catalog"."default",
                                     "category" varchar(255) COLLATE "pg_catalog"."default",
                                     "event" varchar(255) COLLATE "pg_catalog"."default",
                                     "type" varchar(255) COLLATE "pg_catalog"."default",
                                     "val" varchar(255) COLLATE "pg_catalog"."default",
                                     "create_user" int8,
                                     "create_dept" int8,
                                     "create_time" timestamp(6),
                                     "update_user" int8,
                                     "update_time" timestamp(6),
                                     "status" int4,
                                     "is_deleted" int4 DEFAULT 0,
                                     "tenant_id" varchar(12) COLLATE "pg_catalog"."default" DEFAULT '000000'::character varying
)
;
COMMENT ON COLUMN "blade_wf_listener"."name" IS '名称';
COMMENT ON COLUMN "blade_wf_listener"."category" IS '分类';
COMMENT ON COLUMN "blade_wf_listener"."event" IS '事件';
COMMENT ON COLUMN "blade_wf_listener"."type" IS '监听类型';
COMMENT ON COLUMN "blade_wf_listener"."val" IS '值';
COMMENT ON COLUMN "blade_wf_listener"."create_user" IS '创建人';
COMMENT ON COLUMN "blade_wf_listener"."create_dept" IS '创建部门';
COMMENT ON COLUMN "blade_wf_listener"."create_time" IS '创建时间';
COMMENT ON COLUMN "blade_wf_listener"."update_user" IS '修改人';
COMMENT ON COLUMN "blade_wf_listener"."update_time" IS '修改时间';
COMMENT ON COLUMN "blade_wf_listener"."status" IS '状态';
COMMENT ON COLUMN "blade_wf_listener"."is_deleted" IS '是否已删除';
COMMENT ON COLUMN "blade_wf_listener"."tenant_id" IS '租户ID';
COMMENT ON TABLE "blade_wf_listener" IS '任务/执行监听器';

-- ----------------------------
-- Primary Key structure for table blade_wf_listener
-- ----------------------------
ALTER TABLE "blade_wf_listener" ADD CONSTRAINT "blade_wf_listener_pkey" PRIMARY KEY ("id");
