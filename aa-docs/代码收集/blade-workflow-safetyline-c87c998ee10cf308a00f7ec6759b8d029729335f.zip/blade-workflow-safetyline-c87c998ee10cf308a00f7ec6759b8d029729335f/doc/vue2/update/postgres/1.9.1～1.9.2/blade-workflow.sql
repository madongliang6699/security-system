ALTER TABLE "blade_wf_draft"
DROP COLUMN "task_id",
  ADD COLUMN "task_id" varchar(255);

CREATE UNIQUE INDEX "WF_IDX_DRAFT_UNI2" ON "blade_wf_draft" USING btree (
    "user_id",
    "platform",
    "task_id"
    );

COMMENT ON COLUMN "blade_wf_draft"."task_id" IS '任务id';
