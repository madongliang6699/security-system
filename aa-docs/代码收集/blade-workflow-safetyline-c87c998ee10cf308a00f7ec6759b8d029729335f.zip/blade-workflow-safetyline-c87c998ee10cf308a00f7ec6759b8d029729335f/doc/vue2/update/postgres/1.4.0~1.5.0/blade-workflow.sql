ALTER TABLE "act_de_model" ADD COLUMN "icon" varchar(255);

COMMENT ON COLUMN "act_de_model"."icon" IS '图标';
