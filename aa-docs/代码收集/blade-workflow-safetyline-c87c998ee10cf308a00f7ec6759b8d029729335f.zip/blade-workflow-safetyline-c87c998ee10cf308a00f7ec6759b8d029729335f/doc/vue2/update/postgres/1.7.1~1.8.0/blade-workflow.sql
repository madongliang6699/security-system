-- ----------------------------
-- Table structure for blade_wf_form_theme
-- ----------------------------
DROP TABLE IF EXISTS "blade_wf_form_theme";
CREATE TABLE "blade_wf_form_theme" (
                                                "id" int8 NOT NULL,
                                                "name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
                                                "theme_key" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
                                                "border_width" varchar(255) COLLATE "pg_catalog"."default",
                                                "border_color" varchar(255) COLLATE "pg_catalog"."default",
                                                "label_color" varchar(255) COLLATE "pg_catalog"."default",
                                                "label_bg" varchar(255) COLLATE "pg_catalog"."default",
                                                "label_width" varchar(255) COLLATE "pg_catalog"."default",
                                                "label_font_size" varchar(255) COLLATE "pg_catalog"."default",
                                                "value_color" varchar(255) COLLATE "pg_catalog"."default",
                                                "value_bg" varchar(255) COLLATE "pg_catalog"."default",
                                                "value_font_size" varchar(255) COLLATE "pg_catalog"."default",
                                                "field0" varchar(255) COLLATE "pg_catalog"."default",
                                                "field1" varchar(255) COLLATE "pg_catalog"."default",
                                                "field2" varchar(255) COLLATE "pg_catalog"."default",
                                                "field3" varchar(255) COLLATE "pg_catalog"."default",
                                                "field4" varchar(255) COLLATE "pg_catalog"."default",
                                                "field5" varchar(255) COLLATE "pg_catalog"."default",
                                                "field6" varchar(255) COLLATE "pg_catalog"."default",
                                                "field7" varchar(255) COLLATE "pg_catalog"."default",
                                                "field8" varchar(255) COLLATE "pg_catalog"."default",
                                                "field9" varchar(255) COLLATE "pg_catalog"."default",
                                                "create_user" int8,
                                                "create_dept" int8,
                                                "create_time" timestamp(6),
                                                "update_user" int8,
                                                "update_time" timestamp(6),
                                                "status" int4,
                                                "is_deleted" int4 DEFAULT 0,
                                                "tenant_id" varchar(12) COLLATE "pg_catalog"."default" DEFAULT '000000'::character varying
)
;
ALTER TABLE "blade_wf_form_theme" OWNER TO "postgres";
COMMENT ON COLUMN "blade_wf_form_theme"."name" IS '名称';
COMMENT ON COLUMN "blade_wf_form_theme"."theme_key" IS '主题key';
COMMENT ON COLUMN "blade_wf_form_theme"."border_width" IS '边框宽度';
COMMENT ON COLUMN "blade_wf_form_theme"."border_color" IS '边框颜色';
COMMENT ON COLUMN "blade_wf_form_theme"."label_color" IS 'label字体颜色';
COMMENT ON COLUMN "blade_wf_form_theme"."label_bg" IS 'label背景颜色';
COMMENT ON COLUMN "blade_wf_form_theme"."label_width" IS 'label宽度';
COMMENT ON COLUMN "blade_wf_form_theme"."label_font_size" IS 'label字体大小';
COMMENT ON COLUMN "blade_wf_form_theme"."value_color" IS 'value字体颜色';
COMMENT ON COLUMN "blade_wf_form_theme"."value_bg" IS 'value背景颜色';
COMMENT ON COLUMN "blade_wf_form_theme"."value_font_size" IS 'value字体大小';
COMMENT ON COLUMN "blade_wf_form_theme"."field0" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field1" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field2" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field3" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field4" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field5" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field6" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field7" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field8" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."field9" IS '预留字段';
COMMENT ON COLUMN "blade_wf_form_theme"."create_user" IS '创建人';
COMMENT ON COLUMN "blade_wf_form_theme"."create_dept" IS '创建部门';
COMMENT ON COLUMN "blade_wf_form_theme"."create_time" IS '创建时间';
COMMENT ON COLUMN "blade_wf_form_theme"."update_user" IS '修改人';
COMMENT ON COLUMN "blade_wf_form_theme"."update_time" IS '修改时间';
COMMENT ON COLUMN "blade_wf_form_theme"."status" IS '状态';
COMMENT ON COLUMN "blade_wf_form_theme"."is_deleted" IS '是否已删除';
COMMENT ON COLUMN "blade_wf_form_theme"."tenant_id" IS '租户ID';
COMMENT ON TABLE "blade_wf_form_theme" IS '流程表单 - 主题';

-- ----------------------------
-- Records of blade_wf_form_theme
-- ----------------------------
BEGIN;
INSERT INTO "blade_wf_form_theme" ("id", "name", "theme_key", "border_width", "border_color", "label_color", "label_bg", "label_width", "label_font_size", "value_color", "value_bg", "value_font_size", "field0", "field1", "field2", "field3", "field4", "field5", "field6", "field7", "field8", "field9", "create_user", "create_dept", "create_time", "update_user", "update_time", "status", "is_deleted", "tenant_id") VALUES (1, '蓝色', 'blue', '1px', '#cbdcf0', '#01418a', '#eef6ff', '', '14px', '', '', '14px', '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598813738675201, '2023-04-04 15:36:46', 1123598821738675201, '2023-05-04 10:43:18', 1, 0, '000000');
INSERT INTO "blade_wf_form_theme" ("id", "name", "theme_key", "border_width", "border_color", "label_color", "label_bg", "label_width", "label_font_size", "value_color", "value_bg", "value_font_size", "field0", "field1", "field2", "field3", "field4", "field5", "field6", "field7", "field8", "field9", "create_user", "create_dept", "create_time", "update_user", "update_time", "status", "is_deleted", "tenant_id") VALUES (2, '默认', 'default', '1px', 'rgba(235, 238, 245, 1)', 'rgba(144, 147, 153, 1)', 'rgba(250, 250, 250, 1)', NULL, NULL, 'rgba(96, 98, 102, 1)', 'rgba(255, 255, 255, 1)', NULL, '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598813738675201, '2023-04-04 15:16:47', 1123598821738675201, '2023-04-18 11:50:10', 1, 0, '000000');
INSERT INTO "blade_wf_form_theme" ("id", "name", "theme_key", "border_width", "border_color", "label_color", "label_bg", "label_width", "label_font_size", "value_color", "value_bg", "value_font_size", "field0", "field1", "field2", "field3", "field4", "field5", "field6", "field7", "field8", "field9", "create_user", "create_dept", "create_time", "update_user", "update_time", "status", "is_deleted", "tenant_id") VALUES (3, '黑色', 'black', '1px', 'rgba(0, 0, 0, 1)', '#000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 1123598821738675201, 1123598821738675201, '2023-04-04 16:57:35', 1123598821738675201, '2023-05-04 10:43:44', 1, 0, '000000');
COMMIT;

-- ----------------------------
-- Indexes structure for table blade_wf_form_theme
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_THEME_KEY" ON "blade_wf_form_theme" USING btree (
    "theme_key" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
    );

-- ----------------------------
-- Primary Key structure for table blade_wf_form_theme
-- ----------------------------
ALTER TABLE "blade_wf_form_theme" ADD CONSTRAINT "blade_wf_form_theme_pkey" PRIMARY KEY ("id");
