
-- 请先查看升级指南1.6，再确定是否执行这一段注释的SQL
-- UPDATE "blade_wf_form" SET "form_key" = 'leave', "name" = '请假流程表单', "content" = '{column:[{type:''input'',label:''创建人'',span:12,display:true,prop:''creator'',value:''${this.$store.getters.userInfo.nick_name}'',readonly:true},{type:''input'',label:''创建部门'',span:12,display:true,prop:''creatorDept'',value:''${this.$store.getters.userInfo.dept_name}'',readonly:true},{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''yyyy-MM-dd HH:mm:ss'',valueFormat:''yyyy-MM-dd HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''请假时间必须填写''}],change:({value}) => {
--   if (!value || value.length == 0) {
--     this.$set(this.form, ''days'', undefined)
--   } else {
--     const d1 = Date.parse(value.split('','')[0])
--     const d2 = Date.parse(value.split('','')[1])
--     const day = (d2-d1)/(1*24*60*60*1000)
--     this.$set(this.form, ''days'', Number(day.toFixed(2)))
--   }
-- },dataType:''string''},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
--   if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )
--   else this.$set(this.form, ''reason'', '''')
-- }},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]},{label:''附件'',type:''upload'',propsHttp:{res:''data'',url:''link'',name:''originalName''},action:''/api/blade-resource/oss/endpoint/put-file'',display:true,span:24,showFileList:true,multiple:true,limit:10,prop:''attachment'',dataType:''string''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', "app_content" = '{"column":[{"type":"input","label":"创建人","span":12,"display":true,"prop":"creator","value":"${this.$store.getters.userInfo.nick_name}","readonly":true},{"type":"input","label":"创建部门","span":12,"display":true,"prop":"creatorDept","value":"${this.$store.getters.userInfo.dept_name}","readonly":true},{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"yyyy-MM-dd HH:mm:ss","valueFormat":"yyyy-MM-dd HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"请假时间必须填写"}],"change":"({value}) => {\r\n  if (!value || value.length == 0) {\r\n    this.$set(this.form, ''days'', undefined)\r\n  } else {\r\n    const d1 = Date.parse(value.split('','')[0])\r\n    const d2 = Date.parse(value.split('','')[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    this.$set(this.form, ''days'', Number(day.toFixed(2)))\r\n  }\r\n}","dataType":"string"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\n  if (value) this.$set(this.form, ''reason'',''请假'' + value + ''天'' )\n  else this.$set(this.form, ''reason'', '''')\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]},{"label":"附件","type":"upload","propsHttp":{"res":"data","url":"link","name":"originalName"},"action":"/api/blade-resource/oss/endpoint/put-file","display":true,"span":24,"showFileList":true,"multiple":true,"limit":10,"prop":"attachment","dataType":"string"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', "version" = 1, "category_id" = -1, "remark" = '', "create_user" = 1123598821738675201, "create_dept" = 1123598813738675201, "create_time" = '2021-06-01 22:06:20', "update_user" = 1123598821738675201, "update_time" = '2022-04-12 10:27:07', "status" = '1', "is_deleted" = 0, "tenant_id" = '000000' WHERE "id" = 1399729025840140290;

-- ----------------------------
-- Table structure for blade_wf_process_leave
-- ----------------------------
DROP TABLE IF EXISTS "blade_wf_process_leave";
CREATE TABLE "blade_wf_process_leave" (
                                                   "id" int8 NOT NULL,
                                                   "process_ins_id" varchar(64) COLLATE "pg_catalog"."default",
                                                   "process_def_id" varchar(64) COLLATE "pg_catalog"."default",
                                                   "current_node" varchar(64) COLLATE "pg_catalog"."default",
                                                   "datetime" varchar(64) COLLATE "pg_catalog"."default",
                                                   "days" int4,
                                                   "reason" text COLLATE "pg_catalog"."default",
                                                   "attachment" text COLLATE "pg_catalog"."default",
                                                   "create_user" int8,
                                                   "create_dept" int8,
                                                   "create_time" timestamp(6) NOT NULL,
                                                   "update_user" int8,
                                                   "update_time" timestamp(6),
                                                   "status" int4,
                                                   "is_deleted" int4 DEFAULT 0
)
;
ALTER TABLE "blade_wf_process_leave" OWNER TO "postgres";
COMMENT ON COLUMN "blade_wf_process_leave"."process_ins_id" IS '流程实例id';
COMMENT ON COLUMN "blade_wf_process_leave"."process_def_id" IS '流程定义id';
COMMENT ON COLUMN "blade_wf_process_leave"."current_node" IS '当前节点';
COMMENT ON COLUMN "blade_wf_process_leave"."datetime" IS '时间范围';
COMMENT ON COLUMN "blade_wf_process_leave"."days" IS '请假天数';
COMMENT ON COLUMN "blade_wf_process_leave"."reason" IS '请假理由';
COMMENT ON COLUMN "blade_wf_process_leave"."attachment" IS '附件';
COMMENT ON COLUMN "blade_wf_process_leave"."create_user" IS '创建人';
COMMENT ON COLUMN "blade_wf_process_leave"."create_dept" IS '创建部门';
COMMENT ON COLUMN "blade_wf_process_leave"."create_time" IS '创建时间';
COMMENT ON COLUMN "blade_wf_process_leave"."update_user" IS '修改人';
COMMENT ON COLUMN "blade_wf_process_leave"."update_time" IS '修改时间';
COMMENT ON COLUMN "blade_wf_process_leave"."status" IS '状态';
COMMENT ON COLUMN "blade_wf_process_leave"."is_deleted" IS '是否已删除';
COMMENT ON TABLE "blade_wf_process_leave" IS '请假流程业务示例';

-- ----------------------------
-- Table structure for blade_wf_proxy
-- ----------------------------
DROP TABLE IF EXISTS "blade_wf_proxy";
CREATE TABLE "blade_wf_proxy" (
                                           "id" int8 NOT NULL,
                                           "user_id" int8,
                                           "proxy_user_id" int8,
                                           "process_def_key" varchar(750) COLLATE "pg_catalog"."default",
                                           "type" varchar(255) COLLATE "pg_catalog"."default",
                                           "start_time" timestamp(6),
                                           "end_time" timestamp(6),
                                           "status" int4
)
;
ALTER TABLE "blade_wf_proxy" OWNER TO "postgres";
COMMENT ON COLUMN "blade_wf_proxy"."user_id" IS '委托人';
COMMENT ON COLUMN "blade_wf_proxy"."proxy_user_id" IS '代理人';
COMMENT ON COLUMN "blade_wf_proxy"."process_def_key" IS '流程定义key';
COMMENT ON COLUMN "blade_wf_proxy"."type" IS '1永久 2定时';
COMMENT ON COLUMN "blade_wf_proxy"."start_time" IS '开始时间';
COMMENT ON COLUMN "blade_wf_proxy"."end_time" IS '结束时间';
COMMENT ON COLUMN "blade_wf_proxy"."status" IS '状态';
COMMENT ON TABLE "blade_wf_proxy" IS '流程代理';

-- ----------------------------
-- Primary Key structure for table blade_wf_process_leave
-- ----------------------------
ALTER TABLE "blade_wf_process_leave" ADD CONSTRAINT "blade_wf_process_leave_pkey" PRIMARY KEY ("id", "create_time");

-- ----------------------------
-- Indexes structure for table blade_wf_proxy
-- ----------------------------
CREATE UNIQUE INDEX "WF_IDX_UNI_PROXY" ON "blade_wf_proxy" USING btree (
    "user_id" "pg_catalog"."int8_ops" ASC NULLS LAST,
    "process_def_key" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
    );
CREATE INDEX "WF_IDX_USER_ID" ON "blade_wf_proxy" USING btree (
    "user_id" "pg_catalog"."int8_ops" ASC NULLS LAST
    );

-- ----------------------------
-- Primary Key structure for table blade_wf_proxy
-- ----------------------------
ALTER TABLE "blade_wf_proxy" ADD CONSTRAINT "blade_wf_proxy_pkey" PRIMARY KEY ("id");
