-- ----------------------------
-- Table structure for ACT_DE_MODEL
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[ACT_DE_MODEL]') AND type IN ('U'))
DROP TABLE [dbo].[ACT_DE_MODEL]
    GO

CREATE TABLE [dbo].[ACT_DE_MODEL] (
    [id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [name] nvarchar(400) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [model_key] nvarchar(400) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [category_id] bigint  NULL,
    [description] nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_comment] nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [created] datetime2(7)  NULL,
    [created_by] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [last_updated] datetime2(7)  NULL,
    [last_updated_by] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [version] int  NULL,
    [model_xml] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_editor_json] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [thumbnail] varbinary(max)  NULL,
    [model_type] int  NULL,
    [tenant_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL,
    [icon] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
    )
    GO

ALTER TABLE [dbo].[ACT_DE_MODEL] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型标识',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'model_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单标识',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类id',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'category_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'描述',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'description'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'评论',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'model_comment'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'created'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'created_by'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'最后更新时间',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'last_updated'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'最后更新人',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'last_updated_by'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'版本',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'version'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型XML',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'model_xml'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'flowable-ui编辑器json',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'model_editor_json'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'缩略图',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'thumbnail'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'类型',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'model_type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户id',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'图标',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL',
    'COLUMN', N'icon'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程 - 定义 - 模型',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL'
    GO


-- ----------------------------
-- Records of ACT_DE_MODEL
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'0676f2277420b7dc67f69dd3a0ec1164', N'请假流程 - 外置表单', N'ex-leave', N'wf_ex_Leave', 1642162799092207618, NULL, NULL, '2021-06-08 08:40:51.9010000', N'1123598821738675201', '2023-04-09 18:28:29.2440000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="ex-leave" name="请假流程 - 外置表单" isExecutable="true" flowable:skipFirstNode="true" flowable:rollbackNode="Activity_1bvvbi2">
    <extensionElements>
      <flowable:serial name="测试流水号" prefix="SQ" dateFormat="yyyyMMdd" suffixLength="5" startSequence="0" connector="" cycle="none" />
    </extensionElements>
    <startEvent id="startEvent_1" name="开始" flowable:exFormKey="Leave">
      <extensionElements>
        <flowable:exFormKey value="Leave" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="true" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="true" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="true" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
      </extensionElements>
      <outgoing>Flow_1itpbiu</outgoing>
    </startEvent>
    <userTask id="Activity_1bvvbi2" name="发起人" flowable:exFormKey="Leave" flowable:backToRejecter="false" flowable:assignee="${applyUser}" flowable:hideCopy="true">
      <extensionElements>
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="true" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="true" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="true" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_1itpbiu</incoming>
      <outgoing>Flow_0eeuztq</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1itpbiu" sourceRef="startEvent_1" targetRef="Activity_1bvvbi2" />
    <userTask id="Activity_0xqgcpk" name="人事" flowable:exFormKey="Leave" flowable:candidateUsers="1123598821738675202">
      <extensionElements>
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="false" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="false" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="false" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0eeuztq</incoming>
      <outgoing>Flow_1vu0qon</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0eeuztq" sourceRef="Activity_1bvvbi2" targetRef="Activity_0xqgcpk" />
    <userTask id="Activity_0k0fyan" name="经理" flowable:exFormKey="Leave" flowable:candidateUsers="1123598821738675203">
      <extensionElements>
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="false" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="false" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="false" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_1vu0qon</incoming>
      <outgoing>Flow_1d63z9m</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1vu0qon" sourceRef="Activity_0xqgcpk" targetRef="Activity_0k0fyan" />
    <endEvent id="Event_06z26fy">
      <incoming>Flow_1d63z9m</incoming>
    </endEvent>
    <sequenceFlow id="Flow_1d63z9m" sourceRef="Activity_0k0fyan" targetRef="Event_06z26fy" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="ex-leave">
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="30" height="30" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="243" y="237" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1bvvbi2_di" bpmnElement="Activity_1bvvbi2">
        <dc:Bounds x="320" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0xqgcpk_di" bpmnElement="Activity_0xqgcpk">
        <dc:Bounds x="470" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0k0fyan_di" bpmnElement="Activity_0k0fyan">
        <dc:Bounds x="620" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_06z26fy_di" bpmnElement="Event_06z26fy">
        <dc:Bounds x="772" y="197" width="36" height="36" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="Flow_1itpbiu_di" bpmnElement="Flow_1itpbiu">
        <di:waypoint x="270" y="215" />
        <di:waypoint x="320" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0eeuztq_di" bpmnElement="Flow_0eeuztq">
        <di:waypoint x="420" y="215" />
        <di:waypoint x="470" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1vu0qon_di" bpmnElement="Flow_1vu0qon">
        <di:waypoint x="570" y="215" />
        <di:waypoint x="620" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1d63z9m_di" bpmnElement="Flow_1d63z9m">
        <di:waypoint x="720" y="215" />
        <di:waypoint x="772" y="215" />
      </bpmndi:BPMNEdge>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'2f6b3b6de24354bb5df5aad3a87789af', N'请假流程', N'leave', N'leave', 1642162799092207618, NULL, NULL, '2021-06-01 22:14:07.3630000', N'1123598821738675201', '2023-04-09 18:03:28.9130000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="leave" name="请假流程" isExecutable="true" flowable:skipFirstNode="true" flowable:rollbackNode="Activity_0u3ywm0">
    <extensionElements>
      <flowable:serial name="请假流水号" prefix="Leave" dateFormat="yyyyMMdd" suffixLength="5" startSequence="0" connector="" cycle="none" />
    </extensionElements>
    <startEvent id="startEvent_1" name="开始">
      <extensionElements>
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="true" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="true" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
      </extensionElements>
      <outgoing>Flow_0myeljb</outgoing>
    </startEvent>
    <userTask id="Activity_0u3ywm0" name="发起人" flowable:backToRejecter="false">
      <extensionElements>
        <flowable:assignee type="custom" value="applyUser" text="流程发起人" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="true" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="true" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0myeljb</incoming>
      <outgoing>Flow_0bz2pj7</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0myeljb" sourceRef="startEvent_1" targetRef="Activity_0u3ywm0" />
    <userTask id="Activity_1hmjyx7" name="人事" flowable:backToRejecter="false" flowable:skipExpression="${days&#60;5}">
      <extensionElements>
        <flowable:assignee type="role" value="1123598816738675203" text="人事" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="false" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="false" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="false" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="false" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="false" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="false" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0bz2pj7</incoming>
      <outgoing>Flow_1pf3fia</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0bz2pj7" sourceRef="Activity_0u3ywm0" targetRef="Activity_1hmjyx7" />
    <exclusiveGateway id="Gateway_1qc70vy">
      <incoming>Flow_1pf3fia</incoming>
      <outgoing>Flow_0of3zct</outgoing>
      <outgoing>Flow_139q6po</outgoing>
    </exclusiveGateway>
    <sequenceFlow id="Flow_1pf3fia" sourceRef="Activity_1hmjyx7" targetRef="Gateway_1qc70vy" />
    <userTask id="Activity_1r4xgdo" name="经理">
      <extensionElements>
        <flowable:assignee type="role" value="1123598816738675204" text="经理" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="false" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="false" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="false" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="false" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="false" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="false" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0of3zct</incoming>
      <outgoing>Flow_1dmv86y</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0of3zct" name="小于5天" sourceRef="Gateway_1qc70vy" targetRef="Activity_1r4xgdo">
      <conditionExpression xsi:type="tFormalExpression">${days&lt;5}</conditionExpression>
    </sequenceFlow>
    <userTask id="Activity_1bt0gzy" name="老板">
      <extensionElements>
        <flowable:assignee type="role" value="1123598816738675205" text="老板" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="false" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="false" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="false" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="false" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="false" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="false" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_139q6po</incoming>
      <outgoing>Flow_1bugorc</outgoing>
    </userTask>
    <sequenceFlow id="Flow_139q6po" name="大于5天" sourceRef="Gateway_1qc70vy" targetRef="Activity_1bt0gzy">
      <conditionExpression xsi:type="tFormalExpression">${days&gt;=5}</conditionExpression>
    </sequenceFlow>
    <exclusiveGateway id="Gateway_0ciyfci">
      <incoming>Flow_1dmv86y</incoming>
      <incoming>Flow_1bugorc</incoming>
      <outgoing>Flow_0vtl8w4</outgoing>
    </exclusiveGateway>
    <sequenceFlow id="Flow_1dmv86y" sourceRef="Activity_1r4xgdo" targetRef="Gateway_0ciyfci" />
    <sequenceFlow id="Flow_1bugorc" sourceRef="Activity_1bt0gzy" targetRef="Gateway_0ciyfci" />
    <endEvent id="Event_1j9xjra" name="结束">
      <incoming>Flow_0vtl8w4</incoming>
    </endEvent>
    <sequenceFlow id="Flow_0vtl8w4" sourceRef="Gateway_0ciyfci" targetRef="Event_1j9xjra" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="leave">
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="30" height="30" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="243" y="237" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0u3ywm0_di" bpmnElement="Activity_0u3ywm0">
        <dc:Bounds x="320" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1hmjyx7_di" bpmnElement="Activity_1hmjyx7">
        <dc:Bounds x="470" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Gateway_1qc70vy_di" bpmnElement="Gateway_1qc70vy" isMarkerVisible="true">
        <dc:Bounds x="625" y="190" width="50" height="50" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1r4xgdo_di" bpmnElement="Activity_1r4xgdo">
        <dc:Bounds x="730" y="70" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1bt0gzy_di" bpmnElement="Activity_1bt0gzy">
        <dc:Bounds x="730" y="290" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Gateway_0ciyfci_di" bpmnElement="Gateway_0ciyfci" isMarkerVisible="true">
        <dc:Bounds x="875" y="190" width="50" height="50" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_1j9xjra_di" bpmnElement="Event_1j9xjra">
        <dc:Bounds x="992" y="197" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="999" y="240" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="Flow_0myeljb_di" bpmnElement="Flow_0myeljb">
        <di:waypoint x="270" y="215" />
        <di:waypoint x="320" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0bz2pj7_di" bpmnElement="Flow_0bz2pj7">
        <di:waypoint x="420" y="215" />
        <di:waypoint x="470" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1pf3fia_di" bpmnElement="Flow_1pf3fia">
        <di:waypoint x="570" y="215" />
        <di:waypoint x="625" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0of3zct_di" bpmnElement="Flow_0of3zct">
        <di:waypoint x="650" y="190" />
        <di:waypoint x="650" y="110" />
        <di:waypoint x="730" y="110" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="600" y="147" width="40" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_139q6po_di" bpmnElement="Flow_139q6po">
        <di:waypoint x="650" y="240" />
        <di:waypoint x="650" y="330" />
        <di:waypoint x="730" y="330" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="600" y="282" width="40" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1dmv86y_di" bpmnElement="Flow_1dmv86y">
        <di:waypoint x="830" y="110" />
        <di:waypoint x="900" y="110" />
        <di:waypoint x="900" y="190" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1bugorc_di" bpmnElement="Flow_1bugorc">
        <di:waypoint x="830" y="330" />
        <di:waypoint x="900" y="330" />
        <di:waypoint x="900" y="240" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0vtl8w4_di" bpmnElement="Flow_0vtl8w4">
        <di:waypoint x="925" y="215" />
        <di:waypoint x="992" y="215" />
      </bpmndi:BPMNEdge>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'5b7a367e1139f1ab5cb1e6210685fa91', N'多实例示例', N'demo-multi-instance', N'demo-test', 1642162799092207618, NULL, NULL, '2021-06-25 20:35:27.5220000', N'1123598821738675201', '2021-06-25 21:12:43.8520000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="demo-multi-instance" name="多实例示例" isExecutable="true" flowable:skipFirstNode="true" flowable:rollbackNode="Activity_0srhxhz">
    <extensionElements>
      <flowable:serial name="多实例流水号" prefix="MT" dateFormat="yyyyMMdd" suffixLength="4" startSequence="0" connector="" cycle="none" />
    </extensionElements>
    <startEvent id="startEvent_1" name="开始">
      <extensionElements>
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
      </extensionElements>
      <outgoing>Flow_1i5g9nh</outgoing>
    </startEvent>
    <userTask id="Activity_0srhxhz" name="发起人">
      <extensionElements>
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
        <flowable:assignee type="custom" value="applyUser" text="流程发起人" />
      </extensionElements>
      <incoming>Flow_1i5g9nh</incoming>
      <outgoing>Flow_15l5hak</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1i5g9nh" sourceRef="startEvent_1" targetRef="Activity_0srhxhz" />
    <userTask id="Activity_1qj1out" name="多实例（串行）" flowable:assignee="${assignee}">
      <extensionElements>
        <flowable:assignee type="custom" value="leader" text="上级部门领导" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_15l5hak</incoming>
      <outgoing>Flow_0afq5tt</outgoing>
      <multiInstanceLoopCharacteristics isSequential="true" flowable:collection="${wfMultiInstanceHandler.getList(execution)}" flowable:elementVariable="assignee">
        <completionCondition xsi:type="tFormalExpression">${nrOfCompletedInstances/nrOfInstances &gt;= 0.5}</completionCondition>
      </multiInstanceLoopCharacteristics>
    </userTask>
    <sequenceFlow id="Flow_15l5hak" sourceRef="Activity_0srhxhz" targetRef="Activity_1qj1out" />
    <userTask id="Activity_0oh31om" name="多实例（并行）" flowable:assignee="${assignee}">
      <extensionElements>
        <flowable:assignee type="dept" value="1123598813738675202" text="常州刀锋" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0afq5tt</incoming>
      <outgoing>Flow_0dera7k</outgoing>
      <multiInstanceLoopCharacteristics flowable:collection="${wfMultiInstanceHandler.getList(execution)}" flowable:elementVariable="assignee">
        <completionCondition xsi:type="tFormalExpression">${nrOfCompletedInstances/nrOfInstances &gt;= 1}</completionCondition>
      </multiInstanceLoopCharacteristics>
    </userTask>
    <sequenceFlow id="Flow_0afq5tt" sourceRef="Activity_1qj1out" targetRef="Activity_0oh31om" />
    <endEvent id="Event_02858i0" name="结束">
      <incoming>Flow_0dera7k</incoming>
    </endEvent>
    <sequenceFlow id="Flow_0dera7k" sourceRef="Activity_0oh31om" targetRef="Event_02858i0" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="demo-multi-instance">
      <bpmndi:BPMNEdge id="Flow_0dera7k_di" bpmnElement="Flow_0dera7k">
        <di:waypoint x="720" y="215" />
        <di:waypoint x="772" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0afq5tt_di" bpmnElement="Flow_0afq5tt">
        <di:waypoint x="570" y="215" />
        <di:waypoint x="620" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_15l5hak_di" bpmnElement="Flow_15l5hak">
        <di:waypoint x="420" y="215" />
        <di:waypoint x="470" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1i5g9nh_di" bpmnElement="Flow_1i5g9nh">
        <di:waypoint x="270" y="215" />
        <di:waypoint x="320" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="30" height="30" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="243" y="237" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0srhxhz_di" bpmnElement="Activity_0srhxhz">
        <dc:Bounds x="320" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1qj1out_di" bpmnElement="Activity_1qj1out">
        <dc:Bounds x="470" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0oh31om_di" bpmnElement="Activity_0oh31om">
        <dc:Bounds x="620" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_02858i0_di" bpmnElement="Event_02858i0">
        <dc:Bounds x="772" y="197" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="779" y="240" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'617167d80b6051708484bbedfb72a137', N'人员/流转调用自定义方法示例', N'demo-custom-method', N'demo-test', 1642162799092207618, NULL, NULL, '2021-11-29 09:42:20.0680000', N'1123598821738675201', '2021-12-01 19:18:18.4630000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="demo-custom-method" name="人员/流转调用自定义方法示例" isExecutable="true" flowable:skipFirstNode="true" flowable:rollbackNode="Activity_06t0e98">
    <documentation>人员/流转调用自定义方法示例</documentation>
    <startEvent id="startEvent_1" name="开始">
      <extensionElements>
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
      </extensionElements>
      <outgoing>Flow_0yhobgw</outgoing>
    </startEvent>
    <userTask id="Activity_06t0e98" name="发起人">
      <extensionElements>
        <flowable:assignee type="custom" value="applyUser" text="流程发起人" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0yhobgw</incoming>
      <outgoing>Flow_1t6zwdf</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0yhobgw" sourceRef="startEvent_1" targetRef="Activity_06t0e98" />
    <userTask id="Activity_07ghy8s" name="方式1">
      <extensionElements>
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
        <flowable:assignee type="custom" value="${wfCustomUserHandler.userList(execution, &#39;自定义参数&#39;)}" text="${wfCustomUserHandler.userList(execution, &#39;自定义参数&#39;)}" />
      </extensionElements>
      <incoming>Flow_1t6zwdf</incoming>
      <outgoing>Flow_0kxxs74</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1t6zwdf" sourceRef="Activity_06t0e98" targetRef="Activity_07ghy8s" />
    <userTask id="Activity_10810pv" name="方式2">
      <extensionElements>
        <flowable:assignee type="custom" value="${wfCustomUserHandler.strList(execution, &#39;自定义参数&#39;)}" text="${wfCustomUserHandler.strList(execution, &#39;自定义参数&#39;)}" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0kxxs74</incoming>
      <outgoing>Flow_01h467o</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0kxxs74" sourceRef="Activity_07ghy8s" targetRef="Activity_10810pv" />
    <userTask id="Activity_1i46ta4" name="方式3">
      <extensionElements>
        <flowable:assignee type="custom" value="${wfCustomUserHandler.longList(execution, &#39;自定义参数&#39;)}" text="${wfCustomUserHandler.longList(execution, &#39;自定义参数&#39;)}" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0kdt4xu</incoming>
      <outgoing>Flow_1x5wxzy</outgoing>
    </userTask>
    <userTask id="Activity_03trwm6" name="方式4">
      <extensionElements>
        <flowable:assignee type="custom" value="${wfCustomUserHandler.str(execution, &#39;自定义参数&#39;)}" text="${wfCustomUserHandler.str(execution, &#39;自定义参数&#39;)}" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0jw1ae2</incoming>
      <outgoing>Flow_00r5t9o</outgoing>
    </userTask>
    <endEvent id="Event_0uefnoo">
      <incoming>Flow_1fun2ye</incoming>
    </endEvent>
    <exclusiveGateway id="Gateway_0mtj57e">
      <incoming>Flow_01h467o</incoming>
      <outgoing>Flow_0kdt4xu</outgoing>
      <outgoing>Flow_0jw1ae2</outgoing>
    </exclusiveGateway>
    <sequenceFlow id="Flow_01h467o" sourceRef="Activity_10810pv" targetRef="Gateway_0mtj57e" />
    <sequenceFlow id="Flow_0kdt4xu" sourceRef="Gateway_0mtj57e" targetRef="Activity_1i46ta4">
      <conditionExpression xsi:type="tFormalExpression">${wfCustomUserHandler.condition(execution, ''对'')}</conditionExpression>
    </sequenceFlow>
    <sequenceFlow id="Flow_0jw1ae2" sourceRef="Gateway_0mtj57e" targetRef="Activity_03trwm6">
      <conditionExpression xsi:type="tFormalExpression">${wfCustomUserHandler.condition(execution, ''错'')}</conditionExpression>
    </sequenceFlow>
    <exclusiveGateway id="Gateway_0ha0m7b">
      <incoming>Flow_1x5wxzy</incoming>
      <incoming>Flow_00r5t9o</incoming>
      <outgoing>Flow_1fun2ye</outgoing>
    </exclusiveGateway>
    <sequenceFlow id="Flow_1x5wxzy" sourceRef="Activity_1i46ta4" targetRef="Gateway_0ha0m7b" />
    <sequenceFlow id="Flow_1fun2ye" sourceRef="Gateway_0ha0m7b" targetRef="Event_0uefnoo" />
    <sequenceFlow id="Flow_00r5t9o" sourceRef="Activity_03trwm6" targetRef="Gateway_0ha0m7b" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="demo-custom-method">
      <bpmndi:BPMNEdge id="Flow_0kxxs74_di" bpmnElement="Flow_0kxxs74">
        <di:waypoint x="590" y="218" />
        <di:waypoint x="650" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1t6zwdf_di" bpmnElement="Flow_1t6zwdf">
        <di:waypoint x="430" y="218" />
        <di:waypoint x="490" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0yhobgw_di" bpmnElement="Flow_0yhobgw">
        <di:waypoint x="276" y="218" />
        <di:waypoint x="330" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_01h467o_di" bpmnElement="Flow_01h467o">
        <di:waypoint x="750" y="218" />
        <di:waypoint x="815" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0kdt4xu_di" bpmnElement="Flow_0kdt4xu">
        <di:waypoint x="840" y="193" />
        <di:waypoint x="840" y="90" />
        <di:waypoint x="910" y="90" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0jw1ae2_di" bpmnElement="Flow_0jw1ae2">
        <di:waypoint x="840" y="243" />
        <di:waypoint x="840" y="360" />
        <di:waypoint x="910" y="360" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1x5wxzy_di" bpmnElement="Flow_1x5wxzy">
        <di:waypoint x="1010" y="90" />
        <di:waypoint x="1080" y="90" />
        <di:waypoint x="1080" y="193" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1fun2ye_di" bpmnElement="Flow_1fun2ye">
        <di:waypoint x="1105" y="218" />
        <di:waypoint x="1142" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_00r5t9o_di" bpmnElement="Flow_00r5t9o">
        <di:waypoint x="1010" y="360" />
        <di:waypoint x="1080" y="360" />
        <di:waypoint x="1080" y="243" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="248" y="243" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_06t0e98_di" bpmnElement="Activity_06t0e98">
        <dc:Bounds x="330" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_07ghy8s_di" bpmnElement="Activity_07ghy8s">
        <dc:Bounds x="490" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_10810pv_di" bpmnElement="Activity_10810pv">
        <dc:Bounds x="650" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Gateway_0mtj57e_di" bpmnElement="Gateway_0mtj57e" isMarkerVisible="true">
        <dc:Bounds x="815" y="193" width="50" height="50" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1i46ta4_di" bpmnElement="Activity_1i46ta4">
        <dc:Bounds x="910" y="50" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_03trwm6_di" bpmnElement="Activity_03trwm6">
        <dc:Bounds x="910" y="320" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Gateway_0ha0m7b_di" bpmnElement="Gateway_0ha0m7b" isMarkerVisible="true">
        <dc:Bounds x="1055" y="193" width="50" height="50" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_0uefnoo_di" bpmnElement="Event_0uefnoo">
        <dc:Bounds x="1142" y="200" width="36" height="36" />
      </bpmndi:BPMNShape>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'd71049b6ba4eda39cacf9baf984274ac', N'节点独立表单示例', N'demo-indep-form', N'wf_indep_default-value', 1642162799092207618, NULL, NULL, '2021-10-11 21:32:41.5670000', N'1123598821738675201', '2023-04-01 21:53:04.6570000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="demo-indep-form" name="节点独立表单示例" isExecutable="true">
    <startEvent id="startEvent_1" name="开始">
      <extensionElements>
        <flowable:indepFormKey value="default-value" />
        <flowable:formProperty id="1622472547203_21841" name="人事姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622553629767_65211" name="人事职位" readable="true" writable="true" />
        <flowable:formProperty id="1622472547375_86557" name="人事部门" readable="true" writable="true" />
        <flowable:formProperty id="1622553629949_3168" name="当前日期" readable="true" writable="true" />
        <flowable:formProperty id="1622553631752_15562" name="当前时间" readable="true" writable="true" />
        <flowable:formProperty id="1622553691156_69886" name="人事姓名和日期" readable="true" writable="true" />
        <flowable:formProperty id="1622472547780_5707" name="经理姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622472547975_90560" name="经理部门" readable="true" writable="true" />
        <flowable:formProperty id="1622472548372_60141" name="老板姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622472548560_32474" name="老板部门" readable="true" writable="true" />
      </extensionElements>
      <outgoing>Flow_0u2w7hr</outgoing>
    </startEvent>
    <userTask id="Activity_0a06fpe" name="节点1" flowable:indepFormKey="leave" flowable:indepFormSummary="0" flowable:backToRejecter="false">
      <extensionElements>
        <flowable:assignee type="user" value="1123598821738675201" text="管理员" />
        <flowable:formProperty id="a168034007928961412" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034007945696775" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034007961335688" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034007975278606" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034007991131235" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008006241829" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008021231887" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008037897067" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a16803400805367452" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008068779999" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008084626281" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="a168034008101366417" name="单行文本" readable="true" writable="true" />
        <flowable:formProperty id="creator" name="创建人" readable="true" writable="true" />
        <flowable:formProperty id="creatorDept" name="创建部门" readable="true" writable="true" />
        <flowable:formProperty id="datetime" name="请假时间" readable="true" writable="true" />
        <flowable:formProperty id="days" name="请假天数" readable="true" writable="true" />
        <flowable:formProperty id="reason" name="请假理由" readable="true" writable="true" />
        <flowable:formProperty id="attachment" name="附件" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0u2w7hr</incoming>
      <outgoing>Flow_1gfy6oq</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0u2w7hr" sourceRef="startEvent_1" targetRef="Activity_0a06fpe" />
    <userTask id="Activity_0k3kp91" name="节点2" flowable:indepFormKey="demo-test" flowable:indepFormSummary="0">
      <extensionElements>
        <flowable:assignee type="user" value="1123598821738675201" text="管理员" />
        <flowable:formProperty id="1624624365132_23209" name="单行文本" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_1gfy6oq</incoming>
      <outgoing>Flow_016wlba</outgoing>
    </userTask>
    <sequenceFlow id="Flow_1gfy6oq" sourceRef="Activity_0a06fpe" targetRef="Activity_0k3kp91" />
    <userTask id="Activity_1yv7km2" name="汇总" flowable:indepFormSummary="1" flowable:backToRejecter="false">
      <extensionElements>
        <flowable:assignee type="user" value="1123598821738675201" text="管理员" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_016wlba</incoming>
      <outgoing>Flow_1omx17n</outgoing>
    </userTask>
    <sequenceFlow id="Flow_016wlba" sourceRef="Activity_0k3kp91" targetRef="Activity_1yv7km2" />
    <endEvent id="Event_1vr1neq" name="结束">
      <incoming>Flow_1omx17n</incoming>
    </endEvent>
    <sequenceFlow id="Flow_1omx17n" sourceRef="Activity_1yv7km2" targetRef="Event_1vr1neq" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="demo-indep-form">
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="247" y="243" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0a06fpe_di" bpmnElement="Activity_0a06fpe">
        <dc:Bounds x="330" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0k3kp91_di" bpmnElement="Activity_0k3kp91">
        <dc:Bounds x="490" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1yv7km2_di" bpmnElement="Activity_1yv7km2">
        <dc:Bounds x="650" y="178" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_1vr1neq_di" bpmnElement="Event_1vr1neq">
        <dc:Bounds x="812" y="200" width="36" height="36" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="819" y="243" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="Flow_0u2w7hr_di" bpmnElement="Flow_0u2w7hr">
        <di:waypoint x="276" y="218" />
        <di:waypoint x="330" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1gfy6oq_di" bpmnElement="Flow_1gfy6oq">
        <di:waypoint x="430" y="218" />
        <di:waypoint x="490" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_016wlba_di" bpmnElement="Flow_016wlba">
        <di:waypoint x="590" y="218" />
        <di:waypoint x="650" y="218" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1omx17n_di" bpmnElement="Flow_1omx17n">
        <di:waypoint x="750" y="218" />
        <di:waypoint x="812" y="218" />
      </bpmndi:BPMNEdge>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
INSERT INTO [dbo].[ACT_DE_MODEL] ([id], [name], [model_key], [form_key], [category_id], [description], [model_comment], [created], [created_by], [last_updated], [last_updated_by], [version], [model_xml], [model_editor_json], [thumbnail], [model_type], [tenant_id], [icon]) VALUES (N'fb4c1a6a8c4588779a2519a547966846', N'表单默认值示例', N'demo-default-values', N'default-value', 1642162799092207618, NULL, NULL, '2021-05-31 21:39:46.5450000', N'1123598821738675201', '2023-04-01 21:53:15.6840000', N'1123598821738675201', 1, N'<?xml version="1.0" encoding="UTF-8"?>
<definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:flowable="http://flowable.org/bpmn" xmlns:activiti="http://activiti.org/bpmn" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" targetNamespace="http://bpmn.io/schema/bpmn">
  <process id="demo-default-values" name="表单默认值示例" isExecutable="true" flowable:rollbackNode="Activity_0p2hxfq">
    <startEvent id="startEvent_1" name="开始">
      <extensionElements>
        <flowable:formProperty id="1622472547203_21841" name="人事姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622553629767_65211" name="人事职位" readable="true" writable="false" />
        <flowable:formProperty id="1622472547375_86557" name="人事部门" readable="true" writable="false" />
        <flowable:formProperty id="1622553629949_3168" name="当前日期" readable="true" writable="false" />
        <flowable:formProperty id="1622553631752_15562" name="当前时间" readable="true" writable="false" />
        <flowable:formProperty id="1622553691156_69886" name="人事姓名和日期" readable="true" writable="false" />
        <flowable:formProperty id="1622472547780_5707" name="经理姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472547975_90560" name="经理部门" readable="true" writable="false" />
        <flowable:formProperty id="1622472548372_60141" name="老板姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472548560_32474" name="老板部门" readable="true" writable="false" />
      </extensionElements>
      <outgoing>Flow_0c932wc</outgoing>
    </startEvent>
    <userTask id="Activity_0p2hxfq" name="人事" flowable:backToRejecter="false" flowable:assignee="1123598821738675201">
      <extensionElements>
        <flowable:formProperty id="1622472547203_21841" name="人事姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622553629767_65211" name="人事职位" readable="true" writable="true" />
        <flowable:formProperty id="1622472547375_86557" name="人事部门" readable="true" writable="true" />
        <flowable:formProperty id="1622553629949_3168" name="当前日期" readable="true" writable="true" />
        <flowable:formProperty id="1622553631752_15562" name="当前时间" readable="true" writable="true" />
        <flowable:formProperty id="1622553691156_69886" name="人事姓名和日期" readable="true" writable="true" />
        <flowable:formProperty id="1622472547780_5707" name="经理姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472547975_90560" name="经理部门" readable="true" writable="false" />
        <flowable:formProperty id="1622472548372_60141" name="老板姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472548560_32474" name="老板部门" readable="true" writable="false" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0c932wc</incoming>
      <outgoing>Flow_042y9oy</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0c932wc" sourceRef="startEvent_1" targetRef="Activity_0p2hxfq" />
    <userTask id="Activity_0p0q6jd" name="经理" flowable:assignee="1123598821738675203">
      <extensionElements>
        <flowable:formProperty id="1622472547203_21841" name="人事姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622553629767_65211" name="人事职位" readable="true" writable="false" />
        <flowable:formProperty id="1622472547375_86557" name="人事部门" readable="true" writable="false" />
        <flowable:formProperty id="1622553629949_3168" name="当前日期" readable="true" writable="false" />
        <flowable:formProperty id="1622553631752_15562" name="当前时间" readable="true" writable="false" />
        <flowable:formProperty id="1622553691156_69886" name="人事姓名和日期" readable="true" writable="false" />
        <flowable:formProperty id="1622472547780_5707" name="经理姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622472547975_90560" name="经理部门" readable="true" writable="true" />
        <flowable:formProperty id="1622472548372_60141" name="老板姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472548560_32474" name="老板部门" readable="true" writable="false" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_042y9oy</incoming>
      <outgoing>Flow_0c47aum</outgoing>
    </userTask>
    <sequenceFlow id="Flow_042y9oy" sourceRef="Activity_0p2hxfq" targetRef="Activity_0p0q6jd" />
    <userTask id="Activity_1dj1hpj" name="老板" flowable:assignee="1123598821738675204">
      <extensionElements>
        <flowable:formProperty id="1622472547203_21841" name="人事姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622553629767_65211" name="人事职位" readable="true" writable="false" />
        <flowable:formProperty id="1622472547375_86557" name="人事部门" readable="true" writable="false" />
        <flowable:formProperty id="1622553629949_3168" name="当前日期" readable="true" writable="false" />
        <flowable:formProperty id="1622553631752_15562" name="当前时间" readable="true" writable="false" />
        <flowable:formProperty id="1622553691156_69886" name="人事姓名和日期" readable="true" writable="false" />
        <flowable:formProperty id="1622472547780_5707" name="经理姓名" readable="true" writable="false" />
        <flowable:formProperty id="1622472547975_90560" name="经理部门" readable="true" writable="false" />
        <flowable:formProperty id="1622472548372_60141" name="老板姓名" readable="true" writable="true" />
        <flowable:formProperty id="1622472548560_32474" name="老板部门" readable="true" writable="true" />
        <flowable:button label="通过" prop="wf_pass" display="true" />
        <flowable:button label="驳回" prop="wf_reject" display="true" />
        <flowable:button label="打印" prop="wf_print" display="true" />
        <flowable:button label="转办" prop="wf_transfer" display="true" />
        <flowable:button label="委托" prop="wf_delegate" display="true" />
        <flowable:button label="终止" prop="wf_terminate" display="true" />
        <flowable:button label="加签" prop="wf_add_instance" display="true" />
        <flowable:button label="减签" prop="wf_del_instance" display="true" />
        <flowable:button label="指定回退" prop="wf_rollback" display="true" />
      </extensionElements>
      <incoming>Flow_0c47aum</incoming>
      <outgoing>Flow_1ehhsly</outgoing>
    </userTask>
    <sequenceFlow id="Flow_0c47aum" sourceRef="Activity_0p0q6jd" targetRef="Activity_1dj1hpj" />
    <endEvent id="Event_03anpp1">
      <incoming>Flow_1ehhsly</incoming>
    </endEvent>
    <sequenceFlow id="Flow_1ehhsly" sourceRef="Activity_1dj1hpj" targetRef="Event_03anpp1" />
  </process>
  <bpmndi:BPMNDiagram id="BPMNDiagram_flow">
    <bpmndi:BPMNPlane id="BPMNPlane_flow" bpmnElement="demo-default-values">
      <bpmndi:BPMNShape id="BPMNShape_startEvent_1" bpmnElement="startEvent_1">
        <dc:Bounds x="240" y="200" width="30" height="30" />
        <bpmndi:BPMNLabel>
          <dc:Bounds x="243" y="237" width="22" height="14" />
        </bpmndi:BPMNLabel>
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0p2hxfq_di" bpmnElement="Activity_0p2hxfq">
        <dc:Bounds x="320" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_0p0q6jd_di" bpmnElement="Activity_0p0q6jd">
        <dc:Bounds x="470" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Activity_1dj1hpj_di" bpmnElement="Activity_1dj1hpj">
        <dc:Bounds x="620" y="175" width="100" height="80" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNShape id="Event_03anpp1_di" bpmnElement="Event_03anpp1">
        <dc:Bounds x="772" y="197" width="36" height="36" />
      </bpmndi:BPMNShape>
      <bpmndi:BPMNEdge id="Flow_0c932wc_di" bpmnElement="Flow_0c932wc">
        <di:waypoint x="270" y="215" />
        <di:waypoint x="320" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_042y9oy_di" bpmnElement="Flow_042y9oy">
        <di:waypoint x="420" y="215" />
        <di:waypoint x="470" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_0c47aum_di" bpmnElement="Flow_0c47aum">
        <di:waypoint x="570" y="215" />
        <di:waypoint x="620" y="215" />
      </bpmndi:BPMNEdge>
      <bpmndi:BPMNEdge id="Flow_1ehhsly_di" bpmnElement="Flow_1ehhsly">
        <di:waypoint x="720" y="215" />
        <di:waypoint x="772" y="215" />
      </bpmndi:BPMNEdge>
    </bpmndi:BPMNPlane>
  </bpmndi:BPMNDiagram>
</definitions>
', NULL, NULL, 0, N'000000', NULL);
GO

COMMIT
GO


-- ----------------------------
-- Table structure for ACT_DE_MODEL_HISTORY
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[ACT_DE_MODEL_HISTORY]') AND type IN ('U'))
DROP TABLE [dbo].[ACT_DE_MODEL_HISTORY]
    GO

CREATE TABLE [dbo].[ACT_DE_MODEL_HISTORY] (
    [id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [name] nvarchar(400) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [model_key] nvarchar(400) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [category_id] bigint  NULL,
    [description] nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_comment] nvarchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [created] datetime2(7)  NULL,
    [created_by] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [last_updated] datetime2(7)  NULL,
    [last_updated_by] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [removal_date] datetime2(7)  NULL,
    [version] int  NULL,
    [model_xml] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_editor_json] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [model_type] int  NULL,
    [tenant_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL,
    [icon] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
    )
    GO

ALTER TABLE [dbo].[ACT_DE_MODEL_HISTORY] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型标识',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单标识',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类id',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'category_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'描述',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'description'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'注释',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_comment'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'created'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'created_by'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'最后更新时间',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'last_updated'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'最后更新人',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'last_updated_by'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'移除时间',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'removal_date'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'版本',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'version'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型XML',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_xml'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'flowable-ui编辑器json',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_editor_json'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'modelId',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'类型',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'model_type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户id',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'图标',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY',
    'COLUMN', N'icon'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程 - 定义 - 模型历史',
    'SCHEMA', N'dbo',
    'TABLE', N'ACT_DE_MODEL_HISTORY'
    GO


-- ----------------------------
-- Records of ACT_DE_MODEL_HISTORY
-- ----------------------------
BEGIN TRANSACTION
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_button
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_button]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_button]
    GO

CREATE TABLE [dbo].[blade_wf_button] (
    [id] bigint  NOT NULL,
    [button_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [display] tinyint  NULL,
    [sort] int  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_button] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'按钮key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'button_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'默认是否显示',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'display'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'排序',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'sort'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程按钮',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_button'
    GO


-- ----------------------------
-- Records of blade_wf_button
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1394176899911041025', N'wf_pass', N'通过', N'1', N'1', N'1123598821738675201', N'1123598813738675201', N'2021-05-16 14:24:10.0000000', N'1123598821738675201', N'2021-05-16 14:24:10.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1394177198465794050', N'wf_reject', N'驳回', N'1', N'2', N'1123598821738675201', N'1123598813738675201', N'2021-05-16 14:25:21.0000000', N'1123598821738675201', N'2021-05-16 14:25:21.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1394179125421326337', N'wf_print', N'打印', N'1', N'3', N'1123598821738675201', N'1123598813738675201', N'2021-05-16 14:33:01.0000000', N'1123598821738675201', N'2021-05-16 14:33:01.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1394609969089761281', N'wf_transfer', N'转办', N'1', N'4', N'1123598821738675201', N'1123598813738675201', N'2021-05-16 19:05:02.0000000', N'1123598821738675201', N'2021-05-16 19:05:02.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1394610036672581634', N'wf_delegate', N'委托', N'1', N'5', N'1123598821738675201', N'1123598813738675201', N'2021-05-16 19:05:18.0000000', N'1123598821738675201', N'2021-05-16 19:05:18.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1395271519601426433', N'wf_terminate', N'终止', N'1', N'6', N'1123598821738675201', N'1123598813738675201', N'2021-05-20 14:53:48.0000000', N'1123598821738675201', N'2021-05-20 14:53:48.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1395274709692579841', N'wf_add_instance', N'加签', N'1', N'7', N'1123598821738675201', N'1123598813738675201', N'2021-05-20 15:06:28.0000000', N'1123598821738675201', N'2021-05-20 15:06:28.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1395274774674931713', N'wf_del_instance', N'减签', N'1', N'8', N'1123598821738675201', N'1123598813738675201', N'2021-05-20 15:06:44.0000000', N'1123598821738675201', N'2021-05-20 15:06:44.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_button] ([id], [button_key], [name], [display], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1395274955986305025', N'wf_rollback', N'指定回退', N'1', N'9', N'1123598821738675201', N'1123598813738675201', N'2021-05-20 15:07:27.0000000', N'1123598821738675201', N'2021-05-20 15:07:27.0000000', N'1', N'0', N'000000')
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_category
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_category]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_category]
    GO

CREATE TABLE [dbo].[blade_wf_category] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [pid] bigint DEFAULT 0 NULL,
    [sort] int  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_category] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'上级id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'pid'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'排序',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'sort'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程分类',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_category'
    GO


-- ----------------------------
-- Records of blade_wf_category
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_category] ([id], [name], [pid], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1394133715940073474, N'请假流程', 0, 2, 1123598821738675201, 1123598813738675201, '2021-05-16 11:32:34.0000000', 1123598821738675201, '2023-04-01 21:51:42.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_category] ([id], [name], [pid], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1394158934813609986, N'财务流程', 0, 3, 1123598821738675201, 1123598813738675201, '2021-05-16 13:12:47.0000000', 1123598821738675201, '2023-04-01 21:51:49.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_category] ([id], [name], [pid], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1394159147934584833, N'报销流程', 1394158934813609986, 1, 1123598821738675201, 1123598813738675201, '2021-05-16 13:13:38.0000000', 1123598821738675201, '2021-05-16 13:13:38.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_category] ([id], [name], [pid], [sort], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1642162799092207618, N'示例流程', 0, 1, 1123598821738675201, 1123598813738675201, '2023-04-01 21:51:36.0000000', 1123598821738675201, '2023-04-01 21:51:36.0000000', N'1', 0, N'000000');
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_condition
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_condition]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_condition]
    GO

CREATE TABLE [dbo].[blade_wf_condition] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [expression] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_condition] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表达式',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'expression'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'类型',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表达式',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_condition'
    GO


-- ----------------------------
-- Records of blade_wf_condition
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_condition] ([id], [name], [expression], [type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1408267023015739393', N'流程发起人', N'applyUser', N'user', N'1123598821738675201', N'1123598813738675201', N'2021-06-25 11:33:17.0000000', N'1123598821738675201', N'2021-06-25 11:33:17.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_condition] ([id], [name], [expression], [type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1408267100878798850', N'当前操作人', N'currentUser', N'user', N'1123598821738675201', N'1123598813738675201', N'2021-06-25 11:33:36.0000000', N'1123598821738675201', N'2021-06-25 11:33:36.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_condition] ([id], [name], [expression], [type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1408305933398896641', N'上级部门领导', N'leader', N'user', N'1123598821738675201', N'1123598813738675201', N'2021-06-25 14:07:54.0000000', N'1123598821738675201', N'2021-06-25 14:07:54.0000000', N'1', N'0', N'000000')
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_copy
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_copy]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_copy]
    GO

CREATE TABLE [dbo].[blade_wf_copy] (
    [id] bigint  NOT NULL,
    [user_id] bigint  NULL,
    [title] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [initiator] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [process_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [deployment_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_url] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_copy] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'用户id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'标题',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'title'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'发起者',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'initiator'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'task_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程实例id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'process_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'deployment_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单url',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'form_url'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程抄送',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_copy'
    GO


-- ----------------------------
-- Records of blade_wf_copy
-- ----------------------------
BEGIN TRANSACTION
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_deployment_form
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_deployment_form]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_deployment_form]
    GO

CREATE TABLE [dbo].[blade_wf_deployment_form] (
    [id] bigint  NOT NULL,
    [deployment_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [app_content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_deployment_form] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'deployment_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'app表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'app_content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'节点key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'task_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'节点名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'task_name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署 - 表单',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_deployment_form'
    GO


-- ----------------------------
-- Records of blade_wf_deployment_form
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_deployment_form] ([id], [deployment_id], [form_key], [content], [app_content], [task_key], [task_name], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted]) VALUES (N'1493407680587395074', N'a35a73a4-8e04-11ec-9e83-92d6166784a9', N'leave', N'{column:[{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''yyyy-MM-dd HH:mm:ss'',valueFormat:''yyyy-MM-dd HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''开始时间必须填写''}],change:({value}) => {
  if (!value || value.length == 0) {
    this.$set(this.form, ''days'', undefined)
  } else {
    const d1 = Date.parse(value[0])
    const d2 = Date.parse(value[1])
    const day = (d2-d1)/(1*24*60*60*1000)
    this.$set(this.form, ''days'', Number(day.toFixed(2)))
  }
}},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
this.$set(this.form, ''reason'',''请假'' + value + ''天'' )
}},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', N'{"column":[{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"yyyy-MM-dd HH:mm:ss","valueFormat":"yyyy-MM-dd HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"开始时间必须填写"}],"change":"({value}) => {\r\n  if (!value || value.length == 0) {\r\n    this.$set(this.form, ''days'', undefined)\r\n  } else {\r\n    const d1 = Date.parse(value[0])\r\n    const d2 = Date.parse(value[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    this.$set(this.form, ''days'', Number(day.toFixed(2)))\r\n  }\r\n}"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\nthis.$set(this.form, ''reason'',''请假'' + value + ''天'' )\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'1')
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_draft
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_draft]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_draft]
    GO

CREATE TABLE [dbo].[blade_wf_draft] (
    [id] bigint  NOT NULL,
    [user_id] bigint  NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [process_def_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [variables] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [platform] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_draft] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'用户id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程定义id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'process_def_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'task_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单变量',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'variables'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'平台 pc/app',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft',
    'COLUMN', N'platform'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程草稿箱',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_draft'
    GO


-- ----------------------------
-- Records of blade_wf_draft
-- ----------------------------
BEGIN TRANSACTION
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_form
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form]
    GO

CREATE TABLE [dbo].[blade_wf_form] (
    [id] bigint  NOT NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [app_content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [version] int  NULL,
    [category_id] bigint  NULL,
    [remark] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'app表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'app_content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'版本',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'version'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'category_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'备注',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'remark'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form'
    GO


-- ----------------------------
-- Records of blade_wf_form
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_form] ([id], [form_key], [name], [content], [app_content], [version], [category_id], [remark], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399359377009377281, N'default-value', N'测试默认值', N'{column:[{type:''input'',label:''人事姓名'',span:24,display:true,prop:''1622472547203_21841'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''人事职位'',span:24,display:true,prop:''1622553629767_65211'',value:''${this.$store.getters.userInfo.post_name}''},{type:''input'',label:''人事部门'',span:24,display:true,prop:''1622472547375_86557'',value:''${this.$store.getters.userInfo.dept_name}''},{type:''input'',label:''当前日期'',span:24,display:true,prop:''1622553629949_3168'',value:''${this.dateFormat(new Date(),\"YYYY-MM-DD\")}''},{type:''input'',label:''当前时间'',span:24,display:true,prop:''1622553631752_15562'',value:''${this.dateFormat(new Date(),\"HH:mm:ss\")}''},{type:''input'',label:''人事姓名和日期'',span:24,display:true,prop:''1622553691156_69886'',value:''${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),\"YYYY-MM-DD\")}''},{type:''input'',label:''经理姓名'',span:24,display:true,prop:''1622472547780_5707'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''经理部门'',span:24,display:true,prop:''1622472547975_90560'',value:''${this.$store.getters.userInfo.dept_name}''},{type:''input'',label:''老板姓名'',span:24,display:true,prop:''1622472548372_60141'',value:''${this.$store.getters.userInfo.nick_name}''},{type:''input'',label:''老板部门'',span:24,display:true,prop:''1622472548560_32474'',value:''${this.$store.getters.userInfo.dept_name}''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:140,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', N'{"column":[{"type":"input","label":"人事姓名","span":24,"display":true,"prop":"1622472547203_21841","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"人事职位","span":24,"display":true,"prop":"1622553629767_65211","value":"${this.$store.getters.userInfo.post_name}"},{"type":"input","label":"人事部门","span":24,"display":true,"prop":"1622472547375_86557","value":"${this.$store.getters.userInfo.dept_name}"},{"type":"input","label":"当前日期","span":24,"display":true,"prop":"1622553629949_3168","value":"${this.dateFormat(new Date(),\"YYYY-MM-DD\")}"},{"type":"input","label":"当前时间","span":24,"display":true,"prop":"1622553631752_15562","value":"${this.dateFormat(new Date(),\"HH:mm:ss\")}"},{"type":"input","label":"人事姓名和日期","span":24,"display":true,"prop":"1622553691156_69886","value":"${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),\"YYYY-MM-DD\")}"},{"type":"input","label":"经理姓名","span":24,"display":true,"prop":"1622472547780_5707","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"经理部门","span":24,"display":true,"prop":"1622472547975_90560","value":"${this.$store.getters.userInfo.dept_name}"},{"type":"input","label":"老板姓名","span":24,"display":true,"prop":"1622472548372_60141","value":"${this.$store.getters.userInfo.nick_name}"},{"type":"input","label":"老板部门","span":24,"display":true,"prop":"1622472548560_32474","value":"${this.$store.getters.userInfo.dept_name}"}],"labelPosition":"left","labelSuffix":"：","labelWidth":140,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', 1, 1642162799092207618, '', 1123598821738675201, 1123598813738675201, '2021-05-31 21:37:29.0000000', 1123598821738675201, '2023-04-01 21:58:47.0000000', 1, 0, N'000000');
INSERT INTO [dbo].[blade_wf_form] ([id], [form_key], [name], [content], [app_content], [version], [category_id], [remark], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399729025840140290, N'leave', N'请假流程表单', N'{column:[{type:''input'',label:''创建人'',span:12,display:true,prop:''creator'',value:''${this.$store.getters.userInfo.nick_name}'',readonly:true},{type:''input'',label:''创建部门'',span:12,display:true,prop:''creatorDept'',value:''${this.$store.getters.userInfo.dept_name}'',readonly:true},{type:''datetimerange'',label:''请假时间'',span:12,display:true,format:''YYYY-MM-DD HH:mm:ss'',valueFormat:''YYYY-MM-DD HH:mm:ss'',prop:''datetime'',required:true,rules:[{required:true,message:''请假时间必须填写''}],change:({value}) => {
  let days
  if (!value || value.length == 0) {
    days = undefined
  } else {
    const d1 = Date.parse(value.split('','')[0])
    const d2 = Date.parse(value.split('','')[1])
    const day = (d2-d1)/(1*24*60*60*1000)
    days = Number(day.toFixed(2))
  }
  this.form.days = days
},dataType:''string''},{type:''number'',label:''请假天数'',span:12,display:true,prop:''days'',required:true,rules:[{required:true,message:''请假天数必须填写''}],controls:true,controlsPosition:''right'',change:({value}) => {
  let reason
  if (value) reason = ''请假'' + value + ''天''
  else reason = ''''
  this.form.reason = reason
}},{type:''textarea'',label:''请假理由'',span:24,display:true,prop:''reason'',required:true,rules:[{required:true,message:''请假理由必须填写''}]},{label:''附件'',type:''upload'',propsHttp:{res:''data'',url:''link'',name:''originalName''},action:''/api/blade-resource/oss/endpoint/put-file'',display:true,span:24,showFileList:true,multiple:true,limit:10,prop:''attachment'',dataType:''string''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', N'{"column":[{"type":"input","label":"创建人","span":12,"display":true,"prop":"creator","value":"${this.$store.getters.userInfo.nick_name}","readonly":true},{"type":"input","label":"创建部门","span":12,"display":true,"prop":"creatorDept","value":"${this.$store.getters.userInfo.dept_name}","readonly":true},{"type":"datetimerange","label":"请假时间","span":12,"display":true,"format":"YYYY-MM-DD HH:mm:ss","valueFormat":"YYYY-MM-DD HH:mm:ss","prop":"datetime","required":true,"rules":[{"required":true,"message":"请假时间必须填写"}],"change":"({value}) => {\r\n  let days\r\n  if (!value || value.length == 0) {\r\n    days = undefined\r\n  } else {\r\n    const d1 = Date.parse(value.split('','')[0])\r\n    const d2 = Date.parse(value.split('','')[1])\r\n    const day = (d2-d1)/(1*24*60*60*1000)\r\n    days = Number(day.toFixed(2))\r\n  }\r\n  this.form.days = days\r\n}","dataType":"string"},{"type":"number","label":"请假天数","span":12,"display":true,"prop":"days","required":true,"rules":[{"required":true,"message":"请假天数必须填写"}],"controls":true,"controlsPosition":"right","change":"({value}) => {\n  let reason\n  if (value) reason = ''请假'' + value + ''天''\n  else reason = ''''\n  this.form.reason = reason\n}"},{"type":"textarea","label":"请假理由","span":24,"display":true,"prop":"reason","required":true,"rules":[{"required":true,"message":"请假理由必须填写"}]},{"label":"附件","type":"upload","propsHttp":{"res":"data","url":"link","name":"originalName"},"action":"/api/blade-resource/oss/endpoint/put-file","display":true,"span":24,"showFileList":true,"multiple":true,"limit":10,"prop":"attachment","dataType":"string"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', 1, 1642162799092207618, '', 1123598821738675201, 1123598813738675201, '2021-06-01 22:06:20.0000000', 1123598821738675201, '2023-04-09 18:03:17.0000000', 1, 0, N'000000');
INSERT INTO [dbo].[blade_wf_form] ([id], [form_key], [name], [content], [app_content], [version], [category_id], [remark], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1408402768310304770, N'demo-test', N'测试简单表单', N'{column:[{type:''input'',label:''单行文本'',span:24,display:true,prop:''1624624365132_23209''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', N'{"column":[{"type":"input","label":"单行文本","span":24,"display":true,"prop":"1624624365132_23209"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', 1, 1642162799092207618, '', 1123598821738675201, 1123598813738675201, '2021-06-25 20:32:41.0000000', 1123598821738675201, '2023-04-01 21:58:47.0000000', 1, 0, N'000000');
INSERT INTO [dbo].[blade_wf_form] ([id], [form_key], [name], [content], [app_content], [version], [category_id], [remark], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1429672727182159874, N'field-linkage', N'字段联动', N'{column:[{type:''switch'',label:''控制显隐'',span:24,display:true,value:''0'',dicData:[{label:'''',value:''0''},{label:'''',value:''1''}],prop:''1629695558953_19833'',change:({value}) => {
    const input = this.findObject(this.option.column, ''input'')
    if(value == 0) {
        input.display = false
    } else {
        input.display = true
    }
}},{type:''input'',label:''单行文本'',span:24,display:true,prop:''input''},{type:''select'',label:''值改变'',dicData:[{label:''一天'',value:''1''},{label:''两天'',value:''2''},{label:''三天'',value:''3''}],cascaderItem:[],span:24,display:true,props:{label:''label'',value:''value''},prop:''1629695859796_23456'',change:({value}) => {
    let text = value
    if(value) {
        text = ''请假 '' + value + '' 天''
    }
    this.form.input2 = text
}},{type:''input'',label:''单行文本'',span:24,display:true,prop:''input2''}],labelPosition:''left'',labelSuffix:''：'',labelWidth:120,gutter:0,menuBtn:true,submitBtn:true,submitText:''提交'',emptyBtn:true,emptyText:''清空'',menuPosition:''center''}', N'{"column":[{"type":"switch","label":"控制显隐","span":24,"display":true,"value":"0","dicData":[{"label":"","value":"0"},{"label":"","value":"1"}],"prop":"1629695558953_19833","change":"({value}) => {\r\n    const input = this.findObject(this.option.column, ''input'')\r\n    if(value == 0) {\r\n        input.display = false\r\n    } else {\r\n        input.display = true\r\n    }\r\n}"},{"type":"input","label":"单行文本","span":24,"display":true,"prop":"input"},{"type":"select","label":"值改变","dicData":[{"label":"一天","value":"1"},{"label":"两天","value":"2"},{"label":"三天","value":"3"}],"cascaderItem":[],"span":24,"display":true,"props":{"label":"label","value":"value"},"prop":"1629695859796_23456","change":"({value}) => {\r\n    let text = value\r\n    if(value) {\r\n        text = ''请假 '' + value + '' 天''\r\n    }\r\n    this.form.input2 = text\r\n}"},{"type":"input","label":"单行文本","span":24,"display":true,"prop":"input2"}],"labelPosition":"left","labelSuffix":"：","labelWidth":120,"gutter":0,"menuBtn":true,"submitBtn":true,"submitText":"提交","emptyBtn":true,"emptyText":"清空","menuPosition":"center"}', 1, 1642162799092207618, N'字段联动示例', 1123598821738675201, 1123598813738675201, '2021-08-23 13:11:54.0000000', 1123598821738675201, '2023-04-01 21:58:47.0000000', 1, 0, N'000000');
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_form_default_values
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_default_values]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_default_values]
    GO

CREATE TABLE [dbo].[blade_wf_form_default_values] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [content] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field_type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_default_values] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'字段类型',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'field_type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单字段默认值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_default_values'
    GO


-- ----------------------------
-- Records of blade_wf_form_default_values
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399346112331087873, N'当前操作人姓名', N'${this.$store.getters.userInfo.nick_name}', N'input', 1123598821738675201, 1123598813738675201, '2021-05-31 20:44:46.0000000', 1123598821738675201, '2021-05-31 20:56:32.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399347906465595393, N'当前操作人部门', N'${this.$store.getters.userInfo.dept_name}', N'input', 1123598821738675201, 1123598813738675201, '2021-05-31 20:51:54.0000000', 1123598821738675201, '2021-05-31 20:56:41.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399717069960855553, N'当前日期', N'${this.dateFormat(new Date(),"YYYY-MM-DD")}', N'input', 1123598821738675201, 1123598813738675201, '2021-06-01 21:18:50.0000000', 1123598821738675201, '2023-04-01 21:44:30.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399717187904684034, N'当前操作人职位', N'${this.$store.getters.userInfo.post_name}', N'input', 1123598821738675201, 1123598813738675201, '2021-06-01 21:19:18.0000000', 1123598821738675201, '2021-06-01 21:19:18.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399717285564858369, N'当前时间', N'${this.dateFormat(new Date(),"HH:mm:ss")}', N'input', 1123598821738675201, 1123598813738675201, '2021-06-01 21:19:41.0000000', 1123598821738675201, '2023-04-01 17:27:03.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1399718803940655106, N'当前操作人姓名和日期', N'${this.$store.getters.userInfo.nick_name} - ${this.dateFormat(new Date(),"YYYY-MM-DD")}', N'input', 1123598821738675201, 1123598813738675201, '2021-06-01 21:25:43.0000000', 1123598821738675201, '2023-04-01 21:46:20.0000000', N'1', 0, N'000000');
INSERT INTO [dbo].[blade_wf_form_default_values] ([id], [name], [content], [field_type], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (1408401952027443201, N'当前操作人姓名', N'${this.$store.getters.userInfo.nick_name}', N'input', 1123598821738675201, 1123598813738675201, '2021-06-25 20:29:27.0000000', 1123598821738675201, '2021-06-25 20:29:32.0000000', N'1', 1, N'000000');
GO

COMMIT
GO


-- ----------------------------
-- Table structure for blade_wf_form_history
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_history]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_history]
    GO

CREATE TABLE [dbo].[blade_wf_form_history] (
    [id] bigint  NOT NULL,
    [form_id] bigint  NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [app_content] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [version] int  NULL,
    [category_id] bigint  NULL,
    [remark] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_history] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'form_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'app表单内容',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'app_content'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'版本',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'version'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'category_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'备注',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'remark'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_history'
    GO


-- ----------------------------
-- Records of blade_wf_form_history
-- ----------------------------
BEGIN TRANSACTION
GO

COMMIT
GO

-- ----------------------------
-- Table structure for blade_wf_form_theme
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_theme]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_theme]
    GO

CREATE TABLE [dbo].[blade_wf_form_theme] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [theme_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL,
    [border_width] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [border_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_bg] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_width] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [label_font_size] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_color] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_bg] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [value_font_size] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field0] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field1] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field2] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field3] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field4] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field5] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field6] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field7] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field8] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [field9] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_theme] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'主题key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'theme_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'边框宽度',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'border_width'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'边框颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'border_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label字体颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label背景颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_bg'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label宽度',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_width'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'label字体大小',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'label_font_size'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value字体颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_color'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value背景颜色',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_bg'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'value字体大小',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'value_font_size'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field0'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field1'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field2'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field3'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field4'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field5'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field6'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field7'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field8'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'预留字段',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'field9'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单 - 主题',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_theme'
    GO


-- ----------------------------
-- Records of blade_wf_form_theme
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'1', N'蓝色', N'blue', N'1px', N'#cbdcf0', N'#01418a', N'#eef6ff', N'', N'14px', N'', N'', N'14px', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598813738675201', N'2023-04-04 15:36:46.0000000', N'1123598821738675201', N'2023-05-04 10:43:18.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'2', N'默认', N'default', N'1px', N'rgba(235, 238, 245, 1)', N'rgba(144, 147, 153, 1)', N'rgba(250, 250, 250, 1)', NULL, NULL, N'rgba(96, 98, 102, 1)', N'rgba(255, 255, 255, 1)', NULL, N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598813738675201', N'2023-04-04 15:16:47.0000000', N'1123598821738675201', N'2023-04-18 11:50:10.0000000', N'1', N'0', N'000000')
GO

INSERT INTO [dbo].[blade_wf_form_theme] ([id], [name], [theme_key], [border_width], [border_color], [label_color], [label_bg], [label_width], [label_font_size], [value_color], [value_bg], [value_font_size], [field0], [field1], [field2], [field3], [field4], [field5], [field6], [field7], [field8], [field9], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted], [tenant_id]) VALUES (N'3', N'黑色', N'black', N'1px', N'rgba(0, 0, 0, 1)', N'#000', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'', N'1123598821738675201', N'1123598821738675201', N'2023-04-04 16:57:35.0000000', N'1123598821738675201', N'2023-05-04 10:43:44.0000000', N'1', N'0', N'000000')
GO

COMMIT
GO


-- ----------------------------
-- Indexes structure for table blade_wf_form_theme
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_THEME_KEY]
ON [dbo].[blade_wf_form_theme] (
  [theme_key] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_theme
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_theme] ADD CONSTRAINT [PK__blade_wf__3213E83FE1B9E59C] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

-- ----------------------------
-- Table structure for blade_wf_form_variable
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_form_variable]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_form_variable]
    GO

CREATE TABLE [dbo].[blade_wf_form_variable] (
    [id] bigint  NOT NULL,
    [process_ins_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [deployment_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_def_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [task_name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_option] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_variable] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [create_dept] bigint  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_form_variable] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程实例id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'process_ins_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'deployment_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务节点key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_def_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务节点名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'task_name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单js',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'form_option'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'表单值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'form_variable'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程表单 - 历史变量',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_form_variable'
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_variable
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_variable] ADD CONSTRAINT [PK__blade_wf__3213E83F21E7286A] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

-- ----------------------------
-- Table structure for blade_wf_listener
-- ----------------------------
    IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_listener]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_listener]
    GO

CREATE TABLE [dbo].[blade_wf_listener] (
    [id] bigint  NOT NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [category] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [event] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [val] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [tenant_id] nvarchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS DEFAULT '000000' NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_listener] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'分类',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'category'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'事件',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'event'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'监听类型',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'val'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'租户ID',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener',
    'COLUMN', N'tenant_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'任务/执行监听器',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_listener'
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_listener
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_listener] ADD CONSTRAINT [PK__blade_wf__3213E83FF80DDE18] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

-- ----------------------------
-- Table structure for blade_wf_model_scope
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_model_scope]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_model_scope]
    GO

CREATE TABLE [dbo].[blade_wf_model_scope] (
    [id] bigint  NOT NULL,
    [model_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [model_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [val] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [text] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_model_scope] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope',
    'COLUMN', N'model_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'模型key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope',
    'COLUMN', N'model_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'类型 user用户 role角色 dept部门 post职位',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'用户/角色/部门/职位 id集合',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope',
    'COLUMN', N'val'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'用户/角色/部门/职位 name集合',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope',
    'COLUMN', N'text'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程模型权限',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_model_scope'
    GO


-- ----------------------------
-- Records of blade_wf_model_scope
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1418457955400978434', N'0676f2277420b7dc67f69dd3a0ec1164', N'ex-leave', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1418457988913467393', N'5b7a367e1139f1ab5cb1e6210685fa91', N'demo-multi-instance', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1418458020752429058', N'fb4c1a6a8c4588779a2519a547966846', N'test-default-values', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1429675430591442946', N'89d9c299dfed64a7834fdb7caccc913f', N'field-linkage', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1447556025547763714', N'd71049b6ba4eda39cacf9baf984274ac', N'indep-form', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1493407710006243329', N'2f6b3b6de24354bb5df5aad3a87789af', N'leave', N'role', N'1123598816738675201,1123598816738675202,1123598816738675203,1123598816738675204,1123598816738675205', N'超级管理员,用户,人事,经理,老板')
GO

INSERT INTO [dbo].[blade_wf_model_scope] ([id], [model_id], [model_key], [type], [val], [text]) VALUES (N'1493407710014631938', N'2f6b3b6de24354bb5df5aad3a87789af', N'leave', N'platform', N'h5', N'移动端H5')
GO

COMMIT
GO

-- ----------------------------
-- Table structure for blade_wf_process_leave
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_process_leave]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_process_leave]
    GO

CREATE TABLE [dbo].[blade_wf_process_leave] (
    [id] bigint  NOT NULL,
    [process_ins_id] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [process_def_id] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [current_node] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [datetime] nvarchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [days] int  NULL,
    [reason] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [attachment] nvarchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NOT NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] int  NULL,
    [is_deleted] int DEFAULT 0 NULL,
    [form_key] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [form_url] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_process_leave] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程实例id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'process_ins_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程定义id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'process_def_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'当前节点',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'current_node'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'时间范围',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'datetime'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假天数',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'days'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假理由',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'reason'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'附件',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'attachment'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'form_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'外置表单url',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave',
    'COLUMN', N'form_url'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'请假流程业务示例',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_process_leave'
    GO


    -- ----------------------------
-- Table structure for blade_wf_proxy
-- ----------------------------
    IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_proxy]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_proxy]
    GO

CREATE TABLE [dbo].[blade_wf_proxy] (
    [id] bigint  NOT NULL,
    [user_id] bigint  NULL,
    [proxy_user_id] bigint  NULL,
    [process_def_key] nvarchar(750) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [type] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [start_time] datetime2(7)  NULL,
    [end_time] datetime2(7)  NULL,
    [status] int  NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_proxy] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'委托人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'代理人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'proxy_user_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程定义key',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'process_def_key'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'1永久 2定时',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'type'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'开始时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'start_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'结束时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'end_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程代理',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_proxy'
    GO

-- ----------------------------
-- Table structure for blade_wf_serial
-- ----------------------------
IF EXISTS (SELECT * FROM sys.all_objects WHERE object_id = OBJECT_ID(N'[dbo].[blade_wf_serial]') AND type IN ('U'))
DROP TABLE [dbo].[blade_wf_serial]
    GO

CREATE TABLE [dbo].[blade_wf_serial] (
    [id] bigint  NOT NULL,
    [deployment_id] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [name] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [prefix] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [date_format] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [suffix_length] int  NULL,
    [start_sequence] int  NULL,
    [connector] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [current_sequence] int  NULL,
    [cycle] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [create_user] bigint  NULL,
    [create_dept] bigint  NULL,
    [create_time] datetime2(7)  NULL,
    [update_user] bigint  NULL,
    [update_time] datetime2(7)  NULL,
    [status] nvarchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS  NULL,
    [is_deleted] int DEFAULT 0 NULL
    )
    GO

ALTER TABLE [dbo].[blade_wf_serial] SET (LOCK_ESCALATION = TABLE)
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'部署id',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'deployment_id'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'名称',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'name'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'前缀',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'prefix'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'日期格式化',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'date_format'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'后缀位数',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'suffix_length'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'初始数值',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'start_sequence'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'连接符',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'connector'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'当前序列',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'current_sequence'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'重置周期 none不重置 day天 week周 month月 year年',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'cycle'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'create_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建部门',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'create_dept'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'创建时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'create_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改人',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'update_user'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'修改时间',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'update_time'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'状态',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'status'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'是否已删除',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial',
    'COLUMN', N'is_deleted'
    GO

    EXEC sp_addextendedproperty
    'MS_Description', N'流程流水号',
    'SCHEMA', N'dbo',
    'TABLE', N'blade_wf_serial'
    GO


-- ----------------------------
-- Records of blade_wf_serial
-- ----------------------------
BEGIN TRANSACTION
GO

INSERT INTO [dbo].[blade_wf_serial] ([id], [deployment_id], [name], [prefix], [date_format], [suffix_length], [start_sequence], [connector], [current_sequence], [cycle], [create_user], [create_dept], [create_time], [update_user], [update_time], [status], [is_deleted]) VALUES (N'1493407680641921025', N'a35a73a4-8e04-11ec-9e83-92d6166784a9', N'请假流水号', N'Leave', N'yyyyMMdd', N'5', N'0', N'', N'1', N'none', NULL, NULL, N'2022-02-15 10:11:51.8940000', N'1123598821738675201', N'2022-02-15 10:12:12.5750000', N'1', N'1')
GO

COMMIT
GO


-- ----------------------------
-- Indexes structure for table ACT_DE_MODEL
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_MODEL_KEY]
ON [dbo].[ACT_DE_MODEL] (
  [model_key] ASC,
  [tenant_id] ASC
)
GO

CREATE NONCLUSTERED INDEX [idx_proc_mod_created]
ON [dbo].[ACT_DE_MODEL] (
  [created_by] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ACT_DE_MODEL
-- ----------------------------
ALTER TABLE [dbo].[ACT_DE_MODEL] ADD CONSTRAINT [PK__ACT_DE_M__3213E83FC76FC5C7] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table ACT_DE_MODEL_HISTORY
-- ----------------------------
CREATE NONCLUSTERED INDEX [idx_proc_mod_history_proc]
ON [dbo].[ACT_DE_MODEL_HISTORY] (
  [model_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table ACT_DE_MODEL_HISTORY
-- ----------------------------
ALTER TABLE [dbo].[ACT_DE_MODEL_HISTORY] ADD CONSTRAINT [PK__ACT_DE_M__3213E83F74E9721D] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_button
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_button] ADD CONSTRAINT [PK__blade_wf__3213E83FA7AAFF79] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_category
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_category] ADD CONSTRAINT [PK__blade_wf__3213E83F090A6076] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table blade_wf_condition
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_EXPRESSION]
ON [dbo].[blade_wf_condition] (
  [expression] ASC,
  [type] ASC,
  [tenant_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_condition
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_condition] ADD CONSTRAINT [PK__blade_wf__3213E83F09AC2B92] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_copy
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_copy] ADD CONSTRAINT [PK__blade_wf__3213E83FB51F11C3] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_deployment_form
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_deployment_form] ADD CONSTRAINT [PK__blade_wf__3213E83F06F23ECF] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table blade_wf_draft
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_DRAFT_UNI]
ON [dbo].[blade_wf_draft] (
  [user_id] ASC,
  [process_def_id] ASC,
  [platform] ASC
)
GO

CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_DRAFT_UNI2]
ON [dbo].[blade_wf_draft] (
  [user_id] ASC,
  [task_id] ASC,
  [platform] ASC
)
GO

-- ----------------------------
-- Primary Key structure for table blade_wf_draft
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_draft] ADD CONSTRAINT [PK__blade_wf__3213E83F1EC6CDBD] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table blade_wf_form
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_FORM_KEY]
ON [dbo].[blade_wf_form] (
  [form_key] ASC,
  [tenant_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form] ADD CONSTRAINT [PK__blade_wf__3213E83F02914E3C] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_default_values
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_default_values] ADD CONSTRAINT [PK__blade_wf__3213E83F1ADE97B9] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_form_history
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_form_history] ADD CONSTRAINT [PK__blade_wf__3213E83FC05BEC14] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Primary Key structure for table blade_wf_model_scope
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_model_scope] ADD CONSTRAINT [PK__blade_wf__3213E83FDD345387] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

-- ----------------------------
-- Primary Key structure for table blade_wf_process_leave
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_process_leave] ADD CONSTRAINT [PK__blade_wf__639A04C108BAB258] PRIMARY KEY CLUSTERED ([id], [create_time])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO


-- ----------------------------
-- Indexes structure for table blade_wf_proxy
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [WF_IDX_UNI_PROXY]
ON [dbo].[blade_wf_proxy] (
  [user_id] ASC,
  [process_def_key] ASC
)
GO

CREATE NONCLUSTERED INDEX [WF_IDX_USER_ID]
ON [dbo].[blade_wf_proxy] (
  [user_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_proxy
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_proxy] ADD CONSTRAINT [PK__blade_wf__3213E83F8DB1B00B] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO



-- ----------------------------
-- Indexes structure for table blade_wf_serial
-- ----------------------------
CREATE UNIQUE NONCLUSTERED INDEX [uni]
ON [dbo].[blade_wf_serial] (
  [deployment_id] ASC
)
GO


-- ----------------------------
-- Primary Key structure for table blade_wf_serial
-- ----------------------------
ALTER TABLE [dbo].[blade_wf_serial] ADD CONSTRAINT [PK__blade_wf__3213E83F4B321660] PRIMARY KEY CLUSTERED ([id])
    WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
    ON [PRIMARY]
    GO

