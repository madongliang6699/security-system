package org.springblade.plugin.workflow.core.listener;

import feign.Feign;
import feign.Param;
import feign.RequestLine;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import lombok.AllArgsConstructor;
import org.apache.commons.collections4.map.LinkedMap;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.workflow.core.utils.WfTaskUtil;
import org.springblade.plugin.workflow.entity.SimpleTask;
import org.springblade.plugin.workflow.entity.TaskListenerInfo;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.springblade.plugin.workflow.constant.AppConstant.TASK_LISTENER_KEY;

@Service
@AllArgsConstructor
public class CNOOCTaskListenerService {
	private BladeRedis bladeRedis;
	private RestTemplate restTemplate;

	public R<Boolean> parseTaskListener(SimpleTask task) {
		TaskListenerInfo info = bladeRedis.hGet(TASK_LISTENER_KEY, WfTaskUtil.getProcessDefKeyByDefId(task.getProcessDefinitionId()));
		if (info == null) {
			return R.fail("没有找到对应的任务监听器");
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		Map<String, Object> data = new LinkedMap<>();
		data.put("task", task);

		HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(data, headers);

		String url = "http://" + info.getApplicationName() + info.getEndpoint();
		ParameterizedTypeReference<R<Boolean>> responseType = new ParameterizedTypeReference<>() {};
		ResponseEntity<R<Boolean>> resultRes = restTemplate.exchange(url, HttpMethod.POST, requestEntity, responseType);
		if (!resultRes.getStatusCode().is2xxSuccessful()) {
			throw new ServiceException(String.format("解析%s服务任务用户或用户组失败，http错误码：%d",
				info.getApplicationName(), resultRes.getStatusCode().value()));
		}
		R<Boolean> result = resultRes.getBody();
		if (result == null || !result.isSuccess()) {
			throw new ServiceException(String.format("解析%s服务任务用户或用户组失败，错误信息：%s", info.getApplicationName(),
				result.getMsg()));
		}
		return result;
	}

	private R<Boolean> callTaskListener(String baseUrl, String endpoint, SimpleTask task) {
		DynamicTaskListenerApiClient client = Feign.builder()
			.encoder(new JacksonEncoder())
			.decoder(new JacksonDecoder())
			.target(DynamicTaskListenerApiClient.class, baseUrl);

		return client.callDynamicEndpoint(task, endpoint);
	}

	// Feign interface for a dynamic endpoint
	interface DynamicTaskListenerApiClient {
		@RequestLine("POST {endpoint}")
		R<Boolean> callDynamicEndpoint(SimpleTask task, @Param("endpoint") String endpoint);
	}
}
