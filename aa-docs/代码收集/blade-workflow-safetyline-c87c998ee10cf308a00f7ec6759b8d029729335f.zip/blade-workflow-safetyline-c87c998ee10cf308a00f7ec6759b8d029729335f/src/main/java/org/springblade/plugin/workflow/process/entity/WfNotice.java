package org.springblade.plugin.workflow.process.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.experimental.Accessors;
import org.flowable.engine.runtime.ProcessInstance;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

/**
 * 流程消息实体类
 *
 * @author ssc
 */
@Data
@Accessors(chain = true)
public class WfNotice implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	@Schema(description = "发送者")
	private String fromUserId;

	@Schema(description = "接受者")
	private String toUserId;

	@Schema(description = "评论")
	private String comment;

	@Schema(description = "任务id")
	private String taskId;

	@Schema(description = "流程实例id")
	private String processId;

	@Schema(description = "任务变量")
	private Map<String, Object> taskVariables;

	@Schema(description = "消息类型")
	private Type type;

	@Getter
	@AllArgsConstructor
	public enum Type {

		START("start", "发起流程", 1),
		PASS("pass", "审核通过", 2),
		REJECT("reject", "审核驳回", 3),
		TRANSFER("transfer", "转办任务", 4),
		DELEGATE("delegate", "委托任务", 5),
		TERMINATE("terminate", "流程终结", 6),
		FINISH("finish", "流程结束", 7),
		CANDIDATE("candidate", "候选任务", 8),
		COPY("copy", "抄送任务", 9),
		ASSIGNEE("assignee", "变更审核人", 10),
		SUSPEND("suspend", "流程挂起", 11),
		ACTIVE("active", "流程激活", 12),
		URGE("urge", "催办任务", 13),
		DISPATCH("dispatch", "调度任务", 14),
		ADD_MULTI_INSTANCE("addMultiInstance", "加签任务", 15),
		DELETE_MULTI_INSTANCE("deleteMultiInstance", "减签任务", 16),
		CANCEL("cancel", "撤销流程", 17),
		DELETE_PROCESS("deleteProcess", "删除流程", 18),
		RECALL("recall", "撤回流程", 19);

		private final String type;
		private final String name;
		private final Integer code;
	}

	@TableField(exist = false)
	private Boolean skip;

	@Schema(description = "租户id")
	@TableField(exist = false)
	private String tenantId;

	@Schema(description = "流程实例")
	@TableField(exist = false)
	private ProcessInstance processInstance;
}
