package org.springblade.plugin.workflow;

import org.springblade.core.cloud.client.BladeCloudApplication;
import org.springblade.core.cloud.feign.EnableBladeFeign;
import org.springblade.core.launch.BladeApplication;

import static org.springblade.plugin.workflow.constant.AppConstant.APPLICATION_WORKFLOW_NAME;

@EnableBladeFeign
//@SpringCloudApplication
@BladeCloudApplication
public class WorkflowApplication {

	public static void main(String[] args) {
		BladeApplication.run(APPLICATION_WORKFLOW_NAME, WorkflowApplication.class, args);
	}
}
