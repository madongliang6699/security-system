package org.springblade.plugin.workflow.design.service.impl;

import lombok.RequiredArgsConstructor;
import org.flowable.bpmn.model.StartEvent;
import org.flowable.engine.HistoryService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.task.api.Task;
import org.jetbrains.annotations.Nullable;
import org.springblade.plugin.workflow.core.constant.WfProcessConstant;
import org.springblade.plugin.workflow.design.entity.WfFormVariable;
import org.springblade.plugin.workflow.design.vo.WfFormVariableVO;
import org.springblade.plugin.workflow.design.mapper.WfFormVariableMapper;
import org.springblade.plugin.workflow.design.service.IWfFormVariableService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;

import java.util.Map;

/**
 * 流程表单 - 历史变量 服务实现类
 *
 * @author ssc
 */
@Service
@RequiredArgsConstructor
public class WfFormVariableServiceImpl extends BaseServiceImpl<WfFormVariableMapper, WfFormVariable> implements IWfFormVariableService {

	private final HistoryService historyService;

	@Override
	public IPage<WfFormVariableVO> selectWfFormVariablePage(IPage<WfFormVariableVO> page, WfFormVariableVO wfFormVariable) {
		return page.setRecords(baseMapper.selectWfFormVariablePage(page, wfFormVariable));
	}

	@Async
	@Override
	public void saveFormVariable(String processInsId, @Nullable Task task, @Nullable StartEvent startEvent, Map<String, Object> variables, Long createUser) {
		if (variables == null) {
			return;
		}
		Object formOption = variables.get(WfProcessConstant.TASK_VARIABLE_FORM_OPTION);
		Object formVariable = variables.get(WfProcessConstant.TASK_VARIABLE_FORM_VARIABLE);
		if (formOption == null || formVariable == null) {
			return;
		}
		HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery()
			.processInstanceId(processInsId)
			.singleResult();
		if (historicProcessInstance == null) {
			return;
		}

		WfFormVariable variable = new WfFormVariable();
		variable.setProcessInsId(historicProcessInstance.getId());
		variable.setDeploymentId(historicProcessInstance.getDeploymentId());
		if (task != null) {
			variable.setTaskId(task.getId());
			variable.setTaskDefKey(task.getTaskDefinitionKey());
			variable.setTaskName(task.getName());
		} else if (startEvent != null) {
			variable.setTaskDefKey(startEvent.getId());
			variable.setTaskName(startEvent.getName());
		}
		variable.setFormOption(formOption.toString());
		variable.setFormVariable(formVariable.toString());
		variable.setCreateUser(createUser);

		this.save(variable);
	}
}
