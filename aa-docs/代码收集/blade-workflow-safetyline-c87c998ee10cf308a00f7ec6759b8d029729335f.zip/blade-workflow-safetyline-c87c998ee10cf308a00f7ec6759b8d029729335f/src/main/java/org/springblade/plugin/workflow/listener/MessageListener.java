package org.springblade.plugin.workflow.listener;

import org.flowable.engine.delegate.TaskListener;
import org.flowable.task.service.delegate.DelegateTask;
import org.springblade.core.tool.utils.SpringUtil;
import org.springblade.plugin.message.enums.MessageEnum;
import org.springblade.plugin.message.feign.IMessageClient;
import org.springblade.plugin.message.params.MessageParams;
import org.springframework.stereotype.Service;


/**
 * 发送消息监听
 * 可在流程内传递参数自定义发送内容
 * @author weikun
 */
@Service
public class MessageListener implements TaskListener {

	@Override
	public void notify(DelegateTask delegateTask) {
		IMessageClient messageClient = SpringUtil.getBean("org.springblade.message.feign.IMessageClient");
		String assignee = delegateTask.getAssignee();
		String userId = assignee.split("_")[1];
		MessageParams message = MessageParams.builder().title(delegateTask.getName())
			.content("您有新的流程待审批，请前往待办事务查看")
			.receiveUser(Long.valueOf(userId))
			.type(MessageEnum.APPROVAL.getCode())
			.build();
		messageClient.sendMsg(message);
	}
}
