package org.springblade.plugin.workflow.core.listener;

import lombok.AllArgsConstructor;
import org.flowable.task.service.delegate.DelegateTask;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.workflow.entity.SimpleTask;
import org.springblade.plugin.workflow.wrapper.FlowableSimplify;
import org.springframework.stereotype.Component;

@Component("wfTaskListener")
@AllArgsConstructor
public class WfTaskListener implements org.flowable.engine.delegate.TaskListener {
	private CNOOCTaskListenerService cnoocTaskListenerService;

	@Override
	public void notify(DelegateTask delegateTask) {
//		System.err.println(delegateTask.getEventName());
//		String eventName = delegateTask.getEventName();
//		switch (eventName) {
//			case EVENTNAME_CREATE:
//				System.err.println("任务创建");
//				break;
//			case EVENTNAME_ASSIGNMENT:
//				System.err.println("任务分配审核人");
//				break;
//			case EVENTNAME_COMPLETE:
//				System.err.println("任务完成");
//				break;
//			case EVENTNAME_DELETE:
//				System.err.println("任务删除");
//				break;
//		}
		SimpleTask task = FlowableSimplify.simpleDelegateTask(delegateTask);
		R<Boolean> result = cnoocTaskListenerService.parseTaskListener(task);
		if (result == null) {
			throw new RuntimeException("调用任务监听器失败");
		}
		if (!result.isSuccess()) {
			throw new RuntimeException(result.getMsg());
		} else if (!result.getData()) {
			throw new RuntimeException("任务监听器返回失败");
		}
	}
}
