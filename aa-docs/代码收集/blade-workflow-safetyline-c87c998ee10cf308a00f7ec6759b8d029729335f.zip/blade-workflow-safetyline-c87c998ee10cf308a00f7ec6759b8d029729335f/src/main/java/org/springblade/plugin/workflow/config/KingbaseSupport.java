package org.springblade.plugin.workflow.config;

import lombok.RequiredArgsConstructor;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.flowable.spring.SpringProcessEngineConfiguration;
import org.springframework.stereotype.Component;

@Aspect
@Component
@RequiredArgsConstructor
public class KingbaseSupport {

	private final SpringProcessEngineConfiguration appEngineConfiguration;

	@Pointcut("execution(* org.flowable.spring.SpringProcessEngineConfiguration.buildProcessEngine())")
	public void access() {

	}

	@Before("access()")
	public void before() {
		appEngineConfiguration.setDatabaseType("oracle");
	}
}
