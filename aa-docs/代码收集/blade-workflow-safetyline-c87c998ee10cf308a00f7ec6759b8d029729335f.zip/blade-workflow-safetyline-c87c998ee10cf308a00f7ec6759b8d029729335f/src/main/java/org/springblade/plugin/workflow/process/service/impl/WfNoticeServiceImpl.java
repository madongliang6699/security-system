package org.springblade.plugin.workflow.process.service.impl;

import com.alibaba.fastjson.JSON;
import lombok.AllArgsConstructor;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.impl.persistence.entity.ExecutionEntity;
import org.flowable.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.flowable.engine.impl.persistence.entity.HistoricProcessInstanceEntityImpl;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.identitylink.api.IdentityLinkInfo;
import org.flowable.task.api.history.HistoricTaskInstance;
import org.jetbrains.annotations.NotNull;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.ObjectUtil;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.plugin.workflow.core.constant.WfProcessConstant;
import org.springblade.plugin.workflow.core.user.WfUser;
import org.springblade.plugin.workflow.core.user.WfUserCache;
import org.springblade.plugin.workflow.core.user.WfUserService;
import org.springblade.plugin.workflow.demo.entity.WfProcessLeave;
import org.springblade.plugin.workflow.demo.service.IWfProcessLeaveService;
import org.springblade.plugin.workflow.process.entity.WfNotice;
import org.springblade.plugin.workflow.process.service.IWfNoticeService;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * 流程消息 服务实现类
 *
 * @author ssc
 */
@Service
@AllArgsConstructor
public class WfNoticeServiceImpl implements IWfNoticeService {

	private final RuntimeService runtimeService;
	private final TaskService taskService;
	private final HistoryService historyService;

	private final WfUserService userSearchService;
	private final BladeRedis redis;

	private final IWfProcessLeaveService leaveService;

	@Async
	@Override
	public void sendNotice(WfUser fromUser, WfUser toUser, String comment, WfNotice.Type type, HistoricProcessInstance processInstance, @Nullable HistoricTaskInstance task, Map<String, Object> taskVariables) {
		System.err.println("发送人：" + fromUser.getName());
		System.err.println("接受人：" + toUser.getName());
		System.err.println("消息内容：" + buildMessage(fromUser, toUser, processInstance, task, comment, type));
		System.err.println("消息类型：" + type.getName());
		System.err.println("流程变量：" + processInstance.getProcessVariables());
		System.err.println("流程状态：" + (processInstance.getEndTime() == null ? "审核中" : "已结束"));
		System.err.println("任务变量：" + taskVariables);
		if (task != null) {
			System.err.println("任务节点：" + task.getTaskDefinitionKey() + " - " + task.getName());
		}

		// 控制发起流程只触发一遍业务
		if (type.equals(WfNotice.Type.START)) {
			String key = "wf_start_" + processInstance.getId();
			Object value = redis.get(key);
			if (ObjectUtil.isEmpty(value)) {
				redis.setEx(key, "1", 60 * 60 * 24L);
			} else {
				return;
			}
		}

		/*
		  模拟同业务对接，以下操作不保证正确，请根据实际情况进行修改。
		  ！！！此处对接业务只是临时方法，目前缺少连接流程与业务的独立模块，正在规划中！！！
		  1、通过流程定义key区分操作哪一个业务
		  2、通过WfNotice.Type区分流程进行了哪一步操作
		  3、此方法为异步方法，请确保操作的业务能成功。若不能保证，请去掉@Async注解，并添加事务控制。
		 */
		// 流程/模型定义key，用于区分保存到哪个业务表
		String processDefKey = processInstance.getProcessDefinitionKey();
		try {
			switch (type) { // 根据type判断流程进行了哪一步操作
				case START: // 发起流程
					if ("leave".equals(processDefKey)) { // 假设为请假业务
						// 将发起表单变量转换为Leave对象，请确保表单内变量prop与Leave对象字段相匹配
						WfProcessLeave leave = JSON.parseObject(JSON.toJSONString(processInstance.getProcessVariables()), WfProcessLeave.class);
						leave.setProcessInsId(processInstance.getId());
						leave.setProcessDefId(processInstance.getProcessDefinitionId());
						leave.setCreateUser(fromUser.getId());
						leave.setCreateDept(Func.firstLong(fromUser.getDeptId()));
						leave.setUpdateUser(fromUser.getId());
						leave.setCurrentNode(task == null ? "" : task.getName());

						leaveService.save(leave);
						// 业务保存成功后将返回的id更新到流程业务key，以后可根据流程业务key对业务直接进行操作
						runtimeService.updateBusinessKey(processInstance.getId(), String.valueOf(leave.getId()));
					}
					break;
				case REJECT: // 某一任务节点审核驳回
				case ASSIGNEE: // 某一任务节点审核通过
				case PASS: // 某一任务节点审核通过
				case CANDIDATE: // 某一任务节点审核通过
				case DISPATCH: // 某一任务被调度
				case TERMINATE: // 流程被终结（流程非正常完成）
				case CANCEL: // 流程撤销
				case FINISH: // 流程正常完成
				case DELETE_PROCESS: // 流程被删除
				case RECALL: // 流程撤回
					// 此处获取的业务key就是发起时的业务id
					String businessKey = processInstance.getBusinessKey();
					// 此处模拟流程操作时修改业务状态
					if ("leave".equals(processDefKey)) {
						WfProcessLeave leave = new WfProcessLeave();
						leave.setId(Long.valueOf(businessKey));
						leave.setCurrentNode(task == null ? "结束" : task.getName());
						leave.setStatus(type.getCode());
						leaveService.updateById(leave);
					}
					break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Async
	@Override
	public Future<String> resolveNoticeInfo(WfNotice notice) {
		String tenantId = notice.getTenantId();
		// 流程实例
		String processId = notice.getProcessId();
		HistoricProcessInstance processInstance;
		if (WfNotice.Type.START.equals(notice.getType())) {
			processInstance = new HistoricProcessInstanceEntityImpl(getExecutionEntity(notice.getProcessInstance()));
		} else {
			processInstance = historyService
					.createHistoricProcessInstanceQuery()
					.includeProcessVariables()
					.processInstanceId(processId).singleResult();
		}

		// 当前任务实例
		String taskId = notice.getTaskId();
		HistoricTaskInstance task = null;
		if (StringUtil.isNotBlank(taskId)) {
			task = historyService.createHistoricTaskInstanceQuery()
				.taskId(taskId)
				.singleResult();
		}

		// 当前节点用户
		String fromUserId = notice.getFromUserId();
		WfUser fromUser = WfUserCache.getUser(Long.valueOf(fromUserId), tenantId);

		// 流程申请人
		String applyUserId = processInstance.getStartUserId();
		WfUser applyUser = WfUserCache.getUser(Long.valueOf(applyUserId), tenantId);

		// 审核意见
		String comment = notice.getComment();

		// 任务变量
		Map<String, Object> taskVariables = notice.getTaskVariables();

		WfNotice.Type type = notice.getType();

		switch (type) {
			case START:
				Boolean skip = notice.getSkip();
				if (skip == null || !skip) {
					this.sendNotice(applyUser, applyUser, comment, type, processInstance, task, taskVariables);
				} else {
					this.handleCompleteTask(applyUser, applyUser, processInstance, comment, type, taskVariables, tenantId);
				}
				break;
			case PASS:
			case REJECT:
				this.handleCompleteTask(fromUser, applyUser, processInstance, comment, type, taskVariables, tenantId);
				break;
			case COPY:
			case TRANSFER:
			case DELEGATE:
			case ASSIGNEE:
			case SUSPEND:
			case ACTIVE:
			case URGE:
			case DISPATCH:
			case ADD_MULTI_INSTANCE:
			case DELETE_MULTI_INSTANCE:
				String toUserId = notice.getToUserId();
				WfUser toUser = WfUserCache.getUser(Long.valueOf(toUserId), tenantId);
				this.sendNotice(fromUser, toUser, comment, type, processInstance, task, taskVariables);
				break;
			case TERMINATE:
			case DELETE_PROCESS:
			case CANCEL:
			case RECALL:
				this.sendNotice(fromUser, applyUser, comment, type, processInstance, task, taskVariables);
				break;
		}
		return new AsyncResult<>("");
	}

	/**
	 * 处理审核通过/驳回信息
	 *
	 * @param fromUser                当前节点用户
	 * @param applyUser       	      申请用户
	 * @param historicProcessInstance 流程实例
	 */
	private void handleCompleteTask(WfUser fromUser, WfUser applyUser, HistoricProcessInstance historicProcessInstance, String comment, WfNotice.Type type, Map<String, Object> taskVariables, String tenantId) {
		new Thread(() -> {
            try {
                Thread.sleep(2000);

				HistoricProcessInstance processInstance = historyService.createHistoricProcessInstanceQuery()
						.processInstanceId(historicProcessInstance.getId())
						.includeProcessVariables()
						.singleResult();
				if (processInstance.getEndTime() == null) {
					List<HistoricTaskInstance> taskList = historyService.createHistoricTaskInstanceQuery()
							.processInstanceId(processInstance.getId())
							.taskVariableNotExists(WfProcessConstant.TASK_VARIABLE_NOTICE)
							.includeIdentityLinks()
							.unfinished()
							.list();
					if (taskList != null && !taskList.isEmpty()) {
						for (HistoricTaskInstance nextTask : taskList) {
							// 添加调用消息服务标记，相同任务只调用一次
							if (nextTask.getEndTime() == null) {
								taskService.setVariableLocal(nextTask.getId(), WfProcessConstant.TASK_VARIABLE_NOTICE, "1");
							}

							// 当前节点名称
							// String currentNode = nextTask.getName();
							// 当前节点执行人id
							String toUserId = nextTask.getAssignee();
							if (StringUtil.isBlank(toUserId)) { // 无执行人，查看候选
								List<? extends IdentityLinkInfo> identityLinks = nextTask.getIdentityLinks();
								// 候选组，角色ID、部门ID、职位ID
								List<String> roles = new ArrayList<>();
								// 候选人
								LinkedHashSet<String> userIds = new LinkedHashSet<>();
								identityLinks.forEach(link -> {
									if (StringUtil.isNotBlank(link.getGroupId())) {
										roles.add(link.getGroupId());
									}
									if (StringUtil.isNotBlank(link.getUserId())) {
										userIds.add(link.getUserId());
									}
								});
								// 给候选组发消息
								if (!roles.isEmpty()) {
									List<Long> groups = roles.stream().map(val -> {
										try {
											return Long.valueOf(val);
										} catch (Exception ignore) {
											return 0L;
										}
									}).collect(Collectors.toList());
									// 部门
									userSearchService.listByDept(groups).forEach(user -> userIds.add(String.valueOf(user.getId())));
									// 角色
									userSearchService.listByRole(groups).forEach(user -> userIds.add(String.valueOf(user.getId())));
									// 职位
									userSearchService.listByPost(groups).forEach(user -> userIds.add(String.valueOf(user.getId())));
								}
								// 给候选人发送消息
								for (String userId : userIds) {
									this.sendNotice(fromUser, WfUserCache.getUser(Long.valueOf(userId), tenantId), comment, type, processInstance, nextTask, taskVariables);
								}
							} else {
								// 下一节点执行人
								WfUser toUser = WfUserCache.getUser(Long.valueOf(toUserId), tenantId);
								this.sendNotice(fromUser, toUser, comment, type, processInstance, nextTask, taskVariables);
							}
						}
					}
				} else {
					this.sendNotice(fromUser, applyUser, comment, WfNotice.Type.FINISH, processInstance, null, taskVariables);
				}
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start();
	}

	private String buildMessage(WfUser fromUser, WfUser applyUser, HistoricProcessInstance processInstance, HistoricTaskInstance task, String comment, WfNotice.Type type) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		StringBuilder message = new StringBuilder();
		Object sn = processInstance.getProcessVariables().get(WfProcessConstant.TASK_VARIABLE_SN);
		if (sn != null) {
			message.append("流水号：").append(sn).append(";");
		}
		message.append(processInstance.getName()).append(" - ").append(applyUser.getName()).append(" ").append(dateFormat.format(processInstance.getStartTime())).append(";");
		if (StringUtil.isNotBlank(comment)) {
			message.append("审核意见：").append(comment);
		}
		return message.toString();
	}

	@NotNull
	private static ExecutionEntity getExecutionEntity(ProcessInstance instance) {
		ExecutionEntity entity = ExecutionEntityImpl.createWithEmptyRelationshipCollections();
		entity.setId(instance.getId());
		entity.setProcessDefinitionId(instance.getProcessDefinitionId());
		entity.setProcessDefinitionName(instance.getProcessDefinitionName());
		entity.setProcessDefinitionKey(instance.getProcessDefinitionKey());
		entity.setProcessDefinitionVersion(instance.getProcessDefinitionVersion());
		entity.setBusinessKey(instance.getBusinessKey());
		entity.setBusinessStatus(instance.getBusinessStatus());
		entity.setName(instance.getName());
		entity.setStartUserId(instance.getStartUserId());
		return entity;
	}
}
