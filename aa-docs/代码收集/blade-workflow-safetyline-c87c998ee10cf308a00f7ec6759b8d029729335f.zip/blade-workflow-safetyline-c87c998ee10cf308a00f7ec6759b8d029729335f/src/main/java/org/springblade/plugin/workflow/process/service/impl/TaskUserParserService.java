package org.springblade.plugin.workflow.process.service.impl;

import lombok.AllArgsConstructor;
import org.springblade.core.log.exception.ServiceException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.workflow.core.utils.WfTaskUtil;
import org.springblade.plugin.workflow.entity.TaskUserParserInfo;
import org.springblade.plugin.workflow.process.model.WfTaskUser;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

import static org.springblade.plugin.workflow.constant.AppConstant.TASK_USER_PARSER_KEY;

@Service
@AllArgsConstructor
public class TaskUserParserService {
	private BladeRedis bladeRedis;
	private final RestTemplate restTemplate;

	public WfTaskUser parseTaskUser(String processDefId, String processInstanceId, String nodeId, String userOrGroupCategory) {
		String processDefKey = WfTaskUtil.getProcessDefKeyByDefId(processDefId);
		TaskUserParserInfo info = bladeRedis.hGet(TASK_USER_PARSER_KEY, processDefKey);
		if (info == null) {
			return null;
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(headers);

		LinkedMultiValueMap<String, String> linkedMultiValueMap = new LinkedMultiValueMap<>();
		linkedMultiValueMap.add("processInstanceId", processInstanceId);
		linkedMultiValueMap.add("nodeId", nodeId);
		linkedMultiValueMap.add("userOrGroupCategory", userOrGroupCategory);

		String url = "http://" + info.getApplicationName() + info.getEndpoint();
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParams(linkedMultiValueMap);
		UriComponents uriComponents = builder.build().encode();
		ParameterizedTypeReference<R<WfTaskUser>> responseType = new ParameterizedTypeReference<>() {};
		ResponseEntity<R<WfTaskUser>> taskUserRes = restTemplate.exchange(uriComponents.toUri(), HttpMethod.POST,
			requestEntity, responseType);
		if (!taskUserRes.getStatusCode().is2xxSuccessful()) {
			throw new ServiceException(String.format("解析%s服务任务用户或用户组失败，http错误码：%d",
				info.getApplicationName(), taskUserRes.getStatusCode().value()));
		}
		R<WfTaskUser> taskUser = taskUserRes.getBody();
		if (taskUser == null || !taskUser.isSuccess()) {
			throw new ServiceException(String.format("解析%s服务任务用户或用户组失败，错误信息：%s", info.getApplicationName(),
				taskUser.getMsg()));
		}
		return taskUser.getData();
	}
}
