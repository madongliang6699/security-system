package org.springblade.plugin.workflow.demo.service.impl;

import org.springblade.plugin.workflow.demo.entity.WfProcessLeave;
import org.springblade.plugin.workflow.demo.mapper.WfProcessLeaveMapper;
import org.springblade.plugin.workflow.demo.service.IWfProcessLeaveService;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * 请假流程业务示例 服务实现类
 *
 * @author ssc
 */
@Service
public class WfProcessLeaveServiceImpl extends BaseServiceImpl<WfProcessLeaveMapper, WfProcessLeave> implements IWfProcessLeaveService {

}
