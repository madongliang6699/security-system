package org.springblade.plugin.workflow.feign;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.AllArgsConstructor;
import org.flowable.engine.ProcessEngineConfiguration;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.identitylink.api.IdentityLink;
import org.flowable.identitylink.api.IdentityLinkType;
import org.flowable.task.api.Task;
import org.springblade.core.mp.support.BladePage;
import org.springblade.core.mp.support.Query;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tenant.annotation.NonDS;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.plugin.workflow.app.entity.WfAppProcess;
import org.springblade.plugin.workflow.app.service.IWfAppProcessService;
import org.springblade.plugin.workflow.core.constant.WfProcessConstant;
import org.springblade.plugin.workflow.core.query.WfProcessDefinitionQuery;
import org.springblade.plugin.workflow.core.utils.WfTaskUtil;
import org.springblade.plugin.workflow.design.entity.WfButton;
import org.springblade.plugin.workflow.design.entity.WfCategory;
import org.springblade.plugin.workflow.design.service.IWfButtonService;
import org.springblade.plugin.workflow.design.service.IWfCategoryService;
import org.springblade.plugin.workflow.design.service.IWfModelService;
import org.springblade.plugin.workflow.design.vo.WfCategoryVO;
import org.springblade.plugin.workflow.design.vo.WfModelVO;
import org.springblade.plugin.workflow.entity.SimpleTask;
import org.springblade.plugin.workflow.entity.TaskAction;
import org.springblade.plugin.workflow.entity.TaskListenerInfo;
import org.springblade.plugin.workflow.entity.TaskUserParserInfo;
import org.springblade.plugin.workflow.enums.CommonTaskButton;
import org.springblade.plugin.workflow.ops.model.WfOps;
import org.springblade.plugin.workflow.ops.service.IWfOpsService;
import org.springblade.plugin.workflow.process.model.WfProcess;
import org.springblade.plugin.workflow.process.service.IWfProcessService;
import org.springblade.plugin.workflow.wrapper.FlowableSimplify;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import static org.springblade.plugin.workflow.constant.AppConstant.TASK_LISTENER_KEY;
import static org.springblade.plugin.workflow.constant.AppConstant.TASK_USER_PARSER_KEY;


@NonDS
@RestController
@AllArgsConstructor
public class WorkflowClient implements IWorkflowClient {
	private final IWfAppProcessService processService;
	private final IWfProcessService wfProcessService;
	private final ProcessEngineConfiguration processEngineConfiguration;
	private final TaskService taskService;
	private final RuntimeService runtimeService;
	private final IWfButtonService buttonService;
	private final IWfModelService modelService;
	private final IWfCategoryService wfCategoryService;
	private final IWfOpsService wfOpsService;
	private final BladeRedis bladeRedis;

	@Override
	public R<BladePage<WfAppProcess>> todoList(WfAppProcess wfAppProcess, Integer current, Integer size) {
		wfAppProcess.setStatus(WfProcessConstant.STATUS_TODO);
		Query query = new Query();
		query.setCurrent(current);
		query.setSize(size);
		IPage<WfAppProcess> data = processService.taskList(wfAppProcess, query);
		BladePage page = new BladePage<WfAppProcess>();
		page.setCurrent(data.getCurrent());
		page.setSize(data.getSize());
		page.setTotal(data.getTotal());
		page.setRecords(data.getRecords());
		return R.data(page);
	}

	@Override
	public R<BladePage<WfAppProcess>> doneList(WfAppProcess wfAppProcess, Integer current, Integer size) {
		wfAppProcess.setStatus(WfProcessConstant.STATUS_DONE);
		Query query = new Query();
		query.setCurrent(current);
		query.setSize(size);
		IPage<WfAppProcess> data = processService.processList(wfAppProcess, query);
		BladePage page = new BladePage<WfAppProcess>();
		page.setCurrent(data.getCurrent());
		page.setSize(data.getSize());
		page.setTotal(data.getTotal());
		page.setRecords(data.getRecords());
		return R.data(page);
	}

	@Override
	public R<String> startProcessInstanceByKey(String processDefKey, String bussinessKey, Map<String, Object> variables) {
		return R.data(wfProcessService.startProcessInstanceByKey(processDefKey, bussinessKey, variables));
	}

	@Override
	public R<String> getProcessDefinitionByKey(String flowKey, String tenantId) {
		ProcessDefinition processDefinition = new WfProcessDefinitionQuery(processEngineConfiguration
			.getCommandExecutor())
			.latestVersion()
			.processDefinitionKey(flowKey)
			.processDefinitionTenantId(tenantId)
			.singleResult();
		return R.success(processDefinition == null ? null : processDefinition.getId());
	}

	@Override
	public R transferTask(WfProcess wfProcess) {
		return (R) wfProcessService.transferTask(wfProcess);
	}

	@Override
	public R delegateTask(WfProcess wfProcess) {
		return (R) wfProcessService.delegateTask(wfProcess);
	}

	@Override
	public R terminateProcess(WfProcess wfProcess) {
		return (R) wfProcessService.terminateProcess(wfProcess);
	}

	@Override
	public R<String> addMultiInstance(WfProcess wfProcess) {
		return (R) wfProcessService.addMultiInstance(wfProcess);
	}

	@Override
	public R<String> completeTask(WfProcess wfProcess) {
		return (R) wfProcessService.completeTask(wfProcess);
	}

	@Override
	public R<Boolean> setTaskVariable(String taskId, Map<String, Object> variables) {
		taskService.setVariables(taskId, variables);
		return R.data(true);
	}

	@Override
	public R<Boolean> setRuntimeVariables(String processInstanceId, Map<String, Object> variables) {
		runtimeService.setVariables(processInstanceId, variables);
		return R.data(true);
	}

	@Override
	public R<List<WfButton>> buttonsByTaskId(String taskId) {
		// 此方法获取的函数不包含自定义的formKey和finished字段
		List<WfButton> buttons;
		try {
			buttons = buttonService.getButtonByTaskId(taskId).get();
		} catch (InterruptedException | ExecutionException e) {
			return R.fail("获取按钮失败：" + e.getMessage());
		}
		if (buttons.isEmpty()) return R.data(new ArrayList<>());
		return R.data(buttonService.list(new LambdaQueryWrapper<WfButton>()
			.in(WfButton::getButtonKey, buttons.stream().map(WfButton::getButtonKey).collect(Collectors.toList()))
			.orderByAsc(WfButton::getSort)));
	}

	@Override
	public R<String> getCurrentUserCandidateGroups() {
		return R.data(WfTaskUtil.getCandidateGroup());
	}

	@Override
	public R<WfProcess> getProcessDetail(String taskId, String assignee, String candidateGroup) {
		try {
			return R.data(wfProcessService.detail(taskId, assignee, candidateGroup).get());
		} catch (InterruptedException | ExecutionException e) {
			return R.fail("获取流程详情失败：" + e.getMessage());
		}
	}

	@Override
	public R<Boolean> completeTaskWithAction(String action, WfProcess process) {
		taskService.setVariable(process.getTaskId(), "action", action);
		// pass设为真值，防止调用wfProcessService.rejectTask
		process.setPass(true);
		wfProcessService.completeTask(process);
		return R.data(true);
	}

	@Override
	public R<Boolean> deleteProcess(String processInstanceId) {
		WfOps wfOps = new WfOps();
		wfOps.setProcessInstanceId(processInstanceId);
		wfOpsService.deleteProcessInstance(wfOps);
		return R.data(true);
	}

	@Override
	public R<Boolean> setCurrentTaskAssignee(String processInstanceId, Long userId) {
		List<Task> tasks = taskService.createTaskQuery().processInstanceId(processInstanceId).active().list();
		if (tasks.isEmpty()) {
			return R.fail("流程实例中不存在任务，无法强制修改执行人");
		} else if (tasks.size() > 1) {
			return R.fail("流程实例中存在多个任务，无法强制修改执行人");
		} else {
			taskService.setAssignee(tasks.get(0).getId(), userId.toString());
		}
		return R.data(true);
	}

	@Override
	public R<String> getBusinessKey(String processInstanceId) {
		ProcessInstance instance = runtimeService.createProcessInstanceQuery()
			.processInstanceId(processInstanceId)
			.singleResult();
		return R.data(instance.getBusinessKey());
	}

	@Override
	public R<Boolean> isTaskExist(String taskId) {
		return R.data(taskService.createTaskQuery().taskId(taskId).active().count() > 0);
	}

	@Override
	public R<Object> getRuntimeVariableValue(String processInstanceId, String variable) {
		return R.data(runtimeService.getVariable(processInstanceId, variable));
	}

	@Override
	public R<Boolean> deployModel(String modelId, String category) {
		WfModelVO model = new WfModelVO();
		model.setId(modelId);
		model.setCategory(category); //FIXME 此处category为空
		modelService.deploy(model);
		return R.data(true);
	}

	@Override
	public R<SimpleTask> getTask(@PathVariable String taskId) {
		Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
		SimpleTask simpleTask = FlowableSimplify.simplifyTask(task);
		getCandidates(simpleTask);
		return R.data(simpleTask);
	}

	@Override
	public R<List<SimpleTask>> getTasksByProcessInstanceId(String processInstanceId) {
		List<Task> tasks = taskService.createTaskQuery().processInstanceId(processInstanceId).active().list();
		List<SimpleTask> simpleTasks = tasks.stream().map(FlowableSimplify::simplifyTask).collect(Collectors.toList());
		simpleTasks.forEach(this::getCandidates);
		return R.data(simpleTasks);
	}

	@Override
	public R<WfCategory> getCategoryById(Long id) {
		return R.data(wfCategoryService.getById(id));
	}

	@Override
	public R<List<WfCategoryVO>> getCategoryTree() {
		return R.data(wfCategoryService.tree());
	}

	@Override
	public R<Boolean> commonTaskOperation(TaskAction action) {
		if (action == null || StringUtil.isBlank(action.getButton())) {
			return R.data(false);
		}
		CommonTaskButton commonButton = CommonTaskButton.getByValue(action.getButton());
		if (commonButton == null) {
			return R.data(false);
		}
		switch (commonButton) {
			case COMMON_CONFIRM:
				return completeTaskWithAction(action.getButton(), action);
			case COMMON_CANCEL:
				if (StringUtil.isBlank(action.getComment())) {
					return R.fail("请填写驳回原因");
				}
				return completeTaskWithAction(action.getButton(), action);
			case WF_TRANSFER:
				R<String> result = (R<String>) wfProcessService.transferTask(action);
				if (result.isSuccess()) {
					return R.data(true);
				} else {
					return R.fail(result.getMsg());
				}
			case WF_DELEGATE:
				R<String> result1 = (R<String>) wfProcessService.delegateTask(action);
				if (result1.isSuccess()) {
					return R.data(true);
				} else {
					return R.fail(result1.getMsg());
				}
			case WF_TERMINATE:
				R<String> result2 = (R<String>) wfProcessService.terminateProcess(action);
				if (result2.isSuccess()) {
					return R.data(true);
				} else {
					return R.fail(result2.getMsg());
				}
			case WF_ADD_INSTANCE:
				R<String> result3 = (R<String>) wfProcessService.addMultiInstance(action);
				if (result3.isSuccess()) {
					return R.data(true);
				} else {
					return R.fail(result3.getMsg());
				}
			default:
				return R.data(false);
		}
	}

	private void getCandidates(SimpleTask task) {
		List<String> users = new ArrayList<>();
		List<String> groups = new ArrayList<>();
		List<IdentityLink> links = taskService.getIdentityLinksForTask(task.getId());
		for (IdentityLink link : links) {
			if (IdentityLinkType.CANDIDATE.equals(link.getType())) {
				String userId = link.getUserId();
				if (userId != null) {
					users.add(userId);
				}
				String groupId = link.getGroupId();
				if (groupId != null) {
					groups.add(groupId);
				}
			}
		}
		task.setCandidateUsers(users);
		task.setCandidateGroups(groups);
	}

	@Override
	public R<Boolean> registerTaskUserParser(TaskUserParserInfo parserInfo) {
		bladeRedis.hSet(TASK_USER_PARSER_KEY, parserInfo.getProcessDefKey(), parserInfo);
		bladeRedis.persist(TASK_USER_PARSER_KEY);
		return R.data(true);
	}

	@Override
	public R<Boolean> registerTaskListener(TaskListenerInfo listenerInfo) {
		bladeRedis.hSet(TASK_LISTENER_KEY, listenerInfo.getProcessDefKey(), listenerInfo);
		bladeRedis.persist(TASK_LISTENER_KEY);
		return R.data(true);
	}

	@Override
	public R<Boolean> statusOfTaskUserParser(String processDefKey) {
		return R.data(bladeRedis.hExists(TASK_USER_PARSER_KEY, processDefKey));
	}

	@Override
	public R<Boolean> statusOfTaskListener(String processDefKey) {
		return R.data(bladeRedis.hExists(TASK_LISTENER_KEY, processDefKey));
	}
}
