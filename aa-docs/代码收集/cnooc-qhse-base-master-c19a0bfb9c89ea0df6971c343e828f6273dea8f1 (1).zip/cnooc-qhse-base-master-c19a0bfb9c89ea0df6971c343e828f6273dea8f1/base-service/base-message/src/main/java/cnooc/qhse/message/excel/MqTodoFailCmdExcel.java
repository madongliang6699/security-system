package cnooc.qhse.message.excel;


import lombok.Data;

import java.util.Date;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import java.io.Serializable;
import java.io.Serial;


/**
 * 待办补偿机制表 Excel实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@ColumnWidth(25)
@HeadRowHeight(20)
@ContentRowHeight(18)
public class MqTodoFailCmdExcel implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * 业务id
	 */
	@ColumnWidth(20)
	@ExcelProperty("业务id")
	private String srcTodoId;
	/**
	 * 接收人
	 */
	@ColumnWidth(20)
	@ExcelProperty("接收人")
	private String mqReceiver;
	/**
	 * 接收人名字
	 */
	@ColumnWidth(20)
	@ExcelProperty("接收人名字")
	private String mqReceiverName;
	/**
	 * 类型
	 */
	@ColumnWidth(20)
	@ExcelProperty("类型")
	private String mqType;
	/**
	 * 内容
	 */
	@ColumnWidth(20)
	@ExcelProperty("内容")
	private String mqContent;
	/**
	 * 创建内容
	 */
	@ColumnWidth(20)
	@ExcelProperty("创建内容")
	private Date creationTime;
	/**
	 * 重试次数
	 */
	@ColumnWidth(20)
	@ExcelProperty("重试次数")
	private Integer mqRetrycount;
	/**
	 * mq状态
	 */
	@ColumnWidth(20)
	@ExcelProperty("mq状态")
	private Integer mqStatus;

}
