package cnooc.qhse.message.service;

import cnooc.qhse.message.bean.MQTodoFailCmd;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import cnooc.qhse.message.pojo.vo.MqTodoFailCmdVO;
import cnooc.qhse.message.excel.MqTodoFailCmdExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseService;
import org.springframework.amqp.rabbit.connection.CorrelationData;

import java.util.List;

/**
 * 待办补偿机制表 服务类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public interface IMqTodoFailCmdService extends BaseService<MqTodoFailCmdEntity> {
	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param mqTodoFailCmd
	 * @return
	 */
	IPage<MqTodoFailCmdVO> selectMqTodoFailCmdPage(IPage<MqTodoFailCmdVO> page, MqTodoFailCmdVO mqTodoFailCmd);


	/**
	 * 导出数据
	 *
	 * @param queryWrapper
	 * @return
	 */
	List<MqTodoFailCmdExcel> exportMqTodoFailCmd(Wrapper<MqTodoFailCmdEntity> queryWrapper);

	String saveFailMsgByNotExchange(CorrelationData correlationData);

	void deleteFailMsg(CorrelationData correlationData);

	List<MQTodoFailCmd> findTopMQTodoFailCmds(int retryCount);

	void saveFailMsgByException(String message);


}
