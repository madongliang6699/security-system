package cnooc.qhse.message.controller;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import lombok.AllArgsConstructor;
import jakarta.validation.Valid;

import org.springblade.core.redis.lock.RedisLock;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import cnooc.qhse.message.pojo.vo.MqTodoFailCmdVO;
import cnooc.qhse.message.excel.MqTodoFailCmdExcel;
import cnooc.qhse.message.wrapper.MqTodoFailCmdWrapper;
import cnooc.qhse.message.service.IMqTodoFailCmdService;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.excel.util.ExcelUtil;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.core.tool.constant.RoleConstant;
import java.util.Map;
import java.util.List;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 待办补偿机制表 控制器
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@RestController
@AllArgsConstructor
@RequestMapping("mqTodoFailCmd")
@Tag(name = "待办补偿机制表", description = "待办补偿机制表接口")
public class MqTodoFailCmdController extends BladeController {

	private final IMqTodoFailCmdService mqTodoFailCmdService;

	/**
	 * 待办补偿机制表 详情
	 */
	@GetMapping("/detail")
	@ApiOperationSupport(order = 1)
	@Operation(summary = "详情", description  = "传入mqTodoFailCmd")
	public R<MqTodoFailCmdVO> detail(MqTodoFailCmdEntity mqTodoFailCmd) {
		MqTodoFailCmdEntity detail = mqTodoFailCmdService.getOne(Condition.getQueryWrapper(mqTodoFailCmd));
		return R.data(MqTodoFailCmdWrapper.build().entityVO(detail));
	}
	/**
	 * 待办补偿机制表 分页
	 */
	@GetMapping("/list")
	@ApiOperationSupport(order = 2)
	@Operation(summary = "分页", description  = "传入mqTodoFailCmd")
	public R<IPage<MqTodoFailCmdVO>> list(@Parameter(hidden = true) @RequestParam Map<String, Object> mqTodoFailCmd, Query query) {
		IPage<MqTodoFailCmdEntity> pages = mqTodoFailCmdService.page(Condition.getPage(query), Condition.getQueryWrapper(mqTodoFailCmd, MqTodoFailCmdEntity.class));
		return R.data(MqTodoFailCmdWrapper.build().pageVO(pages));
	}

	/**
	 * 待办补偿机制表 自定义分页
	 */
	@GetMapping("/page")
	@ApiOperationSupport(order = 3)
	@Operation(summary = "分页", description  = "传入mqTodoFailCmd")
	public R<IPage<MqTodoFailCmdVO>> page(MqTodoFailCmdVO mqTodoFailCmd, Query query) {
		IPage<MqTodoFailCmdVO> pages = mqTodoFailCmdService.selectMqTodoFailCmdPage(Condition.getPage(query), mqTodoFailCmd);
		return R.data(pages);
	}

	/**
	 * 待办补偿机制表 新增
	 */
	@PostMapping("/save")
	@ApiOperationSupport(order = 4)
	@Operation(summary = "新增", description  = "传入mqTodoFailCmd")
	public R save(@Valid @RequestBody MqTodoFailCmdEntity mqTodoFailCmd) {
		return R.status(mqTodoFailCmdService.save(mqTodoFailCmd));
	}

	/**
	 * 待办补偿机制表 修改
	 */
	@PostMapping("/update")
	@ApiOperationSupport(order = 5)
	@Operation(summary = "修改", description  = "传入mqTodoFailCmd")
	public R update(@Valid @RequestBody MqTodoFailCmdEntity mqTodoFailCmd) {
		return R.status(mqTodoFailCmdService.updateById(mqTodoFailCmd));
	}

	/**
	 * 待办补偿机制表 新增或修改
	 */
	@PostMapping("/submit")
	@ApiOperationSupport(order = 6)
	@Operation(summary = "新增或修改", description  = "传入mqTodoFailCmd")
	public R submit(@Valid @RequestBody MqTodoFailCmdEntity mqTodoFailCmd) {
		return R.status(mqTodoFailCmdService.saveOrUpdate(mqTodoFailCmd));
	}

	/**
	 * 待办补偿机制表 删除
	 */
	@PostMapping("/remove")
	@ApiOperationSupport(order = 7)
	@Operation(summary = "逻辑删除", description  = "传入ids")
	public R remove(@Parameter(description = "主键集合", required = true) @RequestParam String ids) {
		return R.status(mqTodoFailCmdService.deleteLogic(Func.toLongList(ids)));
	}


	/**
	 * 导出数据
	 */
	@PreAuth(RoleConstant.HAS_ROLE_ADMIN)
	@GetMapping("/export-mqTodoFailCmd")
	@ApiOperationSupport(order = 9)
	@Operation(summary = "导出数据", description  = "传入mqTodoFailCmd")
	public void exportMqTodoFailCmd(@Parameter(hidden = true) @RequestParam Map<String, Object> mqTodoFailCmd, BladeUser bladeUser, HttpServletResponse response) {
		QueryWrapper<MqTodoFailCmdEntity> queryWrapper = Condition.getQueryWrapper(mqTodoFailCmd, MqTodoFailCmdEntity.class);
		//if (!AuthUtil.isAdministrator()) {
		//	queryWrapper.lambda().eq(MqTodoFailCmd::getTenantId, bladeUser.getTenantId());
		//}
		queryWrapper.lambda().eq(MqTodoFailCmdEntity::getIsDeleted, BladeConstant.DB_NOT_DELETED);
		List<MqTodoFailCmdExcel> list = mqTodoFailCmdService.exportMqTodoFailCmd(queryWrapper);
		ExcelUtil.export(response, "待办补偿机制表数据" + DateUtil.time(), "待办补偿机制表数据表", list, MqTodoFailCmdExcel.class);
	}

	@GetMapping("/export-sendTodo")
	@ApiOperationSupport(order = 9)
	@Operation(summary = "发送待办", description  = "发送待办")
	public void sendTodo(@Parameter(hidden = true) @RequestParam Map<String, Object> mqTodoFailCmd, BladeUser bladeUser, HttpServletResponse response) {

	}

}
