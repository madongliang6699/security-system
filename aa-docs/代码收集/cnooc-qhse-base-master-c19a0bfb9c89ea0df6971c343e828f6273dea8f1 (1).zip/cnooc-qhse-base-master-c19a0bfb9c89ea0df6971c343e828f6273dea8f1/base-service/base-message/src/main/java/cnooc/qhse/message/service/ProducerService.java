package cnooc.qhse.message.service;

public interface ProducerService {
}
