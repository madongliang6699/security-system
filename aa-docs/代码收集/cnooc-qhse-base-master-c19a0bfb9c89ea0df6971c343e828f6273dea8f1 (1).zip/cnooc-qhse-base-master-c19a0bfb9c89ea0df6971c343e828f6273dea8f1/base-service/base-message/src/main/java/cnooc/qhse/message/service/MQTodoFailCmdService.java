/*
 * Copyright 2013-2019 Smartdot Technologies Co., Ltd. All rights reserved.
 * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 */
package cnooc.qhse.message.service;

import cnooc.qhse.message.bean.MQTodoFailCmd;

import java.util.List;

/**
 * <p>
 * MQ待办命令服务接口
 *
 * @version 1.0, 2023年5月29日
 * @amqhor <a href="mailto:renchao@smartdot.com">任超</a>
 */
public interface MQTodoFailCmdService {

	/**
	 * 创建MQ待办异常命令
	 *
	 * @param mqCliCmds 待创建的MQ待办命令列表
	 * @return mqCliCmds
	 */
	public void createFailCliCmd(List<MQTodoFailCmd> mqCliCmds);

	/**
	 * 删除MQ待办异常命令
	 *
	 * @param mqCliCmd 待删除的MQ待办命令
	 * @return
	 */
	public void deleteFailCliCmd(MQTodoFailCmd mqCliCmd);

	/**
	 * 修改MQ待办异常命令
	 *
	 * @param mqCliCmd
	 */
	public void updateFailCliCmd(MQTodoFailCmd mqCliCmd);

	/**
	 * 获取异常MQ待办推送命令
	 *
	 * @param topCount 获取头条数目，默认使用id升序排序
	 * @return mqTodoCmds
	 */
	public MQTodoFailCmd[] findTopMQTodoFailCmds(int topCount);

	/**
	 * 根据接收人与源待办ID查询命令
	 *
	 * @param srcTodoId 源待办ID
	 * @param eceiver   接收人
	 * @return
	 */
	public MQTodoFailCmd findBySrcTodoIdAndReceiver(String srcTodoId, String receiver);

	/**
	 * 删除异常mq数据
	 *
	 * @param srcTodoId 源待办ID
	 * @param receiver  接收人
	 * @param status    mq状态
	 */
	public void deleteBySrcTodoIdAndReceiverAndStatus(String srcTodoId, String receiver, int status);


	/**
	 * 删除异常mq数据
	 *
	 * @param srcTodoId 源待办ID
	 * @param receiver  接收人
	 */
	public void deleteBySrcTodoIdAndReceiver(String srcTodoId, String receiver);

	/**
	 * 删除异常mq数据
	 *
	 * @param id 异常mq数据ID
	 */
	public void deleteById(Long id);

	/**
	 * 需要手动干预的异常命令
	 */

	public MQTodoFailCmd[] findMQTodoFailCmdsByManual();
}
