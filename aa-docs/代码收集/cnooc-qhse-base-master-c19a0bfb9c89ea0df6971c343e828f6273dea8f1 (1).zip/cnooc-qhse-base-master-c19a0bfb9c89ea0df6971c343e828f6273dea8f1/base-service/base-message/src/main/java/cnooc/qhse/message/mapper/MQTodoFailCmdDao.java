///*
// * Copyright 2013-2019 Smartdot Technologies Co., Ltd. All rights reserved.
// * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
// *
// */
//package cnooc.qhse.message.mapper;
//
//import cnooc.qhse.message.pojo.entity.MQTodoFailCmdEntity;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import com.hd.rcugrc.data.jpa.GenericRepository;
//
///**
// * <p>
// * 待办MQ异常命令列表dao
// *
// * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
// * @version 1.0, 2023年5月29日
// */
//@Repository
//public interface MQTodoFailCmdDao extends GenericRepository<MQTodoFailCmdEntity, Long> {
//
//	/**
//	 * 根据接收人与源待办ID查询命令
//	 *
//	 * @param srcTodoId 源待办ID
//	 * @param eceiver   接收人
//	 * @return
//	 */
//	public MQTodoFailCmdEntity findBySrcTodoIdAndReceiver(@Param("srcTodoId") String srcTodoId,
//														  @Param("receiver") String receiver);
//
//	/**
//	 * 删除异常mq数据
//	 *
//	 * @param srcTodoId 源待办ID
//	 * @param receiver  接收人
//	 * @param status    mq状态
//	 */
//	public void deleteBySrcTodoIdAndReceiver(@Param("srcTodoId") String srcTodoId,
//											 @Param("receiver") String receiver);
//
//	/**
//	 * 删除异常mq数据
//	 *
//	 * @param srcTodoId 源待办ID
//	 * @param receiver  接收人
//	 * @param status    mq状态
//	 */
//	public void deleteBySrcTodoIdAndReceiverAndStatus(@Param("srcTodoId") String srcTodoId,
//													  @Param("receiver") String receiver, @Param("status") int status);
//
//}
