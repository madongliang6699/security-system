package cnooc.qhse.message.service;

import org.springframework.stereotype.Service;

/**
 * @author zqy
 */
public interface SendMessageService {
	boolean sendMsg();
}
