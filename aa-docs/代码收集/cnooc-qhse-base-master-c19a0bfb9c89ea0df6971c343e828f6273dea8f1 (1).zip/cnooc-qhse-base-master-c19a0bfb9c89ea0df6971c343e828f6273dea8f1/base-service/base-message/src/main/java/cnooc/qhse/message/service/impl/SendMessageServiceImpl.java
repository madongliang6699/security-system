package cnooc.qhse.message.service.impl;

import cnooc.qhse.message.pojo.dto.CreateMessageDTO;
import cnooc.qhse.message.pojo.dto.form.*;
import cnooc.qhse.message.service.SendMessageService;
import com.alibaba.fastjson2.JSON;
import jakarta.annotation.Resource;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * @author zqy
 */
@Service
public class SendMessageServiceImpl implements SendMessageService {

    @Resource(name = "todoRabbitTemplate")
    private RabbitTemplate todoRabbitTemplate;

    @Resource(name = "approveRabbitTemplate")
    private RabbitTemplate approveRabbitTemplate;

    @Override
    public boolean sendMsg() {
        String srcTodoId = System.nanoTime() + "";
        String appCat = "test_test";
        CreateMessageDTO createMessageDTO = new CreateMessageDTO();
        createMessageDTO.setExtSysId("zb_ead_sric");
        createMessageDTO.setSrcTodoId(srcTodoId);
        createMessageDTO.setReceiver("sedits_test");
        createMessageDTO.setReceiverName("sedits_test");
        createMessageDTO.setTitle("测试待办");
        createMessageDTO.setPcAddr("https://demo.cnooc.com.cn/dosm/orderDetail?id=1");
        //createMessageDTO.setMobileAddr("https://demo.cnooc.com.cn/dosm/orderDetail?id=1");
        createMessageDTO.setSender("ex_renchao");
        createMessageDTO.setSenderName("任超");
        createMessageDTO.setAppCat(appCat);
        createMessageDTO.setSentDate(System.currentTimeMillis());
        todoRabbitTemplate.convertAndSend("ead.todo.fastreq", JSON.toJSONString(Collections.singletonList(createMessageDTO)));
        //String tempStr = "{\"formV2\":{\"version\":2,\"id\":\"" + srcTodoId + "\",\"categoryId\":\"test_test\",\"formDefinitionId\":\"\",\"lastApprovalTime\":\"2023-12-13 09:11:05\",\"lastApprover\":\"万之惠\",\"readonly\":false,\"subject\":\"PA10202023121390001\",\"submitter\":\"wanzhh7\",\"submitTime\":\"2023-12-13 09:11:06\",\"description\":\"差旅事前申请\",\"allowEdit\":false,\"type\":\"NEED_TO_APPROVE\",\"valueGroups\":[{\"name\":\"单据信息\",\"expand\":true,\"values\":[{\"name\":\"单据编号\",\"value\":\"PA10202023121390001\"},{\"name\":\"制单人名称\",\"value\":\"刘佳琪\"},{\"name\":\"组织机构名称\",\"value\":\"会计服务处（有限）\"},{\"name\":\"成本中心名称\",\"value\":\"财务管理部\"},{\"name\":\"利润中心名称\",\"value\":\"HQ_公司机关\"},{\"name\":\"WBS元素\",\"value\":\"\"},{\"name\":\"内部订单\",\"value\":\"\"},{\"name\":\"是否超标\",\"value\":\"否\"},{\"name\":\"是否变更\",\"value\":\"否\"},{\"name\":\"出差目的\",\"value\":\"科研项目\"},{\"name\":\"出发开始日期\",\"value\":\"20231218\"},{\"name\":\"出发结束日期\",\"value\":\"20231218\"},{\"name\":\"估算金额\",\"value\":\"300.00\"},{\"name\":\"出差区域\",\"value\":\"市内\"},{\"name\":\"行程信息\",\"value\":\"北京市-北京市\"},{\"name\":\"出行人信息\",\"value\":\"刘佳琪\"},{\"name\":\"申请事由\",\"value\":\"22222\"},{\"name\":\"备注\",\"value\":\"22222\"}],\"childGroups\":[]},{\"name\":\"预算信息\",\"expand\":true,\"values\":[],\"childGroups\":[{\"name\":\"预算信息  1/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-城市间交通费\"},{\"name\":\"预算科目\",\"value\":\"城市间交通费\"},{\"name\":\"金额\",\"value\":\"0.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  2/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-住宿费\"},{\"name\":\"预算科目\",\"value\":\"住宿费\"},{\"name\":\"金额\",\"value\":\"0.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  3/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-市内交通\"},{\"name\":\"预算科目\",\"value\":\"市内交通费\"},{\"name\":\"金额\",\"value\":\"200.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  4/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-伙食补助\"},{\"name\":\"预算科目\",\"value\":\"伙食补助\"},{\"name\":\"金额\",\"value\":\"100.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  5/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"外包费-外包服务费\"},{\"name\":\"预算科目\",\"value\":\"外包服务费\"},{\"name\":\"金额\",\"value\":\"0.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  6/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-退票费\"},{\"name\":\"预算科目\",\"value\":\"其他境内差旅费\"},{\"name\":\"金额\",\"value\":\"0.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]},{\"name\":\"预算信息  7/7\",\"expand\":true,\"values\":[{\"name\":\"预算对象\",\"value\":\"差旅\"},{\"name\":\"费用项目\",\"value\":\"境内差旅费-其他\"},{\"name\":\"预算科目\",\"value\":\"其他境内差旅费\"},{\"name\":\"金额\",\"value\":\"0.00\"},{\"name\":\"核算成本中心\",\"value\":\"\"},{\"name\":\"核算WBS\",\"value\":\"\"},{\"name\":\"核算内部订单\",\"value\":\"\"}]}]}],\"attachments\":[{\"isInternetAddress\":false,\"linkAddress\":\"http://siitappysc-cnooc-shimage-preprod.apps.paas.cnooc/SiitAppYSC/showDetail/downFile.do?tableid=b33c3d0290814b9e82f5f5593d6ec2f6\",\"name\":\"附件测试.txt\",\"size\":0,\"extraInfo\":[]}],\"actions\":[{\"key\":\"agree\",\"name\":\"同意2\",\"minSegments\":1,\"maxSegments\":1,\"opinionRequired\":true,\"allowModifySegments\":false,\"selectUsersInteractively\":false,\"segments\":[]},{\"key\":\"reject\",\"name\":\"不同意2\",\"allowModifySegments\":false,\"opinionRequired\":false,\"selectUsersInteractively\":false,\"segments\":[{\"adPath\":[],\"id\":\"ROllBACKNODE\",\"multiSteps\":false,\"name\":\"退回指定节点\",\"selectUserFromAD\":false,\"stepOptions\":[{\"id\":\"start@@FLOW_TRCCSQ\",\"name\":\"start【开始】\",\"children\":[]},{\"id\":\"S_2@@FLOW_TRCCSQ20227251845341\",\"name\":\"S_2【一级审批】\",\"children\":[]}],\"required\":false}]}],\"history\":[{\"username\":\"万之惠\",\"operateTime\":\"2023-12-13 09:11:05\",\"opinion\":\"一级审批\",\"action\":\"提交\",\"account\":\"wanzhh7\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 09:06:05\",\"opinion\":\"审批【自动审批】\",\"action\":\"提交\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 09:06:04\",\"opinion\":\"开始【同意】\",\"action\":\"提交\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 09:03:37\",\"opinion\":\"审批【取回】\",\"action\":\"取回\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 09:03:37\",\"opinion\":\"一级审批【取回】\",\"action\":\"取回\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 09:00:40\",\"opinion\":\"开始【同意】\",\"action\":\"提交\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"万之惠\",\"operateTime\":\"2023-12-13 08:58:53\",\"opinion\":\"一级审批【不同意】\",\"action\":\"退回\",\"account\":\"wanzhh7\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 08:54:20\",\"opinion\":\"审批【自动审批】\",\"action\":\"提交\",\"account\":\"liujq35\",\"extraInfo\":[]},{\"username\":\"刘佳琪\",\"operateTime\":\"2023-12-13 08:54:19\",\"opinion\":\"开始【同意】\",\"action\":\"提交\",\"account\":\"liujq35\",\"extraInfo\":[]}],\"todoUsers\":[{\"account\":\"wanzhh7\"}]},\"appId\":\"zb_ead_sric\"}";
        //approveRabbitTemplate.convertAndSend("ead.page.syn.default",tempStr);
        approveRabbitTemplate.convertAndSend("ead.page.syn.default", JSON.toJSONString(this.mockData(srcTodoId, appCat)));
        int i = 1;
        return false;
    }

    private FormDataInfo mockData(String id, String appCat) {
        // 创建 FormV2DTO 对象
        FormV2DTO formV2DTO = new FormV2DTO();
        formV2DTO.setVersion(2);
        formV2DTO.setId(id);
        formV2DTO.setCategoryId(appCat);
        formV2DTO.setFormDefinitionId("");
        formV2DTO.setLastApprovalTime("2023-12-13 09:11:05");
        formV2DTO.setLastApprover("万之惠");
        formV2DTO.setReadonly(false);
        formV2DTO.setSubject("PA10202023121390001");
        formV2DTO.setSubmitter("wanzhh7");
        formV2DTO.setSubmitTime("2023-12-13 09:11:06");
        formV2DTO.setDescription("差旅事前申请");
        formV2DTO.setAllowEdit(false);
        formV2DTO.setType("NEED_TO_APPROVE");

        // 创建 Value 对象
        ValuesDTO value1 = new ValuesDTO("单据编号", "PA10202023121390001");
        ValuesDTO value2 = new ValuesDTO("制单人名称", "刘佳琪");
        // ... 其他值

        // 创建 ValueGroup 对象
        ValueGroupsDTO valueGroup1 = new ValueGroupsDTO("单据信息", true, Arrays.asList(
                value1, value2/* 其他值 */), List.of());

        // 创建预算信息子组
        ValuesDTO budgetValue1 = new ValuesDTO("预算对象", "差旅");
        ValuesDTO budgetValue2 = new ValuesDTO("费用项目", "境内差旅费-城市间交通费");
        // ... 其他值

        ValueGroupsDTO budgetChildGroup1 = new ValueGroupsDTO("预算信息  1/7", true, Arrays.asList(
                budgetValue1, budgetValue2 /* 其他值 */), List.of());
        // ... 其他预算信息子组

        ValueGroupsDTO valueGroup2 = new ValueGroupsDTO("预算信息", true, List.of(), Arrays.asList(
                budgetChildGroup1 /* 其他预算信息子组 */));

        // 设置 ValueGroups
        formV2DTO.setValueGroups(Arrays.asList(valueGroup1));

        // 创建 Attachment 对象
        AttachmentsDTO attachment = new AttachmentsDTO(false,
                "http://siitappysc-cnooc-shimage-preprod.apps.paas.cnooc/SiitAppYSC/showDetail/downFile.do?tableid=b33c3d0290814b9e82f5f5593d6ec2f6",
                "附件测试.txt", 0, List.of());
        formV2DTO.setAttachments(Arrays.asList(attachment));

        // 创建 ActionsDTO 对象
        ActionsDTO action1 = new ActionsDTO("agree", "同意2", 1, 1, true, false, false, List.of());
        ActionsDTO action2 = new ActionsDTO("reject", "不同意2", 1, 1, false, false, false, List.of(new SegmentsDTO(List.of(), "ROllBACKNODE", false, "退回指定节点", false, List.of(
                new StepOptionsDTO("start@@FLOW_TRCCSQ", "start【开始】", List.of()),
                new StepOptionsDTO("S_2@@FLOW_TRCCSQ20227251845341", "S_2【一级审批】", List.of())
        ), false)));
        formV2DTO.setActions(Arrays.asList(action1, action2));

        // 创建 History 对象
        HistoryDTO history1 = new HistoryDTO("万之惠", "2023-12-13 09:11:05", "一级审批", "提交", "wanzhh7", List.of());
        // ... 其他历史记录

        formV2DTO.setHistory(Arrays.asList(history1 /* 其他历史记录 */));

        // 创建 TodoUser 对象
        TodoUsersDTO todoUser1 = new TodoUsersDTO("wanzhh7");
        formV2DTO.setTodoUsers(Arrays.asList(todoUser1));
        return new FormDataInfo(formV2DTO, "zb_ead_sric");
    }

}
