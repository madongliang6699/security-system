/*
 * Copyright 2013-2019 Smartdot Technologies Co., Ltd. All rights reserved.
 * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 */
package cnooc.qhse.message.bean;

import java.io.Serializable;

import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * <p>
 * MQ待办命令列表实体
 *
 * @author <a href="mailto:renchao@smartdot.com">任超</a>
 * @version 1.0, 2023年5月29日
 */
public class MQTodoFailCmd implements Serializable {

    private static final long serialVersionUID = -1370915254951357410L;
    private Long id;
    private String srcTodoId;
    private String receiver;
    private String receiverName;
    private String cmdType;
    private String cmdContent;
    private long creationTime;
    private long retryCount;
    private int status;

    // 无参构造方法
    public MQTodoFailCmd() {
        super();
    }

    // 有参构造方法
    public MQTodoFailCmd(MQTodoFailCmd cmd) {
        super();
        this.srcTodoId = cmd.getSrcTodoId();
        this.receiver = cmd.getCmdReceiver();
        this.receiverName = cmd.getReceiverName();
        this.cmdType = cmd.getCmdType();
        this.cmdContent = cmd.getCmdContent();
        this.creationTime = System.currentTimeMillis();
        this.retryCount = cmd.getRetryCount();
        this.status = cmd.getStatus();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSrcTodoId() {
        return srcTodoId;
    }

    public void setSrcTodoId(String srcTodoId) {
        this.srcTodoId = srcTodoId;
    }

    /**
     * MQ待办命令类型
     *
     * @return
     */
    public String getCmdType() {
        return cmdType;
    }

    public void setCmdType(String cmdType) {
        this.cmdType = cmdType;
    }

    /**
     * 获取MQ待办命令内容
     *
     * @return
     */
    public String getCmdContent() {
        return cmdContent;
    }

    /**
     * 设置MQ待办命令内容
     *
     * @param cmdContent
     */
    public void setCmdContent(String cmdContent) {
        this.cmdContent = cmdContent;
    }

    /**
     * 待办接收者
     *
     * @return
     */
    public String getCmdReceiver() {
        return receiver;
    }

    public void setCmdReceiver(String receiver) {
        this.receiver = receiver;
    }

    /**
     * 待办接收者名称
     *
     * @return
     */
    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public long getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(long creationTime) {
        this.creationTime = creationTime;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public long getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(long retryCount) {
        this.retryCount = retryCount;
    }


    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(getId()).toHashCode();
    }

    @Override
    public boolean equals(Object anObject) {
        if (this == anObject) {
            return true;
        }
        if (anObject instanceof MQTodoFailCmd) {
            if (getId() == ((MQTodoFailCmd) anObject).getId()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("cmdId=").append(id).append(",cmdType=" + cmdType).append(",srcTodoId=" + srcTodoId);
        sb.append(",receiver=").append(receiver);
        sb.append(",retryCount=").append(retryCount);
        sb.append(",status=").append(status);
        return sb.toString();
    }

}
