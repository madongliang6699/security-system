package cnooc.qhse.message.service.impl;

import cnooc.qhse.message.bean.MQTodoFailCmd;
import cnooc.qhse.message.bean.MQTodoMsgBean;
import cnooc.qhse.message.excel.MqTodoFailCmdExcel;
import cnooc.qhse.message.mapper.MqTodoFailCmdMapper;
import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import cnooc.qhse.message.pojo.vo.MqTodoFailCmdVO;
import cnooc.qhse.message.service.IMqTodoFailCmdService;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springblade.core.mp.base.BaseEntity;
import org.springblade.core.mp.base.BaseServiceImpl;
import org.springblade.core.tenant.annotation.TenantIgnore;
import org.springblade.core.tool.utils.CollectionUtil;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 待办补偿机制表 服务实现类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Service
@TenantIgnore
public class MqTodoFailCmdServiceImpl extends BaseServiceImpl<MqTodoFailCmdMapper, MqTodoFailCmdEntity> implements IMqTodoFailCmdService {

	Logger logger = LoggerFactory.getLogger(MqTodoFailCmdServiceImpl.class);


	@Override
	public IPage<MqTodoFailCmdVO> selectMqTodoFailCmdPage(IPage<MqTodoFailCmdVO> page, MqTodoFailCmdVO mqTodoFailCmd) {
		return page.setRecords(baseMapper.selectMqTodoFailCmdPage(page, mqTodoFailCmd));
	}


	@Override
	public List<MqTodoFailCmdExcel> exportMqTodoFailCmd(Wrapper<MqTodoFailCmdEntity> queryWrapper) {
		List<MqTodoFailCmdExcel> mqTodoFailCmdList = baseMapper.exportMqTodoFailCmd(queryWrapper);
		//mqTodoFailCmdList.forEach(mqTodoFailCmd -> {
		//	mqTodoFailCmd.setTypeName(DictCache.getValue(DictEnum.YES_NO, MqTodoFailCmd.getType()));
		//});
		return mqTodoFailCmdList;
	}

	@Override
	public String saveFailMsgByNotExchange(CorrelationData correlationData) {
		String result = null;
		if (null != correlationData && null != correlationData.getReturned()
			&& null != correlationData.getReturned().getMessage()
			&& null != correlationData.getReturned().getMessage().getBody()) {
			String message = new String(correlationData.getReturned().getMessage().getBody());
			try {
				List<MQTodoMsgBean> msgBeans = JSONArray.parseArray(message, MQTodoMsgBean.class);
				List<MQTodoFailCmd> cmdList = buildMQTodoFailCmd(msgBeans);
				for (MQTodoFailCmd cmd : cmdList) {
					List<MqTodoFailCmdEntity> oldDataRecord =
						lambdaQuery()
							.eq(MqTodoFailCmdEntity::getSrcTodoId, cmd.getSrcTodoId())
							.eq(MqTodoFailCmdEntity::getMqReceiver, cmd.getReceiver())
							.list();
					if (CollectionUtil.isNotEmpty(oldDataRecord)) {
						removeByIds(oldDataRecord.stream().map(BaseEntity::getId).collect(Collectors.toList()));
					}
				}
				saveBatch(cmdList.stream().filter(Objects::nonNull).map(this::wrapFailEntity).collect(Collectors.toList()));
				result = "saveFailMsgByNotExchange!";
			} catch (Exception e) {
				logger.error("重试机制保存失败", e);
			}
		}
		return result;
	}

	@Override
	public void deleteFailMsg(CorrelationData correlationData) {
		if (null != correlationData && null != correlationData.getId() && !"undefined".equals(correlationData.getId())) {
			String msgId = correlationData.getId();
			removeById(Long.valueOf(msgId));
		}
	}

	@Override
	@TenantIgnore
	public List<MQTodoFailCmd> findTopMQTodoFailCmds(int retryCount) {
		return
			lambdaQuery()
				.le(MqTodoFailCmdEntity::getMqRetrycount, retryCount)
				.list()
				.stream()
				.map(this::wrapMQTodoFailCmd)
				.collect(Collectors.toList());
	}

	@Override
	public void saveFailMsgByException(String message) {
		try {
			List<MQTodoMsgBean> msgBeans = JSONArray.parseArray(message, MQTodoMsgBean.class);
			List<MQTodoFailCmd> cmdList = buildMQTodoFailCmd(msgBeans);
			for (MQTodoFailCmd cmd : cmdList) {
				List<MqTodoFailCmdEntity> oldDataRecord = lambdaQuery()
					.eq(MqTodoFailCmdEntity::getSrcTodoId, cmd.getSrcTodoId())
					.eq(MqTodoFailCmdEntity::getMqReceiver, cmd.getReceiver())
					.list();
				if (CollectionUtil.isNotEmpty(oldDataRecord)) {
					removeByIds(oldDataRecord.stream().map(BaseEntity::getId).collect(Collectors.toList()));
				}
			}
			saveBatch(cmdList.stream().filter(Objects::nonNull).map(this::wrapFailEntity).collect(Collectors.toList()));
		} catch (Exception e) {
			logger.error("重试机制保存失败", e);
		}
	}

	private List<MQTodoFailCmd> buildMQTodoFailCmd(List<MQTodoMsgBean> msgBeans) {
		// 记录失败日志
		List<MQTodoFailCmd> mqCliCmds = new ArrayList<MQTodoFailCmd>();
		for (MQTodoMsgBean msgBean : msgBeans) {
			MQTodoFailCmd cmd = new MQTodoFailCmd();
			cmd.setSrcTodoId(msgBean.getSrcTodoId());
			cmd.setCmdReceiver(msgBean.getReceiver());
			cmd.setReceiverName(msgBean.getReceiverName());
			cmd.setCmdType(msgBean.getActionType());
			String content = null;
			try {
				content = JSON.toJSONString(msgBeans);
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getMessage());
			}
			cmd.setCmdContent(content);
			cmd.setCreationTime(System.currentTimeMillis());
			cmd.setRetryCount(0);
			cmd.setStatus(-2);
			mqCliCmds.add(cmd);
		}
		return mqCliCmds;
	}

	private MqTodoFailCmdEntity wrapFailEntity(MQTodoFailCmd mqTodoCmd) {
		if (mqTodoCmd == null) {
			return null;
		}
		MqTodoFailCmdEntity entity = new MqTodoFailCmdEntity();
		entity.setId(mqTodoCmd.getId());
		entity.setSrcTodoId(mqTodoCmd.getSrcTodoId());
		entity.setMqReceiver(mqTodoCmd.getCmdReceiver());
		entity.setMqReceiverName(mqTodoCmd.getReceiverName());
		entity.setMqType(mqTodoCmd.getCmdType());
		entity.setMqContent(mqTodoCmd.getCmdContent());
		entity.setCreationTime(new Date(mqTodoCmd.getCreationTime()));
		entity.setMqRetrycount(mqTodoCmd.getRetryCount());
		entity.setStatus(mqTodoCmd.getStatus());
		return entity;
	}

	private MQTodoFailCmd wrapMQTodoFailCmd(MqTodoFailCmdEntity entity) {
		if (entity == null) {
			return null;
		}
		MQTodoFailCmd mqTodoCmd = new MQTodoFailCmd();
		mqTodoCmd.setId(entity.getId());
		mqTodoCmd.setSrcTodoId(entity.getSrcTodoId());
		mqTodoCmd.setCmdReceiver(entity.getMqReceiver());
		mqTodoCmd.setReceiverName(entity.getMqReceiverName());
		mqTodoCmd.setCmdType(entity.getMqType());
		mqTodoCmd.setCmdContent(entity.getMqContent());
		mqTodoCmd.setCreationTime(entity.getCreationTime().getTime());
		mqTodoCmd.setRetryCount(entity.getMqRetrycount());
		mqTodoCmd.setStatus(entity.getStatus());
		return mqTodoCmd;
	}

}
