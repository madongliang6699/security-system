package cnooc.qhse.message.wrapper;

import org.springblade.core.mp.support.BaseEntityWrapper;
import org.springblade.core.tool.utils.BeanUtil;
import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import cnooc.qhse.message.pojo.vo.MqTodoFailCmdVO;
import java.util.Objects;

/**
 * 待办补偿机制表 包装类,返回视图层所需的字段
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public class MqTodoFailCmdWrapper extends BaseEntityWrapper<MqTodoFailCmdEntity, MqTodoFailCmdVO>  {

	public static MqTodoFailCmdWrapper build() {
		return new MqTodoFailCmdWrapper();
 	}

	@Override
	public MqTodoFailCmdVO entityVO(MqTodoFailCmdEntity mqTodoFailCmd) {
		MqTodoFailCmdVO mqTodoFailCmdVO = Objects.requireNonNull(BeanUtil.copyProperties(mqTodoFailCmd, MqTodoFailCmdVO.class));

		//User createUser = UserCache.getUser(mqTodoFailCmd.getCreateUser());
		//User updateUser = UserCache.getUser(mqTodoFailCmd.getUpdateUser());
		//mqTodoFailCmdVO.setCreateUserName(createUser.getName());
		//mqTodoFailCmdVO.setUpdateUserName(updateUser.getName());

		return mqTodoFailCmdVO;
	}


}
