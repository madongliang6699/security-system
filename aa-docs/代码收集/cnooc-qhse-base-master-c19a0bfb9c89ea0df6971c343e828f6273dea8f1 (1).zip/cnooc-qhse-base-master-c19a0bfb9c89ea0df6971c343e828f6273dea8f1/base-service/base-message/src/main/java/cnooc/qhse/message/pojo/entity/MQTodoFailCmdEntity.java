///*
// * Copyright 2013-2019 Smartdot Technologies Co., Ltd. All rights reserved.
// * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
// *
// */
//package cnooc.qhse.message.pojo.entity;
//
//import java.io.Serializable;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import org.hibernate.annotations.GenericGenerator;
//import org.hibernate.annotations.Parameter;
//import org.hibernate.annotations.Proxy;
//
///**
// * <p>
// * 待办MQ异常命令列表实体
// *
// * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
// * @version 1.0, 2023年5月29日
// */
//@Entity
//@Proxy(lazy = false)
//@Table(name = "MQ_TODO_FAIL_CMD")
//public class MQTodoFailCmdEntity implements Serializable {
//
//    private static final long serialVersionUID = -5665828684952050112L;
//    private Long id;
//    private String srcTodoId;
//    private String receiver;
//    private String receiverName;
//    private String cmdType;
//    private String cmdContent;
//    private long creationTime;
//    private long retryCount;
//    private int status;
//
//    @Id
//    @GeneratedValue(generator = "mqTodoFailCmdEntityIdGenerator")
//    @GenericGenerator(name = "mqTodoFailCmdEntityIdGenerator", strategy = "com.hd.rcugrc.data.ids.TableBasedLongIdGenerator", parameters = {
//            @Parameter(name = "table_name", value = "HD_ID_GEN"),
//            @Parameter(name = "segment_column_name", value = "ID_NAME"),
//            @Parameter(name = "value_column_name", value = "ID_VAL"),
//            @Parameter(name = "segment_value", value = "MQ_TODO_FAIL_CMD"),
//            @Parameter(name = "increment_size", value = "1") })
//    @Column(name = "ID")
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    @Column(name = "SRC_TODO_ID")
//    public String getSrcTodoId() {
//        return srcTodoId;
//    }
//
//    public void setSrcTodoId(String srcTodoId) {
//        this.srcTodoId = srcTodoId;
//    }
//
//    /**
//     * 待办MQ命令类型
//     *
//     * @return
//     */
//    @Column(name = "MQ_TYPE")
//    public String getCmdType() {
//        return cmdType;
//    }
//
//    public void setCmdType(String cmdType) {
//        this.cmdType = cmdType;
//    }
//
//    /**
//     * 获取待办MQ命令内容
//     *
//     * @return
//     */
//    @Column(name = "MQ_CONTENT")
//    public String getCmdContent() {
//        return cmdContent;
//    }
//
//    /**
//     * 设置待办MQ命令内容
//     *
//     * @param cmdContent
//     */
//    public void setCmdContent(String cmdContent) {
//        this.cmdContent = cmdContent;
//    }
//
//    /**
//     * 待办接收者
//     *
//     * @return
//     */
//    @Column(name = "MQ_RECEIVER")
//    public String getReceiver() {
//        return receiver;
//    }
//
//    public void setReceiver(String receiver) {
//        this.receiver = receiver;
//    }
//
//    /**
//     * 待办接收者名称
//     *
//     * @return
//     */
//    @Column(name = "MQ_RECEIVER_NAME")
//    public String getReceiverName() {
//        return receiverName;
//    }
//
//    public void setReceiverName(String receiverName) {
//        this.receiverName = receiverName;
//    }
//
//    @Column(name = "CREATION_TIME", nullable = false)
//    public long getCreationTime() {
//        return creationTime;
//    }
//
//    public void setCreationTime(long creationTime) {
//        this.creationTime = creationTime;
//    }
//
//    @Column(name = "MQ_RETRYCOUNT", nullable = false)
//    public long getRetryCount() {
//        return retryCount;
//    }
//
//    public void setRetryCount(long retryCount) {
//        this.retryCount = retryCount;
//    }
//
//    @Column(name = "MQ_STATUS", nullable = false)
//    public int getStatus() {
//        return status;
//    }
//
//    public void setStatus(int status) {
//        this.status = status;
//    }
//
//}
