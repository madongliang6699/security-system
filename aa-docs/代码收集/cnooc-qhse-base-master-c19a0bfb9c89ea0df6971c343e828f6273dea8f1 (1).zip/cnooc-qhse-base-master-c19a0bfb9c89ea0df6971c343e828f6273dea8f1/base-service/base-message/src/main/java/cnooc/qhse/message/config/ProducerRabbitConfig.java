/*
 * Copyright 2013-2023 Smartdot Technologies Co., Ltd. All rights reserved.
 * SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 */
package cnooc.qhse.message.config;

import cnooc.qhse.message.service.IMqTodoFailCmdService;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.ReturnedMessage;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


/**
 * <p>
 *
 * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
 * @version 1.0, 2023年5月30日
 */
@Configuration
public class ProducerRabbitConfig {
	private Logger logger = LoggerFactory.getLogger(ProducerRabbitConfig.class);

	@Resource
	private IMqTodoFailCmdService iMqTodoFailCmdService;

	@Bean("todoRabbitTemplate")
	public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setConnectionFactory(connectionFactory);
		// 设置开启Mandatory,才能触发回调函数,无论消息推送结果怎么样都强制调用回调函数
		rabbitTemplate.setMandatory(true);
		// 交换机异常处理
		rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {
			@Override
			public void confirm(CorrelationData correlationData, boolean ack, String cause) {
				if (!ack) {
					logger.error("交换机异常,保存mq信息值数据库");
					//producerSendFailMsgService.saveFailMsgByNotExchange(correlationData);
					iMqTodoFailCmdService.saveFailMsgByNotExchange(correlationData);
				} else {
					logger.warn("mq消息推送成功后，删除数据库中报错的异常mq消息");
					//producerSendFailMsgService.deleteFailMsg(correlationData);
				}

			}
		});
		// 路由异常处理
		rabbitTemplate.setReturnsCallback(new RabbitTemplate.ReturnsCallback() {
			@Override
			public void returnedMessage(ReturnedMessage returned) {
				logger.error("路由异常,保存mq信息值数据库");
				//producerSendFailMsgService.saveFailMsgByNotRouting(returned);
			}
		});
		return rabbitTemplate;
	}
}
