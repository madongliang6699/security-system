package cnooc.qhse.message.mapper;

import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import cnooc.qhse.message.pojo.vo.MqTodoFailCmdVO;
import cnooc.qhse.message.excel.MqTodoFailCmdExcel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * 待办补偿机制表 Mapper 接口
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public interface MqTodoFailCmdMapper extends BaseMapper<MqTodoFailCmdEntity> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param mqTodoFailCmd
	 * @return
	 */
	List<MqTodoFailCmdVO> selectMqTodoFailCmdPage(IPage page, MqTodoFailCmdVO mqTodoFailCmd);


	/**
	 * 获取导出数据
	 *
	 * @param queryWrapper
	 * @return
	 */
	List<MqTodoFailCmdExcel> exportMqTodoFailCmd(@Param("ew") Wrapper<MqTodoFailCmdEntity> queryWrapper);

}
