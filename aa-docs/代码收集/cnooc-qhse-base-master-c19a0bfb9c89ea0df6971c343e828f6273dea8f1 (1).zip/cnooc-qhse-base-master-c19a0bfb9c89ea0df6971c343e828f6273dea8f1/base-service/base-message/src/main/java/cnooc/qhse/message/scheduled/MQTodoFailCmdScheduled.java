package cnooc.qhse.message.scheduled;

import cnooc.qhse.message.bean.MQTodoFailCmd;
import cnooc.qhse.message.props.MessageProperties;
import cnooc.qhse.message.service.IMqTodoFailCmdService;
import jakarta.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.ReturnedMessage;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public class MQTodoFailCmdScheduled {

	private Logger logger = LoggerFactory.getLogger(getClass());

	// 批处理的待办命令个数
	@Resource
	private MessageProperties messageProperties;
	@Autowired
	private IMqTodoFailCmdService mqTodoFailCmdService;
	@Resource(name = "todoRabbitTemplate")
	private RabbitTemplate rabbitTemplate;

	@Scheduled(fixedDelay = 60000)
	public void retrySendMsg() {
		List<MQTodoFailCmd> cliCmds = mqTodoFailCmdService.findTopMQTodoFailCmds(messageProperties.getRetryCount());
		for (MQTodoFailCmd cmd : cliCmds) {
			logger.warn(cmd.getId() + " & " + cmd.getRetryCount());
			String message = cmd.getCmdContent();
			try {
				// ① 发送消息
				rabbitTemplate.convertAndSend("ead.todo.fastreq", message);
				// @ 通过交换机发送消息
				CorrelationData correlationData = new CorrelationData(cmd.getId().toString());
				Message messageObj = new Message(message.getBytes());
				ReturnedMessage returnedMessage = new ReturnedMessage(messageObj, 0, "", "", "ead.todo.fastreq");
				correlationData.setReturned(returnedMessage);
				rabbitTemplate.convertAndSend("", "ead.todo.fastreq", message, correlationData);
			} catch (Exception e) {
				mqTodoFailCmdService.saveFailMsgByException(message);
				logger.error(e.getMessage());
			}
		}
	}
}
