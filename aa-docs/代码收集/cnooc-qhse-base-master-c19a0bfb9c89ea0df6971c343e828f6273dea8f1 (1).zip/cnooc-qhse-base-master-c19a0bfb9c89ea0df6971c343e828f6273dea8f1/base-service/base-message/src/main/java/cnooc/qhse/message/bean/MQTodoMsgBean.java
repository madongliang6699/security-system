package cnooc.qhse.message.bean;

import java.io.Serializable;
import java.util.Date;


/**
 * <p>
 * MQ待办消息实体
 *
 * @author <a href="mailto:renchao@smartdot.com">任超</a>
 * @version 1.0, 2023年5月30日
 */
public class MQTodoMsgBean implements Serializable {

    private static final long serialVersionUID = 6212833731521673840L;

    private String extSysId;
    private String srcTodoId;
    private String receiver;
    private String receiverName;
    private String actionType;
    private String title;
    private String pcAddr;
    private String mobileAddr;
    private String sender;
    private String senderName;
    private Date sentDate;
    private Long instId;
    private int stepId;
    private String stepName;
    private int status;
    private int priority;
    private Date alarmDate;
    private Date dueDate;
    private Date seenDate;
    private Date creationTime;
    private Date lastModifiedTime;
    private String creatorDeptName;
    private String creatorAccount;
    private String creatorName;
    private int processState;
    private Date processDate;
    private int isTop;
    private Date setTopTime;

    public String getExtSysId() {
        return extSysId;
    }

    public void setExtSysId(String extSysId) {
        this.extSysId = extSysId;
    }

    public String getSrcTodoId() {
        return srcTodoId;
    }

    public void setSrcTodoId(String srcTodoId) {
        this.srcTodoId = srcTodoId;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPcAddr() {
        return pcAddr;
    }

    public void setPcAddr(String pcAddr) {
        this.pcAddr = pcAddr;
    }

    public String getMobileAddr() {
        return mobileAddr;
    }

    public void setMobileAddr(String mobileAddr) {
        this.mobileAddr = mobileAddr;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Long getInstId() {
        return instId;
    }

    public void setInstId(Long instId) {
        this.instId = instId;
    }

    public int getStepId() {
        return stepId;
    }

    public void setStepId(int stepId) {
        this.stepId = stepId;
    }

    public String getStepName() {
        return stepName;
    }

    public void setStepName(String stepName) {
        this.stepName = stepName;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public Date getAlarmDate() {
        return alarmDate;
    }

    public void setAlarmDate(Date alarmDate) {
        this.alarmDate = alarmDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Date getSeenDate() {
        return seenDate;
    }

    public void setSeenDate(Date seenDate) {
        this.seenDate = seenDate;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public Date getLastModifiedTime() {
        return lastModifiedTime;
    }

    public void setLastModifiedTime(Date lastModifiedTime) {
        this.lastModifiedTime = lastModifiedTime;
    }

    public String getCreatorDeptName() {
        return creatorDeptName;
    }

    public void setCreatorDeptName(String creatorDeptName) {
        this.creatorDeptName = creatorDeptName;
    }

    public String getCreatorAccount() {
        return creatorAccount;
    }

    public void setCreatorAccount(String creatorAccount) {
        this.creatorAccount = creatorAccount;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public void setCreatorName(String creatorName) {
        this.creatorName = creatorName;
    }

    public int getProcessState() {
        return processState;
    }

    public void setProcessState(int processState) {
        this.processState = processState;
    }

    public Date getProcessDate() {
        return processDate;
    }

    public void setProcessDate(Date processDate) {
        this.processDate = processDate;
    }

    public int getIsTop() {
        return isTop;
    }

    public void setIsTop(int isTop) {
        this.isTop = isTop;
    }

    public Date getSetTopTime() {
        return setTopTime;
    }

    public void setSetTopTime(Date setTopTime) {
        this.setTopTime = setTopTime;
    }

}
