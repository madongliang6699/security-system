///*
//* Copyright 2013-2023 Smartdot Technologies Co., Ltd. All rights reserved.
//* SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//*
//*/
//package cnooc.qhse.message.service.impl;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Sort;
//import org.springframework.data.jpa.domain.Specification;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.hd.rcugrc.data.crud.CriteriaUtils;
//import com.hd.rcugrc.data.crud.criteria.Comparison;
//import com.hd.rcugrc.data.crud.criteria.Criterion;
//import com.hd.rcugrc.data.crud.criteria.Operator;
//import com.hd.rcugrc.data.crud.criteria.OrderBy;
//import com.hd.rcugrc.ut.server.bean.MQTodoFailCmd;
//import com.hd.rcugrc.ut.server.dao.MQTodoFailCmdDao;
//import com.hd.rcugrc.ut.server.entity.MQTodoFailCmdEntity;
//import com.hd.rcugrc.ut.server.service.MQTodoFailCmdService;
//
///**
// * <p>
// * 待办MQ异常命令服务列表
// *
// * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
// * @version 1.0, 2023年5月29日
// */
//public class IMQTodoFailCmdServiceImpl implements MQTodoFailCmdService {
//
//    @Autowired
//    private MQTodoFailCmdDao mqFailCliCmdDao;
//
//    @Override
//    @Transactional
//    public void createFailCliCmd(List<MQTodoFailCmd> mqCliCmds) {
//        List<MQTodoFailCmdEntity> save_entitys = new ArrayList<>();
//        MQTodoFailCmdEntity entity;
//        for (MQTodoFailCmd mqTodoCmd : mqCliCmds) {
//            entity = wrapFailEntity(mqTodoCmd);
//            if (entity == null) {
//                continue;
//            }
//            save_entitys.add(entity);
//        }
//        mqFailCliCmdDao.persist(save_entitys);
//        mqFailCliCmdDao.flush();
//    }
//
//    @Override
//    @Transactional
//    public void deleteFailCliCmd(MQTodoFailCmd mqCliCmd) {
//        MQTodoFailCmdEntity entity = wrapFailEntity(mqCliCmd);
//        if (entity == null) {
//            return;
//        }
//        mqFailCliCmdDao.delete(entity);
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public MQTodoFailCmd[] findTopMQTodoFailCmds(int topCount) {
//        OrderBy[] orderBy = OrderBy.orderBy(OrderBy.asc("id"));
//        Sort sort = CriteriaUtils.getSort(orderBy);
//        Criterion[] c = new Criterion[] { new Comparison("retryCount", Operator.LT, 3, false) };
//        Specification<MQTodoFailCmdEntity> spec = CriteriaUtils.getSpecification(MQTodoFailCmdEntity.class, c);
//        List<MQTodoFailCmdEntity> list = mqFailCliCmdDao.findList(spec, 0, topCount, sort);
//        if (list == null || list.isEmpty()) {
//            return new MQTodoFailCmd[0];
//        } else {
//            return list.stream().map(entry -> wrapMQTodoFailCmd(entry)).toArray(MQTodoFailCmd[]::new);
//        }
//    }
//
//    /**
//     * 构建MQTodoFailCmdEntity实体对象
//     *
//     * @param mqTodoCmd 业务对象
//     * @return
//     */
//    private MQTodoFailCmdEntity wrapFailEntity(MQTodoFailCmd mqTodoCmd) {
//        if (mqTodoCmd == null) {
//            return null;
//        }
//        MQTodoFailCmdEntity entity = new MQTodoFailCmdEntity();
//        entity.setId(mqTodoCmd.getId());
//        entity.setSrcTodoId(mqTodoCmd.getSrcTodoId());
//        entity.setReceiver(mqTodoCmd.getCmdReceiver());
//        entity.setReceiverName(mqTodoCmd.getReceiverName());
//        entity.setCmdType(mqTodoCmd.getCmdType());
//        entity.setCmdContent(mqTodoCmd.getCmdContent());
//        entity.setCreationTime(mqTodoCmd.getCreationTime());
//        entity.setRetryCount(mqTodoCmd.getRetryCount());
//        entity.setStatus(mqTodoCmd.getStatus());
//        return entity;
//    }
//
//    /**
//     * 构建MQTodoFailCmd业务对象
//     *
//     * @param entity 实体对象
//     * @return
//     */
//    private MQTodoFailCmd wrapMQTodoFailCmd(MQTodoFailCmdEntity entity) {
//        if (entity == null) {
//            return null;
//        }
//        MQTodoFailCmd mqTodoCmd = new MQTodoFailCmd();
//        mqTodoCmd.setId(entity.getId());
//        mqTodoCmd.setSrcTodoId(entity.getSrcTodoId());
//        mqTodoCmd.setCmdReceiver(entity.getReceiver());
//        mqTodoCmd.setReceiverName(entity.getReceiverName());
//        mqTodoCmd.setCmdType(entity.getCmdType());
//        mqTodoCmd.setCmdContent(entity.getCmdContent());
//        mqTodoCmd.setCreationTime(entity.getCreationTime());
//        mqTodoCmd.setRetryCount(entity.getRetryCount());
//        mqTodoCmd.setStatus(entity.getStatus());
//        return mqTodoCmd;
//    }
//
//    @Override
//    @Transactional(readOnly = true)
//    public MQTodoFailCmd findBySrcTodoIdAndReceiver(String srcTodoId, String receiver) {
//        return wrapMQTodoFailCmd(mqFailCliCmdDao.findBySrcTodoIdAndReceiver(srcTodoId, receiver));
//    }
//
//    @Override
//    @Transactional
//    public void deleteBySrcTodoIdAndReceiverAndStatus(String srcTodoId, String receiver, int status) {
//        mqFailCliCmdDao.deleteBySrcTodoIdAndReceiverAndStatus(srcTodoId, receiver, status);
//    }
//
//    @Override
//    @Transactional
//    public void updateFailCliCmd(MQTodoFailCmd mqCliCmd) {
//        mqFailCliCmdDao.mergeAndFlush(wrapFailEntity(mqCliCmd));
//    }
//
//    @Override
//    @Transactional
//    public void deleteBySrcTodoIdAndReceiver(String srcTodoId, String receiver) {
//        mqFailCliCmdDao.deleteBySrcTodoIdAndReceiver(srcTodoId, receiver);
//    }
//
//    @Override
//    @Transactional
//    public void deleteById(Long id) {
//        mqFailCliCmdDao.deleteById(id);
//    }
//
//    @Override
//    public MQTodoFailCmd[] findMQTodoFailCmdsByManual() {
//        OrderBy[] orderBy = OrderBy.orderBy(OrderBy.asc("id"));
//        Sort sort = CriteriaUtils.getSort(orderBy);
//        Criterion[] c = new Criterion[] { new Comparison("retryCount", Operator.GE, 3, false) };
//        Specification<MQTodoFailCmdEntity> spec = CriteriaUtils.getSpecification(MQTodoFailCmdEntity.class, c);
//        List<MQTodoFailCmdEntity> list = mqFailCliCmdDao.findList(spec, 0, -1, sort);
//        if (list == null || list.isEmpty()) {
//            return new MQTodoFailCmd[0];
//        } else {
//            return list.stream().map(entry -> wrapMQTodoFailCmd(entry)).toArray(MQTodoFailCmd[]::new);
//        }
//    }
//
//}
