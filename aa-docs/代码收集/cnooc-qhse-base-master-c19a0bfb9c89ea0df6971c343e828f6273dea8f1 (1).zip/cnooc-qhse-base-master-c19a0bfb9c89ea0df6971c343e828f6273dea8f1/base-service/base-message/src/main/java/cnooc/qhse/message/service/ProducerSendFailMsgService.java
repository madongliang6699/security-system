///*
//* Copyright 2013-2023 Smartdot Technologies Co., Ltd. All rights reserved.
//* SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//*
//*/
//package cnooc.qhse.message.service;
//
//import org.springframework.amqp.core.ReturnedMessage;
//import org.springframework.amqp.rabbit.connection.CorrelationData;
//
//import com.hd.rcugrc.ut.server.bean.MQTodoFailCmd;
//
///**
// * <p>
// * 处理异常错误消息服务接口
// *
// * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
// * @version 1.0, 2023年5月30日
// */
//public interface ProducerSendFailMsgService {
//
//    /**
//     * 保存路由丢失的待推送MQ消息
//     *
//     * @param returned
//     */
//    public String saveFailMsgByNotRouting(ReturnedMessage returned);
//
//    /**
//     * 保存交换机丢失的待推送MQ消息
//     *
//     * @param correlationData
//     */
//    public String saveFailMsgByNotExchange(CorrelationData correlationData);
//
//    /**
//     * 保存异常时丢失的待推送的MQ消息
//     *
//     * @param msg
//     */
//    public void saveFailMsgByException(String msg);
//
//    /**
//     * 删除异常mq消息
//     *
//     * @param correlationData
//     */
//    public void deleteFailMsg(CorrelationData correlationData);
//
//
//    /**
//     * 需要手动干预的异常命令
//     */
//
//    public MQTodoFailCmd[] findMQTodoFailCmdsByManual();
//
//}
