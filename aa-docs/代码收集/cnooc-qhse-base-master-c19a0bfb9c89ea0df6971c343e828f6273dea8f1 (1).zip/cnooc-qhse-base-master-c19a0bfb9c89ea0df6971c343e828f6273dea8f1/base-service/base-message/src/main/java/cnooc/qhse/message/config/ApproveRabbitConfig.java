package cnooc.qhse.message.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.connection.RabbitConnectionFactoryBean;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * @author zqy
 */
@Configuration
public class ApproveRabbitConfig {
//	@ConfigurationProperties(prefix = "spring.syn-page-form.rabbitmq")
//	@Bean(name = "cusomSynPageFromInvokerRabbitProperties")
//	@Primary
//	public RabbitProperties customSynPageFormDataInvokerRabbitProperties() {
//		RabbitProperties pro = new RabbitProperties();
//		pro.setAddresses("amqp://10.77.78.202:5673");
//		pro.setPassword("n6axT%!80qkKd7T0");
//		pro.setUsername("bpm");
//		return pro;
//	}

	@Value("${spring.syn-page-form.rabbitmq.page.syn.queue:ead.page.syn.default.fastreq}")
//    @Value("${spring.syn-page-form.rabbitmq.page.syn.queue:ead.page.syn.default.fastreq}")
	public String queueName;
	//    @Value("${spring.syn-page-form.rabbitmq.page.syn.routekey:ead.page.syn.default}")
	@Value("${spring.syn-page-form.rabbitmq.page.syn.routekey:ead.page.syn.default}")
	public String routeKey;

	public final static String exchange = "ead.page.syn.exchange";

	@Bean
	public Queue queue() {
		return new Queue(queueName);
	}

	@Bean
	public DirectExchange directExchange() {
		return new DirectExchange(exchange, true, false);
	}

	/**
	 * 声明一个 Binding Bean, 用于把 Queen 和 Exchange 进行绑定
	 * 并设置 routeKey 作为 Routing Key
	 * 投递消息的时候可以使用这个 key 通过这个 Exchange 发送到这个 Queen 上
	 */
	@Bean
	public Binding bindDirect() {
		//链式写法，绑定交换机和队列，并设置匹配键
		return BindingBuilder
			//绑定队列
			.bind(queue())
			//到交换机
			.to(directExchange())
			//并设置匹配键
			.with(routeKey);
	}


	@Bean("approveRabbitTemplate")
	public RabbitTemplate getRabbitTemplate(RabbitProperties rabbitProperties,CachingConnectionFactory connectionFactory) throws Exception {
		RabbitTemplate rabbitTemplate = new RabbitTemplate();
		rabbitTemplate.setExchange(exchange);
		rabbitTemplate.setRoutingKey(routeKey);
		//ConnectionFactory connectionFactory = (ConnectionFactory) (customSynPageDataInvokerConnectionFactory(rabbitProperties));
		rabbitTemplate.setConnectionFactory(connectionFactory);
		return rabbitTemplate;
	}

//	@Bean
//	public CachingConnectionFactory customSynPageDataInvokerConnectionFactory(RabbitProperties rabbitProperties) throws Exception {
//		PropertyMapper map = PropertyMapper.get();
//		CachingConnectionFactory factory = new CachingConnectionFactory(
//			getRabbitConnectionFactoryBean(rabbitProperties).getObject());
//		map.from(rabbitProperties::determineAddresses).to(factory::setAddresses);
//		map.from(rabbitProperties::getPublisherConfirmType).whenNonNull().to(factory::setPublisherConfirmType);
//		map.from(rabbitProperties::isPublisherReturns).to(factory::setPublisherReturns);
//		RabbitProperties.Cache.Channel channel = rabbitProperties.getCache().getChannel();
//		map.from(channel::getSize).whenNonNull().to(factory::setChannelCacheSize);
//		map.from(channel::getCheckoutTimeout).whenNonNull().as(Duration::toMillis)
//			.to(factory::setChannelCheckoutTimeout);
//		RabbitProperties.Cache.Connection connection = rabbitProperties.getCache().getConnection();
//		map.from(connection::getMode).whenNonNull().to(factory::setCacheMode);
//		map.from(connection::getSize).whenNonNull().to(factory::setConnectionCacheSize);
//		// map.from(connectionNameStrategy::getIfUnique).whenNonNull()
//		// .to(factory::setConnectionNameStrategy);
//		return factory;
//	}

	private RabbitConnectionFactoryBean getRabbitConnectionFactoryBean(
		@Qualifier("cusomSynPageFromInvokerRabbitProperties") RabbitProperties properties) throws Exception {
		PropertyMapper map = PropertyMapper.get();
		RabbitConnectionFactoryBean factory = new RabbitConnectionFactoryBean();
		map.from(properties::determineHost).whenNonNull().to(factory::setHost);
		map.from(properties::determinePort).to(factory::setPort);
		map.from(properties::determineUsername).whenNonNull().to(factory::setUsername);
		map.from(properties::determinePassword).whenNonNull().to(factory::setPassword);
		map.from(properties::determineVirtualHost).whenNonNull().to(factory::setVirtualHost);
		map.from(properties::getRequestedHeartbeat).whenNonNull().asInt(Duration::getSeconds)
			.to(factory::setRequestedHeartbeat);
		RabbitProperties.Ssl ssl = properties.getSsl();
		if (ssl.determineEnabled()) {
			factory.setUseSSL(true);
			map.from(ssl::getAlgorithm).whenNonNull().to(factory::setSslAlgorithm);
			map.from(ssl::getKeyStoreType).to(factory::setKeyStoreType);
			map.from(ssl::getKeyStore).to(factory::setKeyStore);
			map.from(ssl::getKeyStorePassword).to(factory::setKeyStorePassphrase);
			map.from(ssl::getTrustStoreType).to(factory::setTrustStoreType);
			map.from(ssl::getTrustStore).to(factory::setTrustStore);
			map.from(ssl::getTrustStorePassword).to(factory::setTrustStorePassphrase);
			map.from(ssl::isValidateServerCertificate)
				.to((validate) -> factory.setSkipServerCertificateValidation(!validate));
			map.from(ssl::getVerifyHostname).to(factory::setEnableHostnameVerification);
		}
		map.from(properties::getConnectionTimeout).whenNonNull().asInt(Duration::toMillis)
			.to(factory::setConnectionTimeout);
		factory.afterPropertiesSet();
		return factory;
	}
}
