///*
//* Copyright 2013-2023 Smartdot Technologies Co., Ltd. All rights reserved.
//* SMARTDOT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
//*
//*/
//package cnooc.qhse.message.service.impl;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.joda.time.DateTime;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.amqp.core.ReturnedMessage;
//import org.springframework.amqp.rabbit.connection.CorrelationData;
//import org.springframework.beans.factory.InitializingBean;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.hd.rcugrc.ut.server.bean.MQTodoFailCmd;
//import com.hd.rcugrc.ut.server.bean.MQTodoMsgBean;
//import com.hd.rcugrc.ut.server.service.MQTodoFailCmdService;
//import com.hd.rcugrc.ut.server.service.ProducerSendFailMsgService;
//
///**
// * <p>
// * 处理异常错误消息服务实现
// *
// * @author <a href="mailto:renchao@smartdot.com.cn">任超</a>
// * @version 1.0, 2023年5月30日
// */
//public class ProducerSendFailMsgServiceImpl implements ProducerSendFailMsgService, InitializingBean {
//
//    private Logger logger = LoggerFactory.getLogger(getClass());
//
//    @Autowired
//    private MQTodoFailCmdService mqTodoFailCmdService;
//    @Autowired
//    @Qualifier("hdWorkflowJsonObjectMapper")
//    private ObjectMapper jsonObjectMapper;
//
//    @Override
//    public void afterPropertiesSet() throws Exception {
//
//    }
//
//    @Override
//    public String saveFailMsgByNotRouting(ReturnedMessage returned) {
//        String result = null;
//        if (null != returned && null != returned.getMessage()) {
//            String message = new String(returned.getMessage().getBody());
//            try {
//                MQTodoMsgBean[] msgBeans = jsonObjectMapper.readValue(message, MQTodoMsgBean[].class);
//                List<MQTodoFailCmd> cmdList = buildMQTodoFailCmd(msgBeans);
//                for (MQTodoFailCmd cmd : cmdList) {
//                    MQTodoFailCmd oldCmd = mqTodoFailCmdService.findBySrcTodoIdAndReceiver(cmd.getSrcTodoId(),
//                            cmd.getReceiver());
//                    if (null != oldCmd) {
//                        cmd.setRetryCount(oldCmd.getRetryCount() + 1);
//                    }
//                }
//                mqTodoFailCmdService.createFailCliCmd(cmdList);
//                result = "saveFailMsgByNotRouting!";
//
//            } catch (JsonMappingException e) {
//                e.printStackTrace();
//                logger.error(e.getMessage());
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//                logger.error(e.getMessage());
//            }
//        }
//        return result;
//    }
//
//    @Override
//    public String saveFailMsgByNotExchange(CorrelationData correlationData) {
//        String result = null;
//        if (null != correlationData && null != correlationData.getReturned()
//                && null != correlationData.getReturned().getMessage()
//                && null != correlationData.getReturned().getMessage().getBody()) {
//            String message = new String(correlationData.getReturned().getMessage().getBody());
//            try {
//                MQTodoMsgBean[] msgBeans = jsonObjectMapper.readValue(message, MQTodoMsgBean[].class);
//                List<MQTodoFailCmd> cmdList = buildMQTodoFailCmd(msgBeans);
//                for (MQTodoFailCmd cmd : cmdList) {
//                    MQTodoFailCmd oldCmd = mqTodoFailCmdService.findBySrcTodoIdAndReceiver(cmd.getSrcTodoId(),
//                            cmd.getReceiver());
//                    if (null != oldCmd) {
//                        cmd.setRetryCount(oldCmd.getRetryCount() + 1);
//                        mqTodoFailCmdService.deleteById(oldCmd.getId());
//                    }
//                }
//                mqTodoFailCmdService.createFailCliCmd(cmdList);
//                result = "saveFailMsgByNotExchange!";
//            } catch (JsonMappingException e) {
//                e.printStackTrace();
//                logger.error(e.getMessage());
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//                logger.error(e.getMessage());
//            }
//        }
//        return result;
//    }
//
//    @Override
//    public void saveFailMsgByException(String message) {
//        try {
//            MQTodoMsgBean[] msgBeans = jsonObjectMapper.readValue(message, MQTodoMsgBean[].class);
//            List<MQTodoFailCmd> cmdList = buildMQTodoFailCmd(msgBeans);
//            for (MQTodoFailCmd cmd : cmdList) {
//                MQTodoFailCmd oldCmd = mqTodoFailCmdService.findBySrcTodoIdAndReceiver(cmd.getSrcTodoId(),
//                        cmd.getReceiver());
//                if (null != oldCmd) {
//                    cmd.setRetryCount(oldCmd.getRetryCount() + 1);
//                    mqTodoFailCmdService.deleteById(oldCmd.getId());
//                }
//            }
//            mqTodoFailCmdService.createFailCliCmd(cmdList);
//        } catch (JsonMappingException e) {
//            e.printStackTrace();
//            logger.error(e.getMessage());
//        } catch (JsonProcessingException e) {
//            e.printStackTrace();
//            logger.error(e.getMessage());
//        }
//    }
//
//    /**
//     * 构建MQTodoFailCmd对象
//     *
//     * @param msgBeans
//     * @return
//     */
//    private List<MQTodoFailCmd> buildMQTodoFailCmd(MQTodoMsgBean[] msgBeans) {
//        // 记录失败日志
//        List<MQTodoFailCmd> mqCliCmds = new ArrayList<MQTodoFailCmd>();
//        for (MQTodoMsgBean msgBean : msgBeans) {
//            MQTodoFailCmd cmd = new MQTodoFailCmd();
//            cmd.setSrcTodoId(msgBean.getSrcTodoId());
//            cmd.setCmdReceiver(msgBean.getReceiver());
//            cmd.setReceiverName(msgBean.getReceiverName());
//            cmd.setCmdType(msgBean.getActionType());
//            String content = null;
//            try {
//                content = jsonObjectMapper.writeValueAsString(msgBeans);
//            } catch (JsonProcessingException e) {
//                e.printStackTrace();
//                logger.error(e.getMessage());
//            }
//            cmd.setCmdContent(content);
//            cmd.setCreationTime(new DateTime().getMillis());
//            cmd.setRetryCount(0);
//            cmd.setStatus(-2);
//            mqCliCmds.add(cmd);
//        }
//        return mqCliCmds;
//    }
//
//    @Override
//    public void deleteFailMsg(CorrelationData correlationData) {
//        if (null != correlationData && null != correlationData.getId() && !"undefined".equals(correlationData.getId())) {
//            String msgId = correlationData.getId();
//            mqTodoFailCmdService.deleteById(Long.valueOf(msgId));
//        }
//    }
//
//    @Override
//    public MQTodoFailCmd[] findMQTodoFailCmdsByManual() {
//        return mqTodoFailCmdService.findMQTodoFailCmdsByManual();
//    }
//}
