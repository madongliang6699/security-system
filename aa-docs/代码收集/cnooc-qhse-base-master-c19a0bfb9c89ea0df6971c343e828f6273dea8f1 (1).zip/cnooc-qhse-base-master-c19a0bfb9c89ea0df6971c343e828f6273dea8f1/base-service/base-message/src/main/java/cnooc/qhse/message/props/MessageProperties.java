package cnooc.qhse.message.props;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 配置参数
 *
 * @author Chill
 */
@Data
@ConfigurationProperties(prefix = "message-config")
public class MessageProperties {
	private int retryCount = 3;
}
