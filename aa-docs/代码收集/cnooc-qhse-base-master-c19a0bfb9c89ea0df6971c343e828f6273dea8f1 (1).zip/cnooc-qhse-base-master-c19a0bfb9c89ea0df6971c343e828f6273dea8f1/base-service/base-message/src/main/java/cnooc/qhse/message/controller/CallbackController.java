package cnooc.qhse.message.controller;

import cnooc.qhse.message.pojo.entity.ProcessForm;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/callback")
@Tag(name = "待办补偿机制表", description = "待办补偿机制表接口")
public class CallbackController {

	@PostMapping("/dispatch")
	@ApiOperationSupport(order = 1)
	@Operation(summary = "详情", description = "传入mqTodoFailCmd")
	public Map<String, String> dispatch(@RequestBody ProcessForm processForm, HttpServletRequest request) {
		Map<String, String> resultMap = new HashMap<>(2) {{
			put("result", "success");
			put("message", "成功");
		}};
		return resultMap;
	}
}
