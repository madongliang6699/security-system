package cnooc.qhse.message;

import org.springblade.core.cloud.client.BladeCloudApplication;
import org.springblade.core.launch.BladeApplication;

/**
 * Demo启动器
 *
 * @author Chill
 */
@BladeCloudApplication
public class MessageApplication {

	public static void main(String[] args) {
		BladeApplication.run("cnooc-qhse-todo", MessageApplication.class, args);
	}

}

