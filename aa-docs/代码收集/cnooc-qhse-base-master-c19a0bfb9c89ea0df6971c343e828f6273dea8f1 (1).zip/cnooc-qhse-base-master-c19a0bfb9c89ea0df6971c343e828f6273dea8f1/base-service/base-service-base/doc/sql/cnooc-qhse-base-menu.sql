BEGIN;
-- 现场区域菜单与权限
delete from blade_menu where id in (
1201436564600680454,
1201436564600680455,
1201436564600680456,
1201436564600680457,
1201436564600680458,
1201436564600680459,
1201436564600680460
);
-- 排序为基础数据下的2
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1201436564600680454', '1164733399668962201', 'area', '现场区域', 'menu', '/apps/base/pages/area/area', 'iconfont iconarea32', 2, 1, 0, 1, NULL, 0),
('1201436564600680455', '1201436564600680454', 'area_add', '新增', 'add', '/apps/base/pages/area/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1201436564600680456', '1201436564600680454', 'area_edit', '修改', 'edit', '/apps/base/pages/area/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1201436564600680457', '1201436564600680454', 'area_delete', '删除', 'delete', '/apps/base/pages/area/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1201436564600680458', '1201436564600680454', 'area_view', '查看', 'view', '/apps/base/pages/area/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1201436564600680459', '1201436564600680454', 'area_import', '导入', 'import', '/apps/base/pages/area/import', 'menu', 5, 2, 2, 1, NULL, 0),
('1201436564600680460', '1201436564600680454', 'area_export', '导出', 'export', '/apps/base/pages/area/export', 'menu', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
1211565452651745282,
1211565452651745283,
1211565452651745284,
1211565452651745285,
1211565452651745286,
1211565452651745287
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
(1211565452651745282, 1201436564600680454, 'earnest:area:add', '新增', '/base/area/add', 2, 0),
(1211565452651745283, 1201436564600680454, 'earnest:area:edit', '修改', '/base/area/edit', 2, 0),
(1211565452651745284, 1201436564600680454, 'earnest:area:delete', '删除', '/base/area/delete', 2, 0),
(1211565452651745285, 1201436564600680454, 'earnest:area:view', '查看', '/base/area/view', 2, 0),
(1211565452651745286, 1201436564600680454, 'earnest:area:import', '导入', '/base/area/import', 2, 0),
(1211565452651745287, 1201436564600680454, 'earnest:area:export', '导出', '/base/area/export', 2, 0);

-- 数据分类菜单与权限
delete from blade_menu where id in (
'1201436564600680464',
'1201436564600680465',
'1201436564600680466',
'1201436564600680467',
'1201436564600680468',
'1201436564600680469',
'1201436564600680470'
);
-- 排序为基础数据下的3
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1201436564600680464', '1164733399668962201', 'category', '数据分类', 'menu', '/apps/base/pages/category/category', 'iconfont iconicon_work', 3, 1, 0, 1, NULL, 0),
('1201436564600680465', '1201436564600680464', 'category_add', '新增', 'add', '/apps/base/pages/category/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1201436564600680466', '1201436564600680464', 'category_edit', '修改', 'edit', '/apps/base/pages/category/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1201436564600680467', '1201436564600680464', 'category_delete', '删除', 'delete', '/apps/base/pages/category/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1201436564600680468', '1201436564600680464', 'category_view', '查看', 'view', '/apps/base/pages/category/view', 'file-text', 4, 2, 1, 1, NULL, 0),
('1201436564600680469', '1201436564600680464', 'category_import', '导入', 'import', '/apps/base/pages/category/import', 'menu', 5, 2, 1, 1, NULL, 0),
('1201436564600680470', '1201436564600680464', 'category_export', '导出', 'export', '/apps/base/pages/category/export', 'menu', 6, 2, 1, 1, NULL, 0);

delete from blade_scope_api where id in (
1211565452651745292,
1211565452651745293,
1211565452651745294,
1211565452651745295,
1211565452651745296,
1211565452651745297
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
(1211565452651745292,1201436564600680464, 'earnest:category:add', '新增', '/base/category/add', 2, 0),
(1211565452651745293,1201436564600680464, 'earnest:category:edit', '修改', '/base/category/edit', 2, 0),
(1211565452651745294,1201436564600680464, 'earnest:category:delete', '删除', '/base/category/delete', 2, 0),
(1211565452651745295,1201436564600680464, 'earnest:category:view', '查看', '/base/category/view', 2, 0),
(1211565452651745296,1201436564600680464, 'earnest:category:import', '导入', '/base/category/import', 2, 0),
(1211565452651745297,1201436564600680464, 'earnest:category:export', '导出', '/base/category/export', 2, 0);

-- 待办事项的菜单
delete from blade_menu where id in (
'1224508799573876743',
'1224508799573876747',
'1228145509050470407',
'1228145509050470411',
'1229310721858326534',
'1229310721858326535',
'1229310721858326536',
'1229310721858326537',
'1229310721858326538'
);
-- 排序为工作台下的1
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted) VALUES
('1224508799573876743', 1123598815738675201, 'todo', '待办事项', 'menu', '/apps/base/pages/todo/todo', 'iconfont iconicon_savememo', 2, 1, 0, 1, NULL, 0),
('1224508799573876747', '1224508799573876743', 'todo_view', '查看', 'view', '/apps/base/pages/todo/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1228145509050470407', 1123598815738675201, 'done', '办结事项', 'menu', '/apps/base/pages/done/done', 'iconfont iconicon_dispose', 3, 1, 0, 1, NULL, 0),
('1228145509050470411', '1228145509050470407', 'done_view', '查看', 'view', '/apps/base/pages/done/view', 'file-text', 4, 2, 2, 1, NULL, 0);


-- 我的信息
delete from blade_menu where id in (1277398486258520070);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted) VALUES
('1277398486258520070', 1123598815738675201, 'user-supplementary-information', '我的信息', 'menu', '/apps/base/pages/user/user', 'iconfont iconchengbaoshangrenyuanxinxi', 4, 1, 0, 1, NULL, 0);


-- 排序为基础数据下的5
delete from blade_menu where id in (
'1585156937270452239',
'1585156937270452240',
'1585156937270452241',
'1585156937270452242',
'1585156937270452243',
'1585156937270452244',
'1585156937270452245'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1585156937270452239', 1164733399668962201, 'task_people', '流程任务人员', 'menu', '/apps/base/pages/task-people/task-people', 'iconfont iconteamwork', 6, 1, 0, 1, NULL, 0),
('1585156937270452240', '1585156937270452239', 'task_people_add', '新增', 'add', '/apps/base/pages/task-people/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1585156937270452241', '1585156937270452239', 'task_people_edit', '修改', 'edit', '/apps/base/pages/task-people/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1585156937270452242', '1585156937270452239', 'task_people_delete', '删除', 'delete', '/apps/base/pages/task-people/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1585156937270452243', '1585156937270452239', 'task_people_view', '查看', 'view', '/apps/base/pages/task-people/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1585156937270452244', '1585156937270452239', 'task_people_import', '导入', 'import', '/apps/base/pages/task-people/import', 'file-text', 5, 2, 2, 1, NULL, 0),
('1585156937270452245', '1585156937270452239', 'task_people_export', '导出', 'export', '/apps/base/pages/task-people/export', 'file-text', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1585156937270452246',
'1585156937270452247',
'1585156937270452248',
'1585156937270452249',
'1585156937270452250',
'1585156937270452251'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1585156937270452246', '1585156937270452239', 'base:task_people:add', '新增', '/base/task-people/add', 2, 0),
('1585156937270452247', '1585156937270452239', 'base:task_people:edit', '修改', '/base/task-people/edit', 2, 0),
('1585156937270452248', '1585156937270452239', 'base:task_people:delete', '删除', '/base/task-people/delete', 2, 0),
('1585156937270452249', '1585156937270452239', 'base:task_people:view', '查看', '/base/task-people/view', 2, 0),
('1585156937270452250', '1585156937270452239', 'base:task_people:import', '导入', '/base/task-people/import', 2, 0),
('1585156937270452251', '1585156937270452239', 'base:task_people:export', '导出', '/base/task-people/export', 2, 0);


delete from blade_menu where id in (
'1696419357439053839',
'1696419357439053840',
'1696419357439053841',
'1696419357439053842',
'1696419357439053843',
'1696419357439053844',
'1696419357439053845'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1696419357439053839', 1164733399668962201, 'task_setting', '任务设置', 'menu', '/apps/base/pages/task-setting/task-setting', NULL, 4, 1, 0, 1, NULL, 0),
('1696419357439053840', '1696419357439053839', 'task_setting_add', '新增', 'add', '/apps/base/pages/task-setting/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1696419357439053841', '1696419357439053839', 'task_setting_edit', '修改', 'edit', '/apps/base/pages/task-setting/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1696419357439053842', '1696419357439053839', 'task_setting_delete', '删除', 'delete', '/apps/base/pages/task-setting/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1696419357439053843', '1696419357439053839', 'task_setting_view', '查看', 'view', '/apps/base/pages/task-setting/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1696419357439053844', '1696419357439053839', 'task_setting_import', '导入', 'import', '/apps/base/pages/task-setting/import', 'file-text', 5, 2, 2, 1, NULL, 0),
('1696419357439053845', '1696419357439053839', 'task_setting_export', '导出', 'export', '/apps/base/pages/task-setting/export', 'file-text', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1696419357439053846',
'1696419357439053847',
'1696419357439053848',
'1696419357439053849',
'1696419357439053850',
'1696419357439053851'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1696419357439053846', '1696419357439053839', 'flowable:task_setting:add', '新增', '/base/task-setting/add', 2, 0),
('1696419357439053847', '1696419357439053839', 'flowable:task_setting:edit', '修改', '/base/task-setting/edit', 2, 0),
('1696419357439053848', '1696419357439053839', 'flowable:task_setting:delete', '删除', '/base/task-setting/delete', 2, 0),
('1696419357439053849', '1696419357439053839', 'flowable:task_setting:view', '查看', '/base/task-setting/view', 2, 0),
('1696419357439053850', '1696419357439053839', 'flowable:task_setting:import', '导入', '/base/task-setting/import', 2, 0),
('1696419357439053851', '1696419357439053839', 'flowable:task_setting:export', '导出', '/base/task-setting/export', 2, 0);

delete from blade_menu where id in (
'1249945059985489926',
'1249945059985489927',
'1249945059985489928',
'1249945059985489929',
'1249945059985489930',
'1249945059985489931',
'1249945059985489932',
'1249945059985489933',
'1249949597933010951',
'1249949597933010952',
'1249949597933010953',
'1249949597933010954',
'1249949597933010955'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted) VALUES
('1249945059985489926', 0, 'shift', '交接班', 'menu', '/shift', 'iconfont iconshift_bold', 28, 1, 0, 1, NULL, 0),
('1249945059985489927', '1249945059985489926', 'shift', '交接班岗位', 'menu', '/apps/base/pages/shift/shift', 'iconfont iconshift_bold', 1, 1, 0, 1, NULL, 0),
('1249945059985489928', '1249945059985489927', 'shift_add', '新增', 'add', '/apps/base/pages/shift/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1249945059985489929', '1249945059985489927', 'shift_edit', '修改', 'edit', '/apps/base/pages/shift/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1249945059985489930', '1249945059985489927', 'shift_delete', '删除', 'delete', '/apps/base/pages/shift/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1249945059985489931', '1249945059985489927', 'shift_view', '查看', 'view', '/apps/base/pages/shift/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1249945059985489932', '1249945059985489927', 'shift_self', '自主切换', 'self', '/apps/base/pages/shift/self', 'file-text', 5, 2, 2, 1, NULL, 0),
('1249945059985489933', '1249945059985489927', 'shift_assign', '指定', 'assign', '/apps/base/pages/shift/assign', 'file-text', 6, 2, 2, 1, NULL, 0),
('1249949597933010951', '1249945059985489926', 'shift_log', '交接班日志', 'menu', '/apps/base/pages/shiftLog', 'iconfont iconjiaojiebanrizhi', 2, 1, 0, 1, NULL, 0),
('1249949597933010954', '1249949597933010951', 'shift_log_delete', '删除', 'delete', '/apps/base/pages/shiftLog/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1249949597933010955', '1249949597933010951', 'shift_log_view', '查看', 'view', '/apps/base/pages/shiftLog/view', 'file-text', 4, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
1249975340020854785,
1249975450532376577,
1249975546359640065,
1249975684704563201,
1249975800052117505,
1249975897540325378,
1249976165782843394,
1249976265766662146
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted) VALUES
(1249975340020854785, 1249945059985489927, 'shift:add', '新增', '/base/shift/add', 2,  0),
(1249975450532376577, 1249945059985489927, 'shift:edit', '编辑', '/base/shift/edit', 2, 0),
(1249975546359640065, 1249945059985489927, 'shift:delete', '删除', '/base/shift/remove', 2,  0),
(1249975684704563201, 1249945059985489927, 'shift:view', '查看', '/base/shift/view', 2, 0),
(1249975800052117505, 1249945059985489927, 'shift:self', '自主切换', '/base/shift/self', 2, 0),
(1249975897540325378, 1249945059985489927, 'shift:assign', '指定', '/base/shift/assign', 2, 0),
(1249976165782843394, 1249949597933010951, 'shift:log:delete', '删除', '/base/log/remove', 2, 0),
(1249976265766662146, 1249949597933010951, 'shift:log:view', '查看', '/base/log/view', 2, 0);

delete from blade_menu where id in (
'1241177669311160327',
'1241177669311160328',
'1241177669311160329',
'1241177669311160330',
'1241177669311160331'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted) VALUES
('1241177669311160327', 1123598815738675203, 'software_version', '版本更新', 'menu', '/apps/base/pages/software-version/software-version', 'iconfont iconicon_exchange', 10, 1, 0, 1, NULL, 0),
('1241177669311160328', '1241177669311160327', 'software_version_add', '新增', 'add', '/apps/base/pages/software-version/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1241177669311160329', '1241177669311160327', 'software_version_edit', '修改', 'edit', '/apps/base/pages/software-version/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1241177669311160330', '1241177669311160327', 'software_version_delete', '删除', 'delete', '/api/apps/base/pages/software-version/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1241177669311160331', '1241177669311160327', 'software_version_view', '查看', 'view', '/apps/base/pages/software-version/view', 'file-text', 4, 2, 2, 1, NULL, 0);

-- 文档模板菜单

delete from blade_menu where id in (
1265526191663599619,
1265526191663599620,
1265526191663599621,
1265526191663599622
);
INSERT INTO blade_menu (id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted) VALUES
(1265526191663599619, 1123598815738675217, 'doc_template', '文档模板', 'menu', '/apps/base/pages/doc-template/doc-template', 'iconfont iconicon_photo', 11, 1, 0, 1, '', 0),
(1265526191663599620, 1265453853001592833, 'doc_template_add', '新增', 'add', '/apps/base/pages/doc-template/add', 'iconfont iconicon_roundadd', 1, 2, 0, 1, '', 0),
(1265526191663599621, 1265453853001592833, 'doc_template_delete', '删除', 'delete', '/apps/base/pages/doc-template/delete', 'iconfont iconicon_roundclose', 2, 2, 0, 1, '', 0),
(1265526191663599622, 1265453853001592833, 'doc_template_view', '查看', 'view', '/apps/base/pages/doc-template/view', 'iconfont iconicon_glass', 3, 2, 0, 1, '', 0);

-- 字段控制
delete from blade_menu where id in (
'1630744636312023055',
'1630744636312023056',
'1630744636312023057',
'1630744636312023058',
'1630744636312023059',
'1630744636312023060',
'1630744636312023061'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1630744636312023055', 1123598815738675217, 'field_config', '字段控制', 'menu', '/apps/base/pages/field-config/field-config', 'iconfont iconziduankongzhi', 1, 1, 0, 1, NULL, 0),
('1630744636312023056', '1630744636312023055', 'field_config_add', '新增', 'add', '/apps/base/pages/field-config/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1630744636312023057', '1630744636312023055', 'field_config_edit', '修改', 'edit', '/apps/base/pages/field-config/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1630744636312023058', '1630744636312023055', 'field_config_delete', '删除', 'delete', '/apps/base/pages/field-config/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1630744636312023059', '1630744636312023055', 'field_config_view', '查看', 'view', '/apps/base/pages/field-config/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1630744636312023060', '1630744636312023055', 'field_config_import', '导入', 'import', '/apps/base/pages/field-config/import', 'file-text', 5, 2, 2, 1, NULL, 0),
('1630744636312023061', '1630744636312023055', 'field_config_export', '导出', 'export', '/apps/base/pages/field-config/export', 'file-text', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1630744636312023062',
'1630744636312023063',
'1630744636312023064',
'1630744636312023065',
'1630744636312023066',
'1630744636312023067'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1630744636312023062', '1630744636312023055', 'base:field_config:add', '新增', '/base/field-config/add', 2, 0),
('1630744636312023063', '1630744636312023055', 'base:field_config:edit', '修改', '/base/field-config/edit', 2, 0),
('1630744636312023064', '1630744636312023055', 'base:field_config:delete', '删除', '/base/field-config/delete', 2, 0),
('1630744636312023065', '1630744636312023055', 'base:field_config:view', '查看', '/base/field-config/view', 2, 0),
('1630744636312023066', '1630744636312023055', 'base:field_config:import', '导入', '/base/field-config/import', 2, 0),
('1630744636312023067', '1630744636312023055', 'base:field_config:export', '导出', '/base/field-config/export', 2, 0);

delete from blade_menu where id in (
'1678278358863032335',
'1678278358863032336',
'1678278358863032337',
'1678278358863032338',
'1678278358863032339',
'1678278358863032340',
'1678278358863032341'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1678278358863032335', 1164733399668962201, 'alert_config', '预警提醒配置', 'menu', '/apps/base/pages/alert-config/alert-config', 'iconfont iconicon_renwufenxiyujing', 7, 1, 0, 1, NULL, 0),
('1678278358863032336', '1678278358863032335', 'alert_config_add', '新增', 'add', '/apps/base/pages/alert-config/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1678278358863032337', '1678278358863032335', 'alert_config_edit', '修改', 'edit', '/apps/base/pages/alert-config/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1678278358863032338', '1678278358863032335', 'alert_config_delete', '删除', 'delete', '/apps/base/pages/alert-config/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1678278358863032339', '1678278358863032335', 'alert_config_view', '查看', 'view', '/apps/base/pages/alert-config/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1678278358863032340', '1678278358863032335', 'alert_config_import', '导入', 'import', '/apps/base/pages/alert-config/import', 'file-text', 5, 2, 2, 1, NULL, 0),
('1678278358863032341', '1678278358863032335', 'alert_config_export', '导出', 'export', '/apps/base/pages/alert-config/export', 'file-text', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1678278358863032342',
'1678278358863032343',
'1678278358863032344',
'1678278358863032345',
'1678278358863032346',
'1678278358863032347'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1678278358863032342', '1678278358863032335', 'base:alert_config:add', '新增', '/base/alert-config/add', 2, 0),
('1678278358863032343', '1678278358863032335', 'base:alert_config:edit', '修改', '/base/alert-config/edit', 2, 0),
('1678278358863032344', '1678278358863032335', 'base:alert_config:delete', '删除', '/base/alert-config/delete', 2, 0),
('1678278358863032345', '1678278358863032335', 'base:alert_config:view', '查看', '/base/alert-config/view', 2, 0),
('1678278358863032346', '1678278358863032335', 'base:alert_config:import', '导入', '/base/alert-config/import', 2, 0),
('1678278358863032347', '1678278358863032335', 'base:alert_config:export', '导出', '/base/alert-config/export', 2, 0);


-- 日历表：earnest_calendar
delete from blade_menu where id in (
'1679667248010797070',
'1679667248010797071',
'1679667248010797072'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1679667248010797070', 1164733399668962201, 'calendar', '日历表', 'menu', '/apps/base/pages/calendar/calendar', 'iconfont iconrili', 8, 1, 0, 1, NULL, 0),
('1679667248010797071', '1679667248010797070', 'calendar_import', '导入', 'add', '/apps/base/pages/calendar/import', 'file-text', 1, 2, 1, 1, NULL, 0),
('1679667248010797072', '1679667248010797070', 'calendar_view', '列表', 'edit', '/apps/base/pages/calendar/list', 'file-text', 2, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1679667248010797081',
'1679667248010797082'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1679667248010797081', '1679667248010797070', 'calendar:calendar:import', '导入', '/base/calendar/import', 2, 0),
('1679667248010797082', '1679667248010797070', 'calendar:calendar:list', '列表', '/base/calendar/list', 2, 0);

-- 地图：map
delete from blade_menu where id in (
'1679667248010802020'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1679667248010802020', 1164733399668962201, 'map', '地图', 'menu', '/map/index', 'iconfont iconfengxianditu', 9, 1, 0, 2, NULL, 0);

delete from blade_menu where id in (
1623598815738675331,
1623598815738675332,
1623598815738675333,
1623598815738675334
);
-- INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
-- VALUES
-- (1623598815738675331, 1123598815738675204, 'platform_disable_sedits', '禁止访问安全风险智能化管控平台', 'sedits', '/platform/user/sedits', 'plus', 10, 2, 1, 1, '', 0),
-- (1623598815738675332, 1123598815738675204, 'platform_disable_production_safety', '禁止访问生产安全管理数字化信息系统', 'production_safety', '/platform/user/production-safety', 'plus', 11, 2, 1, 1, '', 0),
-- (1623598815738675333, 1123598815738675204, 'platform_disable_consultant_intelligent', '禁止访问咨询数智中心', 'consultant_intelligent', '/platform/user/consultant_intelligent', 'plus', 12, 2, 1, 1, '', 0),
-- (1623598815738675334, 1123598815738675204, 'platform_disable_surveillance_supporting', '禁止访问质安监督单兵支持系统', 'surveillance_supporting', '/platform/user/surveillance-supporting', 'plus', 13, 2, 1, 1, '', 0);


delete from blade_menu where id in (
'1732929225687597070',
'1732929225687597071',
'1732929225687597072',
'1732929225687597073',
'1732929225687597074',
'1732929225687597075',
'1732929225687597076'
);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
('1732929225687597070', 1123598815738675217, 'custom_form', '自定义表单', 'menu', '/apps/base/pages/custom-form/custom-form', NULL, 1, 1, 0, 1, NULL, 0),
('1732929225687597071', '1732929225687597070', 'custom_form_add', '新增', 'add', '/apps/base/pages/custom-form/add', 'plus', 1, 2, 1, 1, NULL, 0),
('1732929225687597072', '1732929225687597070', 'custom_form_edit', '修改', 'edit', '/apps/base/pages/custom-form/edit', 'form', 2, 2, 2, 1, NULL, 0),
('1732929225687597073', '1732929225687597070', 'custom_form_delete', '删除', 'delete', '/apps/base/pages/custom-form/remove', 'delete', 3, 2, 3, 1, NULL, 0),
('1732929225687597074', '1732929225687597070', 'custom_form_view', '查看', 'view', '/apps/base/pages/custom-form/view', 'file-text', 4, 2, 2, 1, NULL, 0),
('1732929225687597075', '1732929225687597070', 'custom_form_import', '导入', 'import', '/apps/base/pages/custom-form/import', 'file-text', 5, 2, 2, 1, NULL, 0),
('1732929225687597076', '1732929225687597070', 'custom_form_export', '导出', 'export', '/apps/base/pages/custom-form/export', 'file-text', 6, 2, 2, 1, NULL, 0);

delete from blade_scope_api where id in (
'1732929225687597077',
'1732929225687597078',
'1732929225687597079',
'1732929225687597080',
'1732929225687597081',
'1732929225687597082'
);
INSERT INTO blade_scope_api (id, menu_id, resource_code, scope_name, scope_path, scope_type, is_deleted)
VALUES
('1732929225687597077', '1732929225687597070', 'base:custom_form:add', '新增', '/base/custom-form/add', 2, 0),
('1732929225687597078', '1732929225687597070', 'base:custom_form:edit', '修改', '/base/custom-form/edit', 2, 0),
('1732929225687597079', '1732929225687597070', 'base:custom_form:delete', '删除', '/base/custom-form/delete', 2, 0),
('1732929225687597080', '1732929225687597070', 'base:custom_form:view', '查看', '/base/custom-form/view', 2, 0),
('1732929225687597081', '1732929225687597070', 'base:custom_form:import', '导入', '/base/custom-form/import', 2, 0),
('1732929225687597082', '1732929225687597070', 'base:custom_form:export', '导出', '/base/custom-form/export', 2, 0);

-- 系统工具
delete from blade_menu where id in (
'1364391743751516161',
'1364392700354818049',
'1364392700354818050'
);
INSERT INTO blade_menu (id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES
(1364391743751516161, 1123598815738675203, 'system-tool', '系统工具', 'menu', '/apps/base/pages/system-tool', 'iconfont iconicon_setting', 12, 1, 0, 1, '', 0),
(1364392700354818049, 1364391743751516161, 'active-face-sdk', '激活人脸SDK', 'edit', '/apps/base/pages/system-tool/active-face-sdk', 'iconfont iconicon_scan_namecard', 1, 2, 0, 1, '', 0),
(1364392700354818050, 1364391743751516161, 'flush-redis', '清空Redis缓存', 'edit', '/apps/base/pages/system-tool/flush-redis', 'iconfont iconicon_scan_namecard', 2, 2, 0, 1, '', 0);
COMMIT;

-- 自定义参数
delete from blade_menu where id in (
'1848540262498828290',
'1848540262498828291',
'1848540262498828292',
'1848540262498828293',
'1848540262498828294'
);

INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES ('1848540262498828290', 1164733399668962201, 'customParameter', '自定义参数表', 'menu', '/apps/base/pages/customParameter/customParameter', NULL, 1, 1, 0, 1, NULL, 0);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES ('1848540262498828291', '1848540262498828290', 'customParameter_add', '新增', 'add', '/apps/base/pages/customParameter/add', 'plus', 1, 2, 1, 1, NULL, 0);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES ('1848540262498828292', '1848540262498828290', 'customParameter_edit', '修改', 'edit', '/apps/base/pages/customParameter/edit', 'form', 2, 2, 2, 1, NULL, 0);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES ('1848540262498828293', '1848540262498828290', 'customParameter_delete', '删除', 'delete', '/api/customParameter/customParameter/remove', 'delete', 3, 2, 3, 1, NULL, 0);
INSERT INTO blade_menu(id, parent_id, code, name, alias, path, source, sort, category, action, is_open, remark, is_deleted)
VALUES ('1848540262498828294', '1848540262498828290', 'customParameter_view', '查看', 'view', '/apps/base/pages/customParameter/view', 'file-text', 4, 2, 2, 1, NULL, 0);
