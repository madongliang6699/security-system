drop table if exists earnest_area;
create table earnest_area
(
    id               bigint not null primary key,
    parent_id        bigint not null,
    ancestors        varchar(2000),
    tenant_id        varchar(12) default '000000',
    area_name        varchar(100) not null,
    area_code        varchar(100) not null,
    dept_ids         varchar(1000),
    user_ids         varchar(1000),
    remark           varchar(255),
    create_user      bigint,
    create_dept      bigint,
    create_time      timestamp ,
	update_user      bigint,
	update_time      timestamp,
	status           int,
	is_deleted       int default 0,
	area_coordinates varchar(2000),
	constraint "area_tenant_id_area_name" unique (tenant_id, area_name, is_deleted)
);
create index "area_parent_id" on earnest_area (parent_id);
create index "area_area_code" on earnest_area (tenant_id, area_code);
create index "area_area_name" on earnest_area (tenant_id, area_name);

comment on table earnest_area is '现场区域';
comment on column earnest_area.id is '主键';
comment on column earnest_area.parent_id is '父级节点';
comment on column earnest_area.ancestors is '祖级列表';
comment on column earnest_area.tenant_id is '租户ID';
comment on column earnest_area.area_name is '区域名称';
comment on column earnest_area.area_code is '区域编码';
comment on column earnest_area.dept_ids is '责任部门';
comment on column earnest_area.user_ids is '责任人';
comment on column earnest_area.remark is '备注';
comment on column earnest_area.create_user is '创建人';
comment on column earnest_area.create_dept is '创建部门';
comment on column earnest_area.create_time is '创建时间';
comment on column earnest_area.update_user is '修改人';
comment on column earnest_area.update_time is '修改时间';
comment on column earnest_area.status is '状态';
comment on column earnest_area.is_deleted is '是否已删除';
comment on column earnest_area.area_coordinates is '区域坐标';

drop table if exists earnest_category;
create table earnest_category
(
    id bigint     not null primary key,
    parent_id     bigint not null,
    ancestors     varchar(2000),
    tenant_id     varchar(12) default '000000',
    category_name varchar(100) not null,
    category_code varchar(100) not null,
    extend1       varchar(255),
    extend2       varchar(255),
    extend3       varchar(255),
    remark        varchar(255),
    create_user   bigint,
    create_dept   bigint,
    create_time   timestamp ,
	update_user   bigint,
	update_time   timestamp,
	status        int,
	is_deleted    int default 0
);
create index "category_parent_id" on earnest_category (parent_id);
create index "category_name" on earnest_category (tenant_id, category_name);
create index "category_code" on earnest_category (tenant_id, category_code);
comment on table earnest_category is '数据分类';
comment on column earnest_category.id is '主键';
comment on column earnest_category.parent_id is '父级节点';
comment on column earnest_category.ancestors is '祖级列表';
comment on column earnest_category.tenant_id is '租户ID';
comment on column earnest_category.category_name is '类型名称';
comment on column earnest_category.category_code is '类型编码';
comment on column earnest_category.extend1 is '扩展数据1';
comment on column earnest_category.extend2 is '扩展数据2';
comment on column earnest_category.extend3 is '扩展数据3';
comment on column earnest_category.remark is '备注';
comment on column earnest_category.create_user is '创建人';
comment on column earnest_category.create_dept is '创建部门';
comment on column earnest_category.create_time is '创建时间';
comment on column earnest_category.update_user is '修改人';
comment on column earnest_category.update_time is '修改时间';
comment on column earnest_category.status is '状态';
comment on column earnest_category.is_deleted is '是否已删除';

drop table if exists earnest_alert_config;
create table earnest_alert_config
(
    id                   bigint not null primary key,
    tenant_id            varchar(12) default '000000',
    alert_category       varchar(60),
    level1_alert_time    int,
    level1_user_group    varchar(200),
    level1_send_email    tinyint,
    level1_no_alert_time int,
    level2_alert_time    int,
    level2_user_group    varchar(200),
    level2_send_email    tinyint,
    level2_no_alert_time int,
    level3_alert_time    int,
    level3_user_group    varchar(200),
    level3_send_email    tinyint,
    level3_no_alert_time int,
    level4_alert_time    int,
    level4_user_group    varchar(200),
    level4_send_email    tinyint,
    level4_no_alert_time int,
    level5_alert_time    int,
    level5_user_group    varchar(200),
    level5_send_email    tinyint,
    level5_no_alert_time int,
    remark               varchar(255),
    create_user          bigint,
    create_dept          bigint,
    create_time          timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0,
	constraint "alert_config_category" unique (tenant_id, alert_category, is_deleted)
);
comment on table earnest_alert_config is '报警配置表';
comment on column earnest_alert_config.id is '主键';
comment on column earnest_alert_config.tenant_id is '租户ID';
comment on column earnest_alert_config.alert_category is '预警类型';
comment on column earnest_alert_config.level1_alert_time is '一级预警时间(分钟)';
comment on column earnest_alert_config.level1_user_group is '一级预警人员组';
comment on column earnest_alert_config.level1_send_email is '一级预警是否发送邮件';
comment on column earnest_alert_config.level1_no_alert_time is '一级预警不重复预警时间(分钟)';
comment on column earnest_alert_config.level2_alert_time is '二级预警时间(分钟)';
comment on column earnest_alert_config.level2_user_group is '二级预警人员组';
comment on column earnest_alert_config.level2_send_email is '二级预警是否发送邮件';
comment on column earnest_alert_config.level2_no_alert_time is '二级预警不重复预警时间(分钟)';
comment on column earnest_alert_config.level3_alert_time is '三级预警时间(分钟)';
comment on column earnest_alert_config.level3_user_group is '三级预警人员组';
comment on column earnest_alert_config.level3_send_email is '三级预警是否发送邮件';
comment on column earnest_alert_config.level3_no_alert_time is '三级预警不重复预警时间(分钟)';
comment on column earnest_alert_config.level4_alert_time is '四级预警时间(分钟)';
comment on column earnest_alert_config.level4_user_group is '四级预警人员组';
comment on column earnest_alert_config.level4_send_email is '四级预警是否发送邮件';
comment on column earnest_alert_config.level4_no_alert_time is '四级预警不重复预警时间(分钟)';
comment on column earnest_alert_config.level5_alert_time is '五级预警时间(分钟)';
comment on column earnest_alert_config.level5_user_group is '五级预警人员组';
comment on column earnest_alert_config.level5_send_email is '五级预警是否发送邮件';
comment on column earnest_alert_config.level5_no_alert_time is '五级预警不重复预警时间(分钟)';
comment on column earnest_alert_config.remark is '备注';
comment on column earnest_alert_config.create_user is '创建人';
comment on column earnest_alert_config.create_dept is '创建部门';
comment on column earnest_alert_config.create_time is '创建时间';
comment on column earnest_alert_config.update_user is '修改人';
comment on column earnest_alert_config.update_time is '修改时间';
comment on column earnest_alert_config.status is '状态';
comment on column earnest_alert_config.is_deleted is '是否已删除';

drop table if exists earnest_attachment;
create table earnest_attachment
(
    id            bigint not null primary key,
    tenant_id     varchar(12) default '000000',
    business_id   varchar(64)  not null,
    original_name varchar(100),
    name          varchar(255) not null,
    extension     varchar(50),
    file_usage    varchar(100),
    sort          int default 0 not null,
    create_user   bigint,
    create_dept   bigint,
    create_time   timestamp ,
	update_user   bigint,
	update_time   timestamp,
	status        int default 0 not null,
	is_deleted    int default 0,
	file_usage_name varchar(100)
);
create index "attachment_business_id"     on earnest_attachment (business_id);
create index "attachment_business_id_file_usage"     on earnest_attachment (tenant_id, business_id, file_usage);
create index "attachment_file_usage"     on earnest_attachment (tenant_id, file_usage);
create index "attachment_business_id_name"     on earnest_attachment (tenant_id, business_id, name);
comment on table earnest_attachment is '附件';
comment on column earnest_attachment.id is '主键';
comment on column earnest_attachment.tenant_id is '租户ID';
comment on column earnest_attachment.business_id is '业务id';
comment on column earnest_attachment.original_name is '原文件名';
comment on column earnest_attachment.name is '文件名';
comment on column earnest_attachment.extension is '附件文件类型';
comment on column earnest_attachment.file_usage is '附件用途';
comment on column earnest_attachment.sort is '排序';
comment on column earnest_attachment.create_user is '创建人';
comment on column earnest_attachment.create_dept is '创建部门';
comment on column earnest_attachment.create_time is '创建时间';
comment on column earnest_attachment.update_user is '修改人';
comment on column earnest_attachment.update_time is '修改时间';
comment on column earnest_attachment.status is '状态';
comment on column earnest_attachment.is_deleted is '是否已删除';
comment on column earnest_attachment.file_usage_name is '附件用途名称';

drop table if exists earnest_app_error;
create table earnest_app_error
(
    id bigint not null primary key,
    phone_model varchar(500),
    error_info  text,
    create_time timestamp
);
comment on table earnest_app_error is 'APP报错信息表';
comment on column earnest_app_error.phone_model is '手机型号';
comment on column earnest_app_error.error_info is '报错信息';
comment on column earnest_app_error.create_time is '时间';

drop table if exists earnest_mail_record;
create table earnest_mail_record
(
    id        bigint not null primary key,
    subject   varchar(500),
    content   text,
    recipient varchar(1000),
    ccs       varchar(1000),
    bccs      varchar(1000),
    send_time timestamp,
	tenant_id varchar(15)
);
comment on table earnest_mail_record is '邮件记录';
comment on column earnest_mail_record.id is 'id';
comment on column earnest_mail_record.subject is '主题';
comment on column earnest_mail_record.content is '内容';
comment on column earnest_mail_record.recipient is '收件人';
comment on column earnest_mail_record.ccs is '抄送人';
comment on column earnest_mail_record.bccs is '密送人';
comment on column earnest_mail_record.send_time is '发送时间';
comment on column earnest_mail_record.tenant_id is '租户';

drop table if exists earnest_task_people;
create table earnest_task_people
(
    id                bigint not null primary key,
    tenant_id         varchar(12) default '000000',
    business_category varchar(50) default '0' not null,
    task_code         varchar(100) not null,
    people            text not null,
    extend1           varchar(255),
    extend2           varchar(255),
    extend3           varchar(255),
    remark            varchar(255),
    create_user       bigint,
    create_dept       bigint,
    create_time       timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0
);
create index "task_people_task_code"     on earnest_task_people (tenant_id, task_code);
create index "task_people_business_category_task_code"     on earnest_task_people (tenant_id, business_category, task_code);
comment on table earnest_task_people is '任务人员表';
comment on column earnest_task_people.id is '主键';
comment on column earnest_task_people.tenant_id is '租户ID';
comment on column earnest_task_people.business_category is '业务类别';
comment on column earnest_task_people.task_code is '任务编号';
comment on column earnest_task_people.extend1 is '扩展字段1';
comment on column earnest_task_people.extend2 is '扩展字段2';
comment on column earnest_task_people.extend3 is '扩展字段3';
comment on column earnest_task_people.remark is '备注';
comment on column earnest_task_people.create_user is '创建人';
comment on column earnest_task_people.create_dept is '创建部门';
comment on column earnest_task_people.create_time is '创建时间';
comment on column earnest_task_people.update_user is '修改人';
comment on column earnest_task_people.update_time is '修改时间';
comment on column earnest_task_people.status is '状态';
comment on column earnest_task_people.is_deleted is '是否已删除';

drop table if exists earnest_task_setting;
create table earnest_task_setting
(
    id                bigint not null primary key,
    tenant_id         varchar(12) default '000000',
    business_category varchar(50) default '0' not null,
    task_id           varchar(100) not null,
    position_needed   tinyint not null,
    remark            varchar(255),
    create_user       bigint,
    create_dept       bigint,
    create_time       timestamp,
	update_user       bigint,
	update_time       timestamp,
	status            int default 0 not null,
	is_deleted        int default 0
);
create index "task_setting_task_id"     on earnest_task_setting(tenant_id, task_id);
create index "task_setting_business_category_task_id"     on earnest_task_setting(tenant_id, business_category, task_id);
comment on table earnest_task_setting is '任务设置表';
comment on column earnest_task_setting.id is '主键';
comment on column earnest_task_setting.tenant_id is '租户ID';
comment on column earnest_task_setting.business_category is '业务类别';
comment on column earnest_task_setting.task_id is '任务ID';
comment on column earnest_task_setting.position_needed is '是否需要定位';
comment on column earnest_task_setting.remark is '备注';
comment on column earnest_task_setting.create_user is '创建人';
comment on column earnest_task_setting.create_dept is '创建部门';
comment on column earnest_task_setting.create_time is '创建时间';
comment on column earnest_task_setting.update_user is '修改人';
comment on column earnest_task_setting.update_time is '修改时间';
comment on column earnest_task_setting.status is '状态';
comment on column earnest_task_setting.is_deleted is '是否已删除';

drop table if exists earnest_calendar;
create table earnest_calendar
(
    id          bigint not null primary key,
    is_deleted  int,
    status      tinyint,
    create_user bigint,
    create_time timestamp,
	create_dept bigint,
	update_user bigint,
	update_time timestamp,
	year int not null,
	month int not null,
	day int not null,
	week_day int,
	year_tips varchar(36),
	type tinyint not null,
	type_desc varchar(36),
	chinese_zodiac varchar(10),
	solar_terms varchar(10),
	lunar_calendar varchar(24),
	avoid varchar(255),
	suit varchar(255),
	day_of_year int,
	week_of_year int,
	constellation varchar(10),
	index_workday_of_month int,
	constraint "earnest_calendar_year_month_day_is_deleted_uindex" unique (year, month, day, is_deleted)
);

comment on table earnest_calendar is '日历表';
comment on column earnest_calendar.year is '年份';
comment on column earnest_calendar.month is '月份';
comment on column earnest_calendar.day is '日';
comment on column earnest_calendar.week_day is '当前周第几天 1-周一 2-周二 ... 7-周日';
comment on column earnest_calendar.year_tips is '天干地支纪年法描述 例如：戊戌';
comment on column earnest_calendar.type is '类型 0 工作日 1 假日 2 节假日';
comment on column earnest_calendar.type_desc is '类型描述 比如 国庆,休息日,工作日';
comment on column earnest_calendar.chinese_zodiac is '属相 例如：狗';
comment on column earnest_calendar.solar_terms is '节气描述 例如：小雪';
comment on column earnest_calendar.lunar_calendar is '农历日期';
comment on column earnest_calendar.avoid is '禁忌';
comment on column earnest_calendar.suit is '宜事项';
comment on column earnest_calendar.day_of_year is '这一年的第几天';
comment on column earnest_calendar.week_of_year is '这一年的第几周';
comment on column earnest_calendar.constellation is '星座';
comment on column earnest_calendar.index_workday_of_month is '如果当前是工作日 则返回是当前月的第几个工作日，否则返回0';

drop table if exists earnest_file_fake_page_info;
create table earnest_file_fake_page_info
(
    id          bigint not null primary key,
    tenant_id   varchar(12) default '000000',
    module      varchar(60),
    remark      varchar(255),
    create_user bigint,
    create_dept bigint,
    create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0
);
create index "file_fake_page_info_module"     on earnest_file_fake_page_info(tenant_id, module);
comment on table earnest_file_fake_page_info is '通用解析配置表';
comment on column earnest_file_fake_page_info.id is '主键';
comment on column earnest_file_fake_page_info.tenant_id is '租户ID';
comment on column earnest_file_fake_page_info.module is '模块名称';
comment on column earnest_file_fake_page_info.remark is '备注';
comment on column earnest_file_fake_page_info.create_user is '创建人';
comment on column earnest_file_fake_page_info.create_dept is '创建部门';
comment on column earnest_file_fake_page_info.create_time is '创建时间';
comment on column earnest_file_fake_page_info.update_user is '修改人';
comment on column earnest_file_fake_page_info.update_time is '修改时间';
comment on column earnest_file_fake_page_info.status is '状态';
comment on column earnest_file_fake_page_info.is_deleted is '是否已删除';

drop table if exists earnest_custom_form_business_map;
create table earnest_custom_form_business_map
(
    id                 bigint not null primary key,
    form_instance_id   varchar(36)  not null,
    form_instance_name varchar(200) not null,
    business_type      varchar(50)  not null,
    business_id        bigint not null,
    business_name      varchar(200) not null,
    create_user        bigint,
    create_dept        bigint,
    create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0 not null,
	tenant_id varchar(12) default '000000'
);
comment on table earnest_custom_form_business_map is '自定义表单与业务关联表';
comment on column earnest_custom_form_business_map.id is '主键';
comment on column earnest_custom_form_business_map.form_instance_id is '自定义表单实例id';
comment on column earnest_custom_form_business_map.form_instance_name is '自定义表单名称';
comment on column earnest_custom_form_business_map.business_type is '关联业务类型';
comment on column earnest_custom_form_business_map.business_id is '关联业务id';
comment on column earnest_custom_form_business_map.business_name is '关联业务名称';
comment on column earnest_custom_form_business_map.create_user is '创建人';
comment on column earnest_custom_form_business_map.create_dept is '创建部门';
comment on column earnest_custom_form_business_map.create_time is '创建时间';
comment on column earnest_custom_form_business_map.update_user is '修改人';
comment on column earnest_custom_form_business_map.update_time is '修改时间';
comment on column earnest_custom_form_business_map.status is '状态';
comment on column earnest_custom_form_business_map.is_deleted is '是否已删除';
comment on column earnest_custom_form_business_map.tenant_id is '租户ID';

drop table if exists earnest_done;
create table earnest_done
(
    id                bigint not null primary key,
    tenant_id         varchar(12) default '000000',
    user_id           bigint not null,
    business_category varchar(30) not null,
    task_name         varchar(50) not null,
    business_key      bigint not null,
    begin_time        timestamp,
	end_time timestamp,
	done_time timestamp not null,
	remark varchar(255),
	create_user bigint,
	create_dept bigint,
	create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int,
	is_deleted int default 0
);
create index "earnest_done_done_time" on earnest_done (user_id, done_time);
comment on table earnest_done is '办结事项';
comment on column earnest_done.id is '主键';
comment on column earnest_done.tenant_id is '租户ID';
comment on column earnest_done.user_id is '用户id';
comment on column earnest_done.business_category is '事务类型';
comment on column earnest_done.task_name is '任务名称';
comment on column earnest_done.business_key is '业务id';
comment on column earnest_done.begin_time is '开始时间';
comment on column earnest_done.end_time is '过期时间';
comment on column earnest_done.done_time is '完成时间';
comment on column earnest_done.remark is '备注';
comment on column earnest_done.create_user is '创建人';
comment on column earnest_done.create_dept is '创建部门';
comment on column earnest_done.create_time is '创建时间';
comment on column earnest_done.update_user is '修改人';
comment on column earnest_done.update_time is '修改时间';
comment on column earnest_done.status is '状态';
comment on column earnest_done.is_deleted is '是否已删除';

drop table if exists earnest_face;
create table earnest_face
(
    id           bigint not null primary key,
    tenant_id    varchar(12) default '000000',
    user_id      bigint,
    user_type    tinyint default 1 not null,
    face_feature blob not null,
    create_user  bigint,
    create_dept  bigint,
    create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0,
    constraint "earnest_face_user_id" unique (user_id, is_deleted)
);
comment on table earnest_face is '人脸表';
comment on column earnest_face.id is '主键';
comment on column earnest_face.tenant_id is '租户ID';
comment on column earnest_face.user_id is '用户id';
comment on column earnest_face.user_type is '用户类型：内置用户1, 承包商用户2';
comment on column earnest_face.face_feature is '人脸数据';
comment on column earnest_face.create_user is '创建人';
comment on column earnest_face.create_dept is '创建部门';
comment on column earnest_face.create_time is '创建时间';
comment on column earnest_face.update_user is '修改人';
comment on column earnest_face.update_time is '修改时间';
comment on column earnest_face.status is '状态';
comment on column earnest_face.is_deleted is '是否已删除';

drop table if exists earnest_field_config;
create table earnest_field_config
(
    id              bigint not null primary key,
    tenant_id       varchar(12) default '000000',
    form_table_name varchar(20) not null,
    scheme          text not null,
    remark          varchar(255),
    create_user     bigint,
    create_dept     bigint,
    create_time     timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0,
	constraint "field_config_form_table_name" unique (tenant_id, form_table_name, is_deleted)
);
comment on table earnest_field_config is '字段控制表';
comment on column earnest_field_config.id is '主键';
comment on column earnest_field_config.tenant_id is '租户ID';
comment on column earnest_field_config.form_table_name is '表单或列表的名称';
comment on column earnest_field_config.scheme is '显示的字段';
comment on column earnest_field_config.remark is '备注';
comment on column earnest_field_config.create_user is '创建人';
comment on column earnest_field_config.create_dept is '创建部门';
comment on column earnest_field_config.create_time is '创建时间';
comment on column earnest_field_config.update_user is '修改人';
comment on column earnest_field_config.update_time is '修改时间';
comment on column earnest_field_config.status is '状态';
comment on column earnest_field_config.is_deleted is '是否已删除';

drop table if exists earnest_shift;
create table earnest_shift
(
    id         bigint not null primary key,
    tenant_id  varchar(12) default '000000',
    code       varchar(50) default '0' not null,
    name       varchar(50) default '0' not null,
    user_id    bigint default 0 not null,
    work_time  int,
    shift_time timestamp default CURRENT_TIMESTAMP not null,
	built_in tinyint default 0 not null,
	record text,
	remark varchar(255),
	create_user bigint,
	create_dept bigint,
	create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0,
	constraint "shift_code" unique (tenant_id, code, is_deleted)
);
comment on table earnest_shift is '交接班';
comment on column earnest_shift.id is '主键';
comment on column earnest_shift.tenant_id is '租户ID';
comment on column earnest_shift.code is '编码';
comment on column earnest_shift.name is '名称';
comment on column earnest_shift.user_id is '用户ID';
comment on column earnest_shift.work_time is '最长工作时间';
comment on column earnest_shift.shift_time is '最近交接时间';
comment on column earnest_shift.built_in is '是否内置';
comment on column earnest_shift.record is '工作记录';
comment on column earnest_shift.remark is '备注';
comment on column earnest_shift.create_user is '创建人';
comment on column earnest_shift.create_dept is '创建部门';
comment on column earnest_shift.create_time is '创建时间';
comment on column earnest_shift.update_user is '修改人';
comment on column earnest_shift.update_time is '修改时间';
comment on column earnest_shift.status is '状态';
comment on column earnest_shift.is_deleted is '是否已删除';

drop table if exists earnest_shift_log;
create table earnest_shift_log
(
    id          bigint not null primary key,
    tenant_id   varchar(12) default '000000',
    code        varchar(50) default '0' not null,
    name        varchar(50) default '0' not null,
    old_user_id bigint default 0,
    new_user_id bigint default 0,
    record      text,
    remark      varchar(255),
    create_user bigint,
    create_dept bigint,
    create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int default 0 not null,
	is_deleted int default 0
);
create index "earnest_shift_log_code" on earnest_shift_log (tenant_id, code);
comment on table earnest_shift_log is '交接班日志';
comment on column earnest_shift_log.id is '主键';
comment on column earnest_shift_log.tenant_id is '租户ID';
comment on column earnest_shift_log.code is '编码';
comment on column earnest_shift_log.name is '名称';
comment on column earnest_shift_log.old_user_id is '上一个用户ID';
comment on column earnest_shift_log.new_user_id is '当前用户ID';
comment on column earnest_shift_log.record is '工作记录';
comment on column earnest_shift_log.remark is '备注';
comment on column earnest_shift_log.create_user is '创建人';
comment on column earnest_shift_log.create_dept is '创建部门';
comment on column earnest_shift_log.create_time is '创建时间';
comment on column earnest_shift_log.update_user is '修改人';
comment on column earnest_shift_log.update_time is '修改时间';
comment on column earnest_shift_log.status is '状态';
comment on column earnest_shift_log.is_deleted is '是否已删除';

drop table if exists earnest_software_version;
create table earnest_software_version
(
    id                    bigint not null primary key,
    major_version_number  int default 0 not null,
    minor_version_number  int default 0 not null,
    revision_number       int default 0 not null,
    build_number          int default 0 not null,
    software_download_url varchar(255) not null,
    update_content        text,
    publish_datetime      timestamp not null,
	type varchar(20) not null,
	force_update tinyint default 1
);
comment on table earnest_software_version is '软件版本信息';
comment on column earnest_software_version.id is '主键';
comment on column earnest_software_version.major_version_number is '主版本号';
comment on column earnest_software_version.minor_version_number is '子版本号';
comment on column earnest_software_version.revision_number is '修正版本号';
comment on column earnest_software_version.build_number is '编译版本号';
comment on column earnest_software_version.software_download_url is '软件下载地址';
comment on column earnest_software_version.update_content is '更新内容';
comment on column earnest_software_version.publish_datetime is '发布时间';
comment on column earnest_software_version.type is '类型';
comment on column earnest_software_version.force_update is '是否强制更新';

drop table if exists earnest_todo;
create table earnest_todo
(
    id                bigint not null primary key,
    tenant_id         varchar(12) default '000000',
    users             varchar(1000),
    user_id           bigint,
    business_category varchar(30)  not null,
    task_name         varchar(200) not null,
    business_key      bigint not null,
    begin_time        timestamp,
	end_time timestamp,
	remark varchar(255),
	create_user bigint,
	create_dept bigint,
	create_time timestamp,
	update_user bigint,
	update_time timestamp,
	status int,
	is_deleted int default 0
);
create index "todo_user_id" on earnest_todo (is_deleted, user_id, begin_time);
create index "todo_users" on earnest_todo (is_deleted, users);
comment on table earnest_todo is '待办事项';
comment on column earnest_todo.id is '主键';
comment on column earnest_todo.tenant_id is '租户ID';
comment on column earnest_todo.users is '候选用户或组';
comment on column earnest_todo.user_id is '用户id';
comment on column earnest_todo.business_category is '事务类型';
comment on column earnest_todo.task_name is '任务名称';
comment on column earnest_todo.business_key is '业务id';
comment on column earnest_todo.begin_time is '开始时间';
comment on column earnest_todo.end_time is '过期时间';
comment on column earnest_todo.remark is '备注';
comment on column earnest_todo.create_user is '创建人';
comment on column earnest_todo.create_dept is '创建部门';
comment on column earnest_todo.create_time is '创建时间';
comment on column earnest_todo.update_user is '修改人';
comment on column earnest_todo.update_time is '修改时间';
comment on column earnest_todo.status is '状态';
comment on column earnest_todo.is_deleted is '是否已删除';

drop table if exists earnest_totp;
create table earnest_totp
(
    id       bigint not null primary key,
    user_id  bigint unique,
    totp_key varchar(255) not null
);
create index "totp_user_id" on earnest_totp (user_id);
comment on table earnest_totp is 'totp表';
comment on column earnest_totp.id is '主键';
comment on column earnest_totp.user_id is '用户id';
comment on column earnest_totp.totp_key is 'totp密钥';

-- 自定义参数表

CREATE TABLE earnest_custom_parameter
(
    id               int8 NOT NULL,
    tenant_id        varchar(12) COLLATE pg_catalog.default,
    create_user      int8,
    create_dept      int8,
    create_time      timestamp(6),
    update_user      int8,
    update_time      timestamp(6),
    status           int4,
    is_deleted       int4,
    module_name      varchar(255) COLLATE pg_catalog.default,
    module_code      varchar(64) COLLATE pg_catalog.default,
    parameter_name   varchar(255) COLLATE pg_catalog.default,
    parameter_key    varchar(64) COLLATE pg_catalog.default,
    parameter_type   varchar(64) COLLATE pg_catalog.default,
    parameter_values varchar(255) COLLATE pg_catalog.default
)
;
COMMENT ON COLUMN earnest_custom_parameter.id IS 'id';
COMMENT ON COLUMN earnest_custom_parameter.tenant_id IS '租户id';
COMMENT ON COLUMN earnest_custom_parameter.create_user IS '创建人';
COMMENT ON COLUMN earnest_custom_parameter.create_dept IS '创建部门';
COMMENT ON COLUMN earnest_custom_parameter.create_time IS '创建时间';
COMMENT ON COLUMN earnest_custom_parameter.update_user IS '修改人';
COMMENT ON COLUMN earnest_custom_parameter.update_time IS '修改时间';
COMMENT ON COLUMN earnest_custom_parameter.status IS '业务状态';
COMMENT ON COLUMN earnest_custom_parameter.is_deleted IS '是否已删除';
COMMENT ON COLUMN earnest_custom_parameter.module_name IS '模块名称';
COMMENT ON COLUMN earnest_custom_parameter.module_code IS '模块编码';
COMMENT ON COLUMN earnest_custom_parameter.parameter_name IS '参数名称';
COMMENT ON COLUMN earnest_custom_parameter.parameter_key IS '参数key';
COMMENT ON COLUMN earnest_custom_parameter.parameter_type IS '参数类型';
COMMENT ON COLUMN earnest_custom_parameter.parameter_values IS '参数值';
COMMENT ON TABLE earnest_custom_parameter IS '自定义参数表';

ALTER TABLE earnest_custom_parameter ADD CONSTRAINT modeCode_key_tenant UNIQUE (module_code, parameter_key, tenant_id, is_deleted);
COMMENT ON CONSTRAINT modeCode_key_tenant ON earnest_custom_parameter IS '同一租户下的模块下的key唯一。增加is_deleted';

ALTER TABLE earnest_custom_parameter ADD CONSTRAINT earnest_custom_parameter_table_pkey PRIMARY KEY (id);



