package cnooc.qhse.base.controller

import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.constant.RoleConstant
import org.springframework.data.redis.connection.DefaultStringRedisConnection
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.data.redis.serializer.RedisSerializer
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/assistant")
@Tag(name = "辅助", description = "运维辅助接口")
class AssistantController(
    private val redisTemplate: RedisTemplate<String, String>
) {

    @GetMapping("/ping")
    fun ping(): R<String> {
        return R.data("pong")
    }

    @PostMapping("/flush-redis")
    @PreAuth(RoleConstant.HAS_ROLE_ADMINISTRATOR)
    fun flushRedis(): R<Boolean> {
        val redisConnection = this.redisTemplate.connectionFactory?.connection ?: return R.status(false)
        val redisSerializer = this.redisTemplate.keySerializer as RedisSerializer<String>
        val defaultStringRedisConnection = DefaultStringRedisConnection(redisConnection, redisSerializer)
        defaultStringRedisConnection.flushAll()
        return R.status(true)
    }
}
