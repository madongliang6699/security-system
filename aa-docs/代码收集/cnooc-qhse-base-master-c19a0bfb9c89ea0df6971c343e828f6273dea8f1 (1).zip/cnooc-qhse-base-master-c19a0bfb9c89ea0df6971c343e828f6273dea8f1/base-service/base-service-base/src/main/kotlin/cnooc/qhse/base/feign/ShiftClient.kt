package cnooc.qhse.base.feign

import cnooc.qhse.base.service.IShiftService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class ShiftClient(private val shiftService: IShiftService): IShiftClient {
    override fun getNameByCode(code: String, tenantId: String): R<String?> {
        return R.data(shiftService.getNameByCode(code, tenantId))
    }

    override fun getUserIdByCode(code: String, tenantId: String): R<Long?> {
        return R.data(shiftService.getUserIdByShiftCode(code, tenantId))
    }

    override fun getShiftCodesByUserId(userId: Long): R<List<String>> {
        return R.data(shiftService.getShiftCodeByUserId(userId))
    }
}
