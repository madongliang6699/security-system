package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.FieldConfig
import cnooc.qhse.base.pojo.vo.FieldConfigVO
import cnooc.qhse.base.service.IFieldConfigService
import cnooc.qhse.base.wrapper.FieldConfigWrapper
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class FieldConfigClient (private val fieldConfigService: IFieldConfigService): IFieldConfigClient {
    override fun getAllFieldConfigs(tenantId: String): R<List<FieldConfigVO>> {
        return R.data(FieldConfigWrapper.build().listVO(fieldConfigService.list(
            KtQueryWrapper(FieldConfig::class.java).eq(FieldConfig::tenantId, tenantId)
        )))
    }
}
