package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.base.pojo.vo.AlertConfigVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil

/**
 * 报警配置表包装类,返回视图层所需的字段
 */
class AlertConfigWrapper : BaseEntityWrapper<AlertConfig, AlertConfigVO>() {
    companion object {
        fun build() : AlertConfigWrapper {
            return AlertConfigWrapper()
        }
    }

	override fun entityVO(entity: AlertConfig) : AlertConfigVO {
		val vo = BeanUtil.copy(entity, AlertConfigVO::class.java)!!
		return vo
	}

}
