package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.base.service.IAreaService
import cnooc.qhse.base.wrapper.AreaWrapper
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.github.oshai.kotlinlogging.KotlinLogging
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.Parameters
import io.swagger.v3.oas.annotations.tags.Tag
import jakarta.servlet.http.HttpServletRequest
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.constant.CacheConstant
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.mp.support.Condition
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile
import org.springframework.web.multipart.MultipartHttpServletRequest
import springfox.documentation.annotations.ApiIgnore
import javax.validation.Valid

private val logger = KotlinLogging.logger {}

@RestController
@RequestMapping("/area")
@Tag(name = "区域", description = "区域")
class AreaController @Autowired constructor(private val areaService: IAreaService) : BladeController() {
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    fun detail(area: AreaEntity): R<AreaVO> {
        val detail = areaService.getOne(Condition.getQueryWrapper(area))
        detail ?: throw ServiceException("无此区域")
        return R.data(AreaWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @Parameters(
        Parameter(name = "areaName", description = "部门名称"),
        Parameter(name = "userId", description = "责任人"),
        Parameter(name = "deptId", description = "责任部门"),
    )
    @ApiOperationSupport(order = 2)
    @Operation(summary = "列表", description = "列表")
    fun list(@ApiIgnore @RequestParam area: Map<String, Any>): R<List<AreaVO>> {
        val queryWrapper = Condition.getQueryWrapper(area, AreaEntity::class.java)
        val list = areaService.list(queryWrapper)
        val result = AreaWrapper.build().listNodeVO(list)
        return R.data(result)
    }

    /**
     * 获取区域树形结构
     */
    @GetMapping("/tree")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "树形结构", description = "树形结构")
    fun tree(): R<List<AreaVO>> {
        val tree = AreaCache.getAreaTree(AuthUtil.getTenantId())
        return R.data(tree)
    }


    // @fixme
//    /**
//     * 获取区域树形结构
//     */
//    @GetMapping("/secondary-unit/tree")
//    @ApiOperationSupport(order = 3)
//    @Operation(summary = "二级单位获取树形结构", description = "二级单位获取树形结构")
//    @TenantIgnore
//    @SubTenantSupport
//    fun secondaryUnitTree(@SubTenantVerification tenantId:String): R<List<AreaVO>> {
//        val tree = AreaCache.getAreaTree(tenantId)
//        return R.data(tree)
//    }
//
    @PostMapping("/submit")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增或修改", description = "新增或修改")
    @PreAuth("hasPermission('earnest:area:edit')")
    fun submit(@RequestBody @Valid area: AreaEntity): R<Boolean> {
        CacheUtil.clear(AreaCache.AREA_CACHE)
        CacheUtil.clear(CacheConstant.USER_CACHE)
        return R.status(areaService.submitArea(area))
    }

    @PostMapping("/update-coordinates")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "更新区域坐标信息", description = "更新区域坐标信息")
    @PreAuth("hasPermission('earnest:area:edit')")
    fun updateCoordinates(@RequestBody coordinatesVO: AreaEntity): R<Boolean> {
        require(coordinatesVO.id != null) { "id不能为空" }
        require(!coordinatesVO.areaCoordinates.isNullOrBlank()) { "区域坐标不能为空" }
        areaService.updateById(AreaEntity(id = coordinatesVO.id, areaCoordinates = coordinatesVO.areaCoordinates))
        CacheUtil.clear(AreaCache.AREA_CACHE)
        CacheUtil.clear(CacheConstant.USER_CACHE)
        return R.status(true)
    }

    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasPermission('earnest:area:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        CacheUtil.clear(AreaCache.AREA_CACHE)
        CacheUtil.clear(CacheConstant.USER_CACHE)
        return R.status(areaService.removeArea(Func.toLongList(ids)))
    }

    @PostMapping("/remove-all")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除全部区域")
    @PreAuth("hasPermission('earnest:area:delete')")
    fun removeAll(): R<Boolean> {
        CacheUtil.clear(AreaCache.AREA_CACHE)
        CacheUtil.clear(CacheConstant.USER_CACHE)
        return R.status(
            areaService.remove(
                KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::tenantId, AuthUtil.getTenantId())
            )
        )
    }

    // @fixme
//    @GetMapping(value = ["/export"])
//    @Operation(summary = "导出现场区域", description = "导出现场区域")
//    @PreAuth("hasPermission('earnest:area:export')")
//    fun exportXls(
//        map: ModelMap, @RequestParam area: Map<String, Any>?, bladeUser: BladeUser, request: HttpServletRequest?,
//        response: HttpServletResponse?
//    ) {
//        val queryWrapper = Condition.getQueryWrapper(area, AreaEntity::class.java)
//        queryWrapper.orderByAsc(AreaEntity::areaCode.toColumn())
//        val list = areaService.list(queryWrapper)
//        val params = ExportParams("现场区域表", "导出数据", ExcelType.XSSF)
//        //		params.setAddIndex(true);
//        params.isFixedTitle = true
//        params.dataHandler = AreaDataHandler()
//        map[NormalExcelConstants.DATA_LIST] = list
//        map[NormalExcelConstants.CLASS] = AreaEntity::class.java
//        map[NormalExcelConstants.PARAMS] = params
//        PoiBaseView.render(map, request, response, NormalExcelConstants.EASYPOI_EXCEL_VIEW)
//    }

    @RequestMapping(value = ["/import"], method = [RequestMethod.POST])
    @Operation(summary = "导入现场区域", description = "导入现场区域")
    @PreAuth("hasPermission('earnest:area:import')")
    fun importExcel(request: HttpServletRequest): R<Boolean> {
        CacheUtil.clear(AreaCache.AREA_CACHE)
        CacheUtil.clear(CacheConstant.USER_CACHE)
        val multipartRequest = request as MultipartHttpServletRequest
        val fileMap: Map<String, MultipartFile> = multipartRequest.fileMap
        for ((_, value) in fileMap) {
            return try {
                val count: Int = areaService.importExcel(value)
                R.success("文件导入成功！数据行数：$count")
            } catch (e: Exception) {
                logger.error(e) { "区域文件导入失败！" }
                R.fail("文件导入失败:" + e.message)
            }
        }
        return R.fail("文件导入失败！")
    }
}
