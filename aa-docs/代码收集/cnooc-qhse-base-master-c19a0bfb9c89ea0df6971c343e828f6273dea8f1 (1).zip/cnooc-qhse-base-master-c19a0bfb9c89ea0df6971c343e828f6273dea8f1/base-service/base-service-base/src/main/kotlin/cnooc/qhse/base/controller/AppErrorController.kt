package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.entity.AppError
import cnooc.qhse.base.service.IAppErrorService
import cnooc.qhse.common.annotation.OpenInterfaceVerification
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.tenant.annotation.TenantIgnore
import org.springblade.core.tool.api.R
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*


/**
 * APP报错信息表 控制器
 *
 * @author Hugh Gao
 * @since 2024-05-24
 */
@RestController
@RequestMapping("/app-error")
@Tag(name = "APP报错信息表", description = "APP报错信息表接口")
class AppErrorController @Autowired constructor(private val appErrorService: IAppErrorService) : BladeController() {

    @TenantIgnore
    @PostMapping("/save")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "新增", description = "新增")
    @OpenInterfaceVerification(value = 5)
    fun save(@Validated @RequestBody appError: AppError): R<Boolean> {
        return R.status(appErrorService.save(appError))
    }

}
