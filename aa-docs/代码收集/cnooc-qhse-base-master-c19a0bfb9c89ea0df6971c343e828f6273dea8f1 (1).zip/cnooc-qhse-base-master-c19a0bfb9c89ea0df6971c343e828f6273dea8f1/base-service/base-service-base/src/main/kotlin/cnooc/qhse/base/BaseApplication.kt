package cnooc.qhse.base

import org.springblade.core.cloud.client.BladeCloudApplication
import org.springblade.core.launch.BladeApplication

/**
 * 启动器
 */
@BladeCloudApplication
class BaseApplication
fun main(args: Array<String>) {
    BladeApplication.run("cnooc-qhse-base", BaseApplication::class.java, *args)
}
