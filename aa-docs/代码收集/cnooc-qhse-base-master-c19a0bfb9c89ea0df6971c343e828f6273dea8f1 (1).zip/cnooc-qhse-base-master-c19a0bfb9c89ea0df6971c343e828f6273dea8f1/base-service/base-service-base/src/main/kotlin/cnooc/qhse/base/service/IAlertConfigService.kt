package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.common.service.BaseServiceKt

/**
 * 报警配置表 服务类
 */
interface IAlertConfigService : BaseServiceKt<AlertConfig>
