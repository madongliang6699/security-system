package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.CalendarPO
import com.baomidou.mybatisplus.core.mapper.BaseMapper
import org.apache.ibatis.annotations.Mapper

@Mapper
interface CalendarMapper : BaseMapper<CalendarPO>
