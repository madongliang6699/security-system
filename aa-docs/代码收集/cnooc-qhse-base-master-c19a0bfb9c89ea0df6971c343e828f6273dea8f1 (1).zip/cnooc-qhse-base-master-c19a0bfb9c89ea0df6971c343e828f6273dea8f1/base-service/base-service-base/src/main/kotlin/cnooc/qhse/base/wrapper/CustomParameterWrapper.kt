package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import cnooc.qhse.base.pojo.vo.CustomParameterVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil

/**
 * 自定义参数表包装类,返回视图层所需的字段
 */
class CustomParameterWrapper : BaseEntityWrapper<CustomParameterEntity, CustomParameterVO>() {
    companion object {
        fun build() : CustomParameterWrapper {
            return CustomParameterWrapper()
        }
    }

	override fun entityVO(entity: CustomParameterEntity) : CustomParameterVO {
		val vo = BeanUtil.copy(entity, CustomParameterVO::class.java)!!
		return vo
	}

}
