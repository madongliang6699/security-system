package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.CalendarCache
import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.base.pojo.vo.CalendarVO
import cnooc.qhse.base.service.ICalendarService
import cnooc.qhse.base.wrapper.CalendarWrapper
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile

@Tag(name = "日历API", description = "日历")
@RestController
@RequestMapping("/calendar")
class CalendarController @Autowired constructor(private val calendarService: ICalendarService) : BladeController() {

    @Operation(summary = "导入", description = "导入")
    @ApiOperationSupport(order = 1)
    @PostMapping("/import")
    fun import(file: MultipartFile): R<Boolean> {
        val result = calendarService.import(file)
        CacheUtil.clear(CalendarCache.CALENDAR_CACHE)
        return R.data(result)
    }

    @Operation(summary = "列表", description = "列表")
    @ApiOperationSupport(order = 2)
    @GetMapping("/list")
    fun list(@RequestParam params: Map<String, Any>, query: Query): R<IPage<CalendarVO>> {

        val qw = Condition.getQueryWrapper(params, CalendarPO::class.java)
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByAsc(CalendarPO::year.toColumn(), CalendarPO::month.toColumn(), CalendarPO::day.toColumn())
        }

        val pages = calendarService.page(Condition.getPage(query), qw)
        return R.data(CalendarWrapper.build().pageVO(pages))
    }

    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @ApiOperationSupport(order = 3)
    @PostMapping("/remove")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        val result = calendarService.deleteLogic(Func.toLongList(ids))
        if (result) {
            CacheUtil.clear(CalendarCache.CALENDAR_CACHE)
        }
        return R.status(result)
    }

    @Operation(summary = "是否符合作业许可提级条件", description = "是否符合作业许可提级条件")
    @ApiOperationSupport(order = 4)
    @GetMapping("/upgradeCondition")
    fun upgradeCondition(): R<Boolean> {
        return R.data(calendarService.upgradeCondition())
    }
}
