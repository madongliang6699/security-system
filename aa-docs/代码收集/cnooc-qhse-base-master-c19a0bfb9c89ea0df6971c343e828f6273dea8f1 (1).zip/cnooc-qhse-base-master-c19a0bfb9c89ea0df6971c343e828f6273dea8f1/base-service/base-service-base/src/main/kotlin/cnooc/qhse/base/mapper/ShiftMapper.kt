package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.Shift
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 交接班 Mapper 接口
 */
interface ShiftMapper : BaseMapper<Shift>
