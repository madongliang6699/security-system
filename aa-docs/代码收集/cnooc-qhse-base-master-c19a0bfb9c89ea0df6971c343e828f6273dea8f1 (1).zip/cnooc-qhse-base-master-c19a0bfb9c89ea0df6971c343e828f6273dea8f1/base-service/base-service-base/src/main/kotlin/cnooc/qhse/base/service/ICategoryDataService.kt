package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.common.service.BaseServiceKt
import org.springframework.web.multipart.MultipartFile

/**
 * 数据分类服务
 */
interface ICategoryDataService : BaseServiceKt<CategoryData> {
    /**
     * 根据分类编码获取分类
     * @param code 分类编码
     * @param tenantId 租户ID
     */
    fun getByCode(code: String, tenantId: String): CategoryData?

    /**
     * 通过父级编码及子类名称子级
     * @param ancestorCode 父级编码
     * @param name 子类名称
     */
    fun getByName(ancestorCode: String, name: String, tenantId: String): CategoryData?

    /**
     * 获取分类名称（全路径）
     * @param code 分类编码
     * @param tenantId 租户ID
     */
    fun getCategoryPathName(code: String, tenantId: String): String?

    /**
     * 获取分类名称（全路径）
     * @param id 分类id
     */
    fun getCategoryPathName(id: Long): String?

    /**
     * 获取指定分类下的所有分类
     * @param rootCode 顶级分类的编码
     */
    fun getCategoryList(rootCode: String, tenantId: String): List<CategoryData>

    /**
     * 全部树形结构
     * @return 树形结构
     */
    fun tree(tenantId: String): List<CategoryDataVO>

    /**
     * 树形结构
     *
     * @param rootCode 根分类编码
     * @return 分类树
     */
    fun singleTree(rootCode: String, tenantId: String): List<CategoryDataVO>

    /**
     * 删除分类及其子分类
     *
     * @param ids 分类id
     * @return 是否删除成功
     */
    fun removeCategories(ids: List<Long>): Boolean

    /**
     * 提交
     *
     * @param category 分类
     * @return 是否添加或更新成功
     */
    fun submit(category: CategoryData): Boolean
    fun importExcel(file: MultipartFile): Int
    fun getByName(name: String, tenantId: String): List<CategoryData>
}
