package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.dto.MailInfo

/**
 * 发送邮件
 */
interface IMailService {

    fun sendSimpleMail(mailInfo: MailInfo): Boolean

    fun sendHtmlMail(mailInfo: MailInfo): Boolean
}
