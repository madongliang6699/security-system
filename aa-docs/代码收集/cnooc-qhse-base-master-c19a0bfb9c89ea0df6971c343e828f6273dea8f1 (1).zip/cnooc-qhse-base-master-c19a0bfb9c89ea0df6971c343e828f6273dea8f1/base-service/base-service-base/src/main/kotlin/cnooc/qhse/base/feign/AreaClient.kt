package cnooc.qhse.base.feign

import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.base.service.IAreaService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springblade.core.tool.constant.BladeConstant
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class AreaClient (private val areaService: IAreaService) : IAreaClient {
    override fun getAreaById(id: Long): R<AreaEntity?> {
        return R.data(areaService.getById(id))
    }

    override fun getAreaByCode(code: String, tenantId: String): R<AreaEntity?> {
        return R.data(areaService.getAreaByCode(code, tenantId))
    }

    override fun getAreaPathNameById(id: Long): R<String> {
        val areaNames = mutableListOf<String>()
        var area: AreaEntity?
        var tempId = id
        do {
            area = AreaCache.getArea(tempId)
            if (area == null) {
                break
            }
            areaNames.add(area.areaName!!)
            tempId = area.parentId!!
        } while (tempId == BladeConstant.TOP_PARENT_ID)
        areaNames.reverse()

        return R.data(areaNames.joinToString("/"))
    }

    override fun getLastLevelAreas(tenantId: String): R<List<AreaVO>> {
        return R.data(areaService.getLastLevelAreas(tenantId))
    }

    override fun getAreasByCodeOrName(
        areaCodeOrName: String,
        tenantId: String
    ): R<List<AreaEntity>> {
        return R.data(areaService.getAreasByCodeOrName(areaCodeOrName, tenantId))
    }

    override fun getAreasByParentId(parentId: Long): R<List<AreaEntity>> {
        return R.data(areaService.getAreasByParentId(parentId))
    }

    override fun tree(tenantId: String): R<List<AreaVO>> {
        return R.data(areaService.tree(tenantId))
    }

    override fun getUserIdsByAreaId(id: Long): R<List<Long>> {
        return R.data(areaService.getUserIdsByAreaId(id))
    }

    override fun getUserIdsByAreaCode(code: String, tenantId: String): R<List<Long>> {
        return R.data(areaService.getUserIdsByAreaCode(code, tenantId))
    }

    override fun getAreasByUserId(userId: Long): R<List<AreaEntity>> {
        return R.data(areaService.getAreasByUserId(userId))
    }
}
