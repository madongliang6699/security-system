package cnooc.qhse.base.cache

import cnooc.qhse.base.pojo.entity.SoftwareVersion
import cnooc.qhse.base.service.ISoftwareVersionService
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import kotlin.jvm.java

/**
 * 软件版本缓存
 */
object SoftwareVersionCache {
    const val SOFTWARE_VERSION_CACHE = "software_version:"
    private const val ANDROID_VERSION = "android:"

    private val softwareVersionService = SpringUtil.getBean(ISoftwareVersionService::class.java)

    val androidLatestVersion: SoftwareVersion?
        get() = CacheUtil.get(SOFTWARE_VERSION_CACHE, ANDROID_VERSION, ANDROID_VERSION,
            { softwareVersionService.androidLatestVersion }, false
        )
}
