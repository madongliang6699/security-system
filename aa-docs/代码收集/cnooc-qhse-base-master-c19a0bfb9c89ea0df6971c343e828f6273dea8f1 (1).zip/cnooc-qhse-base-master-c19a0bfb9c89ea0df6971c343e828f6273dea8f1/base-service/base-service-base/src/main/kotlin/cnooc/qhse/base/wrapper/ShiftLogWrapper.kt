package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.ShiftLog
import cnooc.qhse.base.pojo.vo.ShiftLogVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.system.cache.UserCache
import java.util.*

/**
 * 交接班日志包装类,返回视图层所需的字段
 */
class ShiftLogWrapper : BaseEntityWrapper<ShiftLog, ShiftLogVO>() {
    override fun entityVO(shiftLog: ShiftLog): ShiftLogVO {
        val shiftLogVO: ShiftLogVO = Objects.requireNonNull(BeanUtil.copy(shiftLog, ShiftLogVO::class.java))!!
        UserCache.getUser(shiftLogVO.oldUserId)?.let {
            shiftLogVO.oldUserName = it.realName
        }
        UserCache.getUser(shiftLogVO.newUserId)?.let {
            shiftLogVO.newUserName = it.realName
        }
        return shiftLogVO
    }

    companion object {
        fun build(): ShiftLogWrapper {
            return ShiftLogWrapper()
        }
    }
}
