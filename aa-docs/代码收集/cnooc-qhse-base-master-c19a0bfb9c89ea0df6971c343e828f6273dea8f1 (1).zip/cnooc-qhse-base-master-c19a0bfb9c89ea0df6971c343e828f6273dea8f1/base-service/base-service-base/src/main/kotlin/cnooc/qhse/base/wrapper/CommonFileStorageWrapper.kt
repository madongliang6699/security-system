package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.FileFakePageInfo
import cnooc.qhse.base.pojo.vo.FileFakePageInfoVO
import cnooc.qhse.base.service.IAttachmentService
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.core.tool.utils.SpringUtil

class CommonFileStorageWrapper : BaseEntityWrapper<FileFakePageInfo, FileFakePageInfoVO>() {
    override fun entityVO(commonFile: FileFakePageInfo): FileFakePageInfoVO{
        val vo = BeanUtil.copy(commonFile, FileFakePageInfoVO::class.java)!!
        val fileList = SpringUtil.getBean(IAttachmentService::class.java).getAttachments(commonFile.id.toString())
        vo.commonFiles = fileList
        return vo
    }

    companion object {
        fun build(): CommonFileStorageWrapper {
            return CommonFileStorageWrapper()
        }
    }
}
