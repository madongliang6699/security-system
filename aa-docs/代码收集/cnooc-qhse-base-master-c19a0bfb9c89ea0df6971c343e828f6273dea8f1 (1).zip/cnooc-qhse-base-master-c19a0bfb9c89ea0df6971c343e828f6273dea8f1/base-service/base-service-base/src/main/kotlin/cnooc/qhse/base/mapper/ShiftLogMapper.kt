package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.ShiftLog
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 交接班日志 Mapper 接口
 */
interface ShiftLogMapper : BaseMapper<ShiftLog>
