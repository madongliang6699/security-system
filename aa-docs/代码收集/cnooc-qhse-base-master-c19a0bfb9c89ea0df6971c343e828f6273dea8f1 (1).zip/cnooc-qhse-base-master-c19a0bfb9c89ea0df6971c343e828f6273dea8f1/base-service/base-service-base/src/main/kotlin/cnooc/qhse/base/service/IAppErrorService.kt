package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.AppError
import com.baomidou.mybatisplus.extension.service.IService

/**
 * app报错信息
 */
interface IAppErrorService: IService<AppError> {

}
