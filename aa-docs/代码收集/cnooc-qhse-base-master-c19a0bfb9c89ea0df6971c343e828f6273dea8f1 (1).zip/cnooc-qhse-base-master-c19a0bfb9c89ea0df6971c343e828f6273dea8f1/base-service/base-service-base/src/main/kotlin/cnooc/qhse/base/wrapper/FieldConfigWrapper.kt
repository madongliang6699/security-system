package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.FieldConfig
import cnooc.qhse.base.pojo.vo.FieldConfigVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil

/**
 * 字段控制表包装类,返回视图层所需的字段
 */
class FieldConfigWrapper : BaseEntityWrapper<FieldConfig, FieldConfigVO>() {
    companion object {
        fun build() : FieldConfigWrapper {
            return FieldConfigWrapper()
        }
    }

	override fun entityVO(entity: FieldConfig) : FieldConfigVO {
		val vo = BeanUtil.copy(entity, FieldConfigVO::class.java)!!
		return vo
	}

}
