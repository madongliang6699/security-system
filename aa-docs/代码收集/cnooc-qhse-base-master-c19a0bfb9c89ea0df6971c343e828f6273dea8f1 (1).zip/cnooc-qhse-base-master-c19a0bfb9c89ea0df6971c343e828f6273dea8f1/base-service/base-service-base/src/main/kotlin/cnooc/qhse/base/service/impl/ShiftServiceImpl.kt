package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.ShiftMapper
import cnooc.qhse.base.pojo.entity.Shift
import cnooc.qhse.base.pojo.entity.ShiftLog
import cnooc.qhse.base.service.IShiftLogService
import cnooc.qhse.base.service.IShiftService
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.secure.utils.AuthUtil
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDateTime

/**
 * 交接班 服务实现类
 */
@Service
class ShiftServiceImpl(private val shiftLogService: IShiftLogService) : BaseServiceImplKt<ShiftMapper, Shift>(),
    IShiftService {
    @Transactional
    override fun acceptShift(id: Long) {
        val oldShift = getById(id) ?: throw ServiceException("交接班岗位不存在")
        val userId: Long = AuthUtil.getUserId()
        if (userId == oldShift.userId) {
            throw ServiceException("相同人员不能接班")
        }
        setUserId(oldShift, userId)
    }

    private fun setUserId(oldShift: Shift, userId: Long) {
        val shiftLog = ShiftLog(
            code = oldShift.code,
            name = oldShift.name,
            oldUserId = oldShift.userId,
            newUserId = userId,
            record = oldShift.record
        )
        shiftLogService.save(shiftLog)
        val shift1 = Shift(id = oldShift.id, userId = userId, record = oldShift.record, shiftTime = LocalDateTime.now())
        updateById(shift1)
    }

    @Transactional
    override fun giveShift(id: Long, userId: Long) {
        val oldShift = getById(id) ?: throw ServiceException("交接班岗位不存在")
        if (AuthUtil.getUserId() != oldShift.userId) {
            throw ServiceException("不是您的班，不能交接")
        }
        if (userId == oldShift.userId) {
            throw ServiceException("相同人员不能交接班")
        }
        setUserId(oldShift, userId)
    }

    override fun saveRecord(id: Long, record: String): Boolean {
        val oldShift = getById(id) ?: throw ServiceException("交接班岗位不存在")
        if (oldShift.userId != AuthUtil.getUserId()) {
            throw ServiceException("不是您的岗位，不能更改工作记录")
        }
        val shift = Shift(id = id, record = record)
        return updateById(shift)
    }

    override fun getRecord(id: Long): String {
        val shift: Shift = getById(id) ?: return ""
        if (shift.userId != AuthUtil.getUserId()) {
            throw ServiceException("不是您的岗位，不能查看工作记录")
        }
        return shift.record ?: ""
    }

    override fun deleteShift(id: Long): Boolean {
        val shift = getById(id) ?: throw ServiceException("交接班岗位不存在")
        if (shift.builtIn!!) {
            throw ServiceException("内置岗位不能删除")
        }
        return this.deleteLogic(listOf(id))
    }

    override fun getNameByCode(shiftCode: String, tenantId: String): String? {
        val shift: Shift = this.getOne(
            KtQueryWrapper(Shift::class.java).eq(Shift::tenantId, tenantId).eq
                (Shift::code, shiftCode).select(Shift::name)
        ) ?: return null
        return shift.name
    }

    override fun getShiftCodeByUserId(userId: Long): List<String> {
        val shifts = list(KtQueryWrapper(Shift::class.java).eq(Shift::userId, userId).select(Shift::code))
        return shifts.map { it.code!! }
    }

    override fun getUserIdByShiftCode(shiftCode: String, tenantId: String): Long? {
        val shift: Shift = this.getOne(
            KtQueryWrapper(Shift::class.java).eq(Shift::code, shiftCode).eq(Shift::tenantId, tenantId)
                .select(Shift::userId)
        ) ?: return null
        return shift.userId
    }
}
