package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.CategoryDataCache
import cnooc.qhse.base.cache.CategoryDataCache.CATEGORY_CACHE
import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.base.service.ICategoryDataService
import cnooc.qhse.base.wrapper.CategoryDataWrapper
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.github.oshai.kotlinlogging.KotlinLogging
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.Parameters
import io.swagger.v3.oas.annotations.tags.Tag
import jakarta.servlet.http.HttpServletRequest
import jakarta.validation.Valid
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartHttpServletRequest
import springfox.documentation.annotations.ApiIgnore

private val logger = KotlinLogging.logger {}

/**
 * 数据分类控制器
 */
@RestController
@RequestMapping("/category")
@Tag(name = "数据分类", description = "数据分类")
class CategoryDataController @Autowired constructor(private val categoryDataService: ICategoryDataService) :
    BladeController() {

    /**
     * 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    fun detail(area: CategoryData): R<CategoryDataVO> {
        val detail: CategoryData = categoryDataService.getOne(Condition.getQueryWrapper(area))
        return R.data(CategoryDataWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @Parameters(
        Parameter(name = "categoryName", description = "分类名称")
    )
    @ApiOperationSupport(order = 2)
    @Operation(summary = "列表", description = "列表")
    fun list(@ApiIgnore @RequestParam category: Map<String, Any>): R<List<CategoryDataVO>> {
        val queryWrapper = Condition.getQueryWrapper(category, CategoryData::class.java)
        val list: List<CategoryData> = categoryDataService.list(queryWrapper)
        return R.data(CategoryDataWrapper.build().listNodeVO(list))
    }

    /**
     * 获取全部分类树形结构
     */
    @GetMapping("/tree")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "树形结构", description = "树形结构")
    fun tree(): R<List<CategoryDataVO>> {
        val tree: List<CategoryDataVO> = categoryDataService.tree(AuthUtil.getTenantId())
        return R.data(tree)
    }

    /**
     * 获某一分类树形结构
     */
    @GetMapping("/single-tree")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "单类树形结构", description = "单类树形结构")
    fun singleTree(rootCode: String): R<List<CategoryDataVO>> {
        val tree = CategoryDataCache.getCategoryTree(rootCode, AuthUtil.getTenantId())
        return R.data(tree)
    }

    /**
     * 新增 代码自定义代号
     */
    @PostMapping("/submit")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增或修改", description = "新增或修改")
    @PreAuth("hasPermission('earnest:category:edit')")
    fun submit(@RequestBody @Valid category: CategoryData): R<Boolean> {
        CacheUtil.clear(CATEGORY_CACHE)
        return R.status(categoryDataService.submit(category))
    }

    /**
     * 删除 代码自定义代号
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasPermission('earnest:category:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        CacheUtil.clear(CATEGORY_CACHE)
        return R.status(categoryDataService.removeCategories(Func.toLongList(ids)))
    }

    // @fixme
//    @GetMapping(value = ["/export"])
//    @PreAuth("hasPermission('earnest:category:export')")
//    fun exportXls(map: ModelMap, @RequestParam area: Map<String, Any>, request: HttpServletRequest, response: HttpServletResponse) {
//        val queryWrapper = Condition.getQueryWrapper(area, CategoryData::class.java)
//        queryWrapper.orderByAsc(CategoryData::categoryCode.toColumn())
//        val list: List<CategoryData> = categoryDataService.list(queryWrapper)
//        val params = ExportParams("数据分类表", "导出数据", ExcelType.XSSF)
//        params.isFixedTitle = true
//        map[NormalExcelConstants.DATA_LIST] = list
//        map[NormalExcelConstants.CLASS] = CategoryData::class.java
//        map[NormalExcelConstants.PARAMS] = params
//        PoiBaseView.render(map, request, response, NormalExcelConstants.EASYPOI_EXCEL_VIEW)
//    }

    @PostMapping(value = ["/import"])
    @PreAuth("hasPermission('earnest:category:import')")
    fun importExcel(request: HttpServletRequest): R<*> {
        CacheUtil.clear(CATEGORY_CACHE)
        val multipartRequest  = request as MultipartHttpServletRequest
        for ((_, value) in multipartRequest.fileMap) {
            return try {
                val count: Int = categoryDataService.importExcel(value)
                R.success<Any>("文件导入成功！数据行数：$count")
            } catch (e: Exception) {
                logger.error(e) {"数据分类文件导入失败！" }
                R.fail<Any>("文件导入失败:" + e.message)
            }
        }
        return R.fail<Any>("文件导入失败！")
    }
}
