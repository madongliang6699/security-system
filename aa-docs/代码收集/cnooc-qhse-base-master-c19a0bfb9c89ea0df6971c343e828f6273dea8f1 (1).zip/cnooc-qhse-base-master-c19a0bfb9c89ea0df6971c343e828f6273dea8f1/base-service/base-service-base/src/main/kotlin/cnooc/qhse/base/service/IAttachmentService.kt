package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.common.service.BaseServiceKt
import org.springblade.core.oss.model.BladeFile
import org.springframework.web.multipart.MultipartFile

/**
 * 附件 服务类
 */
interface IAttachmentService : BaseServiceKt<Attachment> {
    fun addAttachments(attachments: List<Attachment>): Boolean
    fun addAttachments(files: List<BladeFile>, businessId: String, fileUsage: String): List<AttachmentVO>

    /**
     * 根据业务id和用途获取附件，参数不能全部为null
     * @param businessId 业务id
     * @param fileUsage 附件用途
     * @return 附件列表
     */
    fun getAttachments(businessId: String, fileUsage: String): List<AttachmentVO>

    /**
     * 根据业务id和用途获取附件，包括已删除的
     * @param businessId 业务id
     * @param fileUsage 附件用途
     * @return 附件列表
     */
    fun getAttachmentsIncludeDeleted(businessId: String, fileUsage: String): List<AttachmentVO>


    /**
     * 根据业务id获取附件，参数不能全部为null
     * @param businessId 业务id
     * @return 附件列表
     */
    fun getAttachments(businessId: String): List<AttachmentVO>

    /**
     * 根据业务id集合获取附件，参数不能全部为null
     * @param businessIds 业务id集合
     * @return 附件列表
     */
    fun getAttachments(businessIds: List<String>): List<AttachmentVO>

    /**
     * 根据业务id删除附件
     * @param businessIds 业务id列表
     * @return 是否成功
     */
    fun removeByBusinessIds(businessIds: List<String>): Boolean
    fun removeByBusinessesAndUsage(businessIds: List<String>, usage: String): Boolean
    fun removeByIds(ids: List<Long>): Boolean

    /**
     * 上传文件
     * @param fileName 文件名
     * @param file 文件（如果没有，可以使用CustomMultipartFile构造）
     * @param businessId 业务id
     * @param fileUsage 附件用途
     * @return 附件信息
     */
    fun putFileAndSaveAttachment(tenantId: String, fileName: String, file: MultipartFile, businessId: String, fileUsage: String): AttachmentVO

    fun addAttachments(tenantId: String, files: List<BladeFile>, businessId: String, fileUsage: String): List<AttachmentVO>
}
