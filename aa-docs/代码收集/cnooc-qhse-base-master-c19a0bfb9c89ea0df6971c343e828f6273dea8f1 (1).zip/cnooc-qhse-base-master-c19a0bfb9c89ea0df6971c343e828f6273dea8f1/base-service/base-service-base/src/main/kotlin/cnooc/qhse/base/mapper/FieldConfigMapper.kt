package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.FieldConfig
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 字段控制表 Mapper 接口
 */
interface FieldConfigMapper : BaseMapper<FieldConfig>
