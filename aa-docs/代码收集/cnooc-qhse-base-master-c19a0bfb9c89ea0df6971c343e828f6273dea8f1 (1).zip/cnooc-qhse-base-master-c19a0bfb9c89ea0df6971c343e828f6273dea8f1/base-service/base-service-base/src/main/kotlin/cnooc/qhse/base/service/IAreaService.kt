package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.common.service.BaseServiceKt
import org.springframework.web.multipart.MultipartFile

/**
 * 服务类
 */
interface IAreaService : BaseServiceKt<AreaEntity> {
    /**
     * 树形结构
     * @param tenantId 租户id
     * @return 区域树
     */
    fun tree(tenantId: String): List<AreaVO>

    /**
     * 删除区域
     *
     * @param ids 区域id集合
     * @return 是否成功
     */
    fun removeArea(ids: List<Long>): Boolean
    /**
     * 提交
     *
     * @param area 区域对象
     * @return 是否成功
     */
    fun submitArea(area: AreaEntity): Boolean

    /**
     * 根据区域id获取责任人id
     * @param areaId 区域id
     * @return 用户id集合
     */
    fun getUserIdsByAreaId(areaId: Long): List<Long>

    /**
     * 根据责任人id获取区域列表
     * @param userId 用户id
     * @return 区域集合
     */
    fun getAreasByUserId(userId: Long): List<AreaEntity>

    /**
     * 根据区域code获取区域名称
     * @param areaCode 区域编码
     * @param tenantId 租户
     * @return 区域
     */
    fun getAreaByCode(areaCode: String, tenantId: String): AreaEntity?

    /**
     * 根据区域code获取责任人id
     * @param areaCode 区域编码
     * @param tenantId 租户id
     * @return 用户id集合
     */
    fun getUserIdsByAreaCode(areaCode: String, tenantId: String): List<Long>
    fun importExcel(file: MultipartFile): Int

    /**
     * 根据区域编码或名称获取区域
     */
    fun getAreasByCodeOrName(areaCodeOrName: String, tenantId: String): List<AreaEntity>

    /**
     * 获取最后一级的区域列表
     */
    fun getLastLevelAreas(tenantId: String): List<AreaVO>

    /**
     * 根据父id查询子区域
     */
    fun getAreasByParentId(parentId: Long): List<AreaEntity>?
}
