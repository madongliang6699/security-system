package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.vo.AttachmentVO

/**
 * 手写签名 服务类
 */
interface ISignService {
    /**
     * 添加用户的手写签名
     * @param name oss 文件名
     * @param userId 用户id
     * @return 是否成功
     */
    fun addSign(name: String, userId: Long): Boolean

    /**
     * 获取用户的手写签名
     */
    fun getSign(userId: Long): AttachmentVO?

    companion object {
        const val PERSONAL_SIGN = "personal_sign"
    }
}
