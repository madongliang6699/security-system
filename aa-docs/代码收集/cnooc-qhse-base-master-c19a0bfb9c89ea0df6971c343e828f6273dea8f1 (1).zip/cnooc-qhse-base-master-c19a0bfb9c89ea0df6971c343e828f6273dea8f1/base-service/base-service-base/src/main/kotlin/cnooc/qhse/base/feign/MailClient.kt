package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.dto.MailInfo
import cnooc.qhse.base.service.IMailService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class MailClient(private val mailService: IMailService) : IMailClient {
    override fun sendSimpleMail(mailInfo: MailInfo): R<Boolean> {
        return R.data(mailService.sendSimpleMail(mailInfo))
    }

    override fun sendHtmlMail(mailInfo: MailInfo): R<Boolean> {
        return R.data(mailService.sendHtmlMail(mailInfo))
    }
}
