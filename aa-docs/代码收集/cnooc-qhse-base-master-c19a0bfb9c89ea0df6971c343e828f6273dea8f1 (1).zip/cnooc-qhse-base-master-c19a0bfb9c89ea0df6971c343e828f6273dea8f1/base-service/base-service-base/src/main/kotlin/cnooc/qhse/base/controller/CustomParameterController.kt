package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import cnooc.qhse.base.pojo.vo.CustomParameterVO
import cnooc.qhse.base.service.ICustomParameterService
import cnooc.qhse.base.wrapper.CustomParameterWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import jakarta.validation.Valid;
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*


/**
 * 自定义参数表 控制器
 *
 * @author Hugh Gao
 * @since 2024-10-21
 */
@RestController
@RequestMapping("customParameter/custom-parameter")
@Tag(name = "自定义参数表", description = "自定义参数表接口")
class CustomParameterController @Autowired constructor(private val customParameterService: ICustomParameterService) :
    BladeController() {

    /**
     * 自定义参数表 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入customParameter")
    fun detail(customParameter: CustomParameterEntity): R<CustomParameterVO> {
        val detail: CustomParameterEntity = customParameterService.getOne(Condition.getQueryWrapper(customParameter))
        return R.data(CustomParameterWrapper.build().entityVO(detail))
    }

    /**
     * 自定义参数表 分页
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入customParameter")
    fun list(
        @Parameter(hidden = true) @RequestParam customParameter: Map<String?, Any?>?,
        query: Query?
    ): R<IPage<CustomParameterVO>> {
        val pages: IPage<CustomParameterEntity> = customParameterService.page(
            Condition.getPage(query), Condition.getQueryWrapper(
                customParameter,
                CustomParameterEntity::class.java
            )
        )
        return R.data(CustomParameterWrapper.build().pageVO(pages))
    }

    /**
     * 自定义参数表 自定义分页
     */
    @GetMapping("/page")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "分页", description = "传入customParameter")
    fun page(customParameter: CustomParameterVO?, query: Query?): R<IPage<CustomParameterVO>> {
        val pages: IPage<CustomParameterVO> =
            customParameterService.selectCustomParameterPage(Condition.getPage(query), customParameter)
        return R.data(pages)
    }

    /**
     * 自定义参数表 新增
     */
    @PostMapping("/save")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增", description = "传入customParameter")
    fun save(@Valid @RequestBody customParameter: CustomParameterEntity?): R<*> {
        return R.status<Any>(customParameterService.save(customParameter))
    }

    /**
     * 自定义参数表 修改
     */
    @PostMapping("/update")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "修改", description = "传入customParameter")
    fun update(@Valid @RequestBody customParameter: CustomParameterEntity?): R<*> {
        return R.status<Any>(customParameterService.updateById(customParameter))
    }

    /**
     * 自定义参数表 新增或修改
     */
    @PostMapping("/submit")
    @ApiOperationSupport(order = 6)
    @Operation(summary = "新增或修改", description = "传入customParameter")
    fun submit(@Valid @RequestBody customParameter: CustomParameterEntity?): R<*> {
        return R.status<Any>(customParameterService.saveOrUpdate(customParameter))
    }

    /**
     * 自定义参数表 删除
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "传入ids")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String?): R<*> {
        return R.status<Any>(customParameterService.deleteLogic(Func.toLongList(ids)))
    }



}
