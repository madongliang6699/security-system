package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.MailRecord
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * APP报错信息表 Mapper 接口
 */
interface MailRecordMapper : BaseMapper<MailRecord>
