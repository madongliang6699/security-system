package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.ShiftLogMapper
import cnooc.qhse.base.pojo.entity.ShiftLog
import cnooc.qhse.base.service.IShiftLogService
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import org.springframework.stereotype.Service

/**
 * 交接班日志 服务实现类
 */
@Service
class ShiftLogServiceImpl : BaseServiceImplKt<ShiftLogMapper, ShiftLog>(), IShiftLogService
