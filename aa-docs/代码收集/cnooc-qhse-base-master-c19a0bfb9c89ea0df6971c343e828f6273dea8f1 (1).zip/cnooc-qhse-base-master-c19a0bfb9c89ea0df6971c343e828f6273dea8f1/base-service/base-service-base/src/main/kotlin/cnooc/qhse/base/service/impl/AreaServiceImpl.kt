package cnooc.qhse.base.service.impl

import cn.afterturn.easypoi.excel.ExcelImportUtil
import cn.afterturn.easypoi.excel.entity.ImportParams
import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.constant.BaseConstant.AREA_CODE_LENGTH
import cnooc.qhse.base.excel.AreaDataHandler
import cnooc.qhse.base.mapper.AreaMapper
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.base.service.IAreaService
import cnooc.qhse.base.wrapper.AreaWrapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.common.utils.ExceptionUtil
import cnooc.qhse.common.utils.PostCodeUtil
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.StringPool
import org.springframework.dao.DuplicateKeyException
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.multipart.MultipartFile
import java.util.LinkedList
import java.util.Queue

@Service
class AreaServiceImpl : BaseServiceImplKt<AreaMapper, AreaEntity>(), IAreaService {
    override fun tree(tenantId: String): List<AreaVO> {
        val areas = this.list(KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::tenantId, tenantId))
        return AreaWrapper.build().listNodeVO(areas)
    }

    override fun removeArea(ids: List<Long>): Boolean {
        val cnt = this.count(KtQueryWrapper(AreaEntity::class.java).`in`(AreaEntity::parentId, ids))
        if (cnt > 0) {
            throw ServiceException("请先删除子区域!")
        }
        return deleteLogic(ids)
    }

    private fun addArea(areaEntity: AreaEntity): Boolean {
        var parentId = BladeConstant.TOP_PARENT_ID
        var parentCode: String? = null
        if (areaEntity.parentId != null) {
            parentId = areaEntity.parentId

            //PID 不是根节点
            if (parentId != BladeConstant.TOP_PARENT_ID) {
                val parent: AreaEntity = this.getById(parentId)
                parentCode = parent.areaCode
            }
        }
        /*
		 * 分成三种情况
		 * 1.数据库无数据 调用YouBianCodeUtil.getNextYouBianCode(null);
		 * 2.添加子节点，无兄弟元素 YouBianCodeUtil.getSubYouBianCode(parentCode,null);
		 * 3.添加子节点有兄弟元素 YouBianCodeUtil.getNextYouBianCode(lastCode);
		 * */
        //找同类 确定上一个最大的code值
        val list: List<AreaEntity> = this.list(
            KtQueryWrapper(AreaEntity::class.java).eq(
                AreaEntity::parentId,
                parentId
            ).orderByDesc(AreaEntity::areaCode)
        )
        areaEntity.areaCode = if (list.isEmpty()) {
            if (BladeConstant.TOP_PARENT_ID == parentId) {
                //情况1
                PostCodeUtil.getNextPostCode(null)
            } else {
                //情况2
                PostCodeUtil.getSubPostCode(parentCode, null)
            }
        } else {
            //情况3
            PostCodeUtil.getNextPostCode(list[0].areaCode)
        }
        areaEntity.parentId = parentId
        return this.save(areaEntity)
    }

    override fun submitArea(area: AreaEntity): Boolean {
        if (area.parentId == null) {
            area.parentId = BladeConstant.TOP_PARENT_ID
            area.ancestors = "0"
        } else if (area.parentId!! > 0) {
            val parent = getById(area.parentId)
            area.ancestors = parent.ancestors + StringPool.COMMA + area.parentId
        }
        area.isDeleted = BladeConstant.DB_NOT_DELETED
        return if (area.id == null) {
            addArea(area)
        } else {
            this.updateById(area)
        }
    }

    override fun getUserIdsByAreaId(areaId: Long): List<Long> {
        val areaEntity = this.getById(areaId)
        return if (areaEntity?.userIds == null) {
            listOf()
        } else areaEntity.userIds!!.split(StringPool.COMMA).map { it.toLong() }
    }

    override fun getAreasByUserId(userId: Long): List<AreaEntity> =
        this.list(
            KtQueryWrapper(AreaEntity::class.java).like(
                AreaEntity::userIds,
                userId
            )
        )

    override fun getAreaByCode(areaCode: String, tenantId: String): AreaEntity? = getOne(
        KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::tenantId, tenantId).eq(AreaEntity::areaCode, areaCode)
    )

    override fun getAreasByCodeOrName(areaCodeOrName: String, tenantId: String): List<AreaEntity> = list(
        KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::tenantId, tenantId).and {
            it.eq(AreaEntity::areaCode, areaCodeOrName).or().eq(AreaEntity::areaName, areaCodeOrName.trim())
        }
    )

    override fun getLastLevelAreas(tenantId: String): List<AreaVO> {
        val areaTree = AreaCache.getAreaTree(tenantId)
        val lastLevelAreas = mutableListOf<AreaVO>()
        val queue: Queue<AreaVO> = LinkedList<AreaVO>(areaTree)
        while (!queue.isEmpty()) {
            val area = queue.poll()
            if (area.children == null || area.children!!.isEmpty()) {
                lastLevelAreas.add(area)
            } else {
                queue.addAll(area.children!!)
            }
        }
        return lastLevelAreas
    }

    override fun getUserIdsByAreaCode(areaCode: String, tenantId: String): List<Long> {
        val area = this.getAreaByCode(areaCode, tenantId)
        return if (area?.userIds == null) {
            listOf()
        } else area.userIds!!.split(StringPool.COMMA).map { it.toLong() }
    }

    @Transactional
    override fun importExcel(file: MultipartFile): Int {
        val params = ImportParams()
        params.titleRows = 1
        params.headRows = 1
        params.dataHandler = AreaDataHandler()
        return try {
            // orgCode编码长度
            var listArea: List<AreaEntity> =
                ExcelImportUtil.importExcel(file.inputStream, AreaEntity::class.java, params)
            listArea = listArea.filterNot { it.areaName.isNullOrBlank() }
            //按长度排序
            listArea.sortedBy { it.areaCode!!.length }
            for (area in listArea) {
                val code: String = area.areaCode!!
                if (code.length > AREA_CODE_LENGTH) {
                    val parentCode = code.substring(0, code.length - AREA_CODE_LENGTH)
                    val queryWrapper = KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::areaCode, parentCode)
                    try {
                        val parentArea = this.getOne(queryWrapper)
                        area.parentId = if (parentArea != null) parentArea.id else 0L
                    } catch (e: Exception) {
                        throw ServiceException("找不到父级区域")
                    }
                } else {
                    area.parentId = 0L
                }
                this.save(area)
            }
            listArea.size
        } catch (e: Exception) {
            log.error(e.message, e)
            if (e is DuplicateKeyException) {
                throw ServiceException("重复的数据：${ExceptionUtil.extractDuplicateKeyExceptionMessage(e)}")
            }
            throw ServiceException("文件导入失败：" + e.message)
        }
    }

    override fun getAreasByParentId(parentId: Long): List<AreaEntity>? {
        return this.list(KtQueryWrapper(AreaEntity::class.java)
            .eq(AreaEntity::parentId, parentId))
    }
}
