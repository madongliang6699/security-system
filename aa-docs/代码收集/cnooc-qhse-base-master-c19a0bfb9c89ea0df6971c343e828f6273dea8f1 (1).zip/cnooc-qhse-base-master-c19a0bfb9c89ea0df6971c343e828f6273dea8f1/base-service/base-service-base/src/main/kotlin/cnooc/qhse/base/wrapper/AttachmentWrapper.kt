package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.resource.feign.IOssClient

/**
 * 附件包装类,返回视图层所需的字段
 */
class AttachmentWrapper : BaseEntityWrapper<Attachment, AttachmentVO>() {
    override fun entityVO(attachment: Attachment): AttachmentVO {
        val vo = BeanUtil.copy(attachment, AttachmentVO::class.java)!!
        vo.name?.let {
            vo.link = SpringUtil.getBean(IOssClient::class.java).fileLinkInTenant(vo.name!!, vo.tenantId!!).retrieve()
        }
        return vo
    }

    companion object {
        fun build(): AttachmentWrapper {
            return AttachmentWrapper()
        }
    }
}
