package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.AlertConfigMapper
import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.base.service.IAlertConfigService
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import org.springframework.stereotype.Service

/**
 * 报警配置表 服务实现类
 */
@Service
class AlertConfigServiceImpl : BaseServiceImplKt<AlertConfigMapper, AlertConfig>(), IAlertConfigService
