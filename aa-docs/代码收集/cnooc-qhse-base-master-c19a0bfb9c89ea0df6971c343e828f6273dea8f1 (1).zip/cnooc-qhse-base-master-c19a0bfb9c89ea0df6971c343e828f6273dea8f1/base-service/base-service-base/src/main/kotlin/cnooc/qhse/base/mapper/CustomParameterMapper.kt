package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.vo.CustomParameterVO;
import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Param;


/**
 * 自定义参数表 Mapper 接口
 */
interface CustomParameterMapper : BaseMapper<CustomParameterEntity>{
    /**
     * 自定义分页
     *
     * @param page
     * @param customParameter
     * @return
     */
    fun selectCustomParameterPage( page: IPage<CustomParameterVO>, customParameter: CustomParameterVO?): List<CustomParameterVO>


}
