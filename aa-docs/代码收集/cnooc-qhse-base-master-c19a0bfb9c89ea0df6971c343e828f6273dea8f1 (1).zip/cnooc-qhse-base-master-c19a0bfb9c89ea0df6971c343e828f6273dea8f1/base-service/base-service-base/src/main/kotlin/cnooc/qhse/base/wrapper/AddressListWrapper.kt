package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.AddressList
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.system.pojo.entity.Dept

class AddressListWrapper : BaseEntityWrapper<Dept, AddressList>() {
    override fun entityVO(dept: Dept): AddressList {
        val addressList =  BeanUtil.copy(dept, AddressList::class.java)!!
        addressList.id = dept.id
        addressList.parentId = dept.parentId
        return addressList
    }

    companion object {
        fun build(): AddressListWrapper {
            return AddressListWrapper()
        }
    }
}
