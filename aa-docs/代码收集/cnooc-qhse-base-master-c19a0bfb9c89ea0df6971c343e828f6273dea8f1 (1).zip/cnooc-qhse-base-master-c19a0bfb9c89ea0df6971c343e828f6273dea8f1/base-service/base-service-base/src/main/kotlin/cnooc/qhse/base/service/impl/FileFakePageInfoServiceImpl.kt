package cnooc.qhse.base.service.impl

import cn.hutool.core.util.ObjectUtil
import cn.hutool.json.JSONUtil
import cn.hutool.poi.excel.ExcelPicUtil
import cn.hutool.poi.excel.ExcelReader
import cn.hutool.poi.excel.ExcelUtil
import cn.hutool.poi.excel.cell.CellUtil
import cnooc.qhse.base.constant.FileFakePageConstant
import cnooc.qhse.base.mapper.FileFakePageInfoMapper
import cnooc.qhse.base.pojo.dto.FileFakePageCellStyleResult
import cnooc.qhse.base.pojo.dto.FileFakePageCustomCellStyle
import cnooc.qhse.base.pojo.dto.FileFakePageExcelCell
import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.entity.FileFakePageInfo
import cnooc.qhse.base.pojo.enums.FileAttachmentUsage
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.pojo.vo.FileFakePageInfoVO
import cnooc.qhse.base.pojo.vo.FileFakePageListVO
import cnooc.qhse.base.service.IAttachmentService
import cnooc.qhse.base.service.IFileFakePageInfoService
import cnooc.qhse.base.wrapper.CommonFileStorageWrapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.apache.poi.hssf.usermodel.HSSFFont
import org.apache.poi.hssf.usermodel.HSSFRichTextString
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.PictureData
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.*
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.awt.Color
import java.io.InputStream
import java.net.URL
import java.util.*
import kotlin.toString

/**
 * Excel信息解析Str服务类
 */
@Service
class FileFakePageInfoServiceImpl(
    private val attachmentService: IAttachmentService
) : BaseServiceImplKt<FileFakePageInfoMapper, FileFakePageInfo>(), IFileFakePageInfoService {

    /**
     * 获取对应模块的文件列表
     * @param module  模块名称
     */
    override fun getFiles(module: String): List<FileFakePageListVO> {
        val attachments = checkFileExist(module)
        return packageFileList(attachments, module)
    }

    /**
     * 获取对应模块的原始文件列表
     * @param module  模块名称
     * @return 文件展示列表
     */
    override fun getExistFiles(module: String): FileFakePageInfoVO? {
        //先查找是否已存在该模块存储信息
        val existsBasicsInfo = this.getOne(
            KtQueryWrapper(FileFakePageInfo::class.java).eq(
                FileFakePageInfo::module,
                module
            ), false
        )
        return existsBasicsInfo?.let { CommonFileStorageWrapper.build().entityVO(it) }
    }

    private fun packageFileList(attachments: List<AttachmentVO>, module: String?): List<FileFakePageListVO> {
        val block: MutableList<FileFakePageListVO>.() -> Unit = {
            val excelExtension = listOf("xls", "xlsx")
            attachments.sortedBy { it.sort }.forEach {
                //如果是待解析的文件类型，并且是Excel文件，则解析Excel文件
                if (FileAttachmentUsage.AWAITING_ANALYSIS.value == it.fileUsage && excelExtension.contains(it.extension)) {
                    this.add(
                        FileFakePageListVO(
                            module = module,
                            name = it.originalName,
                            fileType = FileFakePageConstant.EXCEL_STR,
                            extension = it.extension,
                            link = it.link,
                            excelStr = getExcelStr(it)
                        )
                    )
                } else {
                    this.add(
                        FileFakePageListVO(
                            module = module,
                            name = it.originalName,
                            extension = it.extension,
                            fileType = FileAttachmentUsage.DOCUMENT.value,
                            link = it.link
                        )
                    )
                }
            }
        }
        return mutableListOf<FileFakePageListVO>().apply(block)
    }


    /**
     * 保存文件信息,并返回文件信息列表
     */
    @Transactional(rollbackFor = [Exception::class])
    override fun saveInfo(commonFileStorageInfo: FileFakePageInfoVO): List<FileFakePageListVO> {
        //先查找是否已存在该模块存储信息
        val existsBasicsInfo = this.getOne(
            KtQueryWrapper(FileFakePageInfo::class.java).eq(
                FileFakePageInfo::module,
                commonFileStorageInfo.module
            ), false
        )
        //存在信息,则先更新信息并删除附件信息
        if (ObjectUtil.isNotEmpty(existsBasicsInfo)) {
            attachmentService.removeByBusinessIds(Collections.singletonList(existsBasicsInfo.id.toString()))
            commonFileStorageInfo.id = existsBasicsInfo.id
            this.updateById(existsBasicsInfo)
        } else {
            this.save(commonFileStorageInfo)
        }
        commonFileStorageInfo.commonFiles?.let {
            val attachments = mutableListOf<Attachment>()
            var index = 0
            it.forEach { attachment ->
                attachment.businessId = commonFileStorageInfo.id.toString()
                //如果前台传来的是Document,则认为为附件,Excel也不做解析
                if (FileAttachmentUsage.DOCUMENT.value == attachment.fileUsage) {
                    attachment.fileUsage = FileAttachmentUsage.DOCUMENT.value
                } else {
                    attachment.fileUsage = FileAttachmentUsage.AWAITING_ANALYSIS.value
                }
                attachment.sort = index++
                attachments.add(attachment)
            }
            attachmentService.addAttachments(attachments)

        }
        val attachmentVOs = attachmentService.getAttachments(commonFileStorageInfo.id.toString())
        return packageFileList(attachmentVOs, commonFileStorageInfo.module)
    }


    /**
     * 获取Excel解析后的字符串
     */
    private fun getExcelStr(attachment: AttachmentVO): String {
        val inputStream = getModuleInputStream(attachment)

        val reader = ExcelUtil.getReader(inputStream)
        val result: HashMap<String, MutableSet<FileFakePageExcelCell?>> = LinkedHashMap()
        //结果set集合
        val specialCells = HashMap<String, FileFakePageExcelCell?>()
        val sheet = reader.sheet
        //处理特殊格式
        // 1. 先处理图片格式  key格式为 row_cell
        val picMap = ExcelPicUtil.getPicMap(reader.workbook, 0)
        parsePictureCell(specialCells, picMap)
        // 2. 处理合并区域
        val mergedRegions = sheet.mergedRegions
        for (cellRangeAddress in mergedRegions) {
            parseMergedRegions(specialCells, cellRangeAddress)
        }
        val firstRowNum = sheet.firstRowNum
        val lastRowNum = sheet.lastRowNum

        //按行新建默认
        for (i in firstRowNum..lastRowNum) {
            result[i.toString()] = LinkedHashSet()
        }

        parseCellInfo(reader, firstRowNum, lastRowNum, specialCells, result)

        val parse = JSONUtil.parse(result)
        println(parse.toJSONString(2))
        return parse.toJSONString(2)
    }

    /**查询当前模块关联的文件信息
     *
     */
    private fun checkFileExist(module: String): List<AttachmentVO> {
        val commonFileStorageInfo =
            this.getOne(
                (KtQueryWrapper(FileFakePageInfo::class.java).eq(FileFakePageInfo::module, module)),
                false
            )
        commonFileStorageInfo ?: return mutableListOf()
        val attachments = attachmentService.getAttachments(commonFileStorageInfo.id.toString())
        return attachments.ifEmpty { mutableListOf() }
    }

    /**
     * 根据模块名获取文件流  TODO  IO异常需要处理
     */
    private fun getModuleInputStream(attachment: AttachmentVO): InputStream? {
        //获取Excel文件流
        val url = URL(attachment.link)
        val connection = url.openConnection()
        return connection.getInputStream()
    }

    /**
     * 读取并设置单元格信息
     */
    private fun parseCellInfo(
        reader: ExcelReader,
        firstRowNum: Int,
        lastRowNum: Int,
        specialCells: HashMap<String, FileFakePageExcelCell?>,
        result: HashMap<String, MutableSet<FileFakePageExcelCell?>>
    ) {
        reader.read(firstRowNum, lastRowNum) { cell: Cell?, _: Any? ->
            //TODO 此处会不知道为什么读出为空值的单元格，需要跳过NULL值的单元格
            cell?.let {
                val columnIndex = cell.columnIndex
                val rowIndex = cell.rowIndex
                //处理特殊单元格
                var resultCell = specialCells[rowIndex.toString() + "_" + columnIndex]
                resultCell?.let {
                    if (FileFakePageConstant.PICTURE != it.dataType) {
                        it.data = (ObjectUtil.toString(CellUtil.getCellValue(cell)))
                    }
                }
                resultCell = resultCell ?: FileFakePageExcelCell(rowIndex, columnIndex).apply {
                    this.data = ObjectUtil.toString(CellUtil.getCellValue(cell))
                }
                //设置单元格格式
                val styleResult = getCellStyle(cell)
                if (styleResult.isMulti) {
                    resultCell.customCellStyles = styleResult.cellStyles
                } else {
                    resultCell.customCellStyle = styleResult.cellStyle
                }
                result[rowIndex.toString()]?.add(resultCell)
            }
        }
    }


    /**
     * 获取单元格样式
     */
    private fun getCellStyle(cell: Cell): FileFakePageCellStyleResult {
        val cellStyleResult = FileFakePageCellStyleResult()
        val customCellStyle = FileFakePageCustomCellStyle()
        //获取单元格样式
        val originCellStyle = cell.cellStyle
        // 获取样式所属的工作簿对象
        val workbook = cell.sheet.workbook
        // 获取填充颜色的索引值
        val extendedColor = originCellStyle.fillForegroundColorColor
        var color = "none"
        extendedColor?.let {
            color = (extendedColor as XSSFColor).argbHex
        }

        //判断是否为多格式内容,仅判断字符串格式的类型
        if (cell.cellType == CellType.STRING) {
            val stringCellValue = cell.richStringCellValue
            val formattingRuns = stringCellValue.numFormattingRuns()
            //格式大于一种
            if (formattingRuns > 1) {
                cellStyleResult.isMulti = true
                cellStyleResult.cellStyles = getMultiCellStyle(cell, color)
            } else {
                //设置背景颜色
                customCellStyle.backGroundColor = color
                //设置是否加粗
                // 获取样式中应用的字体信息
                val font = workbook.getFontAt(originCellStyle.fontIndexAsInt)
                val isBold = font.bold
                customCellStyle.fontWeight = isBold
                //字体大小和颜色
                val points = font.fontHeightInPoints
                customCellStyle.fontSize = points
                var fontColor = ""
                if (font is HSSFFont) {
                    val hssfColor = font.getHSSFColor(workbook as HSSFWorkbook)
                    fontColor = getArgbHex(hssfColor.hexString)
                } else if (font is XSSFFont) {
                    val xssfColor = font.xssfColor
                    fontColor = xssfColor?.argbHex ?: FileFakePageConstant.DEFAULT_FONT_COLOR
                }
                customCellStyle.color = fontColor
                cellStyleResult.cellStyle = customCellStyle
            }
        }
        return cellStyleResult
    }

    /**
     * 多格式单元格内容处理
     * @param cell 单元格
     * @param backGroundColor 单元格背景颜色
     */
    private fun getMultiCellStyle(cell: Cell, backGroundColor: String): List<FileFakePageCustomCellStyle> {
        val cellStyles = ArrayList<FileFakePageCustomCellStyle>()
        val workbook = cell.sheet.workbook
        val textString = cell.richStringCellValue
        if (textString is XSSFRichTextString) {
            for (i in 0 until textString.numFormattingRuns()) {
                val startIndex = textString.getIndexOfFormattingRun(i)
                val endIndex = startIndex + textString.getLengthOfFormattingRun(i)
                val fontAtIndex = textString.getFontAtIndex(i)
                //TODO  此处获取到的xssfColor可能会为空，设置为单元格的颜色,若还为空，再去获取主题颜色，颜色可能会不准确
                var xssfColor = fontAtIndex.xssfColor
                if (xssfColor == null) {
                    //获取单元格的颜色
                    val cellStyle = cell.cellStyle
                    val font = workbook.getFontAt(cellStyle.fontIndexAsInt)
                    font?.let {
                        font as XSSFFont
                        xssfColor = font.xssfColor
                    }
                    //还为空的话，再去获取主题颜色
                    if (xssfColor == null) {
                        var rgbArray: ByteArray? = null
                        val idx = fontAtIndex.color.toInt()
                        if (idx != XSSFFont.COLOR_NORMAL.toInt()) {
                            val theme = (workbook as XSSFWorkbook).theme
                            if (theme != null) {
                                val themeColor = theme.getThemeColor(idx)
                                if (themeColor != null) {
                                    rgbArray = themeColor.rgb
                                }
                            }
                        }
                        rgbArray?.let {
                            val color = Color(
                                rgbArray[0].toInt() and 0xFF,
                                rgbArray[1].toInt() and 0xFF,
                                rgbArray[2].toInt() and 0xFF
                            )
                            xssfColor = XSSFColor(
                                color, DefaultIndexedColorMap()
                            )

                        }
                    }
                }
                val customCellStyle = FileFakePageCustomCellStyle(
                    startIndex,
                    endIndex,
                    backGroundColor,
                    fontAtIndex.bold,
                    xssfColor!!.argbHex,
                    fontAtIndex.fontHeightInPoints
                )
                cellStyles.add(customCellStyle)
            }
        } else if (textString is HSSFRichTextString) {
            //FIXME 此处未经测试
            var startIndex = 0
            for (i in 0 until textString.numFormattingRuns()) {
                val nextIndex = textString.getIndexOfFormattingRun(i)
                val length = nextIndex - startIndex
                val font =
                    (workbook as HSSFWorkbook).getFontAt(textString.getFontOfFormattingRun(i).toInt()) as HSSFFont
                val customCellStyle = FileFakePageCustomCellStyle(
                    startIndex,
                    startIndex + length,
                    backGroundColor,
                    font.bold,
                    font.getHSSFColor(workbook).hexString,
                    font.fontHeightInPoints
                )
                cellStyles.add(customCellStyle)
                startIndex = nextIndex
            }
        }
        return cellStyles
    }

    /**
     * 解析合并单元格信息
     */
    private fun parseMergedRegions(cells: HashMap<String, FileFakePageExcelCell?>, cellRangeAddress: CellRangeAddress) {
        val firstRow = cellRangeAddress.firstRow
        val lastRow = cellRangeAddress.lastRow
        val firstColumn = cellRangeAddress.firstColumn
        val lastColumn = cellRangeAddress.lastColumn
        //处理首个单元格,特殊单元格设置合并的范围
        var existCell = cells[firstRow.toString() + "_" + firstColumn]
        existCell = existCell ?: FileFakePageExcelCell(firstRow, firstColumn)
        existCell.merged = true
        existCell.mergedRowCount = lastRow - firstRow + 1
        existCell.mergedColumnCount = lastColumn - firstColumn + 1
        cells[firstRow.toString() + "_" + firstColumn] = existCell
        for (i in firstRow..lastRow) {
            for (j in firstColumn..lastColumn) {
                if (i == firstRow && j == firstColumn) {
                    continue
                }
                val excelCellNoMerged = FileFakePageExcelCell(i, j, true, 0, 0)
                cells[i.toString() + "_" + j] = excelCellNoMerged
            }
        }
    }

    /**
     * 解析图片格式的单元格
     */
    private fun parsePictureCell(cells: HashMap<String, FileFakePageExcelCell?>, picMap: Map<String, PictureData>) {
        picMap.forEach { (k: String, v: PictureData) ->
            val excelCell = FileFakePageExcelCell(dataType = FileFakePageConstant.PICTURE)
            val index = k.split("_".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            excelCell.row = Integer.valueOf(index[0])
            excelCell.column = Integer.valueOf(index[1])
            excelCell.data = byteArr2String(v.data)
            cells[k] = excelCell
        }
    }

    /**
     * 将RGB转换为十六进制ARGB(默认完全不透明)
     * @param color 字符串rgb颜色,格式为x:y:z
     */
    private fun getArgbHex(color: String?): String {
        //为空或者长度不等于3,则默认取黑色
        color ?: return "FF000000"
        val colors = color.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        if (colors.size != 3) return "FF000000"
        val red = colors[0].toInt()
        val green = colors[1].toInt()
        val blue = colors[2].toInt()
        val alpha = 255
        val argb = alpha shl 24 or (red shl 16) or (green shl 8) or blue
        return String.format("#%08X", argb)
    }

    /** 二进制图片转换成base64字符串
     * @param byteArr 图片二进制数组
     * @return Base64格式的字符串
     */

    fun byteArr2String(byteArr: ByteArray?): String? {
        var stringBase64: String? = null
        try {
            val encoder = Base64.getEncoder()
            stringBase64 = if (byteArr != null) encoder.encodeToString(byteArr) else ""
        } catch (e: Exception) {
            System.err.println("图片二进制转换失败，错误原因:$e")
        }
        return stringBase64
    }
}
