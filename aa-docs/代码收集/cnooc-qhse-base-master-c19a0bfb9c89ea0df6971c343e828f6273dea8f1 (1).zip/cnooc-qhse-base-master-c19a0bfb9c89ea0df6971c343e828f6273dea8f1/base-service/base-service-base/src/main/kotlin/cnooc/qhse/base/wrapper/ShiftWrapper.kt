package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.Shift
import cnooc.qhse.base.pojo.vo.ShiftVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.system.cache.UserCache

/**
 * 交接班包装类,返回视图层所需的字段
 */
class ShiftWrapper : BaseEntityWrapper<Shift, ShiftVO>() {
    override fun entityVO(shift: Shift): ShiftVO {
        val shiftVO = BeanUtil.copy(shift, ShiftVO::class.java)!!
        val currentUser = UserCache.getUser(shift.userId)
        if (currentUser != null) {
            shiftVO.userName = currentUser.realName
        }
        return shiftVO
    }

    companion object {
        fun build(): ShiftWrapper {
            return ShiftWrapper()
        }
    }
}
