package cnooc.qhse.base.wrapper

import cnooc.qhse.base.cache.CategoryDataCache
import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.common.node.ForestNodeMergerKt
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.BeanUtil
import java.util.*

/**
 * 包装类,返回视图层所需的字段
 */
class CategoryDataWrapper : BaseEntityWrapper<CategoryData, CategoryDataVO>() {
    override fun entityVO(category: CategoryData): CategoryDataVO {
        val vo = Objects.requireNonNull(BeanUtil.copy(category, CategoryDataVO::class.java))!!
        vo.parentName = if (category.parentId == BladeConstant.TOP_PARENT_ID) {
            BladeConstant.TOP_PARENT_NAME
        } else {
            val parent = CategoryDataCache.getCategory(category.parentId!!)
            if (parent == null) "" else parent.categoryName
        }
        return vo
    }

    fun listNodeVO(list: List<CategoryData>): List<CategoryDataVO> {
        return ForestNodeMergerKt.merge(list.map { entityVO(it) })
    }

    companion object {
        fun build(): CategoryDataWrapper {
            return CategoryDataWrapper()
        }
    }
}
