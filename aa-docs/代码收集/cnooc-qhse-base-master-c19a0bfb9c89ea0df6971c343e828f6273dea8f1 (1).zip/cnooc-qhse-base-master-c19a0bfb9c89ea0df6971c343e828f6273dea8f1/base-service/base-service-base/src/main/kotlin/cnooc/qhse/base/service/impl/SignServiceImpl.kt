package cnooc.qhse.base.service.impl

import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.service.IAttachmentService
import cnooc.qhse.base.service.ISignService
import cnooc.qhse.base.service.ISignService.Companion.PERSONAL_SIGN
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class SignServiceImpl @Autowired constructor(private val attachmentService: IAttachmentService) : ISignService {

    @Transactional
    override fun addSign(name: String, userId: Long): Boolean {
        val attachment = Attachment(
            businessId = userId.toString(),
            extension = "png",
            fileUsage = PERSONAL_SIGN,
            sort = 0,
            name = name,
        )
        // 移除已经存在的数据
        val attachments = attachmentService.list(
            KtQueryWrapper(Attachment::class.java)
                .eq(Attachment::businessId, userId)
                .eq(Attachment::fileUsage, PERSONAL_SIGN)
        )
        if (attachments.isNotEmpty()) {
            attachmentService.removeByIds(attachments.map { it?.id!! })
        }
        return attachmentService.addAttachments(listOf(attachment))
    }

    override fun getSign(userId: Long): AttachmentVO? {
        val attachments: List<AttachmentVO> =
            attachmentService.getAttachments(userId.toString(), PERSONAL_SIGN)
        return if (attachments.isEmpty()) null else attachments[0]
    }
}
