package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.CalendarMapper
import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.base.service.ICalendarService
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.multipart.MultipartFile
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@Service
class CalendarServiceImpl : BaseServiceImplKt<CalendarMapper, CalendarPO>(), ICalendarService {

    @Transactional(rollbackFor = [Exception::class])
    override fun import(file: MultipartFile): Boolean {

        val om = ObjectMapper()
        val jsonNode = om.readTree(file.inputStream)
        val monthList = jsonNode["data"].toList()

        val list = mutableListOf<CalendarPO>()
        monthList.forEach {

            val year = it["year"].intValue()
            val month = it["month"].intValue()
            val dayList = it["days"].toList()

            dayList.forEach { day ->
                run {

                    val date = day["date"].asText()
                    val d = date.split("-")[2].toInt()

                    val po = CalendarPO(
                        year = year,
                        month = month,
                        day = d,
                        type = day["type"].asInt(),
                        weekDay = day["weekDay"]?.asInt(),
                        yearTips = day["yearTips"]?.asText(),
                        typeDesc = day["typeDes"]?.asText(),
                        chineseZodiac = day["chineseZodiac"]?.asText(),
                        solarTerms = day["solarTerms"]?.asText(),
                        avoid = day["avoid"]?.asText(),
                        suit = day["suit"]?.asText(),
                        lunarCalendar = day["lunarCalendar"]?.asText(),
                        dayOfYear = day["dayOfYear"]?.asInt(),
                        weekOfYear = day["weekOfYear"]?.asInt(),
                        constellation = day["constellation"]?.asText(),
                        indexWorkdayOfMonth = day["indexWorkDayOfMonth"]?.asInt()
                    )

                    list.add(po)
                }
            }
        }

        return this.saveBatch(list)
    }

    override fun queryByDate(date: LocalDate): CalendarPO? {
        return this.getOne(
            KtQueryWrapper(CalendarPO::class.java)
                .eq(CalendarPO::year, date.year)
                .eq(CalendarPO::month, date.month)
                .eq(CalendarPO::day, date.dayOfMonth)
        )
    }

    override fun upgradeCondition(): Boolean {
        val now = LocalDateTime.now()
        //如果当前时间在18:00-06:30范围内，返回true
        val startTime = LocalDateTime.of(now.toLocalDate(), LocalTime.of(18,0,0))
        val endTime = LocalDateTime.of(now.toLocalDate(), LocalTime.of(6,30,0))
        if(now.isAfter(startTime) || now.isBefore(endTime))  return true
        //如果今天是节假日(周末、法定），返回true
        val calendarNow = getOne(
            KtQueryWrapper(CalendarPO::class.java).eq(CalendarPO::year, now.year).eq(CalendarPO::month, now.month)
                .eq(CalendarPO::day, now.dayOfMonth)
        )
        return calendarNow.type != 0
    }
}
