package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.ShiftLog
import cnooc.qhse.common.service.BaseServiceKt

/**
 * 交接班日志 服务类
 */
interface IShiftLogService : BaseServiceKt<ShiftLog> {
}
