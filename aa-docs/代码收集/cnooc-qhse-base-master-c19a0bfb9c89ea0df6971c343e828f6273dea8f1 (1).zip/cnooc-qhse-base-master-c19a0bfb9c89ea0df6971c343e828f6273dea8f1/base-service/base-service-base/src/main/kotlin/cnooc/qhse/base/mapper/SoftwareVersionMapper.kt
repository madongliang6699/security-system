package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.SoftwareVersion
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 软件版本信息 Mapper 接口
 */
interface SoftwareVersionMapper : BaseMapper<SoftwareVersion?>
