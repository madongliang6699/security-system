package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.FileFakePageInfo
import cnooc.qhse.base.pojo.vo.FileFakePageInfoVO
import cnooc.qhse.base.pojo.vo.FileFakePageListVO
import cnooc.qhse.common.service.BaseServiceKt

interface IFileFakePageInfoService : BaseServiceKt<FileFakePageInfo> {
    /**
     * 上传文件
     * @param info  模块关联文件基本信息
     */
    fun saveInfo(info: FileFakePageInfoVO): List<FileFakePageListVO>


    /**
     * 获取对应模块解析后的文件列表
     * @param module  模块名称
     * @return 文件展示列表
     */
    fun getFiles(module: String): List<FileFakePageListVO>

    /**
     * 获取对应模块的原始文件列表
     * @param module  模块名称
     * @return 文件展示列表
     */
    fun getExistFiles(module: String): FileFakePageInfoVO?
}
