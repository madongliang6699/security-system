package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.AddressList
import cnooc.qhse.base.service.IBladeEnhancedService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class BladeEnhancedClient (private val bladeService: IBladeEnhancedService): IBladeEnhancedClient {
    override fun getUserIdsByPostCode(postCode: String, tenantId: String): R<List<Long>> {
        return R.data(bladeService.getUserIdsByPostCode(postCode, tenantId))
    }

    override fun getPostCodeByUserId(userId: Long): R<List<String>> {
        return R.data(bladeService.getPostCodeByUserId(userId))
    }

    override fun getPostIdByCode(postCode: String, tenantId: String): R<Long?> {
        return R.data(bladeService.getIdByPostCode(postCode, tenantId))
    }

    override fun getAddressList(tenantId: String): R<List<AddressList>> {
        return R.data(bladeService.addressList(tenantId))
    }
}
