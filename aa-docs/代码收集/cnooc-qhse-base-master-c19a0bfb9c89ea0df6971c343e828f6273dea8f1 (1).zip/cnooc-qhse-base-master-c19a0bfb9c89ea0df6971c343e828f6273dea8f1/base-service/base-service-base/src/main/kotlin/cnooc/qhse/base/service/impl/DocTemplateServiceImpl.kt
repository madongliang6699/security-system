package cnooc.qhse.base.service.impl

import cnooc.qhse.common.vo.CascadeData
import org.springblade.system.cache.DictBizCache

/**
 * 文档模板服务类，其中包含两类数据，一类是从其他模块注入的，比如作业许可，另一类是通过业务字典docTemplate定义的各租户的附件用途
 */
object DocTemplateServiceImpl {
    private val DOC_TEMPLATE_DICT_CODE = "docTemplate"
    //启动时由各模块，注入附件用途
    private val docUsageList: MutableList<CascadeData> = mutableListOf()

    /**
     *启动时，由各模块加入附件用途数据
     */
    fun addUsage(list: List<CascadeData>) {
        docUsageList.addAll(list)
    }

    fun getUsageName(type: String): String? {
        for (e in getInjectedAndDictDocUsageList()) {
            val label = e.getLabelByValueRecursively(type)
            if (label != null) {
                return label
            }
        }
        return null
    }

    /**
     * 获取注入的和字典定义的文档模板列表
     */
    fun getInjectedAndDictDocUsageList(): List<CascadeData> {
        val dicts = DictBizCache.getList(DOC_TEMPLATE_DICT_CODE) ?: return docUsageList
        val dictCascadeData = CascadeData.fromDictBizs(dicts)
        return docUsageList + dictCascadeData
    }

    /**
     *获取所有的type
     */
    fun getAllTypes(): List<String> {
        val re = mutableListOf<String>()
        for (e in getInjectedAndDictDocUsageList()){
            re.addAll(e.getAllValues())
        }
        return re
    }

    /**
     *
     */
    fun getUsageList(): List<CascadeData> {
        return getInjectedAndDictDocUsageList()
    }

    fun getUsageListByParentValue(parentValues: List<String>): List<CascadeData> {
        val re = mutableListOf<CascadeData>()
        for (e in getInjectedAndDictDocUsageList()) {
            for (parentValue in parentValues) {
                e.getCascaderDataByValue(parentValue)?.let { re.add(it) }
            }
        }
        return re
    }
}
