package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.base.service.IAlertConfigService
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class AlertConfigClient (private val alertConfigService: IAlertConfigService): IAlertConfigClient {
    override fun getAlertConfigList(tenantId: String): R<List<AlertConfig>> {
        return R.data(alertConfigService.list(
            KtQueryWrapper(AlertConfig::class.java).eq(AlertConfig::tenantId, tenantId)
        ))
    }
}
