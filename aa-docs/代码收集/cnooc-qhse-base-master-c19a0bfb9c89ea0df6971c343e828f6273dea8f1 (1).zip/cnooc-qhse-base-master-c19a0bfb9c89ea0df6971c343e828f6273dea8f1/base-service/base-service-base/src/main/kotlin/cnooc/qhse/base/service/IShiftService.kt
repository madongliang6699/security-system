package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.Shift
import cnooc.qhse.common.service.BaseServiceKt

/**
 * 交接班 服务类
 */
interface IShiftService : BaseServiceKt<Shift> {
    /**
     * 用户接班
     */
    fun acceptShift(id: Long)

    /**
     * 设置接班用户
     * @param id 接班岗位id
     * @param userId 用户id
     */
    fun giveShift(id: Long, userId: Long)

    /**
     * 保存工作记录
     */
    fun saveRecord(id: Long, record: String): Boolean

    /**
     * 获取工作记录
     */
    fun getRecord(id: Long): String?

    fun getNameByCode(shiftCode: String, tenantId: String): String?

    /**
     * 获取用户的值班code
     * @param userId 用户id
     * @return 值班code的集合
     */
    fun getShiftCodeByUserId(userId: Long): List<String>

    /**
     * 根据编码获取用户id
     * @param shiftCode 值班编码
     * @param tenantId 租户id
     * @return 用户id
     */
    fun getUserIdByShiftCode(shiftCode: String, tenantId: String): Long?

    /**
     * 删除值班岗位
     */
    fun deleteShift(id: Long): Boolean
}
