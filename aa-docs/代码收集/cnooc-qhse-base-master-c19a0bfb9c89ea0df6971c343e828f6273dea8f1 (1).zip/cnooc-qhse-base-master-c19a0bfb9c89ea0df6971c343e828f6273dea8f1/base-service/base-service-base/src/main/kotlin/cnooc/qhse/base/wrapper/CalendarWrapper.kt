package cnooc.qhse.base.wrapper

import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.base.pojo.vo.CalendarVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil

class CalendarWrapper : BaseEntityWrapper<CalendarPO, CalendarVO>() {
    override fun entityVO(calendar: CalendarPO): CalendarVO {
        return BeanUtil.copy(calendar, CalendarVO::class.java)!!
    }

    companion object {
        fun build(): CalendarWrapper {
            return CalendarWrapper()
        }
    }
}
