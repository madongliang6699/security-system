package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.AlertConfigCache
import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.base.pojo.vo.AlertConfigVO
import cnooc.qhse.base.service.IAlertConfigService
import cnooc.qhse.base.wrapper.AlertConfigWrapper
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import org.springframework.web.bind.annotation.RequestParam
import springfox.documentation.annotations.ApiIgnore

/**
 * 报警配置表 控制器
 *
 * @author Hugh Gao
 * @since 2023-07-10
 */
@RestController
@RequestMapping("/alert-config")
@Tag(name = "报警分组表", description = "报警分组表接口")
class AlertConfigController @Autowired constructor(private val alertConfigService: IAlertConfigService) :
    BladeController() {

    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入alertConfig")
    @PreAuth("hasPermission('base:alert_config:view')")
    fun detail(alertConfig: AlertConfig): R<AlertConfigVO> {
        val detail =
            alertConfigService.getOne(Condition.getQueryWrapper(alertConfig)) ?: return R.fail("未找到对应对象")
        return R.data(AlertConfigWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入alertConfig")
    @PreAuth("hasPermission('base:alert_config:view')")
    fun list(@ApiIgnore @RequestParam alertConfig: Map<String, Any>, query: Query): R<IPage<AlertConfigVO>> {
        val qw = Condition.getQueryWrapper(alertConfig, AlertConfig::class.java)
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(AlertConfig::createTime.toColumn())
        }
        val pages = alertConfigService.page(Condition.getPage(query), qw)
        return R.data(AlertConfigWrapper.build().pageVO(pages))
    }


    @PostMapping("/save")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "新增", description = "传入alertConfig")
    @PreAuth("hasPermission('base:alert_config:add')")
    fun save(@Validated @RequestBody alertConfig: AlertConfig): R<Boolean> {
        CacheUtil.clear(AlertConfigCache.ALERT_CONFIG_CACHE)
        return R.status(alertConfigService.save(alertConfig))
    }

    @PostMapping("/update")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "修改", description = "传入alertConfig")
    @PreAuth("hasPermission('base:alert_config:edit')")
    fun update(@Validated @RequestBody alertConfig: AlertConfig): R<Boolean> {
        CacheUtil.clear(AlertConfigCache.ALERT_CONFIG_CACHE)
        return R.status(alertConfigService.updateById(alertConfig))
    }

    @PostMapping("/remove")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "逻辑删除", description = "传入ids")
    @PreAuth("hasPermission('base:alert_config:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        CacheUtil.clear(AlertConfigCache.ALERT_CONFIG_CACHE)
        return R.status(alertConfigService.deleteLogic(Func.toLongList(ids)))
    }
}
