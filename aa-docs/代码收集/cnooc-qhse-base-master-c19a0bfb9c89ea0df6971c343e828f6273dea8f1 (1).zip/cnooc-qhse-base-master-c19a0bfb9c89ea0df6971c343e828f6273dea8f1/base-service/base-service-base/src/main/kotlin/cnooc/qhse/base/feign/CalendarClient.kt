package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.base.service.ICalendarService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController
import java.time.LocalDate

@NonDS
@RestController
class CalendarClient (private val calendarService: ICalendarService): ICalendarClient {
    override fun getByDate(date: LocalDate): R<CalendarPO> {
        return R.data(calendarService.queryByDate(date))
    }
}
