package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.FileFakePageInfo
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 通用附件解析基本信息 Mapper 接口
 */
interface FileFakePageInfoMapper : BaseMapper<FileFakePageInfo>
