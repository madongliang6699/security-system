package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.FieldConfig
import cnooc.qhse.common.service.BaseServiceKt

/**
 * 字段控制表 服务类
 */
interface IFieldConfigService : BaseServiceKt<FieldConfig>
