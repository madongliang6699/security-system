package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.SoftwareVersionCache
import cnooc.qhse.base.pojo.entity.SoftwareVersion
import cnooc.qhse.base.service.ISoftwareVersionService
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

/**
 * 软件版本信息 控制器
 */
@RestController
@RequestMapping("/software-version")
@Tag(name = "软件版本信息", description = "软件版本信息接口")
class SoftwareVersionController(private val softwareVersionService: ISoftwareVersionService) {

    /**
     * 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    @PreAuth("hasRole('administrator')")
    fun detail(id: Long): R<SoftwareVersion> {
        val detail = softwareVersionService.getById(id) ?: throw IllegalArgumentException("查询结果为空")
        return R.data(detail)
    }

    /**
     * 分页 软件版本信息
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "分页")
    @PreAuth("hasRole('administrator')")
    fun list(@RequestParam softwareVersion: Map<String, Any?>, query: Query): R<IPage<SoftwareVersion>> {
        val qw = Condition.getQueryWrapper(softwareVersion, SoftwareVersion::class.java)
        // 默认以状态和创建时间排序
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByAsc(SoftwareVersion::publishDatetime.toColumn())
        }
        val pages = softwareVersionService.page(Condition.getPage(query), qw)
        return R.data(pages)
    }

    /**
     * 新增 软件版本信息
     */
    @PostMapping("/save")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增", description = "新增")
    @PreAuth("hasRole('administrator')")
    fun save(@RequestBody @Valid softwareVersion: SoftwareVersion?): R<Boolean> {
        CacheUtil.clear(SoftwareVersionCache.SOFTWARE_VERSION_CACHE, false)
        return R.status(softwareVersionService.save(softwareVersion))
    }

    /**
     * 修改 软件版本信息
     */
    @PostMapping("/update")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "修改", description = "修改")
    @PreAuth("hasRole('administrator')")
    fun update(@RequestBody @Valid softwareVersion: SoftwareVersion?): R<Boolean> {
        CacheUtil.clear(SoftwareVersionCache.SOFTWARE_VERSION_CACHE, false)
        return R.status(softwareVersionService.updateById(softwareVersion))
    }

    /**
     * 新增或修改 软件版本信息
     */
    @PostMapping("/submit")
    @ApiOperationSupport(order = 6)
    @Operation(summary = "新增或修改", description = "新增或修改")
    @PreAuth("hasRole('administrator')")
    fun submit(@RequestBody @Valid softwareVersion: SoftwareVersion): R<Boolean> {
        CacheUtil.clear(SoftwareVersionCache.SOFTWARE_VERSION_CACHE, false)
        return R.status(softwareVersionService.saveOrUpdate(softwareVersion))
    }

    /**
     * 删除 软件版本信息
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasRole('administrator')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        CacheUtil.clear(SoftwareVersionCache.SOFTWARE_VERSION_CACHE, false)
        return R.status(softwareVersionService.removeByIds(Func.toLongList(ids)))
    }

    @get:Operation(description = "获取最新android应用版本")
    @get:ApiOperationSupport(order = 8)
    @get:GetMapping("/android")
    val androidLatestVersion: R<SoftwareVersion>
        get() = R.data(SoftwareVersionCache.androidLatestVersion)
}
