package cnooc.qhse.base.service.impl

import cnooc.qhse.base.pojo.dto.MailInfo
import cnooc.qhse.base.pojo.entity.MailRecord
import cnooc.qhse.base.service.IMailRecordService
import cnooc.qhse.base.service.IMailService
import io.github.oshai.kotlinlogging.KotlinLogging
import jakarta.mail.internet.InternetAddress
import org.springblade.core.tool.utils.Func
import org.springframework.boot.autoconfigure.mail.MailProperties
import org.springframework.mail.javamail.JavaMailSender
import org.springframework.mail.javamail.MimeMessageHelper
import org.springframework.stereotype.Service
import java.time.LocalDateTime

private val log = KotlinLogging.logger {}
/**
 * 发送邮件
 */
@Service
class MailServiceImpl(
    private val jms: JavaMailSender,
    private val mailProperties: MailProperties,
    private val mailRecordService: IMailRecordService
) : IMailService {


    override fun sendSimpleMail(mailInfo: MailInfo): Boolean {
        if (mailProperties.properties["enabled"] != "true") {
            log.info { "==============配置文件邮件发送功能未开启================" }
            return true
        }
        checkValue(mailInfo)
        log.info("========开始发送邮件=========")
        val message = jms.createMimeMessage()
        val mimeMessageHelper = MimeMessageHelper(message, false)
        mailInfo.recipients = mailInfo.recipients?.distinct()
        //是否分组;
        if (mailInfo.isGroup) {
            val internetAddressList = mutableListOf<InternetAddress>()
            mailInfo.recipients!!.forEach {
                internetAddressList.add(InternetAddress(it, true))
                mimeMessageHelper.setTo(internetAddressList.toTypedArray())
            }
        } else {
            mimeMessageHelper.setTo(mailInfo.recipients!!.toTypedArray())
        }
        //主题
        mimeMessageHelper.setSubject(mailInfo.subject!!)
        //内容
        mimeMessageHelper.setText(mailInfo.content!!, false)
        //from和username一致
        mimeMessageHelper.setFrom(mailProperties.username)
        //抄送人
        if (!mailInfo.ccs.isNullOrEmpty()) {
            mimeMessageHelper.setCc(mailInfo.ccs!!.toTypedArray())
        }
        //密送人
        if (!mailInfo.bccs.isNullOrEmpty()) {
            mimeMessageHelper.setBcc(mailInfo.bccs!!.toTypedArray())
        }
        try {
            jms.send(message)
            //保存发送记录
            mailRecordService.save(MailRecord(
                subject = mailInfo.subject,
                content = mailInfo.content,
                recipient = mailInfo.recipients?.let { Func.join(it) },
                ccs = mailInfo.ccs?.let { Func.join(it) },
                bccs = mailInfo.bccs?.let { Func.join(it) },
                sendTime = LocalDateTime.now(),
                tenantId = mailInfo.tenantId
            ))
        } catch (e: Exception) {
            log.error("==========邮件发送失败==========")
            return false
        }
        log.info("========邮件发送成功=========")
        return true
    }

    /**
     * html邮件
     *
     * @param to      收件人
     * @param subject 主题
     * @param content 内容
     */
    override fun sendHtmlMail(mailInfo: MailInfo): Boolean {
        if (mailProperties.properties["enabled"] != "true") {
            return true
        }
        checkValue(mailInfo)
        log.info("========开始发送邮件=========")
        val message = jms.createMimeMessage()
        val mimeMessageHelper = MimeMessageHelper(message, true)
        mailInfo.recipients = mailInfo.recipients?.distinct()
        //是否分组;
        if (mailInfo.isGroup) {
            val internetAddressList = mutableListOf<InternetAddress>()
            mailInfo.recipients!!.forEach {
                internetAddressList.add(InternetAddress(it, true))
                mimeMessageHelper.setTo(internetAddressList.toTypedArray())
            }
        } else {
            mimeMessageHelper.setTo(mailInfo.recipients!!.toTypedArray())
        }
        //主题
        mimeMessageHelper.setSubject(mailInfo.subject!!)
        //内容
        mimeMessageHelper.setText(mailInfo.content!!, true)
        //from和username一致
        mimeMessageHelper.setFrom(mailProperties.username)
        //抄送人
        if (!mailInfo.ccs.isNullOrEmpty()) {
            mimeMessageHelper.setCc(mailInfo.ccs!!.toTypedArray())
        }
        //密送人
        if (!mailInfo.bccs.isNullOrEmpty()) {
            mimeMessageHelper.setBcc(mailInfo.bccs!!.toTypedArray())
        }
        try {
            jms.send(message)
            //保存发送记录
            mailRecordService.save(MailRecord(
                subject = mailInfo.subject,
                content = mailInfo.content,
                recipient = mailInfo.recipients?.let { Func.join(it) },
                ccs = mailInfo.ccs?.let { Func.join(it) },
                bccs = mailInfo.bccs?.let { Func.join(it) },
                sendTime = LocalDateTime.now()
            ))
        } catch (e: Exception) {
            log.error("==========邮件发送失败==========")
            return false
        }
        log.info("========邮件发送成功=========")
        return true
    }

    /**
     *  校验邮件主题、内容、收件人是否为空
     */
    private fun checkValue(mailInfo: MailInfo) {
        //剔除不合法的邮箱
        mailInfo.recipients = mailInfo.recipients?.filter { isValidEmail(it) }
        mailInfo.ccs = mailInfo.ccs?.filter { isValidEmail(it) }
        mailInfo.bccs = mailInfo.bccs?.filter { isValidEmail(it) }
        when {
            mailInfo.subject.isNullOrBlank() -> throw Exception("邮件主题不能为空")
            mailInfo.content.isNullOrBlank() -> throw Exception("邮件内容不能为空")
            mailInfo.recipients.isNullOrEmpty() -> throw Exception("有效收件人不能为空")
        }
    }

    /**
     *  校验邮箱合法性
     */
    fun isValidEmail(email: String): Boolean {
        val regex =  Regex("^([a-zA-Z0-9_\\-\\.]+)@([\\da-zA-Z\\-]+)\\.([a-zA-Z\\-\\.]+)\$")
        return email.matches(regex)
    }
}
