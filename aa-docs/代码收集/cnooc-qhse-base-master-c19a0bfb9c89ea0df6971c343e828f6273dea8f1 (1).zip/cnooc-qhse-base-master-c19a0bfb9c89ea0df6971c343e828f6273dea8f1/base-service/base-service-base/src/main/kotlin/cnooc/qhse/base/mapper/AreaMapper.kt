package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.AreaEntity
import com.baomidou.mybatisplus.core.mapper.BaseMapper

interface AreaMapper : BaseMapper<AreaEntity>
