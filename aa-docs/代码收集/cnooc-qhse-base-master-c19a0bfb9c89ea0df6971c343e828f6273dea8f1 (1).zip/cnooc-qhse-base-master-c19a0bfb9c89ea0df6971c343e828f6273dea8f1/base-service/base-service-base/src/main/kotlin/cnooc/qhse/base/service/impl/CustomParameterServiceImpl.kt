package cnooc.qhse.base.service.impl

import cnooc.qhse.base.pojo.entity.CustomParameterEntity;
import cnooc.qhse.base.pojo.vo.CustomParameterVO;
import cnooc.qhse.base.mapper.CustomParameterMapper;
import cnooc.qhse.base.service.ICustomParameterService;
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.metadata.IPage;


/**
 * 自定义参数表 服务实现类
 */
@Service
open class CustomParameterServiceImpl : BaseServiceImplKt<CustomParameterMapper, CustomParameterEntity>(), ICustomParameterService {

    override fun selectCustomParameterPage(
        page: IPage<CustomParameterVO>,
        customParameter: CustomParameterVO?
    ): IPage<CustomParameterVO> {
        return page.setRecords(baseMapper.selectCustomParameterPage(page, customParameter))
    }


}
