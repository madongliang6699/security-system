package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.SoftwareVersion
import com.baomidou.mybatisplus.extension.service.IService

/**
 * 软件版本信息 服务类
 */
interface ISoftwareVersionService : IService<SoftwareVersion> {
    companion object {
        const val TYPE_ANDROID = "android"
    }
    val androidLatestVersion: SoftwareVersion?
}
