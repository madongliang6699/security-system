package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.FieldConfigCache
import cnooc.qhse.base.pojo.entity.FieldConfig
import cnooc.qhse.base.pojo.vo.FieldConfigVO
import cnooc.qhse.base.service.IFieldConfigService
import cnooc.qhse.base.wrapper.FieldConfigWrapper
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import springfox.documentation.annotations.ApiIgnore

/**
 * 字段控制表 控制器
 *
 * @author Hugh Gao
 * @since 2023-03-01
 */
@RestController
@RequestMapping("/field-config")
@Tag(name = "字段控制表", description = "字段控制表接口")
class FieldConfigController @Autowired constructor(private val fieldConfigService: IFieldConfigService) :
    BladeController() {

    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    @PreAuth("hasPermission('base:field_config:view')")
    fun detail(fieldConfig: FieldConfig): R<FieldConfigVO> {
        val detail =
            fieldConfigService.getOne(Condition.getQueryWrapper(fieldConfig)) ?: return R.fail("未找到对应对象")
        return R.data(FieldConfigWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "分页")
    @PreAuth("hasPermission('base:field_config:view')")
    fun list(@ApiIgnore @RequestParam fieldConfig: Map<String, Any>, query: Query): R<IPage<FieldConfigVO>> {
        val qw = Condition.getQueryWrapper(fieldConfig, FieldConfig::class.java)
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(FieldConfig::createTime.toColumn())
        }
        val pages = fieldConfigService.page(Condition.getPage(query), qw)
        return R.data(FieldConfigWrapper.build().pageVO(pages))
    }


    @PostMapping("/save")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "新增", description = "新增")
    @PreAuth("hasPermission('base:field_config:add')")
    fun save(@Validated @RequestBody fieldConfig: FieldConfig): R<Boolean> {
        return R.status(fieldConfigService.save(fieldConfig))
    }

    @PostMapping("/update")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "修改", description = "修改")
    @PreAuth("hasPermission('base:field_config:edit')")
    fun update(@Validated @RequestBody fieldConfig: FieldConfig): R<Boolean> {
        return R.status(fieldConfigService.updateById(fieldConfig))
    }

    @PostMapping("/remove")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasPermission('base:field_config:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        return R.status(fieldConfigService.deleteLogic(Func.toLongList(ids)))
    }

    @GetMapping("/all-config")
    fun getAllConfig(): R<List<FieldConfigVO>> {
        return R.data(FieldConfigCache.getAllFieldConfigs(AuthUtil.getTenantId()))
    }
}
