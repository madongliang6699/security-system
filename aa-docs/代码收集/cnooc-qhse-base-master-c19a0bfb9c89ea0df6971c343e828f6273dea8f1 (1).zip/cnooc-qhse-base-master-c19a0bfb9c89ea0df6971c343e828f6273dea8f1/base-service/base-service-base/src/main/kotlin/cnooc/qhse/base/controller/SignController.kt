package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.service.ISignService
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

/**
 * 个人手写签名 控制器
 */
@RestController
@RequestMapping("/sign")
@Tag(name = "个人签名", description = "个人签名接口")
class SignController @Autowired constructor(private val signService: ISignService) : BladeController() {

    @PostMapping("/add")
    @Operation(summary = "添加个人电子签", description = "添加个人电子签")
    fun addSign(
        @Parameter(
            name = "name",
            example = "upload/20200520/klasdf8989.png",
            required = true
        ) @RequestParam name: String
    ): R<Boolean> {
        return R.status(signService.addSign(name, AuthUtil.getUserId()))
    }

    @Operation(summary = "获取个人电子签名")
    @PostMapping("/get")
    fun getSign(): R<AttachmentVO?> = R.data(signService.getSign(AuthUtil.getUserId()))
}
