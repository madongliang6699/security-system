package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.base.service.ICategoryDataService
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class CategoryDataClient (private val categoryService: ICategoryDataService) : ICategoryDataClient {
    override fun getCategoryById(id: Long): R<CategoryData?> {
        return R.data(categoryService.getById(id))
    }

    override fun getCategoryByCode(code: String, tenantId: String): R<CategoryData?> {
        return R.data(categoryService.getByCode(code, tenantId))
    }

    override fun getCategoryPathNameById(id: Long): R<String> {
        return R.data(categoryService.getCategoryPathName(id))
    }

    override fun getCategoryTree(tenantId: String): R<List<CategoryDataVO>> {
        return R.data(categoryService.tree(tenantId))
    }

    override fun getCategorySingleTree(rootCode: String, tenantId: String): R<List<CategoryDataVO>> {
        return R.data(categoryService.singleTree(rootCode, tenantId))
    }

    override fun getCategoriesByName(name: String, tenantId: String): R<List<CategoryData>> {
        return R.data(categoryService.getByName(name, tenantId))
    }
}
