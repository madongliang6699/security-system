package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.common.service.BaseServiceKt
import org.springframework.web.multipart.MultipartFile
import java.time.LocalDate

interface ICalendarService : BaseServiceKt<CalendarPO> {

    /**
     * 导入
     */
    fun import(file: MultipartFile): Boolean

    /**
     * 按日期查询
     */
    fun queryByDate(date: LocalDate): CalendarPO?


    /**
     * 是否符合作业许可提级条件
     */
    fun upgradeCondition(): Boolean
}
