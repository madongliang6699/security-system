package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.AlertConfig
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 报警配置表 Mapper 接口
 */
interface AlertConfigMapper : BaseMapper<AlertConfig>
