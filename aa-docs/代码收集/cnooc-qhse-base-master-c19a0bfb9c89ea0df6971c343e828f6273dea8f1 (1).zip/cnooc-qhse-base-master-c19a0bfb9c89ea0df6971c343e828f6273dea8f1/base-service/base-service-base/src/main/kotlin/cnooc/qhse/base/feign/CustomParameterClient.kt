package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import cnooc.qhse.base.pojo.vo.CustomParameterVO
import cnooc.qhse.base.service.ICustomParameterService
import cnooc.qhse.base.wrapper.CustomParameterWrapper
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数实现类
 */
@NonDS
@RestController
class CustomParameterClient(private val customParameterService: ICustomParameterService) : ICustomParameterClient {

    override fun getValueByParameterKey(
        moduleCode: String,
        parameterKey: String,
        tenantId: String
    ): R<CustomParameterVO?> {
        return R.data(
            CustomParameterWrapper.build().entityVO(
                customParameterService.getOne(
                    KtQueryWrapper(CustomParameterEntity::class.java).eq(CustomParameterEntity::parameterKey, parameterKey)
                        .eq(CustomParameterEntity::moduleCode, moduleCode).eq(CustomParameterEntity::tenantId, tenantId)
                )
            )
        )

    }
}
