package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.vo.FileFakePageInfoVO
import cnooc.qhse.base.pojo.vo.FileFakePageListVO
import cnooc.qhse.base.service.IFileFakePageInfoService
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.tool.api.R
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*

/**
 * 通用文件页面展示处理
 */
@RestController
@RequestMapping("/common-file")
@Tag(name = "common-file", description = "通用文件操作")
class FileFakePageInfoController @Autowired constructor(private val fileFakePageInfoService: IFileFakePageInfoService) :
    BladeController() {

    /**
     * 保存模块关联的文件基本信息
     */
    @PostMapping("/save")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "新增文件信息", description = "新增文件信息")
    fun save(@Validated @RequestBody commonFileStorageInfo: FileFakePageInfoVO): R<List<FileFakePageListVO>> {
        val saveInfo = fileFakePageInfoService.saveInfo(commonFileStorageInfo)
        return R.data(saveInfo)
    }

    /**
     * 获取模块对应原始的文件列表
     */
    @GetMapping("/getExistFiles")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "获取模块对应原始的文件列表", description = "获取模块对应原始的文件列表")
    fun getExistFiles(module: String): R<FileFakePageInfoVO> {
        val commonFileStorageInfoVO = fileFakePageInfoService.getExistFiles(module)
        return R.data(commonFileStorageInfoVO)
    }

    /**
     * 获取模块对应解析后的文件列表
     */
    @GetMapping(value = ["/getFlies"])
    @ApiOperationSupport(order = 3)
    @Operation(summary = "获取模块对应解析后的文件列表", description = "获取模块对应解析后的文件列表")
    fun getFiles(module: String): List<FileFakePageListVO> {
        return fileFakePageInfoService.getFiles(module)
    }
}
