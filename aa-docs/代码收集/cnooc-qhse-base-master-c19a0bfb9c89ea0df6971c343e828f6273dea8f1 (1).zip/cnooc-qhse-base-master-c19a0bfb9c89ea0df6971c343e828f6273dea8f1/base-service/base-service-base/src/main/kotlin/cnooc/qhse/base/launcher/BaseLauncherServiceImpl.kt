package cnooc.qhse.base.launcher

import org.springblade.core.auto.service.AutoService
import org.springblade.core.launch.constant.NacosConstant
import org.springblade.core.launch.service.LauncherService
import org.springblade.core.launch.utils.PropsUtil
import org.springframework.boot.builder.SpringApplicationBuilder

/**
 * 启动参数拓展
 *
 * @author Chill
 */
@AutoService(LauncherService::class)
class BaseLauncherServiceImpl : LauncherService {
    override fun launcher(builder: SpringApplicationBuilder, appName: String, profile: String, isLocalDev: Boolean) {
        val props = System.getProperties()
        // 开启多数据源
        PropsUtil.setProperty(props, "spring.datasource.dynamic.enabled", "true")
        // 指定注册配置信息
        PropsUtil.setProperty(
            props,
            "spring.cloud.nacos.config.extension-configs[0].data-id",
            NacosConstant.dataId("example", profile)
        )
        PropsUtil.setProperty(
            props,
            "spring.cloud.nacos.config.extension-configs[0].group",
            NacosConstant.NACOS_CONFIG_GROUP
        )
        PropsUtil.setProperty(
            props,
            "spring.cloud.nacos.config.extension-configs[0].refresh",
            NacosConstant.NACOS_CONFIG_REFRESH
        )
        // 指定注册IP
        // PropsUtil.setProperty(props, "spring.cloud.nacos.discovery.ip", "127.0.0.1");
        // 指定注册端口
        // PropsUtil.setProperty(props, "spring.cloud.nacos.discovery.port", "8200");
        // 自定义命名空间
        // PropsUtil.setProperty(props, "spring.cloud.nacos.config.namespace", LauncherConstant.NACOS_NAMESPACE);
        // PropsUtil.setProperty(props, "spring.cloud.nacos.discovery.namespace", LauncherConstant.NACOS_NAMESPACE);
        // 自定义分组
        // PropsUtil.setProperty(props, "spring.cloud.nacos.config.group", NacosConstant.NACOS_CONFIG_GROUP);
        // PropsUtil.setProperty(props, "spring.cloud.nacos.discovery.group", NacosConstant.NACOS_CONFIG_GROUP);
    }

    override fun getOrder(): Int {
        return 20
    }
}
