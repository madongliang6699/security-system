package cnooc.qhse.base.wrapper

import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.common.node.ForestNodeMergerKt
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.core.tool.utils.StringPool
import org.springblade.system.cache.SysCache
import org.springblade.system.cache.UserCache

/**
 * 包装类,返回视图层所需的字段
 */
class AreaWrapper : BaseEntityWrapper<AreaEntity, AreaVO>() {
    override fun entityVO(area: AreaEntity): AreaVO {
        val areaVO = BeanUtil.copy(area, AreaVO::class.java)!!
        areaVO.parentName = if (area.parentId == BladeConstant.TOP_PARENT_ID) {
            BladeConstant.TOP_PARENT_NAME
        } else {
            val parent = AreaCache.getArea(area.parentId!!)
            if (parent == null) "" else parent.areaName
        }
        if (!area.userIds.isNullOrBlank()) {
            areaVO.userNames = area.userIds!!.split(StringPool.COMMA)
                .map { it.toLong() }.mapNotNull { UserCache.getUser(it) }
                .joinToString(StringPool.COMMA) { it.realName }
        }
        if (!area.deptIds.isNullOrBlank()) {
            areaVO.deptNames = area.deptIds!!.split(StringPool.COMMA)
                .map { it.toLong() }.mapNotNull { SysCache.getDeptName(it) }.joinToString(StringPool.COMMA)
        }
        return areaVO
    }

    fun listNodeVO(list: List<AreaEntity>): List<AreaVO> {
        val listVO = list.map { entityVO(it) }
        return ForestNodeMergerKt.merge(listVO)
    }

    companion object {
        fun build(): AreaWrapper {
            return AreaWrapper()
        }
    }
}
