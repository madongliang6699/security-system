package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.MailRecord
import com.baomidou.mybatisplus.extension.service.IService

/**
 * app报错信息
 */
interface IMailRecordService: IService<MailRecord> {

}
