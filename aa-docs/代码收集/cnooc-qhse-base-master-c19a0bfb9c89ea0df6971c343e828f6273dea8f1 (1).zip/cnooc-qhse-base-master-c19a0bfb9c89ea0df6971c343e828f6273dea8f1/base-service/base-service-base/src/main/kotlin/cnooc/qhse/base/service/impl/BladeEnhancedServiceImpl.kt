package cnooc.qhse.base.service.impl

import cn.hutool.crypto.digest.DigestUtil
import cnooc.qhse.base.cache.BladeEnhancedCache
import cnooc.qhse.base.common.constant.CommonConstant
import cnooc.qhse.base.pojo.entity.AddressList
import cnooc.qhse.base.pojo.vo.NodeKtVO
import cnooc.qhse.base.service.IBladeEnhancedService
import cnooc.qhse.base.wrapper.AddressListWrapper
import cnooc.qhse.common.node.ForestNodeMergerKt
import cnooc.qhse.common.utils.notNullRetrieve
import cnooc.qhse.common.utils.retrieve
import jakarta.servlet.http.HttpServletResponse
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.core.tool.utils.Func
import org.springblade.resource.feign.IOssClient
import org.springblade.system.cache.DictCache
import org.springblade.system.cache.ParamCache
import org.springblade.system.cache.SysCache
import org.springblade.system.cache.UserCache
import org.springblade.system.feign.IUserSearchClient
import org.springblade.system.pojo.entity.User
import org.springblade.system.pojo.enums.DictEnum
import org.springblade.system.pojo.vo.UserVO
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.io.FileNotFoundException
import java.io.InputStream
import java.net.URL
import java.net.URLEncoder

@Service
class BladeEnhancedServiceImpl @Autowired constructor(
    private val userSearchClient: IUserSearchClient,
    private val ossClient: IOssClient,
) : IBladeEnhancedService {
    override fun getDeptSelectTree(tenantId: String): List<NodeKtVO> {
        val nodes = SysCache.getDeptsByTenantId(tenantId)
        val vos = nodes.map {
            NodeKtVO(
                id = it.id,
                parentId = it.parentId,
                title = it.deptName,
                children = listOf()
            )
        }
        val tree = ForestNodeMergerKt.merge(vos)
        return if (tree.size == 1) tree[0].children ?: listOf() else tree
    }

    override fun addressList(tenantId: String): List<AddressList> {
        // 获取部门
        val depts = SysCache.getDeptsByTenantId(tenantId)
        if (depts.isNullOrEmpty()) throw ServiceException("获取部门为空")
        depts.sortBy { it.sort }
        val addressList = AddressListWrapper.build().listVO(depts)

        // 获取所有用户，这个接口是按照部门id查询的，且使用的是like id的方式，通过传入0-9的数字，可以查询全部用户
        val users = userSearchClient.listByDept(Func.join(depts.map { it.id })).notNullRetrieve()
        val usersVo = fillUsers(users)
        // 组合部门与用户id
        val deptIdToUsers = mutableMapOf<String, MutableList<UserVO>>()
        for (user in usersVo) {
            Func.toStrList(user.deptId).forEach {
                deptIdToUsers.computeIfAbsent(it) { mutableListOf() }
                    .add(user)
            }
        }
        // 递归填充部门下的用户
        addressList.forEach { dept ->
            dept.users = deptIdToUsers[dept.id.toString()]?.sortedBy { it.realName }
        }
        return ForestNodeMergerKt.merge(addressList)
    }

    private fun fillUsers(users: List<User>): List<UserVO> {
        var tenantName = ""
        val roleIdsToNames = mutableMapOf<String, String>()
        val deptIdsToNames = mutableMapOf<String, String>()
        val postIdsToNames = mutableMapOf<String, String>()
        val sex2Name = mutableMapOf<Int, String>()
        val userType2Name = mutableMapOf<Int, String>()

        // 填充用户数据，使用本地缓存，加速查询
        val usersVo = users.mapNotNull { u ->
            if (u.account == "admin") {
                return@mapNotNull null
            }
            val vo = BeanUtil.copy(u, UserVO::class.java)!!
            if (tenantName.isBlank()) {
                val tenant = SysCache.getTenant(u.tenantId)
                tenantName = tenant.tenantName
            }
            vo.tenantName = tenantName
            vo.roleName = if (u.roleId.isNullOrBlank()) "" else roleIdsToNames.computeIfAbsent(u.roleId) {
                val roleName = SysCache.getRoleNames(u.roleId) ?: listOf()
                Func.join(roleName)
            }
            vo.deptName = if (u.deptId.isNullOrBlank()) "" else deptIdsToNames.computeIfAbsent(u.deptId) {
                val deptName = SysCache.getDeptNames(u.deptId) ?: listOf()
                Func.join(deptName)
            }
            vo.postName = if (u.postId.isNullOrBlank()) "" else postIdsToNames.computeIfAbsent(u.postId) {
                val postName = SysCache.getPostNames(u.postId) ?: listOf()
                Func.join(postName)
            }

            vo.sexName = if (u.sex == null) "" else sex2Name.computeIfAbsent(u.sex) {
                DictCache.getValue(DictEnum.SEX, u.sex) ?: ""
            }
            vo.userTypeName = if (u.userType == null) "" else userType2Name.computeIfAbsent(u.userType) {
                DictCache.getValue(DictEnum.USER_TYPE, u.userType) ?: ""
            }
            return@mapNotNull vo
        }
        return usersVo
    }

    override fun getUserIdsByPostCode(postCode: String, tenantId: String): List<Long> {
        val postId = BladeEnhancedCache.getPostIdByCode(postCode, tenantId) ?: return listOf()
        val users = userSearchClient.listByPost(postId.toString()).retrieve() ?: return listOf()
        return users.map { it.id }
    }

    override fun checkPasswordStrength(userId: Long): Boolean {
        val user = UserCache.getUser(userId) ?: throw ServiceException("用户不存在")
        val password = user.password
        val defaultPassword = ParamCache.getValue(CommonConstant.DEFAULT_PASSWORD) ?: "123456"
        val encryptDefaultPassword = DigestUtil.sha1Hex(DigestUtil.md5Hex(defaultPassword))
        return encryptDefaultPassword != password
    }

    override fun downloadOssFile(response: HttpServletResponse, fileName: String, originName: String?, isOnline: Boolean) {
        // 读到流中
        val url = URL(ossClient.fileLink(fileName).retrieve())
        val conn = url.openConnection()
        val inputStream : InputStream
        try {
            inputStream = conn.getInputStream()
        } catch (_: FileNotFoundException) {
            throw FileNotFoundException("文件不存在")
        }
        val name = (originName ?: fileName).substring((originName ?: fileName).lastIndexOf("/") + 1)
        response.reset()
        response.contentType = conn.contentType
        if (isOnline) {
            // 在线打开方式 文件名应该编码成UTF-8
            response.setHeader("Content-Disposition", "inline; filename=" + URLEncoder.encode(name, "UTF-8"))
        } else {
            //纯下载方式 文件名应该编码成UTF-8
            response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(name, "UTF-8"))
        }
        val outputStream = response.outputStream
        val buffer = ByteArray(1024)
        var len = inputStream.read(buffer)
        while (len != -1) {
            outputStream.write(buffer, 0, len)
            len = inputStream.read(buffer)
        }
        inputStream.close()
    }

    override fun getIdByPostCode(postCode: String, tenantId: String): Long? {
        val posts = SysCache.getPostsByCodes(tenantId, postCode)
        if (posts.isEmpty()) return null
        return posts[0].id
    }

    override fun getPostCodeByUserId(userId: Long): List<String> {
        val user = UserCache.getUser(userId) ?: return listOf()
        val postIds = Func.toLongList(user.postId)
        if (postIds.isNotEmpty()) {
            return postIds.mapNotNull { SysCache.getPost(it)?.postCode }
        }
        return listOf()
    }

    override fun getAllTenantIds(): List<String> {
        return SysCache.getAllTenants().map { it.tenantId }
    }
}
