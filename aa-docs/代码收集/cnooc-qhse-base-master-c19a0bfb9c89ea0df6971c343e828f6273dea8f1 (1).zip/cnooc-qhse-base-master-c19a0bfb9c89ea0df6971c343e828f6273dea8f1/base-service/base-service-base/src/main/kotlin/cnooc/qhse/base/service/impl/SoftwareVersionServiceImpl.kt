package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.SoftwareVersionMapper
import cnooc.qhse.base.pojo.entity.SoftwareVersion
import cnooc.qhse.base.service.ISoftwareVersionService
import cnooc.qhse.base.service.ISoftwareVersionService.Companion.TYPE_ANDROID
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl
import org.springframework.stereotype.Service

/**
 * 软件版本信息 服务实现类
 */
@Service
class SoftwareVersionServiceImpl : ServiceImpl<SoftwareVersionMapper, SoftwareVersion>(), ISoftwareVersionService {
    override val androidLatestVersion: SoftwareVersion?
        get() {
            val softwareVersions =
                this.list(KtQueryWrapper(SoftwareVersion::class.java).eq(SoftwareVersion::type, TYPE_ANDROID))
            if (softwareVersions.isEmpty()) {
                return null
            }
            softwareVersions.sortBy { it.toString().toInt() }
            return softwareVersions[softwareVersions.size - 1]
        }
}
