package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.AddressList
import cnooc.qhse.base.pojo.vo.NodeKtVO
import jakarta.servlet.http.HttpServletResponse

interface IBladeEnhancedService {
    /**
     * 获取树形部门选择结构，不包含顶部公司
     * @param tenantId 租户id
     */
    fun getDeptSelectTree(tenantId: String): List<NodeKtVO>

    /**
     * 获取通讯录树形结构
     *
     * @param tenantId 租户id
     * @return 通讯录树：机构下包含用户
     */
    fun addressList(tenantId: String): List<AddressList>

    /**
     * 根据职位code获取用户列表
     */
    fun getUserIdsByPostCode(postCode: String, tenantId: String): List<Long>

    /**
     * 根据职位code获取职位id
     */
    fun getIdByPostCode(postCode: String, tenantId: String): Long?

    /**
     * 获取用户的职位代码列表
     */
    fun getPostCodeByUserId(userId: Long): List<String>

    /**
     * 获取除了00000以外的所有租户id
     */
    fun getAllTenantIds(): List<String>

    /**
     * 密码强度校验
     */
    fun checkPasswordStrength(userId: Long): Boolean

    /**
     * Download oss file
     * @param response
     * @param fileName filename
     * @param originName 原始文件名
     * @param isOnline 文件在线打开还是下载。其Content-Disposition 会有区别
     */
    fun downloadOssFile(response: HttpServletResponse, fileName: String, originName: String?, isOnline: Boolean)
}
