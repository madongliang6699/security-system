package cnooc.qhse.base.excel

import cn.afterturn.easypoi.handler.inter.IExcelDataHandler
import cnooc.qhse.base.pojo.entity.AreaEntity
import org.apache.poi.ss.usermodel.CreationHelper
import org.apache.poi.ss.usermodel.Hyperlink
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache
import org.springblade.system.cache.UserCache

class AreaDataHandler : IExcelDataHandler<AreaEntity> {
    companion object {
        private const val DEPT = "责任部门"
        private const val USER = "责任人"
    }

    override fun exportHandler(obj: AreaEntity, name: String, value: Any?): Any? {
        if (value == null) {
            return null
        }
        return when (name) {
            DEPT -> Func.join(SysCache.getDeptNames(value as String))
            USER -> Func.join(Func.toLongList(value as String).map { UserCache.getUser(it) }.map { it.realName })
            else -> value
        }
    }

    private val needHandlerFields = arrayOf(DEPT, USER)

    override fun importHandler(obj: AreaEntity, name: String, value: Any?): Any? {
        return if (value == null || value.toString().isBlank()) {
            null
        } else when (name) {
            DEPT -> {
                val deptIds = SysCache.getDeptIds(AuthUtil.getTenantId(), value.toString())
                if (deptIds.isNullOrBlank()) {
                    throw ServiceException("不包含名称为${value}的部门")
                }
                return deptIds
            }
            USER -> {
                val ids = mutableListOf<Long>()
                Func.toStrList(value as String).forEach {
                    val users = UserCache.getUsersByNameOrAccount(AuthUtil.getTenantId(), it)
                    if (users.isNullOrEmpty()) {
                        throw ServiceException("无效的用户名或真实姓名：$it")
                    } else if (users.size > 1) {
                        throw ServiceException("重名用户，请使用用户名代替$it")
                    }
                    ids.add(users[0].id)
                }
                Func.join(ids.map { it.toString() })
            }
            else -> value
        }
    }

    override fun setMapValue(map: Map<String, Any>, originKey: String, value: Any) {}

    override fun getNeedHandlerFields(): Array<String> {
        return needHandlerFields
    }

    override fun setNeedHandlerFields(p0: Array<out String>?) {
    }

    override fun getHyperlink(p0: CreationHelper?, p1: AreaEntity?, p2: String?, p3: Any?): Hyperlink? = null
}
