package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.AttachmentMapper
import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.service.IAttachmentService
import cnooc.qhse.base.wrapper.AttachmentWrapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.common.utils.notNullRetrieve
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.oss.model.BladeFile
import org.springblade.core.tool.utils.FileUtil
import org.springblade.resource.feign.IOssClient
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import org.springframework.web.multipart.MultipartFile

/**
 * 附件 服务实现类
 */
@Service
class AttachmentServiceImpl(private val ossClient: IOssClient) :
    BaseServiceImplKt<AttachmentMapper, Attachment>(), IAttachmentService {

    override fun addAttachments(attachments: List<Attachment>): Boolean {
        if (attachments.isEmpty()) {
            return true
        }
        attachments.forEach {
            it.extension = FileUtil.getFileExtension(it.originalName)
            // 添加时清除以前的id
            it.id = null
        }
        return this.saveBatch(attachments)
    }

    override fun addAttachments(files: List<BladeFile>, businessId: String, fileUsage: String):
        List<AttachmentVO> {
        val attachments = files.withIndex().map {
            AttachmentVO(
                businessId = businessId,
                fileUsage = fileUsage,
                name = it.value.name,
                originalName = it.value.originalName,
                extension = FileUtil.getFileExtension(it.value.originalName),
                sort = it.index,
                link = it.value.link,
            )
        }
        addAttachments(attachments)
        return attachments
    }

    override fun addAttachments(tenantId: String, files: List<BladeFile>, businessId: String, fileUsage: String):
        List<AttachmentVO> {
        val attachments = files.withIndex().map {
            AttachmentVO(
                businessId = businessId,
                fileUsage = fileUsage,
                name = it.value.name,
                originalName = it.value.originalName,
                extension = FileUtil.getFileExtension(it.value.originalName),
                sort = it.index,
                link = it.value.link,
                tenantId = tenantId
            )
        }
        addAttachments(attachments)
        return attachments
    }

    override fun getAttachments(businessId: String, fileUsage: String): List<AttachmentVO> {
        val qw = KtQueryWrapper(Attachment::class.java).eq(Attachment::businessId, businessId)
            .eq(Attachment::fileUsage, fileUsage).orderByAsc(Attachment::sort)
        return AttachmentWrapper.build().listVO(this.list(qw))
    }

    override fun getAttachments(businessId: String): List<AttachmentVO> {
        val qw =
            KtQueryWrapper(Attachment::class.java).eq(Attachment::businessId, businessId).orderByDesc(Attachment::sort)
        return AttachmentWrapper.build().listVO(this.list(qw))
    }

    override fun getAttachments(businessIds: List<String>): List<AttachmentVO> {
        val qw = KtQueryWrapper(Attachment::class.java).`in`(Attachment::businessId, businessIds)
            .orderByAsc(Attachment::businessId, Attachment::sort)
        return AttachmentWrapper.build().listVO(this.list(qw))
    }

    override fun getAttachmentsIncludeDeleted(businessId: String, fileUsage: String): List<AttachmentVO> {
        val attachs = baseMapper.getAttachmentsIncludeDeleted(businessId, fileUsage)
        return AttachmentWrapper.build().listVO(attachs)
    }

    @Transactional
    override fun removeByBusinessIds(businessIds: List<String>): Boolean =
        this.removeByWrapper(KtQueryWrapper(Attachment::class.java).`in`(Attachment::businessId, businessIds))

    @Transactional
    override fun removeByBusinessesAndUsage(businessIds: List<String>, usage: String): Boolean =
        this.removeByWrapper(
            KtQueryWrapper(Attachment::class.java).`in`(Attachment::businessId, businessIds)
                .eq(Attachment::fileUsage, usage)
        )

    @Transactional
    override fun removeByIds(ids: List<Long>): Boolean =
        this.removeByWrapper(KtQueryWrapper(Attachment::class.java).`in`(Attachment::id, ids))

    private fun removeByWrapper(wrapper: KtQueryWrapper<Attachment>): Boolean {
        return this.remove(wrapper)
    }

    override fun putFileAndSaveAttachment(
        tenantId: String,
        fileName: String,
        file: MultipartFile,
        businessId: String,
        fileUsage: String
    ): AttachmentVO {
        val bladeFile = ossClient.putFileToTenant(tenantId, fileName, file).notNullRetrieve()
        return addAttachments(tenantId, listOf(bladeFile), businessId, fileUsage).first()
    }
}
