package cnooc.qhse.base.props

import org.springframework.boot.context.properties.ConfigurationProperties

/**
 * BaseProperties
 */
@ConfigurationProperties(prefix = "qhse.base")
data class BaseProperties (
    /**
     * 名称
     */
    private val name: String? = null
)
