package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.service.IAttachmentService
import cnooc.qhse.base.service.impl.DocTemplateServiceImpl
import cnooc.qhse.base.wrapper.AttachmentWrapper
import cnooc.qhse.common.vo.CascadeData
import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*

/**
 * 附件 控制器
 *
 * @author BladeX
 * @since 2020-02-27
 */
@RestController
@RequestMapping("/doc-template")
@Tag(name = "文档模板", description = "文档模板")
class DocTemplateController @Autowired constructor(private val attachmentService: IAttachmentService) {

    @GetMapping("/list-doc-template")
    @Operation(summary = "文档模板列表", description = "文档模板列表")
    fun listDocTemplates(query: Query?): R<IPage<AttachmentVO>> {
        val pages: IPage<Attachment> = attachmentService.page(
            Condition.getPage(query), KtQueryWrapper(Attachment::class.java)
                .eq(Attachment::tenantId, AuthUtil.getTenantId())
                .`in`(
                    Attachment::fileUsage,
                    DocTemplateServiceImpl.getAllTypes()
                )
        )
        return R.data(AttachmentWrapper.build().pageVO(pages))
    }

    @GetMapping("/doc-template-type")
    @Operation(summary = "文档模板类型，类型表示为: [{label: string, value: string, children: []}]", description = "文档模板类型，类型表示为: [{label: string, value: string, children: []}]")
    fun docTemplateTypes(): R<List<CascadeData>> {
        return R.data(DocTemplateServiceImpl.getUsageList())
    }

    @GetMapping("/doc-template-type-by-parent")
    @Operation(summary = "根据多个父值类型获取文档模板类型，类型表示为: [{label: string, value: string, children: []}]", description = "根据多个父值类型获取文档模板类型，类型表示为: [{label: string, value: string, children: []}]")
    fun docTemplateTypesByParentValues(@RequestParam parentValues: String): R<List<CascadeData>> {
        return R.data(DocTemplateServiceImpl.getUsageListByParentValue(Func.toStrList(parentValues)))
    }

    @PostMapping("/add-doc-template")
    @Operation(summary = "添加文档模板", description = "添加文档模板")
    fun addDocTemplate(@RequestBody attachment: Attachment): R<Boolean> {
        require(attachment.fileUsage != null)
        /* 设置businessId为当前租户id*/
        attachment.businessId = AuthUtil.getTenantId()
        attachment.fileUsageName = DocTemplateServiceImpl.getUsageName(attachment.fileUsage!!)
        return R.status(attachmentService.addAttachments(listOf(attachment)))
    }

    @DeleteMapping("/delete-doc-template")
    @Operation(summary = "删除文档模板", description = "删除文档模板")
    fun deleteDocTemplate(ids: String?): R<Boolean> {
        return R.status(attachmentService.removeByIds(Func.toLongList(ids)))
    }
}
