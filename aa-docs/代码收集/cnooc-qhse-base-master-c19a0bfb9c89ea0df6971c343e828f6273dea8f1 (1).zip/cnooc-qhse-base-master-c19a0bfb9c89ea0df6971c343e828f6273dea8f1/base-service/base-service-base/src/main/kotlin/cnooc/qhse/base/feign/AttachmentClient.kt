package cnooc.qhse.base.feign

import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import cnooc.qhse.base.service.IAttachmentService
import org.springblade.core.oss.model.BladeFile
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class AttachmentClient(private val attachmentService: IAttachmentService) : IAttachmentClient {
    override fun addAttachments(attachments: List<Attachment>): R<Boolean> {
        return R.data(attachmentService.addAttachments(attachments))
    }

    override fun addAttachments(
        files: List<BladeFile>,
        tenantId: String,
        businessId: String,
        fileUsage: String
    ): R<List<AttachmentVO>> {
        return R.data(attachmentService.addAttachments(tenantId, files, businessId, fileUsage))
    }

    override fun getAttachments(businessId: String, fileUsage: String): R<List<AttachmentVO>> {
        return R.data(attachmentService.getAttachments(businessId, fileUsage))
    }

    override fun getAttachments(businessId: String): R<List<AttachmentVO>> {
        return R.data(attachmentService.getAttachments(businessId))
    }

    override fun getAttachments(businessIds: List<String>): R<List<AttachmentVO>> {
        return R.data(attachmentService.getAttachments(businessIds))
    }

    override fun getAttachmentsIncludeDeleted(
        businessId: String,
        fileUsage: String
    ): R<List<AttachmentVO>> {
        return R.data(attachmentService.getAttachmentsIncludeDeleted(businessId, fileUsage))
    }

    override fun removeByBusinessIds(businessIds: List<String>): R<Boolean> {
        return R.data(attachmentService.removeByBusinessIds(businessIds))
    }

    override fun removeByBusinessesAndUsage(businessIds: List<String>, fileUsage: String): R<Boolean> {
        return R.data(attachmentService.removeByBusinessesAndUsage(businessIds, fileUsage))
    }

    override fun removeByIds(ids: List<Long>): R<Boolean> {
        return R.data(attachmentService.removeByIds(ids))
    }
}
