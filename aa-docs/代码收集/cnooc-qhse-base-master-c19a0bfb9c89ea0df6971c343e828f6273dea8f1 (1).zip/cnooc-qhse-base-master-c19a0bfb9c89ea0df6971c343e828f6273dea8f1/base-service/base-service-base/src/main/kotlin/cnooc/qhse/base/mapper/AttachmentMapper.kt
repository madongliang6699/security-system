package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.Attachment
import com.baomidou.mybatisplus.core.mapper.BaseMapper
import org.apache.ibatis.annotations.Param

/**
 * 附件 Mapper 接口
 */
interface AttachmentMapper : BaseMapper<Attachment>{

    fun getAttachmentsIncludeDeleted(
        @Param("businessId")
        businessId: String,
        @Param("fileUsage")
        fileUsage: String
    ): List<Attachment>
}
