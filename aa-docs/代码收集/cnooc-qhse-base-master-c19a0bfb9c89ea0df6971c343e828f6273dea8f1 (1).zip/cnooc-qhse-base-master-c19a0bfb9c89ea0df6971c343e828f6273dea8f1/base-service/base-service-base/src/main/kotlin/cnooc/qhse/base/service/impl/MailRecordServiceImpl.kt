package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.MailRecordMapper
import cnooc.qhse.base.pojo.entity.MailRecord
import cnooc.qhse.base.service.IMailRecordService
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl
import org.springframework.stereotype.Service

/**
 * app报错服务类
 */
@Service
class MailRecordServiceImpl: ServiceImpl<MailRecordMapper, MailRecord>(), IMailRecordService {
}
