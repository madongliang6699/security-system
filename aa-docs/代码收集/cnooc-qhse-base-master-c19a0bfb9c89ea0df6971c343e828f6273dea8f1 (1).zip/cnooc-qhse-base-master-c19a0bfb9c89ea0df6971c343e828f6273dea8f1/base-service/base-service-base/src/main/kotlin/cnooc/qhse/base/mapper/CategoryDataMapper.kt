package cnooc.qhse.base.mapper

import cnooc.qhse.base.pojo.entity.CategoryData
import com.baomidou.mybatisplus.core.mapper.BaseMapper

interface CategoryDataMapper : BaseMapper<CategoryData>
