package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.AppErrorMapper
import cnooc.qhse.base.pojo.entity.AppError
import cnooc.qhse.base.service.IAppErrorService
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl
import org.springframework.stereotype.Service


/**
 * app报错服务类
 */
@Service
class AppErrorServiceImpl : ServiceImpl<AppErrorMapper, AppError>(), IAppErrorService {
}
