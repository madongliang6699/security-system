package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.ShiftCache
import cnooc.qhse.base.pojo.entity.Shift
import cnooc.qhse.base.pojo.vo.ShiftVO
import cnooc.qhse.base.service.IShiftService
import cnooc.qhse.base.wrapper.ShiftWrapper
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

/**
 * 交接班 控制器
 */
@RestController
@RequestMapping("/shift")
@Tag(name = "交接班", description = "交接班接口")
class ShiftController(private val shiftService: IShiftService) : BladeController() {

    /**
     * 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    @PreAuth("hasPermission('shift:view')")
    fun detail(shift: Shift): R<ShiftVO> {
        val detail = shiftService.getOne(Condition.getQueryWrapper(shift)) ?: return R.fail("交接班岗位不存在")
        return R.data(ShiftWrapper.build().entityVO(detail))
    }

    @GetMapping("/dict")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "编码与名称字典表")
    fun dict(): R<List<Shift>> {
        val shifts: List<Shift> = shiftService.list(
            KtQueryWrapper(Shift::class.java).eq(Shift::tenantId, AuthUtil.getTenantId())
                .select(Shift::code, Shift::name)
        )
        return R.data(shifts)
    }

    /**
     * 分页 交接班
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "分页")
    fun list(shift: Shift, query: Query): R<IPage<ShiftVO>> {
        val qw = Condition.getQueryWrapper(shift)
        // 默认以创建时间排序
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(Shift::createTime.toColumn())
        }
        val pages = shiftService.page<IPage<Shift>>(Condition.getPage(query), qw)
        return R.data(ShiftWrapper.build().pageVO(pages))
    }

    /**
     * 新增 交接班
     */
    @PostMapping("/save")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增", description = "新增")
    @PreAuth("hasPermission('shift:add')")
    fun save(@RequestBody @Valid shift: Shift): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        return R.status(shiftService.save(shift))
    }

    /**
     * 修改 交接班
     */
    @PostMapping("/update")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "修改", description = "修改")
    @PreAuth("hasPermission('shift:edit')")
    fun update(@RequestBody @Valid shift: Shift): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        return R.status(shiftService.updateById(shift))
    }

    /**
     * 新增或修改 交接班
     */
    @PostMapping("/submit")
    @ApiOperationSupport(order = 6)
    @Operation(summary = "新增或修改", description = "新增或修改")
    @PreAuth("hasPermission('shift:edit')")
    fun submit(@RequestBody @Valid shift: Shift): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        return R.status(shiftService.saveOrUpdate(shift))
    }

    /**
     * 删除 交接班
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasPermission('shift:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam id: Long): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        return R.status(shiftService.deleteShift(id))
    }

    @PostMapping("/set-self")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "自主绑定", description = "自主绑定")
    @PreAuth("hasPermission('shift:self')")
    fun setSelf(@Parameter(description = "id", required = true) @RequestParam id: Long): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        shiftService.acceptShift(id)
        return R.success("设置成功")
    }

    @PostMapping("/assign")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "指定", description = "指定")
    @PreAuth("hasPermission('shift:assign')")
    fun assign(@Parameter(description = "id", required = true) @RequestParam id: Long, @RequestParam userId: Long): R<Boolean> {
        CacheUtil.clear(ShiftCache.SHIFT_CACHE)
        shiftService.giveShift(id, userId)
        return R.success("设置成功")
    }

    @GetMapping("/get-record")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "获取工作日志", description = "获取工作日志")
    @PreAuth("hasPermission('shift:view')")
    fun getRecord(@Parameter(description = "id", required = true) @RequestParam id: Long): R<String> {
        return R.data(shiftService.getRecord(id))
    }

    @PostMapping("/save-record")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "保存工作日志", description = "保存工作日志")
    @PreAuth("hasPermission('shift:edit')")
    fun saveRecord(@RequestBody shift: Shift): R<Boolean> {
        require(shift.id != null) { "id不能为空" }
        require(!shift.record.isNullOrBlank()) { "id不能为空" }
        return R.status(shiftService.saveRecord(shift.id!!, shift.record!!))
    }
}
