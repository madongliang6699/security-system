package cnooc.qhse.base.service.impl

import cnooc.qhse.base.mapper.FieldConfigMapper
import cnooc.qhse.base.pojo.entity.FieldConfig
import cnooc.qhse.base.service.IFieldConfigService
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import org.springframework.stereotype.Service

/**
 * 字段控制表 服务实现类
 */
@Service
class FieldConfigServiceImpl : BaseServiceImplKt<FieldConfigMapper, FieldConfig>(), IFieldConfigService
