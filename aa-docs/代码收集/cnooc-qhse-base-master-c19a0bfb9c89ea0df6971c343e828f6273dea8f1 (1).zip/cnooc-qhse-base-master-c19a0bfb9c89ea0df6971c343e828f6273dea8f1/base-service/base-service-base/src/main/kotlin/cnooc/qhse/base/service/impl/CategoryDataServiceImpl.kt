package cnooc.qhse.base.service.impl

import cn.afterturn.easypoi.excel.ExcelImportUtil
import cn.afterturn.easypoi.excel.entity.ImportParams
import cnooc.qhse.base.cache.CategoryDataCache
import cnooc.qhse.base.constant.BaseConstant.CATEGORY_CODE_LENGTH
import cnooc.qhse.base.constant.BaseConstant.EARNEST_CATEGORY
import cnooc.qhse.base.mapper.CategoryDataMapper
import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.base.service.ICategoryDataService
import cnooc.qhse.base.wrapper.CategoryDataWrapper
import cnooc.qhse.common.constants.CommonConstant
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.common.utils.PostCodeUtil
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.apache.logging.log4j.util.Strings
import org.springblade.core.log.exception.ServiceException
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.StringPool
import org.springblade.system.cache.DictCache
import org.springframework.stereotype.Service
import org.springframework.web.multipart.MultipartFile

/**
 * 数据分类实现类
 */
@Service
class CategoryDataServiceImpl : BaseServiceImplKt<CategoryDataMapper, CategoryData>(), ICategoryDataService {
    override fun getByCode(code: String, tenantId: String): CategoryData? {
        return this.getOne(
            KtQueryWrapper(CategoryData::class.java)
                .eq(CategoryData::categoryCode, code).eq(CategoryData::tenantId, tenantId)
        )
    }

    override fun getByName(name: String, tenantId: String): List<CategoryData> {
        return this.list(
            KtQueryWrapper(CategoryData::class.java)
                .eq(CategoryData::categoryName, name).eq(CategoryData::tenantId, tenantId)
        )
    }

    override fun getByName(ancestorCode: String, name: String, tenantId: String): CategoryData? {
        return this.getOne(
            KtQueryWrapper(CategoryData::class.java).likeRight(
                CategoryData::categoryCode,
                ancestorCode
            ).eq(CategoryData::categoryName, name).eq(CategoryData::tenantId, tenantId)
        )
    }

    override fun getCategoryPathName(code: String, tenantId: String): String? {
        val category = getByCode(code, tenantId)
        category ?: return null

        return getPaths(category).joinToString(CommonConstant.PathSplitter)
    }

    override fun getCategoryPathName(id: Long): String? {
        val category = CategoryDataCache.getCategory(id)
        category ?: return null

        return getPaths(category).joinToString(CommonConstant.PathSplitter)
    }

    private fun getPaths(category: CategoryData) : List<String> {
        val categoryNames = mutableListOf<String>()
        categoryNames.add(category.categoryName!!)

        var cat : CategoryData? = category
        while (cat!!.parentId != BladeConstant.TOP_PARENT_ID) {
            cat = CategoryDataCache.getCategory(cat.parentId!!)
            cat ?: throw ServiceException("父级分类不存在")
            // 分类的最顶级不显示，比如A01代表隐患分类
            if (cat.categoryCode!!.length > CATEGORY_CODE_LENGTH) {
                categoryNames.add(cat.categoryName!!)
            }
        }
        categoryNames.reverse()
        return categoryNames
    }

    override fun getCategoryList(rootCode: String, tenantId: String): List<CategoryData> {
        // 根据别名查询顶级编号
        val code = parseRootCode(rootCode)
        // 获取根
        return this.list(
            KtQueryWrapper(CategoryData::class.java)
                .likeRight(CategoryData::categoryCode, code)
                .ne(CategoryData::categoryCode, code)
                .eq(CategoryData::tenantId, tenantId)
        )
    }

    /**
     * 因为内置分类的代号有些是内置的，所以需要通过字典解析不同分类的代号。通过这个函数，能可以使用字典名称来代替形如A01的编码
     * @param rootCode 分类名称
     * @return 根邮编
     */
    private fun parseRootCode(rootCode: String): String {
        val code = DictCache.getValue(EARNEST_CATEGORY, rootCode)
        return if (Strings.isBlank(code)) rootCode else code
    }

    override fun tree(tenantId: String): List<CategoryDataVO> {
        val categories = this.list(KtQueryWrapper(CategoryData::class.java).eq(CategoryData::tenantId, tenantId))
        return CategoryDataWrapper.build().listNodeVO(categories)
    }

    override fun singleTree(rootCode: String, tenantId: String): List<CategoryDataVO> {
        return CategoryDataWrapper.build().listNodeVO(getCategoryList(rootCode, tenantId))
    }

    override fun removeCategories(ids: List<Long>): Boolean {
        val qw = KtQueryWrapper(CategoryData::class.java).`in`(CategoryData::id, ids)
        for (id in ids) {
            qw.or().like(CategoryData::ancestors, id)
        }
        return this.remove(qw)
    }

    override fun submit(category: CategoryData): Boolean {
        if (category.parentId == null) {
            category.parentId = BladeConstant.TOP_PARENT_ID
            category.ancestors = "0"
        }
        if (category.parentId!! > 0) {
            val parent = getById(category.parentId)
            category.ancestors = parent.ancestors + StringPool.COMMA + category.parentId
        }
        category.isDeleted = BladeConstant.DB_NOT_DELETED
        return if (category.id == null) {
            addCategory(category)
        } else {
            updateById(category)
        }
    }

    private fun addCategory(category: CategoryData): Boolean {
        val categoryCode: String
        var categoryPid = BladeConstant.TOP_PARENT_ID
        var parentCode: String? = null
        if (category.parentId != null) {
            categoryPid = category.parentId

            //PID 不是根节点 说明需要设置父节点 hasChild 为1
            if (BladeConstant.TOP_PARENT_ID != categoryPid) {
                val parent = getById(categoryPid)
                parentCode = parent.categoryCode
            }
        }
        /*
		 * 分成三种情况
		 * 1.数据库无数据 调用YouBianCodeUtil.getNextYouBianCode(null);
		 * 2.添加子节点，无兄弟元素 YouBianCodeUtil.getSubYouBianCode(parentCode,null);
		 * 3.添加子节点有兄弟元素 YouBianCodeUtil.getNextYouBianCode(lastCode);
		 * */
        //找同类 确定上一个最大的code值
        val query = KtQueryWrapper(CategoryData::class.java)
            .eq(CategoryData::parentId, categoryPid)
            .orderByDesc(CategoryData::categoryCode)
        val list = this.list(query)
        categoryCode = if (list.isEmpty()) {
            if (BladeConstant.TOP_PARENT_ID == categoryPid) {
                //情况1
                PostCodeUtil.getNextPostCode(null)
            } else {
                //情况2
                PostCodeUtil.getSubPostCode(parentCode, null)
            }
        } else {
            //情况3
            PostCodeUtil.getNextPostCode(list[0].categoryCode)
        }
        category.categoryCode = categoryCode
        category.parentId = categoryPid
        return save(category)
    }

    override fun importExcel(file: MultipartFile): Int {
        val params = ImportParams()
        params.titleRows = 1
        params.headRows = 1
        return try {
            // orgCode编码长度
            var categories =
                ExcelImportUtil.importExcel<CategoryData>(file.inputStream, CategoryData::class.java, params)
            // 去除空行
            categories = categories.filterNot { it.categoryName.isNullOrBlank() }
            //按长度排序
            categories.sortBy { it.categoryCode!!.length }
            for (category in categories) {
                val code = category.categoryCode
                if (code!!.length > CATEGORY_CODE_LENGTH) {
                    val parentCode = code.substring(0, code.length - CATEGORY_CODE_LENGTH)
                    val queryWrapper =
                        KtQueryWrapper(CategoryData::class.java).eq(CategoryData::categoryCode, parentCode)
                    val parent = this.getOne(queryWrapper)
                    if (parent != null) {
                        category.parentId = parent.id
                        category.ancestors = parent.ancestors + StringPool.COMMA + category.parentId
                    } else {
                        category.parentId = BladeConstant.TOP_PARENT_ID
                        category.ancestors = "0"
                    }
                } else {
                    category.parentId = BladeConstant.TOP_PARENT_ID
                    category.ancestors = "0"
                }
                save(category)
            }
            categories.size
        } catch (e: Exception) {
            log.error(e.message, e)
            throw ServiceException("文件导入失败：" + e.message)
        }
    }
}
