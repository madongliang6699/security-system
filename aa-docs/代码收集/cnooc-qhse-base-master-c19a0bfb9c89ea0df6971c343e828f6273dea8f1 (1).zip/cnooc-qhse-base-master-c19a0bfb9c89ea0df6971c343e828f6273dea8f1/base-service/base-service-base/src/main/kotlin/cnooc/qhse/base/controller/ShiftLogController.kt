package cnooc.qhse.base.controller

import cnooc.qhse.base.pojo.entity.ShiftLog
import cnooc.qhse.base.pojo.vo.ShiftLogVO
import cnooc.qhse.base.service.IShiftLogService
import cnooc.qhse.base.wrapper.ShiftLogWrapper
import cnooc.qhse.common.utils.toColumn
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.web.bind.annotation.*
import springfox.documentation.annotations.ApiIgnore

/**
 * 交接班日志 控制器
 */
@RestController
@RequestMapping("/shift/log")
@Tag(name = "交接班日志", description = "交接班日志接口")
class ShiftLogController(
    private val shiftLogService: IShiftLogService
) : BladeController() {

    /**
     * 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "详情")
    @PreAuth("hasPermission('shift:log:view')")
    fun detail(shiftLog: ShiftLog): R<ShiftLogVO> {
        val detail: ShiftLog = shiftLogService.getOne(Condition.getQueryWrapper(shiftLog)) ?: return R.fail("数据不存在，请重新查询")
        return R.data(ShiftLogWrapper.build().entityVO(detail))
    }

    /**
     * 分页 交接班日志
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "分页")
    @PreAuth("hasPermission('shift:log:view')")
    fun list(@ApiIgnore @RequestParam shiftLog: Map<String, Any>, query: Query): R<IPage<ShiftLogVO>> {
        val qw = Condition.getQueryWrapper(shiftLog, ShiftLog::class.java)
        // 默认以创建时间排序
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(ShiftLog::createTime.toColumn())
        }
        val pages: IPage<ShiftLog> = shiftLogService.page(Condition.getPage(query), qw)
        return R.data(ShiftLogWrapper.build().pageVO(pages))
    }

    /**
     * 删除 交接班日志
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "逻辑删除")
    @PreAuth("hasPermission('shift:log:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String?): R<Boolean> {
        return R.status(shiftLogService.deleteLogic(Func.toLongList(ids)))
    }
}
