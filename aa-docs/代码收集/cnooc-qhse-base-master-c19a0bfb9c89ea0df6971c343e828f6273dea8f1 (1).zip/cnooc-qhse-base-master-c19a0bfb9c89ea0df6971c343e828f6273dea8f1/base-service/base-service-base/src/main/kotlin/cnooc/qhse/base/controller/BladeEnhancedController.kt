package cnooc.qhse.base.controller

import cnooc.qhse.base.cache.BladeEnhancedCache
import cnooc.qhse.base.pojo.entity.AddressList
import cnooc.qhse.base.pojo.vo.NodeKtVO
import cnooc.qhse.base.service.IBladeEnhancedService
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.Parameters
import io.swagger.v3.oas.annotations.tags.Tag
import jakarta.servlet.http.HttpServletResponse
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.api.R
import org.springblade.system.cache.DictBizCache
import org.springblade.system.pojo.entity.DictBiz
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/blade")
@Tag(name = "Blade加强", description = "Blade加强")
class BladeEnhancedController @Autowired constructor(
    private val bladeEnhancedService: IBladeEnhancedService,
) {
    /**
     * 获取树形部门选择结构，不包含顶部公司
     */
    @GetMapping("/dept/select-tree")
    @Operation(summary = "部门树形结构", description = "部门树形结构")
    fun tree(): R<List<NodeKtVO>> {
        return R.data(bladeEnhancedService.getDeptSelectTree(AuthUtil.getTenantId()))
    }

    /**
     * 获取通讯录树形结构
     */
    @GetMapping("/address-list")
    @Operation(summary = "树形结构", description = "树形结构")
    fun addressList(): R<List<AddressList>> {
        return R.data(BladeEnhancedCache.getAddressList(AuthUtil.getTenantId()))
    }

    /**
     * 获取字典
     */
    @GetMapping("/biz-dictionary")
    @ApiOperationSupport(order = 8)
    @Operation(summary = "获取字典", description = "获取字典")
    fun dictionary(code: String): R<List<DictBiz>> {
        val tree: List<DictBiz> = DictBizCache.getList(code) ?: listOf()
        return R.data(tree)
    }

    /**
     * 下载附件
     */
    @GetMapping("/download")
    @Operation(summary = "下载附件", description = "下载附件")
    @Parameters
    fun download(
        @Parameter(description = "文件名", required = true) @RequestParam fileName: String,
        @Parameter(description = "原始文件名", required = false) @RequestParam(required = false) originName: String?,
        @Parameter(description = "是否在线打开", required = false) @RequestParam(required = false) isOnLine: Boolean = false,
        response: HttpServletResponse
    ) {
        bladeEnhancedService.downloadOssFile(response, fileName, originName, isOnLine)
    }

    @GetMapping("/password-strength-check")
    @Operation(summary = "密码强度校验", description = "密码强度校验")
    fun passwordCheck(): R<Boolean> {
        return R.data(bladeEnhancedService.checkPasswordStrength(AuthUtil.getUserId()))
    }
}
