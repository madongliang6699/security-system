package cnooc.qhse.base.service

import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import cnooc.qhse.base.pojo.vo.CustomParameterVO
import cnooc.qhse.common.service.BaseServiceKt
import com.baomidou.mybatisplus.core.metadata.IPage


/**
 * 自定义参数表 服务类
 */
interface ICustomParameterService : BaseServiceKt<CustomParameterEntity> {
    /**
     * 自定义分页
     *
     * @param page
     * @param customParameter
     * @return
     */
    fun selectCustomParameterPage(
        page: IPage<CustomParameterVO>,
        customParameter: CustomParameterVO?
    ): IPage<CustomParameterVO>


}
