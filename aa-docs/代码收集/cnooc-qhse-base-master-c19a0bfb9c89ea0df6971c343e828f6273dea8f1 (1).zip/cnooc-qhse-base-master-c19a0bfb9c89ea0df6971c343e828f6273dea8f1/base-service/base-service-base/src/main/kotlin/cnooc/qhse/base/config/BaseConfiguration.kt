package cnooc.qhse.base.config


import cnooc.qhse.base.props.BaseProperties
import org.mybatis.spring.annotation.MapperScan
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.cloud.openfeign.EnableFeignClients
import org.springframework.context.annotation.ComponentScan
import org.springframework.context.annotation.Configuration

/**
 * 配置feign、mybatis包名、properties
 */
@Configuration(proxyBeanMethods = false)
@ComponentScan("org.springblade", "cnooc.qhse")
@EnableFeignClients("org.springblade", "cnooc.qhse")
@MapperScan("org.springblade.**.mapper.**", "cnooc.qhse.**.mapper.**")
@EnableConfigurationProperties(BaseProperties::class)
class BaseConfiguration
