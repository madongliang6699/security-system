package cnooc.qhse.guanliyun.http;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 管理云response实体
 *
 * @author zhuqinyang
 */
@NoArgsConstructor
@Data
public class GuanLiYunResponse<T> implements Serializable {

	@JsonProperty("code")
	private Integer code;
	@JsonProperty("msg")
	private String msg;
	@JsonProperty("data")
	private T data;
	@JsonProperty("status")
	private Integer status;
	@JsonProperty("error")
	private String error;
	@JsonIgnore
	private String requestResultStr;

	public static <Result> GuanLiYunResponse<Result> convert(GuanLiYunResponse<?> response, Result data) {
		GuanLiYunResponse<Result> tGuanLiYunResponse = new GuanLiYunResponse<>();
		tGuanLiYunResponse.code = response.getCode();
		tGuanLiYunResponse.msg = response.getMsg();
		tGuanLiYunResponse.status = response.getStatus();
		tGuanLiYunResponse.error = response.getError();
		tGuanLiYunResponse.requestResultStr = response.getRequestResultStr();
		tGuanLiYunResponse.data = data;
		return tGuanLiYunResponse;
	}
}
