package cnooc.qhse.guanliyun;

import cnooc.qhse.guanliyun.http.GuanLiYunResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.annotation.Resource;
import org.apache.hc.client5.http.classic.methods.*;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.BasicHttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpEntityContainer;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.utils.Exceptions;
import org.springblade.core.tool.utils.IoUtil;
import org.springblade.core.tool.utils.StringUtil;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Nullable;
import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.rmi.RemoteException;
import java.security.KeyStoreException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 管理云工具类
 *
 * @author zhuqinyang
 */
@EnableConfigurationProperties(GuanLiYunProperties.class)
public class GuanLiYunUtil {

	@Resource
	GuanLiYunProperties guanLiYunProperties;

	static Logger logger = LoggerFactory.getLogger(GuanLiYunUtil.class);

	private static CloseableHttpClient httpClient;

	static {
		try {
			final TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
			final SSLContext sslContext = SSLContexts.custom()
				.loadTrustMaterial(null, acceptingTrustStrategy)
				.build();
			final SSLConnectionSocketFactory sslsf =
				new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
			final Registry<ConnectionSocketFactory> socketFactoryRegistry =
				RegistryBuilder.<ConnectionSocketFactory>create()
					.register("https", sslsf)
					.register("http", new PlainConnectionSocketFactory())
					.build();

			final BasicHttpClientConnectionManager connectionManager =
				new BasicHttpClientConnectionManager(socketFactoryRegistry);
			// 通过HttpClientBuilder构建HttpClient并设置SSLSocketFactory
			httpClient = HttpClients.custom()
				.setConnectionManager(connectionManager)
				.build();
		} catch (Exception e) {
			logger.error("CloseableHttpClient初始化失败");
		}
	}

	protected <T> List<T> get(String url, String bodyStr, Map<String, String> header, Class<T> tClass) throws IOException, KeyStoreException, URISyntaxException {
		StringEntity requestEntity = new StringEntity(bodyStr);
		HttpCustomGet httpCustomGet = new HttpCustomGet("GET", new URI(url));
		httpCustomGet.setHeader("Content-Type", "application/json");
		if (header != null && !header.keySet().isEmpty()) {
			header.forEach(httpCustomGet::setHeader);
		}
		httpCustomGet.setEntity(requestEntity);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpCustomGet);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		if (guanLiYunResponse.getData() instanceof Collection) {
			String json = JsonUtil.toJson(guanLiYunResponse.getData());
			return JsonUtil.parseArray(json, tClass);
		}
		throw new RuntimeException(StringUtil.format("管理云返回结果解析data异常：{}", guanLiYunResponse.getRequestResultStr()));
	}

	protected <T> GuanLiYunResponse<T> getParamBodyEntity(String url, String bodyStr, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = this.disposeHeader(header, ContentType.APPLICATION_JSON);
		StringEntity requestEntity = new StringEntity(bodyStr);
		HttpCustomGet httpCustomGet = new HttpCustomGet("GET", new URI(url));
		header.forEach(httpCustomGet::setHeader);
		httpCustomGet.setEntity(requestEntity);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpCustomGet);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}

	protected <T> GuanLiYunResponse<T> getEntity(String url, Map<String, Object> params, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = this.disposeHeader(header, ContentType.APPLICATION_JSON);
		HttpGet httpGet = new HttpGet(new URI(appendParametersToURL(guanLiYunProperties.getHost() + url, params)));
		header.forEach(httpGet::setHeader);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpGet);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}


	protected <T> GuanLiYunResponse<T> putEntity(String url, String bodyStr, Map<String, Object> params, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = this.disposeHeader(header, ContentType.APPLICATION_JSON);
		HttpPut httpPut = new HttpPut(new URI(appendParametersToURL(guanLiYunProperties.getHost() + url, params)));
		header.forEach(httpPut::setHeader);
		this.disposeEntity(httpPut, bodyStr);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpPut);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}

	protected <T> GuanLiYunResponse<T> postEntity(String url, String bodyStr, Map<String, Object> params, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = this.disposeHeader(header, ContentType.APPLICATION_JSON);
		HttpPost httpPost = new HttpPost(new URI(appendParametersToURL(guanLiYunProperties.getHost() + url, params)));
		header.forEach(httpPost::setHeader);
		this.disposeEntity(httpPost, bodyStr);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpPost);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}

	protected <T> GuanLiYunResponse<T> postEntity(String url, String bodyStr, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		return this.postEntity(url, bodyStr, null, header, tClass);
	}

	protected <T> GuanLiYunResponse<T> postFormDataEntity(String url, Map<String, String> formData, MultipartFile multipartFile, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = header == null ? new java.util.HashMap<>() : header;
		// 构建多部分实体
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		//构建普通参数
		formData.forEach(builder::addTextBody);
		//添加文件
		builder.addBinaryBody("multipartFile", multipartFile.getInputStream(), ContentType.APPLICATION_OCTET_STREAM, multipartFile.getOriginalFilename());
		//添加文件
		HttpPost httpPost = new HttpPost(new URI(guanLiYunProperties.getHost() + url));
		header.put("Authorization", StringUtil.format("APPCODE {}", guanLiYunProperties.getAppCode()));
		header.forEach(httpPost::setHeader);
		httpPost.setEntity(builder.build());
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpPost);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}

	protected <T> GuanLiYunResponse<T> deleteEntity(String url, String bodyStr, Map<String, Object> params, Map<String, String> header, Class<T> tClass) throws IOException, URISyntaxException {
		header = this.disposeHeader(header, ContentType.APPLICATION_JSON);
		HttpCustomDelete httpDelete = new HttpCustomDelete("DELETE", new URI(appendParametersToURL(guanLiYunProperties.getHost() + url, params)));
		header.forEach(httpDelete::setHeader);
		this.disposeEntity(httpDelete, bodyStr);
		GuanLiYunResponse<?> guanLiYunResponse = this.execResponse(httpDelete);
		if (guanLiYunResponse.getCode() == null) {
			throw new RuntimeException("访问管理云失败");
		}
		return GuanLiYunResponse.convert(guanLiYunResponse, this.disposeData(guanLiYunResponse.getData(), tClass));
	}

	public <T> T downloadFile(String url, Map<String, Object> params, Map<String, String> header, HttpClientResponseHandler<T> handler) throws IOException, URISyntaxException {
		header = header == null ? new java.util.HashMap<>() : header;
		HttpGet httpCustomGet = new HttpGet(new URI(StringUtil.format("{}?bucketName={}&folderName={}&objectId={}"
			, guanLiYunProperties.getHost() + url
			, params.get("bucketName")
			, params.get("folderName")
			, params.get("objectId"))));

		httpCustomGet.setHeader("Content-Type", "application/json");
		header.put("Authorization", StringUtil.format("APPCODE {}", guanLiYunProperties.getAppCode()));
		header.forEach(httpCustomGet::setHeader);
		//访问管理云
		return this.exec(httpCustomGet, handler);
	}


	private <T> T exec(HttpUriRequest request, HttpClientResponseHandler<T> httpClientResponseHandler) {
		try {
			return httpClient.execute(request, httpClientResponseHandler);
		} catch (IOException e) {
			logger.error("请求管理云失败", e);
			throw Exceptions.unchecked(e);
		}
	}

	private @Nullable byte[] exec(HttpUriRequest request) {
		try (CloseableHttpResponse response = httpClient.execute(request)) {
			// 获取响应体
			HttpEntity entity = response.getEntity();
			if (entity == null) {
				throw new RuntimeException("访问管理云异常");
			}
			return IoUtil.readToByteArray(entity.getContent());
		} catch (IOException e) {
			logger.error("请求管理云失败", e);
			throw Exceptions.unchecked(e);
		}
	}

	private GuanLiYunResponse<?> execResponse(HttpUriRequest request) throws IOException {
		byte[] resultBytes = this.exec(request);
		if (resultBytes != null && resultBytes.length == 0) {
			throw new RemoteException("返回数据为空");
		}
		return this.extractResponseEntity(new String(resultBytes, StandardCharsets.UTF_8));
	}

	/**
	 * 从返回结果中提取管理员实体类
	 *
	 * @param resStr 返回结果
	 * @return response entity
	 */
	private GuanLiYunResponse<?> extractResponseEntity(String resStr) throws JsonProcessingException {
		GuanLiYunResponse<?> response = JsonUtil.parse(resStr, GuanLiYunResponse.class);
		response.setRequestResultStr(resStr);
		return response;
	}

	/**
	 * 处理请求头
	 *
	 * @param header 请求投
	 * @return
	 */
	private Map<String, String> disposeHeader(Map<String, String> header, ContentType contentType) {
		header = header == null ? new java.util.HashMap<>() : header;
		header.put("Authorization", StringUtil.format("APPCODE {}", guanLiYunProperties.getAppCode()));
		header.put("Content-Type", contentType.toString());
		return header;
	}

	/**
	 * 实现了发送Get请求还可以传Body
	 */
	public static class HttpCustomGet extends HttpUriRequestBase {

		public HttpCustomGet(String method, URI requestUri) {
			super(method, requestUri);
		}

		@Override
		public String getMethod() {
			return "GET";
		}
	}

	/**
	 * 实现了发送Get请求还可以传Body
	 */
	public static class HttpCustomDelete extends HttpUriRequestBase {
		public HttpCustomDelete(String method, URI requestUri) {
			super(method, requestUri);
		}

		@Override
		public String getMethod() {
			return "DELETE";
		}
	}

	public static String appendParametersToURL(String url, Map<String, Object> params) {
		if (params == null || params.isEmpty()) {
			return url;
		}

		StringBuilder urlBuilder = new StringBuilder(url);
		if (!url.contains("?")) {
			urlBuilder.append('?');
		} else if (!url.endsWith("&")) {
			urlBuilder.append('&');
		}

		for (Map.Entry<String, Object> entry : params.entrySet()) {
			urlBuilder.append(entry.getKey()).append('=').append(entry.getValue()).append('&');
		}

		// 移除最后多余的 '&'
		if (urlBuilder.charAt(urlBuilder.length() - 1) == '&') {
			urlBuilder.setLength(urlBuilder.length() - 1);
		}

		return urlBuilder.toString();
	}

	protected CloseableHttpClient getHttpClient() {
		return httpClient;
	}

	/**
	 * response是否成功
	 *
	 * @param response
	 * @return
	 */
	protected boolean isSuccess(GuanLiYunResponse response) {
		return response.getCode() != null && response.getCode() == 200;
	}

	private void disposeEntity(HttpEntityContainer httpEntityContainer, String body) {
		if (StringUtil.isBlank(body)) {
			return;
		}
		StringEntity requestEntity = new StringEntity(body);
		httpEntityContainer.setEntity(requestEntity);
	}

	private <T> T disposeData(Object data, Class<T> tClass) {
		// 检查 data 是否为 null
		if (data == null) {
			return null;
		}
		try {
			String json = JsonUtil.toJson(data);

			if (tClass.equals(String.class)) {
				return (T) json;
			} else {
				return JsonUtil.parse(json, tClass);
			}
		} catch (Exception e) {
			logger.error("转换json失败", e);
			// 处理解析异常
			throw new RuntimeException("转换json失败", e);
		}
	}
}
