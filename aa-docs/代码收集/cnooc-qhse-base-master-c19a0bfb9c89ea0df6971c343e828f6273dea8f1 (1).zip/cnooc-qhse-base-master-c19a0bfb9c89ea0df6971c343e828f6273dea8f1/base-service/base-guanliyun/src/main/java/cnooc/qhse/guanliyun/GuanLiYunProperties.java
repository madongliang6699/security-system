package cnooc.qhse.guanliyun;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 管理云参数
 *
 * @author zhuqinyang
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "guan-li-yun")
public class GuanLiYunProperties {

	/**
	 * 请求前缀
	 */
	private String host;

	/**
	 * appCode
	 */
	private String appCode;

}
