package cnooc.qhse.file.util;

/**
 * 文件名称提取工具
 *
 * @author zqy
 */
public class FileNameExtractor {
	public static String extractFileName(String content) {
		int startIndex = content.indexOf("filename=\"") + "filename=\"".length();
		int endIndex = content.indexOf("\"", startIndex);
		if (startIndex > 0 && endIndex > startIndex) {
			return content.substring(startIndex, endIndex);
		} else {
			return "文件名提取失败";
		}
	}
}
