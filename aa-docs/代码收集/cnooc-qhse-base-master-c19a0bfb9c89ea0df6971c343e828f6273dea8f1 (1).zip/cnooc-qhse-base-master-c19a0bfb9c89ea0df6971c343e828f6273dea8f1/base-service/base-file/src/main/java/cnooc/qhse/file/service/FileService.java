package cnooc.qhse.file.service;

import cnooc.qhse.file.pojo.dto.DeleteFileDTO;
import cnooc.qhse.file.pojo.dto.DownloadDTO;
import cnooc.qhse.file.pojo.dto.FileInfoDTO;
import cnooc.qhse.file.pojo.dto.FolderDTO;
import org.springblade.core.tool.api.R;
import org.springframework.http.ResponseEntity;

import java.util.List;

/**
 * 文件上传接口
 *
 * @author zhuqinyang
 */
public interface FileService {

	String APP_PREFIX = "/file";
	/**
	 * 用于业务系统在指定存储空间创建文件夹
	 */
	String FOLDER = APP_PREFIX + "/mcmp-file-api/folder";

	/**
	 * 文件上传
	 */
	String UPLOAD_FILE = APP_PREFIX + "/mcmp-file-api/file";

	/**
	 * 文件下载
	 */
	String DOWNLOAD_FILE = APP_PREFIX + "/mcmp-file-api/fileStream";

	/**
	 * 文件操作：删除
	 */
	String FILE = APP_PREFIX + "/mcmp-file-api/file";

	/**
	 * 用于业务系统在指定存储空间创建文件夹
	 *
	 * @param folder 文件夹信息
	 * @return 提示消息
	 */
	R<String> createFolder(FolderDTO folder);

	/**
	 * 用于业务系统获取指定存储空间中的文件夹清单
	 *
	 * @param folder 查询实体
	 * @return 指定父文件夹之下的全部文件夹（不含下级）
	 */
	R<List<String>> getFolders(FolderDTO folder);

	/**
	 * 用于业务系统向指定文件夹上传文件。
	 *
	 * @param fileInfo 文件实体
	 * @return 文件ID
	 */
	R<String> uploadFile(FileInfoDTO fileInfo);

	/**
	 * 用于业务系统下载指定文件或指定文件版本
	 *
	 * @param downloadDTO 下载文件实体
	 * @return 文件字节
	 */
	ResponseEntity<byte[]> downloadFile(DownloadDTO downloadDTO);

	/**
	 * 用于业务系统删除指定文件或指定文件版本
	 *
	 * @param deleteFileDTO 删除文件实体
	 * @return 删除文件结果
	 */
	R<String> deleteFile(DeleteFileDTO deleteFileDTO);
}
