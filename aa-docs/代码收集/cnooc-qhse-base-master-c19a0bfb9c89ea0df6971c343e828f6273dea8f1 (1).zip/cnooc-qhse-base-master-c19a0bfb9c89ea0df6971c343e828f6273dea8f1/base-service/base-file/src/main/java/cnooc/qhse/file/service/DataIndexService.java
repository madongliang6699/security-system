package cnooc.qhse.file.service;

import cnooc.qhse.file.pojo.dto.DataIndexBodyDTO;
import cnooc.qhse.file.pojo.dto.DataIndexDTO;
import cnooc.qhse.file.pojo.dto.DataIndexQueryDTO;
import cnooc.qhse.file.pojo.dto.DataIndexResponse;
import cnooc.qhse.file.pojo.entity.DataIndex;
import org.springblade.core.tool.api.R;

import java.util.List;

/**
 * 数据检索服务接口
 *
 * @author zhuqinyang
 */
public interface DataIndexService {

	String APP_PREFIX = "/datasearch-mock";
	/**
	 * 创建索引 put，检索数据 post
	 */
	String DATA_INDEX = APP_PREFIX + "/mcmp-file-search/dataIndex";
	/**
	 * 批量添加文档数据
	 */
	String INDEX_BULK_DATA = APP_PREFIX + "/mcmp-file-search/indexBulkData";
	/**
	 * 更新文档数据 put,删除文档数据 delete,查询文档数据 get,追加文档数据post
	 */
	String INDEX_DATA = APP_PREFIX + "/mcmp-file-search/indexData";


	/**
	 * 用于业务系统创建指定的 ES 数据索引，可指定覆盖或不覆盖原索引，不覆盖则返回已存在同名索引异常
	 *
	 * @param dataIndexDTO 索引名称和是否重写
	 * @return 是否成功
	 */
	R<String> createDataIndex(DataIndexDTO dataIndexDTO);

	/**
	 * 用于业务系统在指定数据索引中检索数据
	 *
	 * @param dataIndexQueryDTO    url查询条件
	 * @param dataIndexBodyDTOList 对应关键词与字段精确匹配的查询检索，多个 condition 为“与逻辑”条件关系
	 * @return 检索出来的数据
	 */
	R<List<DataIndexResponse>> searchDataIndex(DataIndexQueryDTO dataIndexQueryDTO, List<DataIndexBodyDTO> dataIndexBodyDTOList);

	/**
	 * 用于业务系统向指定数据索引追加一条检索数据，对应一个新的 ES Document 记录
	 *
	 * @param indexName 数据索引名称
	 * @param dataIndex JSON 格式检索数据
	 * @return 是否成功
	 */
	R<String> appendIndexData(String indexName, DataIndex dataIndex);

	/**
	 * 用于业务系统向指定数据索引更新检索数据
	 *
	 * @param indexName 数据索引名称
	 * @param dataIndex JSON 格式检索数据
	 * @return 操作结果
	 */
	R<String> updateIndexData(String indexName, DataIndex dataIndex);

	/**
	 * 用于业务系统向指定数据索引删除检索数据
	 *
	 * @param indexName 数据索引名称
	 * @param id        数据索引序号，对应 ES documentId
	 * @return 是否成功
	 */
	R<String> deleteIndexData(String indexName, String id);

	/**
	 * 用于业务系统在指定数据索引中查询某 document 的详细信息
	 *
	 * @param indexName 数据索引名称
	 * @param id        数据索引序号，对应 ES documentId
	 * @return JSON格式数据
	 */
	R<DataIndex> getIndexData(String indexName, String id);


}
