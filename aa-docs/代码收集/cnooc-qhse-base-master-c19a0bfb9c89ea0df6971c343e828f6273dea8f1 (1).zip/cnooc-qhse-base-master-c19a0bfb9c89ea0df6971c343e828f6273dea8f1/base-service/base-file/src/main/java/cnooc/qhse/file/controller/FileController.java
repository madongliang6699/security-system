package cnooc.qhse.file.controller;

import cnooc.qhse.file.feign.IFileStoreClient;
import cnooc.qhse.file.pojo.dto.DeleteFileDTO;
import cnooc.qhse.file.pojo.dto.DownloadDTO;
import cnooc.qhse.file.pojo.dto.FileInfoDTO;
import cnooc.qhse.file.pojo.dto.FolderDTO;
import cnooc.qhse.file.service.FileService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文件管理控制器
 *
 * @author zqy
 */
@RefreshScope
@RestController
@RequiredArgsConstructor
@Tag(name = "文件管理", description = "文件上传、下载等")
public class FileController implements IFileStoreClient {

	@Resource
	public FileService fileService;

	/**
	 * 新增文件夹
	 *
	 * @param folder 文件夹信息
	 * @return 新增文件夹结果
	 */
	@PostMapping(CREATE_FOLDER)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "新增文件夹", description = "新增文件夹")
	@Override
	public R<String> createFolder(@RequestBody FolderDTO folder) {
		return fileService.createFolder(folder);
	}

	/**
	 * 获取子文件夹
	 *
	 * @param folder 查询实体
	 * @return 子文件夹列表
	 */
	@Override
	@GetMapping(GET_FOLDERS)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "获取子文件夹", description = "获取子文件夹")
	public R<List<String>> getFolders(FolderDTO folder) {
		return fileService.getFolders(folder);
	}

	/**
	 * 上传文件
	 *
	 * @param file       文件
	 * @param bucketName 存储空间名称
	 * @param folderName 文件夹名称
	 * @return 上传结果
	 */
	@PostMapping(UPLOAD_FILE)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "上传文件", description = "上传文件")
	@Override
	public R<String> uploadFile(@RequestParam("file") MultipartFile file,
								@RequestParam("bucketName") String bucketName,
								@RequestParam("folderName") String folderName) {
		FileInfoDTO fileInfoDTO = new FileInfoDTO();
		fileInfoDTO.setBucketName(bucketName);
		fileInfoDTO.setFolderName(folderName);
		BladeUser user = AuthUtil.getUser();
		fileInfoDTO.setCreateUser(user != null ? user.getUserName() : "无用户名");
		fileInfoDTO.setMultipartFile(file);
		return fileService.uploadFile(fileInfoDTO);
	}

	/**
	 * 下载文件
	 *
	 * @param downloadDTO 下载文件实体
	 * @return 返回文件字节
	 */
	@Override
	@GetMapping(DOWNLOAD_FILE)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "下载文件", description = "下载文件")
	public ResponseEntity<byte[]> downloadFile(DownloadDTO downloadDTO) {
		return fileService.downloadFile(downloadDTO);
	}

	/**
	 * 删除文件
	 *
	 * @param deleteFileDTO 删除文件实体
	 * @return 删除文件结果
	 */
	@PostMapping(DELETE_FILE)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "删除文件", description = "删除文件")
	@Override
	public R<String> deleteFile(@RequestBody DeleteFileDTO deleteFileDTO) {
		return fileService.deleteFile(deleteFileDTO);
	}

}
