package cnooc.qhse.file.props;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * 文件配置参数
 *
 * @author Chill
 */
@Data
@ConfigurationProperties(prefix = "file-app")
public class FileProperties {
	/**
	 * 命名空间名称
	 */
	private String bucketName;
}
