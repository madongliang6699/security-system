package cnooc.qhse.file.excel;


import lombok.Data;

import java.util.Date;
import java.lang.Double;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.alibaba.excel.annotation.write.style.HeadRowHeight;
import java.io.Serializable;
import java.io.Serial;


/**
 * 附件存储表 Excel实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@ColumnWidth(25)
@HeadRowHeight(20)
@ContentRowHeight(18)
public class StoreExcel implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@ColumnWidth(20)
	@ExcelProperty("")
	private String tenantId;
	/**
	 * 
	 */
	@ColumnWidth(20)
	@ExcelProperty("")
	private Integer isDeleted;
	/**
	 * 业务主键
	 */
	@ColumnWidth(20)
	@ExcelProperty("业务主键")
	private String businessId;
	/**
	 * 业务类型
	 */
	@ColumnWidth(20)
	@ExcelProperty("业务类型")
	private String businessType;
	/**
	 * 管理云文件id
	 */
	@ColumnWidth(20)
	@ExcelProperty("管理云文件id")
	private String objectId;
	/**
	 * 文件大小
	 */
	@ColumnWidth(20)
	@ExcelProperty("文件大小")
	private Double fileSize;
	/**
	 * 文件名称
	 */
	@ColumnWidth(20)
	@ExcelProperty("文件名称")
	private String fileName;
	/**
	 * 源文件名称
	 */
	@ColumnWidth(20)
	@ExcelProperty("源文件名称")
	private String originalFileName;
	/**
	 * 文件扩展名
	 */
	@ColumnWidth(20)
	@ExcelProperty("文件扩展名")
	private String fileType;
	/**
	 * 存放管理云中的文件夹
	 */
	@ColumnWidth(20)
	@ExcelProperty("存放管理云中的文件夹")
	private String folderPath;

}
