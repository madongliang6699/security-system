package cnooc.qhse.file.service.impl;

import cnooc.qhse.file.pojo.dto.BucketDTO;
import cnooc.qhse.file.pojo.entity.Bucket;
import cnooc.qhse.file.service.BucketService;
import org.springblade.core.tool.api.R;
import org.springframework.stereotype.Service;

/**
 * 存储空间实现类
 *
 * @className: 存储空间
 * @author: zhuqinyang
 * @date: 2024/10/8 上午10:33
 * @Version: 1.0
 * @description:
 */
@Service
public class BucketServiceImpl implements BucketService {
	@Override
	public R<Boolean> createBucket(BucketDTO bucket) {
		return null;
	}

	@Override
	public R<Bucket> getBucketInfo(String bucketName) {
		return null;
	}
}
