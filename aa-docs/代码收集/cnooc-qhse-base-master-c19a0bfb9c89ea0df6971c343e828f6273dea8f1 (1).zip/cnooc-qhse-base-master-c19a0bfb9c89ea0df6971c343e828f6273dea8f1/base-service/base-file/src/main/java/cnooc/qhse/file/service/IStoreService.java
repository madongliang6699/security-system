package cnooc.qhse.file.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import cnooc.qhse.file.pojo.entity.StoreEntity;
import cnooc.qhse.file.pojo.vo.StoreVO;
import cnooc.qhse.file.excel.StoreExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseService;
import java.util.List;

/**
 * 附件存储表 服务类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public interface IStoreService extends BaseService<StoreEntity> {
	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param store
	 * @return
	 */
	IPage<StoreVO> selectStorePage(IPage<StoreVO> page, StoreVO store);


	/**
	 * 导出数据
	 *
	 * @param queryWrapper
	 * @return
	 */
	List<StoreExcel> exportStore(Wrapper<StoreEntity> queryWrapper);

	List<StoreExcel> queryByBusiness();

}
