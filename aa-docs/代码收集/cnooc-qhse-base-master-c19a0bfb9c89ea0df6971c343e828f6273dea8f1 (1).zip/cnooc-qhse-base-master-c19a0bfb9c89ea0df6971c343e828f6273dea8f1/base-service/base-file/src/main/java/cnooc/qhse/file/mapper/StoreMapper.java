package cnooc.qhse.file.mapper;

import cnooc.qhse.file.pojo.entity.StoreEntity;
import cnooc.qhse.file.pojo.vo.StoreVO;
import cnooc.qhse.file.excel.StoreExcel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.apache.ibatis.annotations.Param;
import java.util.List;

/**
 * 附件存储表 Mapper 接口
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public interface StoreMapper extends BaseMapper<StoreEntity> {

	/**
	 * 自定义分页
	 *
	 * @param page
	 * @param store
	 * @return
	 */
	List<StoreVO> selectStorePage(IPage page, StoreVO store);


	/**
	 * 获取导出数据
	 *
	 * @param queryWrapper
	 * @return
	 */
	List<StoreExcel> exportStore(@Param("ew") Wrapper<StoreEntity> queryWrapper);

}
