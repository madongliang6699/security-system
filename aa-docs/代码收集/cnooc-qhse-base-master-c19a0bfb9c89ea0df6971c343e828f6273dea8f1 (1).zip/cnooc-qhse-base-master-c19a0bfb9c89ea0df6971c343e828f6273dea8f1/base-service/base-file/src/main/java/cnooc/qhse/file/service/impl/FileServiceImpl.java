package cnooc.qhse.file.service.impl;

import cnooc.qhse.file.dto.DownLoadFileDTO;
import cnooc.qhse.file.pojo.dto.DeleteFileDTO;
import cnooc.qhse.file.pojo.dto.DownloadDTO;
import cnooc.qhse.file.pojo.dto.FileInfoDTO;
import cnooc.qhse.file.pojo.dto.FolderDTO;
import cnooc.qhse.file.service.FileService;
import cnooc.qhse.file.util.FileNameExtractor;
import cnooc.qhse.guanliyun.GuanLiYunUtil;
import cnooc.qhse.guanliyun.http.GuanLiYunResponse;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Exceptions;
import org.springblade.core.tool.utils.IoUtil;
import org.springblade.core.tool.utils.StringUtil;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 文件上传实现类
 *
 * @author zhuqinyang
 */
@Service
public class FileServiceImpl extends GuanLiYunUtil implements FileService {

	static Logger logger = LoggerFactory.getLogger(FileServiceImpl.class);

	@Override
	public R<String> createFolder(FolderDTO folder) {
		try {
			GuanLiYunResponse<Object> obj = super.postEntity(FOLDER, JSON.toJSONString(folder), null, Object.class);
			logger.info("创建文件夹结果：{}", obj);
			return isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建文件夹出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<List<String>> getFolders(FolderDTO folder) {
		try {
			GuanLiYunResponse<String> obj = super.getEntity(FOLDER, JSON.parseObject(JSON.toJSONString(folder)), null, String.class);
			logger.info("获取文件夹结果：{}", obj);
			return isSuccess(obj) ? R.data(JSONArray.parseArray(obj.getData(), String.class)) : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建文件夹出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<String> uploadFile(FileInfoDTO fileInfo) {
		try {
			Map<String, String> params = new HashMap<>();
			params.put("bucketName", fileInfo.getBucketName());
			params.put("folderName", fileInfo.getFolderName());
			params.put("createUser", fileInfo.getCreateUser());
			params.put("labelList", "业务附件");
			params.put("isNpl", fileInfo.getIsNpl() == null ? "false" : fileInfo.getIsNpl());

			GuanLiYunResponse<Object> obj = super.postFormDataEntity(UPLOAD_FILE, params, fileInfo.getMultipartFile(), null, Object.class);
			logger.info("创建文件夹结果：{}", obj);
			return isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建文件夹出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public ResponseEntity<byte[]> downloadFile(DownloadDTO downloadDTO) {
		try {
			Map<String, Object> paramMap = new HashMap<>() {{
				put("bucketName", downloadDTO.getBucketName());
				put("folderName", downloadDTO.getFolderName());
				put("objectId", downloadDTO.getObjectId());
			}};
			//下载文件
			DownLoadFileDTO tempDownloadFileDTO = super.downloadFile(DOWNLOAD_FILE
				, paramMap
				, null
				, responseHandler -> {
					Header filename = responseHandler.getHeader("Content-Disposition");
					HttpEntity entity = responseHandler.getEntity();
					if (entity == null) {
						throw new RuntimeException("返回体为空");
					}
					DownLoadFileDTO downLoadFileDTO = new DownLoadFileDTO();
					downLoadFileDTO.setFileName(URLDecoder.decode(FileNameExtractor.extractFileName(filename.getValue()), StandardCharsets.UTF_8));
					downLoadFileDTO.setFileBytes(IoUtil.readToByteArray(entity.getContent()));
					return downLoadFileDTO;
				});
			return this.downLoad(tempDownloadFileDTO);
		} catch (Exception e) {
			logger.error("下载文件出错", e);
			throw Exceptions.unchecked(e);
		}
	}

	@Override
	public R<String> deleteFile(DeleteFileDTO deleteFileDTO) {
		try {
			GuanLiYunResponse<Object> obj = super.deleteEntity(FILE, JSON.toJSONString(deleteFileDTO), null, null, Object.class);
			logger.info("删除文件结果：{}", obj);
			return isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建文件出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	/**
	 * 传到客户端
	 *
	 * @param downLoadFileDTO 设置请求头，返回ResponseEntity
	 */
	private ResponseEntity<byte[]> downLoad(DownLoadFileDTO downLoadFileDTO) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		headers.add("Content-Disposition", StringUtil.format("attachment;filename={}", URLEncoder.encode(downLoadFileDTO.getFileName(), StandardCharsets.UTF_8)));
		return ResponseEntity.ok().headers(headers).body(downLoadFileDTO.getFileBytes());
	}
}
