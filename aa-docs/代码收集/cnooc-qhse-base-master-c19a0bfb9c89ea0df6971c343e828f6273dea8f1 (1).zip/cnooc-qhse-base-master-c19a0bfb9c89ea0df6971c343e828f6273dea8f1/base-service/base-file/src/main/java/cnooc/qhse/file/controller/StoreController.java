package cnooc.qhse.file.controller;

import cnooc.qhse.file.excel.StoreExcel;
import cnooc.qhse.file.pojo.entity.StoreEntity;
import cnooc.qhse.file.pojo.vo.StoreVO;
import cnooc.qhse.file.service.IStoreService;
import cnooc.qhse.file.wrapper.StoreWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springblade.core.boot.ctrl.BladeController;
import org.springblade.core.excel.util.ExcelUtil;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.annotation.PreAuth;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.core.tool.constant.RoleConstant;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 附件存储表 控制器
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@RestController
@AllArgsConstructor
@RequestMapping("/store")
@Tag(name = "附件存储表", description = "附件存储表接口")
public class StoreController extends BladeController {

    private final IStoreService storeService;

    /**
     * 附件存储表 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入store")
    public R<StoreVO> detail(StoreEntity store) {
        StoreEntity detail = storeService.getOne(Condition.getQueryWrapper(store));
        return R.data(StoreWrapper.build().entityVO(detail));
    }

    /**
     * 附件存储表 分页
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入store")
    public R<IPage<StoreVO>> list(@Parameter(hidden = true) @RequestParam Map<String, Object> store, Query query) {
        IPage<StoreEntity> pages = storeService.page(Condition.getPage(query), Condition.getQueryWrapper(store, StoreEntity.class));
        return R.data(StoreWrapper.build().pageVO(pages));
    }

    /**
     * 附件存储表 自定义分页
     */
    @GetMapping("/page")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "分页", description = "传入store")
    public R<IPage<StoreVO>> page(StoreVO store, Query query) {
        IPage<StoreVO> pages = storeService.selectStorePage(Condition.getPage(query), store);
        return R.data(pages);
    }

    /**
     * 附件存储表 新增
     */
    @PostMapping("/save")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "新增", description = "传入store")
    public R save(@Valid @RequestBody StoreEntity store) {
        return R.status(storeService.save(store));
    }

    /**
     * 附件存储表 修改
     */
    @PostMapping("/update")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "修改", description = "传入store")
    public R update(@Valid @RequestBody StoreEntity store) {
        return R.status(storeService.updateById(store));
    }

    /**
     * 附件存储表 新增或修改
     */
    @PostMapping("/submit")
    @ApiOperationSupport(order = 6)
    @Operation(summary = "新增或修改", description = "传入store")
    public R submit(@Valid @RequestBody StoreEntity store) {
        return R.status(storeService.saveOrUpdate(store));
    }

    /**
     * 附件存储表 删除
     */
    @PostMapping("/remove")
    @ApiOperationSupport(order = 7)
    @Operation(summary = "逻辑删除", description = "传入ids")
    public R remove(@Parameter(description = "主键集合", required = true) @RequestParam String ids) {
        return R.status(storeService.deleteLogic(Func.toLongList(ids)));
    }


    /**
     * 导出数据
     */
    @PreAuth(RoleConstant.HAS_ROLE_ADMIN)
    @GetMapping("/export-store")
    @ApiOperationSupport(order = 9)
    @Operation(summary = "导出数据", description = "传入store")
    public void exportStore(@Parameter(hidden = true) @RequestParam Map<String, Object> store, BladeUser bladeUser, HttpServletResponse response) {
        QueryWrapper<StoreEntity> queryWrapper = Condition.getQueryWrapper(store, StoreEntity.class);
        //if (!AuthUtil.isAdministrator()) {
        //	queryWrapper.lambda().eq(Store::getTenantId, bladeUser.getTenantId());
        //}
        queryWrapper.lambda().eq(StoreEntity::getIsDeleted, BladeConstant.DB_NOT_DELETED);
        List<StoreExcel> list = storeService.exportStore(queryWrapper);
        ExcelUtil.export(response, "附件存储表数据" + DateUtil.time(), "附件存储表数据表", list, StoreExcel.class);
    }

}
