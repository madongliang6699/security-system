package cnooc.qhse.file.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 下载实体
 *
 * @author zqy
 */
@Data
@NoArgsConstructor
public class DownLoadFileDTO {
	private String fileName;

	private byte[] fileBytes;
}
