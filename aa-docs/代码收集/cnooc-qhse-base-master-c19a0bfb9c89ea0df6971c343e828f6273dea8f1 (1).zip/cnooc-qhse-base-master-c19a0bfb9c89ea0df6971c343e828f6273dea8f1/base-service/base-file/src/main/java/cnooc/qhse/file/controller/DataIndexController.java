package cnooc.qhse.file.controller;

import cnooc.qhse.file.feign.IDataIndexClient;
import cnooc.qhse.file.pojo.dto.*;
import cnooc.qhse.file.pojo.entity.DataIndex;
import cnooc.qhse.file.service.DataIndexService;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import org.springblade.core.tool.api.R;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 数据索引控制器
 *
 * @author zqy
 */
@RefreshScope
@RestController
@RequiredArgsConstructor
@Tag(name = "数据索引", description = "数据索引")
public class DataIndexController implements IDataIndexClient {

	@Resource
	private DataIndexService dataIndexService;

	/**
	 * 新增索引
	 *
	 * @param dataIndexDTO 索引名称和是否重写
	 * @return 新增索引结果
	 */
	@PostMapping(CREATE_DATA_INDEX)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "新增索引", description = "新增索引")
	@Override
	public R<String> createDataIndex(@RequestBody DataIndexDTO dataIndexDTO) {
		return dataIndexService.createDataIndex(dataIndexDTO);
	}

	/**
	 * 文档检索
	 *
	 * @param dataIndexQueryDTO url查询条件
	 * @param conditions        对应关键词与字段精确匹配的查询检索，多个 condition 为“与逻辑”条件关系
	 * @return 检索结果
	 */
	@PostMapping(SEARCH_DATA_INDEX)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "文档检索", description = "文档检索")
	@Override
	public R<List<DataIndexResponse>> searchDataIndex(DataIndexQueryDTO dataIndexQueryDTO, @RequestBody List<DataIndexBodyDTO> conditions) {
		return dataIndexService.searchDataIndex(dataIndexQueryDTO, conditions);
	}

	/**
	 * 新增文档
	 *
	 * @param indexDataDTO 新增数据实体类
	 * @return 返回新增结果
	 */
	@PostMapping(APPEND_INDEX_DATA)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "新增文档", description = "新增文档")
	@Override
	public R<String> appendIndexData(@RequestBody IndexDataDTO indexDataDTO) {
		DataIndex dataIndex = new DataIndex(indexDataDTO.getId(), indexDataDTO.getData());
		return dataIndexService.appendIndexData(indexDataDTO.getIndexName(), dataIndex);
	}

	/**
	 * 更新文档
	 *
	 * @param indexDataDTO 数据索引名称
	 * @return 返回更新结果
	 */
	@PostMapping(UPDATE_INDEX_DATA)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "新增文档", description = "新增文档")
	@Override
	public R<String> updateIndexData(@RequestBody IndexDataDTO indexDataDTO) {
		DataIndex dataIndex = new DataIndex(indexDataDTO.getId(), indexDataDTO.getData());
		return dataIndexService.updateIndexData(indexDataDTO.getIndexName(), dataIndex);
	}

	/**
	 * 删除文档
	 *
	 * @param indexDataDTO 要删除的索引信息，indexName、id
	 * @return 返回删除结果
	 */
	@PostMapping(DELETE_INDEX_DATA)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "删除文档", description = "删除文档")
	@Override
	public R<String> deleteIndexData(@RequestBody IndexDataDTO indexDataDTO) {
		return dataIndexService.deleteIndexData(indexDataDTO.getIndexName(), indexDataDTO.getId());
	}

	/**
	 * 查询文档
	 *
	 * @param indexDataDTO 要查询的索引信息，indexName、id
	 * @return 返回具体某一个文档
	 */
	@GetMapping(QUERY_INDEX_DATA)
	@ApiOperationSupport(order = 1)
	@Operation(summary = "查询文档", description = "查询文档")
	@Override
	public R<DataIndex> queryIndexData(IndexDataDTO indexDataDTO) {
		return dataIndexService.getIndexData(indexDataDTO.getIndexName(), indexDataDTO.getId());
	}
}
