package cnooc.qhse.file.config;


import cnooc.qhse.file.props.FileProperties;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * 配置feign、mybatis包名、properties
 *
 * @author Chill
 */
@Configuration(proxyBeanMethods = false)
@ComponentScan({"org.springblade", "cnooc.qhse"})
@EnableFeignClients({"org.springblade", "cnooc.qhse"})
@MapperScan({"org.springblade.**.mapper.**", "cnooc.qhse.**.mapper.**"})
@EnableConfigurationProperties(FileProperties.class)
public class FileConfiguration {

}
