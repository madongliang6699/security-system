package cnooc.qhse.file.service.impl;

import cnooc.qhse.file.pojo.entity.StoreEntity;
import cnooc.qhse.file.pojo.vo.StoreVO;
import cnooc.qhse.file.excel.StoreExcel;
import cnooc.qhse.file.mapper.StoreMapper;
import cnooc.qhse.file.service.IStoreService;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import org.springblade.core.mp.base.BaseServiceImpl;
import java.util.List;

/**
 * 附件存储表 服务实现类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Service
public class StoreServiceImpl extends BaseServiceImpl<StoreMapper, StoreEntity> implements IStoreService {

	@Override
	public IPage<StoreVO> selectStorePage(IPage<StoreVO> page, StoreVO store) {
		return page.setRecords(baseMapper.selectStorePage(page, store));
	}


	@Override
	public List<StoreExcel> exportStore(Wrapper<StoreEntity> queryWrapper) {
		List<StoreExcel> storeList = baseMapper.exportStore(queryWrapper);
		//storeList.forEach(store -> {
		//	store.setTypeName(DictCache.getValue(DictEnum.YES_NO, Store.getType()));
		//});
		return storeList;
	}

	@Override
	public List<StoreExcel> queryByBusiness() {
		return List.of();
	}

}
