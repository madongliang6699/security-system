package cnooc.qhse.file.wrapper;

import org.springblade.core.mp.support.BaseEntityWrapper;
import org.springblade.core.tool.utils.BeanUtil;
import cnooc.qhse.file.pojo.entity.StoreEntity;
import cnooc.qhse.file.pojo.vo.StoreVO;
import java.util.Objects;

/**
 * 附件存储表 包装类,返回视图层所需的字段
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
public class StoreWrapper extends BaseEntityWrapper<StoreEntity, StoreVO>  {

	public static StoreWrapper build() {
		return new StoreWrapper();
 	}

	@Override
	public StoreVO entityVO(StoreEntity store) {
		StoreVO storeVO = Objects.requireNonNull(BeanUtil.copyProperties(store, StoreVO.class));

		//User createUser = UserCache.getUser(store.getCreateUser());
		//User updateUser = UserCache.getUser(store.getUpdateUser());
		//storeVO.setCreateUserName(createUser.getName());
		//storeVO.setUpdateUserName(updateUser.getName());

		return storeVO;
	}


}
