package cnooc.qhse.file.service;

import cnooc.qhse.file.pojo.dto.BucketDTO;
import cnooc.qhse.file.pojo.entity.Bucket;
import org.springblade.core.tool.api.R;

/**
 * 存储空间接口
 *
 * @className: 文件上传
 * @author: zhuqinyang
 * @date: 2024/10/8 上午10:33
 * @Version: 1.0
 * @description:
 */
public interface BucketService {

	/**
	 * 创建存储空间
	 *
	 * @param bucket 存储空间实体
	 * @return 是否成功
	 */
	R<Boolean> createBucket(BucketDTO bucket);

	/**
	 * 删除存储空间
	 *
	 * @param bucketName 存储空间名称
	 * @return 是否成功
	 */
	R<Bucket> getBucketInfo(String bucketName);


}
