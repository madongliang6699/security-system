package cnooc.qhse.file.service.impl;

import cnooc.qhse.file.pojo.dto.DataIndexBodyDTO;
import cnooc.qhse.file.pojo.dto.DataIndexDTO;
import cnooc.qhse.file.pojo.dto.DataIndexQueryDTO;
import cnooc.qhse.file.pojo.dto.DataIndexResponse;
import cnooc.qhse.file.pojo.entity.DataIndex;
import cnooc.qhse.file.service.DataIndexService;
import cnooc.qhse.guanliyun.GuanLiYunUtil;
import cnooc.qhse.guanliyun.http.GuanLiYunResponse;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据检索服务
 *
 * @author zhuqinyang
 */
@Service
public class DataIndexServiceImpl extends GuanLiYunUtil implements DataIndexService {

	static Logger logger = LoggerFactory.getLogger(DataIndexServiceImpl.class);


	@Override
	public R<String> createDataIndex(DataIndexDTO dataIndexDTO) {
		try {
			Map<String, Object> paramMap = new HashMap<>() {{
				put("indexName", dataIndexDTO.getIndexName());
				put("overwrite", Func.toStr(dataIndexDTO.getOverwrite(), "true"));
			}};
			GuanLiYunResponse<Object> obj = super.putEntity(DATA_INDEX, null, paramMap, null, Object.class);
			logger.info("创建索引结果：{}", obj);
			return this.isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建索引出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<List<DataIndexResponse>> searchDataIndex(DataIndexQueryDTO dataIndexQueryDTO, List<DataIndexBodyDTO> dataIndexBodyDTOList) {
		try {
			GuanLiYunResponse<String> obj = super.postEntity(DATA_INDEX, null, JSON.parseObject(JSON.toJSONString(dataIndexQueryDTO)), null, String.class);
			logger.info("文档检索结果：{}", obj);
			return this.isSuccess(obj) ? R.data(JSONArray.parseArray(obj.getData(), DataIndexResponse.class)) : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("文档检索出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<String> appendIndexData(String indexName, DataIndex dataIndex) {
		try {
			JSONObject body = new JSONObject(3);
			body.put("indexName", indexName);
			body.put("id", dataIndex.getId());
			body.put("indexData", dataIndex);
			GuanLiYunResponse<Object> obj = super.postEntity(INDEX_DATA, body.toJSONString(), null, Object.class);
			logger.info("文档追加结果：{}", obj);
			return this.isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("文档追加出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<String> updateIndexData(String indexName, DataIndex dataIndex) {
		try {
			JSONObject body = new JSONObject(3);
			body.put("indexName", indexName);
			body.put("id", dataIndex.getId());
			body.put("indexData", dataIndex);
			GuanLiYunResponse<Object> obj = super.putEntity(INDEX_DATA, body.toJSONString(), null, null, Object.class);
			logger.info("更新文档结果：{}", obj);
			return this.isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("更新文档出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<String> deleteIndexData(String indexName, String id) {
		try {
			Map<String, Object> params = new HashMap<>() {{
				put("indexName", indexName);
				put("id", id);
			}};
			GuanLiYunResponse<Object> obj = super.deleteEntity(INDEX_DATA, null, params, null, Object.class);
			logger.info("删除文件结果：{}", obj);
			return isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("创建文件出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}

	@Override
	public R<DataIndex> getIndexData(String indexName, String id) {
		try {
			Map<String, Object> params = new HashMap<>() {{
				put("indexName", indexName);
				put("Id", id);
			}};
			GuanLiYunResponse<Object> obj = super.getEntity(INDEX_DATA, params, null, Object.class);
			logger.info("查询文档数据结果：{}", obj);
			return isSuccess(obj) ? R.success("操作成功") : R.fail(obj.getRequestResultStr());
		} catch (Exception e) {
			logger.error("查询文档数据出错", e);
			return R.fail("操作失败：" + e.getMessage());
		}
	}
}
