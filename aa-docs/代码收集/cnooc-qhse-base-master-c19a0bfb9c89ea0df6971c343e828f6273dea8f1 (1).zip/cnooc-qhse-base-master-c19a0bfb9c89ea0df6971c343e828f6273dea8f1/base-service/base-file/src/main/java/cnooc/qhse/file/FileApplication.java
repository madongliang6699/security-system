package cnooc.qhse.file;

import org.springblade.core.cloud.client.BladeCloudApplication;
import org.springblade.core.launch.BladeApplication;

/**
 * Demo启动器
 *
 * @author Chill
 */
@BladeCloudApplication
public class FileApplication {

	public static void main(String[] args) {
		BladeApplication.run("cnooc-qhse-file", FileApplication.class, args);
	}

}

