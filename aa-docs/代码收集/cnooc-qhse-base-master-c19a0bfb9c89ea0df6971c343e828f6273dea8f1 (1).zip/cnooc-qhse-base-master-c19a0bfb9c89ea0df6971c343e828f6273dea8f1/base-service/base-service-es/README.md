# 1.配置信息

```yaml
spring:
  elasticsearch:
    uris: 100.64.0.3:9210
    username: elastic
    password: 9MO84ZDei8aXoSu9IK
```

# 2.调用示例
```java

public class FileSaveEsTest {
    
    @Autowired
    private FileService fileService;

    /**
     * 保存
     */
    public void testSave() throws InterruptedException, IOException {

        FileSystemResource file = new FileSystemResource("C:\\Users\\A\\Desktop\\测试文件上传\\基于随机森林方法分析环境因子对空气负离子的影响.pdf");
        MockMultipartFile mockMultipartFile = new MockMultipartFile(file.getFilename(), file.getInputStream());

        FileSaveDTO fileSaveDTO = new FileSaveDTO();
        fileSaveDTO.setTitle("测试基于随机森林方法分析环境因子对空气负离子的影响");
        fileSaveDTO.setFileUrl("https://www.baidu.com?test=1");
        fileSaveDTO.setCategory("科学文献");
        fileSaveDTO.setStatus("执行中");
        fileSaveDTO.setPublishDate(DateUtil.parseDate("2024-01-01"));
        fileSaveDTO.setEffectDate(DateUtil.parseDate("2024-12-01"));
        fileSaveDTO.setExtend("{\"name\":\"测试名称\",\"testField\":\"测试测试\"}");

        R<Boolean> result = fileService.save(mockMultipartFile, fileSaveDTO);
        System.out.println(result);
    }

    /**
     * 查询
     */
    public void search() throws InterruptedException, IOException {

        FileSearchDTO fileSearchDTO = new FileSearchDTO();
        fileSearchDTO.setTitle("测试随机森林方法");
        fileSearchDTO.setContent("测试随机森林方法");
        fileSearchDTO.setCategory("科学文献");

        fileSearchDTO.setStatus("执行中");
        fileSearchDTO.setPublishStartDate(DateUtil.parseDate("2024-01-01"));
        fileSearchDTO.setEffectStartDate(DateUtil.parseDate("2024-12-01"));
        fileSearchDTO.setExtend("测试");

        fileSearchDTO.setMinScore(0.8d);

        Page page = new Page(1,10);

        List<File> files = fileService.queryByTitleOrContent(fileSearchDTO, page);

        System.out.println(JSON.toJSONString(files));
    }
}
    


```
