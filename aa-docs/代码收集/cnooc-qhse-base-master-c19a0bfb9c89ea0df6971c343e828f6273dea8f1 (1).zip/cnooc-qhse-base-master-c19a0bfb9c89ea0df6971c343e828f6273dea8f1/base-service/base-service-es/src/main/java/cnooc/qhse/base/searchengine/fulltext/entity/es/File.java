package cnooc.qhse.base.searchengine.fulltext.entity.es;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson2.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Date;

/**
 * @author A
 * @Descrption 文档查询
 * @date 2024/1/30 14:37
 * @Version 1.0
 */
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@Document(indexName = "file")
public class File {

    @Id
    private String id;

    /**
     * 标题
     */
    @Field(name="title",type = FieldType.Text,analyzer="ik_smart",searchAnalyzer="ik_smart")
    private String title;

    /**
     * 文档地址
     */
    @Field(name = "fileUrl",type = FieldType.Keyword)
    private String fileUrl;

    /**
     * 内容
     */
    @Field(name = "attachment.content",type = FieldType.Text,analyzer="ik_smart",searchAnalyzer="ik_smart")
    private String content;

    /**
     * 分类
     * <p>
     * 文档分类，如 法律法规、国标文件 等
     */
    @Field(name = "category",type = FieldType.Keyword)
    private String category;

    /**
     * 状态
     * <p>
     * 文档状态如：执行中、废止等
     */
    @Field(name = "status",type = FieldType.Keyword)
    private String status;

    /**
     * 发布日期
     */
    @Field(name = "publishDate",type = FieldType.Date,format = DateFormat.date,pattern = "yyyy-MM-dd")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date publishDate;
    /**
     * 实施日期
     */
    @Field(name = "effectDate",type = FieldType.Date,format = DateFormat.date,pattern = "yyyy-MM-dd")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date effectDate;

    /**
     * 扩展字段，用于扩展使用
     */
    @Field(name = "extend",type = FieldType.Text,analyzer="ik_smart",searchAnalyzer="ik_smart")
    private String extend;

	@Override
	public String toString() {
	    return JSON.toJSONString(this);
	}


}
