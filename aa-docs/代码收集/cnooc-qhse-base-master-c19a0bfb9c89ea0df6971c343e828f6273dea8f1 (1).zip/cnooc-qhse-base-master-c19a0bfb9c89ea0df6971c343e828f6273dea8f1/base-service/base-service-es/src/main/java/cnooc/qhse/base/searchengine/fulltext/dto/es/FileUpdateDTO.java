package cnooc.qhse.base.searchengine.fulltext.dto.es;

import com.alibaba.fastjson.annotation.JSONField;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 *
 * 文档更新到ES
 * <p>
 *   更新只允许更新文档描述信息，文档内容、附件地址不更新
 *
 * @author A
 * @Descrption 文档更新到ES
 *
 * @date 2024/1/30 14:37
 * @Version 1.0
 */
@Data
public class FileUpdateDTO {

    @NotBlank(message = "文档id不能为空")
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 分类
     * <p>
     * 文档分类，如 法律法规、国标文件 等
     */
    private String category;

    /**
     * 状态
     * <p>
     * 文档状态如：执行中、废止等
     */
    private String status;

    /**
     * 发布日期
     */
    private Date publishDate;
    /**
     * 实施日期
     */
    private Date effectDate;

    /**
     * 扩展字段，用于扩展使用
     */
    private String extend;

}
