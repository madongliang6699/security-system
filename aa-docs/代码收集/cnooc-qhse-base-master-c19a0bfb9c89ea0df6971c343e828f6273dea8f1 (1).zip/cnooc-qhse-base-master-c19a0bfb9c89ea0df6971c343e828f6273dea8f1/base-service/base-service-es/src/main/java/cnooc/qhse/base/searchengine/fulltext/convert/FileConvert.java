package cnooc.qhse.base.searchengine.fulltext.convert;

import cnooc.qhse.base.searchengine.fulltext.dto.es.FileSaveDTO;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileUpdateDTO;
import cnooc.qhse.base.searchengine.fulltext.entity.es.File;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * 文档 do dto 转换
 * @author jingwei
 */
@Mapper
public interface FileConvert {

    FileConvert INSTANCE = Mappers.getMapper(FileConvert.class);

    /**
     * saveDto to do
     * @param saveDTO savaDTO
     * @return do
     */
    File toDo(FileSaveDTO saveDTO);

    /**
     * updateDto to do
     * @param updateDTO
     * @return do
     */
    File toDo(FileUpdateDTO updateDTO);


}
