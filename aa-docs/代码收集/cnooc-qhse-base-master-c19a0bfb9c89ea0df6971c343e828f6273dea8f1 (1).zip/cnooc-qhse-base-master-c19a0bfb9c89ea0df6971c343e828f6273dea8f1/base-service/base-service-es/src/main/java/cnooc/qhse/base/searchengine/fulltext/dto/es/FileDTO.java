package cnooc.qhse.base.searchengine.fulltext.dto.es;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.util.Date;

/**
 * @author A
 * @Descrption 文档结果
 * @date 2024/1/30 14:37
 * @Version 1.0
 */
@Data
public class FileDTO {

    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 文档地址
     */
    private String fileUrl;

    /**
     * 分类
     * <p>
     * 文档分类，如 法律法规、国标文件 等
     */
    private String category;

    /**
     * 状态
     * <p>
     * 文档状态如：执行中、废止等
     */
    private String status;

    /**
     * 发布日期
     */
    @JSONField(format = "yyyy-MM-dd")
    private Date publishDate;
    /**
     * 实施日期
     */
    @JSONField(format = "yyyy-MM-dd")
    private Date effectDate;

    /**
     * 扩展字段，用于扩展使用
     */
    private String extend;

}
