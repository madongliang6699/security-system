package cnooc.qhse.base.searchengine.util;


import org.apache.commons.lang3.StringUtils;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * 日期工具类
 * @author jignwei
 */
public class DateUtil {

    /**
     * 使用 DateTimeFormatter ,支持并发
     */
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
	private static final ZoneId DEFAULT_ZONE_ID = ZoneId.of("Asia/Shanghai");

    /**
     * 当天开始时间
     * @return
     */
    public static LocalDateTime currentDayStart(){
        // 获取当前日期
        LocalDate today = LocalDate.now();
        // 创建当天的起始时间（0点）
        return LocalDateTime.of(today, LocalTime.MIN);
    }

    /**
     * 当天开始时间
     * @return
     */
    public static Date currentDayStartTime(){
        return Date.from(currentDayStart().atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 当天开始时间
     * @return
     */
    public static LocalDateTime currentDayEnd(){
        // 获取当前日期
        LocalDate today = LocalDate.now();
        // 当天的结束时间（23:59:59）
        return LocalDateTime.of(today, LocalTime.MAX);
    }
    /**
     * 当天开始时间
     * @return
     */
    public static Date currentDayEndTime(){
        return Date.from(currentDayEnd().atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本周一开始时间
     * @return
     */
    public static Date currentWeekFirstDayStartTime(){
        LocalDateTime currentDayStart = currentDayStart();
        int dayOfWeek = currentDayStart.getDayOfWeek().getValue();
        LocalDateTime weekFirstDayStart = currentDayStart.minusDays(dayOfWeek - 1);
        return Date.from(weekFirstDayStart.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本周一结束时间
     * @return
     */
    public static Date currentWeekFirstDayEndTime(){
        LocalDateTime currentDayEnd = currentDayEnd();
        int dayOfWeek = currentDayEnd.getDayOfWeek().getValue();
        LocalDateTime weekFirstDayEndTime = currentDayEnd.minusDays(dayOfWeek - 1);
        return Date.from(weekFirstDayEndTime.atZone(DEFAULT_ZONE_ID).toInstant());
    }


    /**
     * 本月第一天开始时间
     * @return
     */
    public static Date currentMonthFirstDayStartTime(){
        LocalDateTime currentDayStart = currentDayStart();
        int dayOfMonth = currentDayStart.getDayOfMonth();
        LocalDateTime monthFirstDayStartTime = currentDayStart.minusDays(dayOfMonth - 1);
        return Date.from(monthFirstDayStartTime.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本月第一天结束时间
     * @return
     */
    public static Date currentMonthFirstDayEndTime(){
        LocalDateTime currentDayEnd = currentDayEnd();
        int dayOfMonth = currentDayEnd.getDayOfMonth();
        LocalDateTime monthFirstDayEndTime = currentDayEnd.minusDays(dayOfMonth - 1);
        return Date.from(monthFirstDayEndTime.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本月最后一天开始时间
     * @return
     */
    public static Date currentMonthLastDayStartTime(){
        Date currentMonthFirstDayStartTime = currentMonthFirstDayStartTime();
        //本月第一天开始时间
        LocalDateTime monthFirstDayStart = currentMonthFirstDayStartTime.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
        //下月第一天 -1天，则为本月末开始时间
        LocalDateTime monthLastDayStart = monthFirstDayStart.plusMonths(1).minusDays(1);
        return Date.from(monthLastDayStart.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本月最后一天结束时间
     * @return
     */
    public static Date currentMonthLastDayEndTime(){
        Date currentMonthFirstDayEndTime = currentMonthFirstDayEndTime();
        //本月第一天结束时间
        LocalDateTime monthFirstDayEnd = currentMonthFirstDayEndTime.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
        //下月第一天 -1天，则为本月末结束时间
        LocalDateTime monthLastDayEnd = monthFirstDayEnd.plusMonths(1).minusDays(1);
        return Date.from(monthLastDayEnd.atZone(DEFAULT_ZONE_ID).toInstant());
    }



    /**
     * 本年第一天开始时间
     * @return
     */
    public static Date currentYearFirstDayStartTime(){
        LocalDateTime currentDayStart = currentDayStart();
        int dayOfYear = currentDayStart.getDayOfYear();
        LocalDateTime yearFirstDayStartTime = currentDayStart.minusDays(dayOfYear - 1);
        return Date.from(yearFirstDayStartTime.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本年第一天结束时间
     * @return
     */
    public static Date currentYearFirstDayEndTime(){
        LocalDateTime currentDayEnd = currentDayEnd();
        int dayOfYear = currentDayEnd.getDayOfYear();
        LocalDateTime yearFirstDayEndTime = currentDayEnd.minusDays(dayOfYear - 1);
        return Date.from(yearFirstDayEndTime.atZone(DEFAULT_ZONE_ID).toInstant());
    }



    /**
     * 本年最后一天开始时间
     * @return
     */
    public static Date currentYearLastDayStartTime(){
        Date currentYearFirstDayStartTime = currentYearFirstDayStartTime();
        //本年第一天开始时间
        LocalDateTime yearFirstDayStart = currentYearFirstDayStartTime.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
        //下年第一天 -1天，则为本年末开始时间
        LocalDateTime yearLastDayStart = yearFirstDayStart.plusYears(1).minusDays(1);
        return Date.from(yearLastDayStart.atZone(DEFAULT_ZONE_ID).toInstant());
    }

    /**
     * 本年最后一天结束时间
     * @return
     */
    public static Date currentYearLastDayEndTime(){
        Date currentYearFirstDayEndTime = currentYearFirstDayEndTime();
        //本年第一天结束时间
        LocalDateTime yearFirstDayEnd = currentYearFirstDayEndTime.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
        //下年第一天 -1天，则为本年末结束时间
        LocalDateTime yearLastDayEnd = yearFirstDayEnd.plusYears(1).minusDays(1);
        return Date.from(yearLastDayEnd.atZone(DEFAULT_ZONE_ID).toInstant());
    }


    /**
     * 字符串 转 日期时间 支持并发
     * @param dateTimeStr
     * @return
     */
    public static Date parseDatetime(String dateTimeStr){
        return parseDatetime(dateTimeStr,DATETIME_FORMATTER);
    }

    /**
     * 字符串 转 日期 支持并发
     * @param dateStr
     * @return
     */
    public static Date parseDate(String dateStr){
        return parseDate(dateStr,DATE_FORMATTER,null);
    }

	/**
	 * 字符串 转 日期 支持并发
	 * @param dateStr
	 * @param zoneId
	 * @return
	 */
	public static Date parseDate(String dateStr,ZoneId zoneId){
		return parseDate(dateStr,DATE_FORMATTER,zoneId);
	}

    /**
     * 字符串 转 时间 支持并发
     * @param timeStr
     * @return
     */
    public static Date parseTime(String timeStr){
        return parseTime(timeStr,TIME_FORMATTER);
    }



    /**
     * 字符串 转 日期时间 支持并发
     * @param dateTimeStr
     * @param dateTimeFormatter
     * @return
     */
    public static Date parseDatetime(String dateTimeStr,DateTimeFormatter dateTimeFormatter){
        if (StringUtils.isBlank(dateTimeStr) || Objects.isNull(dateTimeFormatter)){
            return null;
        }
        try {
            LocalDateTime localDateTime = LocalDateTime.parse(dateTimeStr,dateTimeFormatter);
            if (Objects.isNull(localDateTime)){
                return null;
            }
            return Date.from(localDateTime.atZone(DEFAULT_ZONE_ID).toInstant());
        }catch (Exception e){
            return null;
        }
    }

    /**
     * 字符串 转 日期 支持并发
     * @param dateStr
     * @param dateTimeFormatter
     * @return
     */
    public static Date parseDate(String dateStr,DateTimeFormatter dateTimeFormatter,ZoneId zoneId){
        if (StringUtils.isBlank(dateStr) || Objects.isNull(dateTimeFormatter)){
            return null;
        }
        try {
            LocalDate localDate = LocalDate.parse(dateStr,dateTimeFormatter);
            if (Objects.isNull(localDate)){
                return null;
            }
			if (Objects.isNull(zoneId)){
				zoneId = DEFAULT_ZONE_ID;
			}
            return Date.from(localDate.atStartOfDay(zoneId).toInstant());
        }catch (Exception e){
            return null;
        }
    }

    /**
     * 字符串 转 时间 支持并发
     * @param timeStr
     * @param dateTimeFormatter
     * @return
     */
    public static Date parseTime(String timeStr,DateTimeFormatter dateTimeFormatter){
        if (StringUtils.isBlank(timeStr) || Objects.isNull(dateTimeFormatter)){
            return null;
        }
        try {
            LocalTime localTime = LocalTime.parse(timeStr,dateTimeFormatter);
            if (Objects.isNull(localTime)){
                return null;
            }
            return Date.from(localTime.atDate(LocalDate.now()).atZone(DEFAULT_ZONE_ID).toInstant());
        }catch (Exception e){
            return null;
        }
    }

    public static Date parseDatetime(long timestamp){
        Date dateTime = new Date(timestamp);
        return dateTime;
    }

    /**
     * 日期 格式化 yyyy-MM-dd HH:mm:ss 支持并发
     * @param dateTime
     * @return
     */
    public static String datetimeFormatToString(Date dateTime){
        if (Objects.isNull(dateTime)) {
            return null;
        }
        try {
            LocalDateTime localDateTime = dateTime.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
            return DATETIME_FORMATTER.format(localDateTime);
        }catch (Exception e){
            return null;
        }
    }

    /**
     * 日期 格式化 yyyy-MM-dd 支持并发
     * @param date
     * @return
     */
    public static String dateFormatToString(Date date){
        if (Objects.isNull(date)) {
            return null;
        }
        try {
            LocalDateTime localDateTime = date.toInstant().atZone(DEFAULT_ZONE_ID).toLocalDateTime();
            return DATE_FORMATTER.format(localDateTime);
        }catch (Exception e){
            return null;
        }
    }


    public static void main(String[] args) {
        System.out.println("currentDayStartTime:" +datetimeFormatToString(currentDayStartTime()));
        System.out.println("currentDayEndTime:"+datetimeFormatToString(currentDayEndTime()));

        System.out.println("currentWeekFirstDayStartTime:"+datetimeFormatToString(currentWeekFirstDayStartTime()));
        System.out.println("currentWeekFirstDayEndTime"+datetimeFormatToString(currentWeekFirstDayEndTime()));

        System.out.println("currentMonthFirstDayStartTime:"+datetimeFormatToString(currentMonthFirstDayStartTime()));
        System.out.println("currentMonthFirstDayEndTime:"+datetimeFormatToString(currentMonthFirstDayEndTime()));
        System.out.println("currentMonthLastDayStartTime:"+datetimeFormatToString(currentMonthLastDayStartTime()));
        System.out.println("currentMonthLastDayEndTime:"+datetimeFormatToString(currentMonthLastDayEndTime()));

        System.out.println("currentYearFirstDayStartTime:"+datetimeFormatToString(currentYearFirstDayStartTime()));
        System.out.println("currentYearFirstDayEndTime:"+datetimeFormatToString(currentYearFirstDayEndTime()));
        System.out.println("currentYearLastDayStartTime:"+datetimeFormatToString(currentYearLastDayStartTime()));
        System.out.println("currentYearLastDayEndTime:"+datetimeFormatToString(currentYearLastDayEndTime()));

	}
}
