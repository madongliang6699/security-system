package cnooc.qhse.base.searchengine.fulltext.service;

import cnooc.qhse.base.searchengine.fulltext.dto.Page;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileSaveDTO;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileSearchDTO;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileUpdateDTO;
import cnooc.qhse.base.searchengine.fulltext.entity.es.File;
import org.springblade.core.tool.api.R;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文档搜索 service
 * @author jingwei
 * @date 2024/1/31 11:17
 * @version 1.0
 */
public interface FileService {

    /**
     * 文档保存
     * @param file 文档
     * @param fileSaveDTO 文档保存参数
     * @return 响应结果
     */
    R<Boolean> save(MultipartFile file, FileSaveDTO fileSaveDTO);

    /**
     * 文档更新
     * @param fileUpdateDTO 文档更新参数
     * @return 响应结果
     */
    R<Boolean> update(FileUpdateDTO fileUpdateDTO);

    /**
     * 文档 全文检索
     * @param fileSearch 查询参数
     * @param page 分页参数
     * @return  响应结果
     */
    List<File> queryByTitleOrContent(FileSearchDTO fileSearch, Page page);
}
