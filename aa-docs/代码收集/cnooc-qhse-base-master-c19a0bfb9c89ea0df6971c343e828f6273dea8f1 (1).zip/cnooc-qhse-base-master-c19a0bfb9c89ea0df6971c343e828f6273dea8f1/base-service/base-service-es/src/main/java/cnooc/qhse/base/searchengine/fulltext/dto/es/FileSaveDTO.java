package cnooc.qhse.base.searchengine.fulltext.dto.es;

import com.alibaba.fastjson.annotation.JSONField;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author A
 * @Descrption 文档保存到ES
 * @date 2024/1/30 14:37
 * @Version 1.0
 */
@Data
public class FileSaveDTO {

    /**
     * 标题
     */
    @NotBlank(message = "文档标题不能为空")
    private String title;

    /**
     * 文档地址
     */
    @NotBlank(message = "文档地址不能为空")
    private String fileUrl;

    /**
     * 分类
     * <p>
     * 文档分类，如 法律法规、国标文件 等
     */
    private String category;

    /**
     * 状态
     * <p>
     * 文档状态如：执行中、废止等
     */
    private String status;

    /**
     * 发布日期
     */
    private Date publishDate;
    /**
     * 实施日期
     */
    private Date effectDate;

    /**
     * 扩展字段，用于扩展使用
     */
    private String extend;

}
