package cnooc.qhse.base.searchengine.fulltext.dto.es;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author A
 * @Descrption 文档查询
 * @date 2024/1/30 14:37
 * @Version 1.0
 */
@Data
public class FileSearchDTO {

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 分类
     * <p>
     * 文档分类，如 法律法规、国标文件 等
     */
    private String category;

    /**
     * 状态
     * <p>
     * 文档状态如：执行中、废止等
     */
    private String status;


    /**
     * 扩展字段，用于扩展使用
     */
    private String extend;


    /**
     * 发布日期（开始时间）
     */
    private Date publishStartDate;

    /**
     * 发布日期（结束时间）
     * <p>
     *  结束时间包含当天
     */
    private Date publishEndDate;

    /**
     * 实施日期(开始时间)
     */
    private Date effectStartDate;

    /**
     * 实施日期(结束时间)
     * <p>
     *  结束时间包含当天
     */
    private Date effectEndDate;
	/**
	 * 匹配的最小分值
	 */
	private Double minScore;

}
