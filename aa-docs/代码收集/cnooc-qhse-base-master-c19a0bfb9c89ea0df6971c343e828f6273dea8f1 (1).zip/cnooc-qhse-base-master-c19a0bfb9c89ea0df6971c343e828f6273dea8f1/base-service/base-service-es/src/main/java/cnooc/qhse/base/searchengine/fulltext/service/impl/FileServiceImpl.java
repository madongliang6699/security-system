package cnooc.qhse.base.searchengine.fulltext.service.impl;

import cnooc.qhse.base.searchengine.fulltext.dto.Page;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileSaveDTO;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileSearchDTO;
import cnooc.qhse.base.searchengine.fulltext.dto.es.FileUpdateDTO;
import cnooc.qhse.base.searchengine.fulltext.entity.es.File;
import cnooc.qhse.base.searchengine.fulltext.service.FileService;
import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryBuilders;
import co.elastic.clients.elasticsearch._types.query_dsl.RangeQuery;
import co.elastic.clients.elasticsearch.core.*;
import co.elastic.clients.elasticsearch.core.search.*;
import co.elastic.clients.elasticsearch.ingest.*;
import co.elastic.clients.json.JsonData;
import com.alibaba.fastjson.JSON;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import cnooc.qhse.base.searchengine.fulltext.convert.FileConvert;
import cnooc.qhse.base.searchengine.util.DateUtil;
import org.springblade.core.tool.api.R;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.IndexOperations;
import org.springframework.data.elasticsearch.core.document.Document;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author A
 * @Descrption 文档搜索 service 实现
 * @date 2024/1/31 11:18
 * @Version 1.0
 */
@Slf4j
@Service
public class FileServiceImpl implements FileService {

    @Resource
    private ElasticsearchTemplate esRestTemplate;
    @Resource
	ElasticsearchClient elasticsearchClient;


    private static final String ATTACHMENT_PIPELINE_NAME = "attachment";
    private static final int MAX_PAGE_NUM = 100;
    private static final int FILE_MAX_SIZE = 100 * 1024 * 1024;
	private static final double MIN_SCORE = 0.9d;




    /**
     * 初始化时创建 attachment 管道
     */
    @PostConstruct
    public void initAttachmentPipeline(){
        if(attachmentPipelineExist()){
            return;
        }
        boolean createResult = createAttachmentPipeline();
        if (!createResult){
            throw new RuntimeException("创建 attachment pipeline 失败！");
        }
    }

    @Override
    public R<Boolean> save(MultipartFile file, FileSaveDTO fileSaveDTO) {
        if (Objects.isNull(file) || file.isEmpty()) {
            return R.fail("文档内容为空");
        }
        String contentType = file.getContentType();
        long size = file.getSize();
        log.info("file save ,file: [contentType：{},size:{}]",contentType,size);
        if (size > FILE_MAX_SIZE){
            return R.fail("文档内容过大，不支持上传。");
        }

        File fileSave = FileConvert.INSTANCE.toDo(fileSaveDTO);
        try {
            // 读取文档内容并进行 Base64 编码
            byte[] documentData = file.getBytes();
            String encodedDocument = Base64.getEncoder().encodeToString(documentData);
            fileSave.setContent(encodedDocument);
        }catch (Exception e){
            log.error("文档读取失败,e:",e);
            return R.fail("文档读取失败,"+e.getMessage());
        }
        IndexOperations indexOperations = esRestTemplate.indexOps(File.class);
        if(!indexOperations.exists()){
            indexOperations.create();
            //生成映射
            Document mapping = indexOperations.createMapping();
            //推送映射
            indexOperations.putMapping(mapping);
        }

        String indexName = indexOperations.getIndexCoordinates().getIndexName();
		IndexRequest<File> indexRequest = new IndexRequest.Builder<File>()
			.index(indexName)
			.document(fileSave)
			.pipeline(ATTACHMENT_PIPELINE_NAME)
			.build();
        //上传同时，使用attachment pipline进行提取文件
        try {
            IndexResponse indexResp = elasticsearchClient.index(indexRequest);
            log.info("es index response:{}",JSON.toJSONString(indexResp));
        } catch (IOException e) {
            log.error("文档上传异常,e:",e);
            return R.fail(String.format("文档上传失败:[%s]",e.getMessage()));
        }

        return R.data(true);
    }

    @Override
    public R<Boolean> update(FileUpdateDTO fileUpdateDTO) {
        File fileUpdate = FileConvert.INSTANCE.toDo(fileUpdateDTO);
        String indexName = esRestTemplate.indexOps(File.class).getIndexCoordinates().getIndexName();
        UpdateRequest updateRequest = new UpdateRequest.Builder<>()
			.index(indexName)
			.id(fileUpdateDTO.getId())
			.doc(fileUpdate)
			.build();
        try {
            UpdateResponse<File> updateResponse = elasticsearchClient.update(updateRequest, File.class);
            log.info("file update response:{}",JSON.toJSONString(updateResponse));
        } catch (IOException e) {
            log.error("文档更新异常,e:",e);
            return R.fail(String.format("文档更新失败:[%s]",e.getMessage()));
        }

        return R.data(true);
    }

    @Override
    public List<File> queryByTitleOrContent(FileSearchDTO fileSearch, Page page) {
        String title = fileSearch.getTitle();
        String content = fileSearch.getContent();
        if (StringUtils.isAllBlank(title,content)){
            log.warn("文档标题和内容不能全部为空");
            throw new RuntimeException("文档标题和内容不能全部为空");
        }
        if (page.getPageNum() <= 0 || page.getPageSize() <= 0){
            log.warn("分页参数不正确");
            throw new RuntimeException("分页参数不正确");
        }

        if (page.getPageNum() > MAX_PAGE_NUM){
            log.warn("page num 不能大于 [{}]",MAX_PAGE_NUM);
            throw new RuntimeException(String.format("page num 不能大于 [%s]",MAX_PAGE_NUM));
        }

        // 查询的数据列表
        List<File> list = new ArrayList<>();

        // 创建 Bool 查询构建器
		Query boolQuery = createQueryBuilder(fileSearch);

        try {
            // 高亮设置
            // 设置高亮三要素:  field: 你的高亮字段 , preTags ：前缀    , postTags：后缀
			Highlight highlight = new Highlight.Builder()
				.fields("title", highlightBuild -> highlightBuild.matchedFields("title")
					.preTags("<font color='red'>")
					.postTags("</font>"))
				.fields("attachment.content", highlightBuild -> highlightBuild.matchedFields("attachment.content")
					.preTags("<font color='red'>")
					.postTags("</font>"))
				.build();
			// 设置返回字段
			// 如果查询的属性很少，那就使用includes，反之使用 excludes
			SourceFilter sourceFilter = new SourceFilter.Builder().excludes("attachment.content").build();
			SourceConfig sourceFilterConfig = new SourceConfig.Builder().filter(sourceFilter).build();

			String indexName = esRestTemplate.indexOps(File.class).getIndexCoordinates().getIndexName();
            // 创建查询请求对象，将查询对象配置到其中
            SearchRequest searchRequest = new SearchRequest.Builder()
				.index(indexName)
				.query(boolQuery)
				.size(page.getPageSize())
				.from((int)page.getStartRow())
				.minScore(Objects.isNull(fileSearch.getMinScore()) ? MIN_SCORE : fileSearch.getMinScore())
				.highlight(highlight)
				.source(sourceFilterConfig)
				.build();

            // 执行查询，然后处理响应结果
            SearchResponse<JsonData> searchResponse = elasticsearchClient.search(searchRequest, JsonData.class);

			System.out.println(searchResponse);
            // 根据状态和数据条数验证是否返回了数据

            if (searchResponse.hits().total().value() > 0) {
				List<Hit<JsonData>> hits = searchResponse.hits().hits();
                for (Hit<JsonData> hit : hits) {
                    // 将 JSON 转换成对象
					File bean = hit.source().to(File.class);
                    String id = hit.id();
                    bean.setId(id);

                    // 获取高亮的数据
                    List<String> highlightTitle = hit.highlight().get("title");
                    setHighlightResultValue(highlightTitle,bean,"setTitle");

                    List<String> highlightContent = hit.highlight().get("attachment.content");
                    setHighlightResultValue(highlightContent,bean,"setContent");

                    list.add(bean);
                }
            }
        } catch (IOException e) {
            log.error("查询失败，错误信息：" ,e);
            throw new RuntimeException("查询失败,[ "+e.getMessage() + " ]");
        }
        return list;
    }

    private Query createQueryBuilder(FileSearchDTO fileSearch){
        String title = fileSearch.getTitle();
        String content = fileSearch.getContent();

        // 创建 Bool 查询构建器
		BoolQuery.Builder boolQueryBuilder = QueryBuilders.bool();

		// 构建查询条件, title 和 content 同时匹配，其他字段单独匹配。
		BoolQuery.Builder titleOrContentQueryBuilder = QueryBuilders.bool();
        if (StringUtils.isNotBlank(title)){
            //根据 title 查询
			Query titleQuery = QueryBuilders.match(matchBuilder-> matchBuilder.field("title").query(title));

			titleOrContentQueryBuilder.should(titleQuery);
		}
		if(StringUtils.isNotBlank(content)){
			// 根据 content 查询
			Query contentQuery = QueryBuilders.match(matchBuilder -> matchBuilder.field("attachment.content").query(content));
			titleOrContentQueryBuilder.should(contentQuery);
		}
		Query titleOrContentQuery = new Query.Builder().bool(titleOrContentQueryBuilder.build()).build();
		boolQueryBuilder.must(titleOrContentQuery);

        if (StringUtils.isNotBlank(fileSearch.getCategory())){

            boolQueryBuilder.must(QueryBuilders.match(matchBuilder -> matchBuilder.field("category").query(fileSearch.getCategory())));
        }
        if (StringUtils.isNotBlank(fileSearch.getStatus())){
            boolQueryBuilder.must(QueryBuilders.match(matchBuilder -> matchBuilder.field("status").query(fileSearch.getStatus())));
        }
        if (StringUtils.isNotBlank(fileSearch.getExtend())){
            boolQueryBuilder.must(QueryBuilders.match(matchBuilder ->matchBuilder.field("extend").query(fileSearch.getExtend())));
        }

        Date publishStartDate = fileSearch.getPublishStartDate();
        Date publishEndDate = fileSearch.getPublishEndDate();
        Date effectStartDate = fileSearch.getEffectStartDate();
        Date effectEndDate = fileSearch.getEffectEndDate();

        // 发布时间范围查询
        if (Objects.nonNull(publishStartDate) || Objects.nonNull(publishEndDate)){
			RangeQuery.Builder publishDateBuilder = QueryBuilders.range().field("publishDate");
			if (Objects.nonNull(publishStartDate)){
				publishDateBuilder.gte(JsonData.of(DateUtil.dateFormatToString(publishStartDate)));
            }
            if (Objects.nonNull(publishEndDate)){
				publishDateBuilder.lte(JsonData.of(DateUtil.dateFormatToString(publishEndDate)));
            }
			Query publishDateQuery = new Query.Builder().range(publishDateBuilder.build()).build();
			boolQueryBuilder.must(publishDateQuery);
        }

        // 生效时间范围查询
        if (Objects.nonNull(effectStartDate) || Objects.nonNull(effectEndDate)){
			RangeQuery.Builder effectDateQueryBuilder = QueryBuilders.range().field("effectDate");
            if (Objects.nonNull(effectStartDate)){
				effectDateQueryBuilder.gte(JsonData.of(DateUtil.dateFormatToString(effectStartDate)));
            }
            if (Objects.nonNull(effectEndDate)){
				effectDateQueryBuilder.lte(JsonData.of(DateUtil.dateFormatToString(effectEndDate)));
            }
			Query effectDateQuery = new Query.Builder().range(effectDateQueryBuilder.build()).build();
			boolQueryBuilder.must(effectDateQuery);
        }

		return new Query.Builder().bool(boolQueryBuilder.build()).build();
    }

    /**
     * 赋值 高亮查询结果
     * @param highlightField
     * @param bean
     * @param methodName
     * @param <T>
     */
    private <T> void  setHighlightResultValue(List<String> highlightField, T bean, String methodName){
        if (Objects.isNull(highlightField) || CollectionUtils.isEmpty(highlightField)){
            return;
        }
        // 替换掉原来的数据
		StringBuilder value = new StringBuilder();
		for (String fragment : highlightField) {
			value.append(fragment);
		}
		try {
			// 获取method对象，其中包含方法名称和参数列表
			Method setValueMethod = bean.getClass().getMethod(methodName, String.class);
			// 执行method，bean为实例对象，后面是方法参数列表；setTitle没有返回值
			setValueMethod.invoke(bean, value.toString());
		}catch (Exception e){
			log.error("高亮查询结果赋值异常：" ,e);
			return;
		}

    }

    /**
     * 查询 attachment 管道是否存在
     * @return
     */
    private boolean attachmentPipelineExist(){
		ElasticsearchIngestClient ingest = elasticsearchClient.ingest();
        try {
            GetPipelineResponse pipelineResult = ingest.getPipeline(new GetPipelineRequest.Builder().id(ATTACHMENT_PIPELINE_NAME).build());
            return !CollectionUtils.isEmpty(pipelineResult.result());
        } catch (Exception e) {
			log.error("获取 attachment pipeline 异常:",e);
            return false;
        }
    }

    /**
     * 创建 attachment 管道
     * @return
     */
    private boolean createAttachmentPipeline(){
		ElasticsearchIngestClient ingest = elasticsearchClient.ingest();

        String pipelineId = ATTACHMENT_PIPELINE_NAME;

		Processor attachmentProcessor = new Processor.Builder().attachment(new AttachmentProcessor.Builder()
			.field("content")
			.ignoreMissing(true)
			.build())
			.build();

		Processor removeProcessor = new Processor.Builder().remove(new RemoveProcessor.Builder()
			.field("content").build())
			.build();

		PutPipelineRequest request = new PutPipelineRequest.Builder()
			.id(pipelineId)
			.description("file attachment pipeline")
			.processors(attachmentProcessor,removeProcessor)
			.build();

        try {
			PutPipelineResponse pipelineResult = ingest.putPipeline(request);
            return pipelineResult.acknowledged();
        } catch (Exception e) {
            log.error("attachment pipeline create exception,e:",e);
            return false;
        }
    }


}
