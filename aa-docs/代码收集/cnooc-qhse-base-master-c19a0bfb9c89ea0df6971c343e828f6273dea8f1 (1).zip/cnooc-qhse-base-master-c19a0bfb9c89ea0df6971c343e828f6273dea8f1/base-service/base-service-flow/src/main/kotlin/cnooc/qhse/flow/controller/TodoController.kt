package cnooc.qhse.flow.controller

import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import cnooc.qhse.flow.service.ITodoService
import cnooc.qhse.flow.wrapper.TodoWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

/**
 * 待办事项 控制器
 */
@RestController
@RequestMapping("/todo")
@Tag(name = "待办事项", description = "待办事项接口")
class TodoController(private val todoService: ITodoService) : BladeController() {

    /**
     * 详情
     */
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入todo")
    fun detail(todo: Todo): R<TodoVO> {
        val detail = todoService.getOne(Condition.getQueryWrapper(todo))
        return R.data(TodoWrapper.build().entityVO(detail))
    }

    /**
     * 分页 待办事项
     */
    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入todo")
    fun list(
        @RequestParam businessCategory: String?, isFlow: Boolean?, flowDeploymentCategory: String?,
        @RequestParam current: Int, @RequestParam size: Int
    ):
        R<IPage<TodoVO>> {
        val query = Query()
        query.current = current
        query.size = size
        // 待办事项与待签事项合并
        return R.data(todoService.selectTodos(businessCategory, isFlow, flowDeploymentCategory, query))
    }
}
