package cnooc.qhse.flow.service

import cnooc.qhse.common.service.BaseServiceKt
import cnooc.qhse.flow.pojo.entity.TaskSetting

/**
 * 任务设置表 服务类
 */
interface ITaskSettingService : BaseServiceKt<TaskSetting>
