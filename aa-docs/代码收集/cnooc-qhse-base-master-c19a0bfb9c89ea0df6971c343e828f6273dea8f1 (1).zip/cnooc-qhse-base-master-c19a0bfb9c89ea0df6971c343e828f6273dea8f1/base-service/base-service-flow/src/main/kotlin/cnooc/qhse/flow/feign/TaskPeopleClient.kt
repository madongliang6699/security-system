package cnooc.qhse.flow.feign

import cnooc.qhse.flow.pojo.entity.TaskPeople
import cnooc.qhse.flow.service.ITaskPeopleService
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class TaskPeopleClient (private val taskPeopleService: ITaskPeopleService): ITaskPeopleClient{
    override fun getTaskPeople(
        tenantId: String,
        businessCategory: String,
        taskCode: String
    ): R<List<TaskPeople>> {
        return R.data(taskPeopleService.list(
            KtQueryWrapper(TaskPeople::class.java)
                .eq(TaskPeople::tenantId, tenantId)
                .eq(TaskPeople::businessCategory, businessCategory)
                .eq(TaskPeople::taskCode, taskCode)
        ))
    }

    override fun getTaskPeopleWithExtend1(
        tenantId: String,
        businessCategory: String,
        taskCode: String,
        extend1: String
    ): R<List<TaskPeople>> {
        return R.data(taskPeopleService.list(
            KtQueryWrapper(TaskPeople::class.java)
                .eq(TaskPeople::tenantId, tenantId)
                .eq(TaskPeople::businessCategory, businessCategory)
                .eq(TaskPeople::taskCode, taskCode)
                .eq(TaskPeople::extend1, extend1)
        ))
    }

    override fun getTaskPeopleWithExtend12(
        tenantId: String,
        businessCategory: String,
        taskCode: String,
        extend1: String,
        extend2: String
    ): R<List<TaskPeople>> {
        return R.data(taskPeopleService.list(
            KtQueryWrapper(TaskPeople::class.java)
                .eq(TaskPeople::tenantId, tenantId)
                .eq(TaskPeople::businessCategory, businessCategory)
                .eq(TaskPeople::taskCode, taskCode)
                .eq(TaskPeople::extend1, extend1)
                .eq(TaskPeople::extend2, extend2)
        ))
    }

    override fun getTaskPeopleWithExtend123(
        tenantId: String,
        businessCategory: String,
        taskCode: String,
        extend1: String,
        extend2: String,
        extend3: String
    ): R<List<TaskPeople>> {
        return R.data(taskPeopleService.list(
            KtQueryWrapper(TaskPeople::class.java)
                .eq(TaskPeople::tenantId, tenantId)
                .eq(TaskPeople::businessCategory, businessCategory)
                .eq(TaskPeople::taskCode, taskCode)
                .eq(TaskPeople::extend1, extend1)
                .eq(TaskPeople::extend2, extend2)
                .eq(TaskPeople::extend3, extend3)
        ))
    }
}
