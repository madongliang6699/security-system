package cnooc.qhse.flow.service.impl

import cnooc.qhse.base.mapper.TaskSettingMapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.flow.pojo.entity.TaskSetting
import cnooc.qhse.flow.service.ITaskSettingService
import org.springframework.stereotype.Service

/**
 * 任务设置表 服务实现类
 */
@Service
class TaskSettingServiceImpl : BaseServiceImplKt<TaskSettingMapper, TaskSetting>(), ITaskSettingService
