package cnooc.qhse.flow.service

import cnooc.qhse.common.service.BaseServiceKt
import cnooc.qhse.flow.pojo.entity.TaskPeople

/**
 * 任务人员表 服务类
 */
interface ITaskPeopleService : BaseServiceKt<TaskPeople>
