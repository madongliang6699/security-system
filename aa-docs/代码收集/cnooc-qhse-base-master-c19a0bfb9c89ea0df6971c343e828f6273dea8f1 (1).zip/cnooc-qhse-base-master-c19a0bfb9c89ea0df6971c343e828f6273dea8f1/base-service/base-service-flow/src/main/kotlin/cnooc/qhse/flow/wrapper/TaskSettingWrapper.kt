package cnooc.qhse.flow.wrapper

import cnooc.qhse.flow.pojo.entity.TaskSetting
import cnooc.qhse.flow.pojo.vo.TaskSettingVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil

/**
 * 任务设置表包装类,返回视图层所需的字段
 */
class TaskSettingWrapper : BaseEntityWrapper<TaskSetting, TaskSettingVO>() {
    companion object {
        fun build() : TaskSettingWrapper {
            return TaskSettingWrapper()
        }
    }

	override fun entityVO(entity: TaskSetting) : TaskSettingVO {
		val vo = BeanUtil.copy(entity, TaskSettingVO::class.java)!!
		return vo
	}

}
