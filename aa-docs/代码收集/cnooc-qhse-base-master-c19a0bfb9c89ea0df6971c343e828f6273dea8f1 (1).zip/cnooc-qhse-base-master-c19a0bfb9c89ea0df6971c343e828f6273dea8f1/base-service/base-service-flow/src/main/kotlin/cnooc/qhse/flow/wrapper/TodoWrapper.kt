package cnooc.qhse.flow.wrapper

import cnooc.qhse.base.assign.AssigneeConstant
import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.system.cache.DictCache
import org.springblade.system.cache.UserCache
import java.time.LocalDateTime

/**
 * 待办事项包装类,返回视图层所需的字段
 */
class TodoWrapper : BaseEntityWrapper<Todo, TodoVO>() {
    override fun entityVO(todo: Todo): TodoVO {
        val todoVO = BeanUtil.copy(todo, TodoVO::class.java)!!
        todoVO.businessCategoryName = DictCache.getValue(AssigneeConstant.DICT_BUSINESS_CATEGORY, todoVO.businessCategory)
        setUserName(todoVO)
        todoVO.endTime?.let {
            todoVO.expired = it.isBefore(LocalDateTime.now())
        }
        return todoVO
    }

    private fun setUserName(todoVO: TodoVO) {
        UserCache.getUser(todoVO.userId)?.let {
            todoVO.userName = it.realName
        }
    }

    companion object {
        fun build(): TodoWrapper {
            return TodoWrapper()
        }
    }
}
