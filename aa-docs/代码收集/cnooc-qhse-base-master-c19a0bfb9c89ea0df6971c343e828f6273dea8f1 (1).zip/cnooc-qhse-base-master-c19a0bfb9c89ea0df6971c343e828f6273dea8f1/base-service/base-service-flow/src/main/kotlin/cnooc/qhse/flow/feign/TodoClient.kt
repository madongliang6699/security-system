package cnooc.qhse.flow.feign

import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import cnooc.qhse.flow.service.ITodoService
import com.baomidou.mybatisplus.core.metadata.IPage
import org.springblade.core.mp.support.Query
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class TodoClient (private val todoService: ITodoService): ITodoClient{
    override fun getTodos(
        businessCategory: String,
        isFlow: Boolean,
        flowDeploymentCategory: String?,
        query: Query
    ): R<IPage<TodoVO>> {
        return R.data(todoService.selectTodos(businessCategory, isFlow, flowDeploymentCategory, query))
    }

    override fun removeByBusinessKeys(businessKeys: List<Long>): R<Boolean> {
        return R.data(todoService.removeByBusinessKeys(businessKeys))
    }

    override fun getByBusinessKey(businessKey: Long): R<Todo?> {
        return R.data(todoService.getByBusinessKey(businessKey))
    }

    override fun addTodos(todos: List<Todo>): R<Boolean> {
        return R.data(todoService.addTodos(todos))
    }
}
