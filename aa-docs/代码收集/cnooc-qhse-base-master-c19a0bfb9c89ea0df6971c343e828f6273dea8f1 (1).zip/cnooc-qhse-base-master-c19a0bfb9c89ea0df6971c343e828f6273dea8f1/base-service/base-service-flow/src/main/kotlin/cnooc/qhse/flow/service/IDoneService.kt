package cnooc.qhse.flow.service

import cnooc.qhse.common.service.BaseServiceKt
import cnooc.qhse.flow.pojo.entity.Done
import cnooc.qhse.flow.pojo.vo.DoneVO
import com.baomidou.mybatisplus.core.metadata.IPage
import org.springblade.core.mp.support.Query

interface IDoneService : BaseServiceKt<Done> {
    /**
     * 获取办结事项列表
     * @param businessCategory 业务类别，如果是流程类的，与flowDeploymentCategory二选一
     * @param isFlow 是否是流程类的
     * @param flowDeploymentCategory 流程部署类别
     * @param query 分页参数
     */
    fun getDonePage(
        businessCategory: String?,
        isFlow: Boolean?,
        flowDeploymentCategory: String?,
        query: Query
    ): IPage<DoneVO>

    /**
     * 通过todo的businessKey来添加done
     * @param businessKey todo的businessKey
     * @return
     */
    fun addDoneByBusinessKey(businessKey: Long)
}
