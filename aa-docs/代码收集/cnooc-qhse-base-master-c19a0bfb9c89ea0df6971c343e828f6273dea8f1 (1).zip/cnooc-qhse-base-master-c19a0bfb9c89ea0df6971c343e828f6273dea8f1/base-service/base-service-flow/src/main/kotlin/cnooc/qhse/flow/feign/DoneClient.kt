package cnooc.qhse.flow.feign

import cnooc.qhse.flow.pojo.vo.DoneVO
import cnooc.qhse.flow.service.IDoneService
import com.baomidou.mybatisplus.core.metadata.IPage
import org.springblade.core.mp.support.Query
import org.springblade.core.tenant.annotation.NonDS
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.RestController

@NonDS
@RestController
class DoneClient (private val doneService: IDoneService): IDoneClient{
    override fun getDones(
        businessCategory: String,
        isFlow: Boolean,
        flowDeploymentCategory: String?,
        query: Query
    ): R<IPage<DoneVO>> {
        return R.data(doneService.getDonePage(businessCategory, isFlow, flowDeploymentCategory, query))
    }

    override fun addDone(businessKey: Long): R<Boolean> {
        doneService.addDoneByBusinessKey(businessKey)
        return R.data(true)
    }
}
