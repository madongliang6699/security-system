package cnooc.qhse.flow.service

import cnooc.qhse.common.service.BaseServiceKt
import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import com.baomidou.mybatisplus.core.metadata.IPage
import org.springblade.core.mp.support.Query

/**
 * 待办事项 服务类
 */
interface ITodoService : BaseServiceKt<Todo> {
    /**
     * 获取待办事项列表
     * @param businessCategory 业务类别，如果是流程类的，与flowDeploymentCategory二选一
     * @param isFlow 是否是流程类的
     * @param flowDeploymentCategory 流程部署类别
     * @param query 分页参数
     */
    fun selectTodos(
        businessCategory: String?,
        isFlow: Boolean?,
        flowDeploymentCategory: String?,
        query: Query): IPage<TodoVO>

    /**
     * 通过业务主键来删除待办事项
     * @param businessKeys
     */
    fun removeByBusinessKeys(businessKeys: List<Long>): Boolean
    fun getByBusinessKey(businessKey: Long): Todo?
    fun addTodos(todos: List<Todo>): Boolean
}
