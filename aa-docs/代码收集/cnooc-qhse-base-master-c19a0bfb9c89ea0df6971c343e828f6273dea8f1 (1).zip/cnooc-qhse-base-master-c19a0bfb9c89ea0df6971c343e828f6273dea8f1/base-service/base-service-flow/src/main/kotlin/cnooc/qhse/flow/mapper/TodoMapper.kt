package cnooc.qhse.base.mapper

import cnooc.qhse.flow.pojo.entity.Todo
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 待办事项 Mapper 接口
 */
interface TodoMapper : BaseMapper<Todo>
