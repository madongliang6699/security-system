package cnooc.qhse.flow.service.impl

import cnooc.qhse.base.mapper.TaskPeopleMapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.flow.pojo.entity.TaskPeople
import cnooc.qhse.flow.service.ITaskPeopleService
import org.springframework.stereotype.Service

/**
 * 任务人员表 服务实现类
 */
@Service
class TaskPeopleServiceImpl : BaseServiceImplKt<TaskPeopleMapper, TaskPeople>(), ITaskPeopleService
