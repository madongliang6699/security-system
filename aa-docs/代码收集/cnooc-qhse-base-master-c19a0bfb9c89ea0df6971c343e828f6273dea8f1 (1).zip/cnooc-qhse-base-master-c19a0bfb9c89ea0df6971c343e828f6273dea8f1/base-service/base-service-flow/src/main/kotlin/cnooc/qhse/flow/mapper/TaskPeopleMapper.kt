package cnooc.qhse.base.mapper

import cnooc.qhse.flow.pojo.entity.TaskPeople
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 任务人员表 Mapper 接口
 */
interface TaskPeopleMapper : BaseMapper<TaskPeople>
