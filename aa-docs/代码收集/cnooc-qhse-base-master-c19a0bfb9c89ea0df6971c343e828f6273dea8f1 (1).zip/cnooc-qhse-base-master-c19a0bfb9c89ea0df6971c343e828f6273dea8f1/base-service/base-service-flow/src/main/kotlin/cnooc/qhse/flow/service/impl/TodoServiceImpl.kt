package cnooc.qhse.flow.service.impl

import cnooc.qhse.base.assign.AssigneeGetterRegister
import cnooc.qhse.base.mapper.TodoMapper
import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.common.utils.notNullRetrieve
import cnooc.qhse.common.utils.toJsonBase64
import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import cnooc.qhse.flow.service.ITodoService
import cnooc.qhse.flow.wrapper.TodoWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.baomidou.mybatisplus.extension.plugins.pagination.Page
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.DateUtil
import org.springblade.core.tool.utils.Func
import org.springblade.plugin.workflow.app.entity.WfAppProcess
import org.springblade.plugin.workflow.core.cache.WfCategoryCache
import org.springblade.plugin.workflow.core.utils.WfTaskUtil
import org.springblade.plugin.workflow.feign.IWorkflowClient
import org.springblade.plugin.workflow.process.model.WfProcess
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional

@Service
class TodoServiceImpl @Autowired constructor(
    private val workflowClient: IWorkflowClient,
) : BaseServiceImplKt<TodoMapper, Todo>(), ITodoService {
    override fun selectTodos(
        businessCategory: String?,
        isFlow: Boolean?,
        flowDeploymentCategory: String?,
        query: Query): IPage<TodoVO> {
        val todoPage = Page<Todo>(query.current.toLong(), query.size.toLong())
        todoPage.records = mutableListOf()
        getInnerTodos(todoPage, businessCategory, isFlow, query)
        getFlowableTodos(todoPage, businessCategory, isFlow, flowDeploymentCategory, query)
        return TodoWrapper.build().pageVO(todoPage)
    }

    private fun getInnerTodos(todoPage: Page<Todo>, businessCategory: String?, isFlow: Boolean?, query: Query) {
        if (isFlow == true) {
            return
        }
        val qw = KtQueryWrapper(Todo::class.java).orderByDesc(Todo::beginTime)
        if (!businessCategory.isNullOrBlank()) {
            qw.eq(Todo::businessCategory, businessCategory)
        }

        // 用户组
        val groups = Func.toStrList(WfTaskUtil.getCandidateGroup()).toMutableList()
        // 把用户id也添加到用户组进行匹配
        groups.add(AuthUtil.getUserId().toString())
        qw.and {wrapper ->
            wrapper.or { wrapper1 -> wrapper1.eq(Todo::userId, AuthUtil.getUserId()) }
            groups.forEach { wrapper.or { wrapper1 -> wrapper1.like(Todo::users, it) } }
        }

        val page = this.page(Page(query.current.toLong(), query.size.toLong()), qw)
        todoPage.total += page.total
        todoPage.records.addAll(page.records)
    }

    fun getFlowableTodos(todoPage: Page<Todo>, businessCategory: String?, isFlow: Boolean?,
                         flowDeploymentCategory: String?, query: Query) {
        if (isFlow == false) {
            return
        }
        // 查询流程实例
        val appProcess = WfAppProcess()
        if (!flowDeploymentCategory.isNullOrBlank()) {
            appProcess.category = WfCategoryCache.getCategoryIdByName(flowDeploymentCategory)?.toString()
        } else {
            appProcess.processDefinitionKey = businessCategory
        }
        val taskPage = workflowClient.todoList(appProcess, query.current, query.size).notNullRetrieve()
        todoPage.total += taskPage.total
        todoPage.records.addAll(taskPage.records.map { process2Todo(it) })
        todoPage.records.sortByDescending { it.beginTime }
    }

    private fun process2Todo(process: WfProcess): TodoVO {
        return TodoVO(
            userId = process.assignee?.toLongOrNull(),
            businessCategory = process.processDefinitionKey,
            businessCategoryName = process.processDefinitionName,
            taskName = process.taskName,
            businessKey = null,
            beginTime = process.createTime?.let { DateUtil.toDateTime(it.toInstant()) },
            endTime = process.endTime?.let { DateUtil.toDateTime(it.toInstant()) },
            flow = process
        )
    }

    override fun removeByBusinessKeys(businessKeys: List<Long>): Boolean {
        if (businessKeys.isEmpty()) return true
        return this.remove(KtQueryWrapper(Todo::class.java).`in`(Todo::businessKey, businessKeys))
    }

    override fun getByBusinessKey(businessKey: Long): Todo? {
        return this.getOne(KtQueryWrapper(Todo::class.java).eq(Todo::businessKey, businessKey))
    }

    @Transactional
    override fun addTodos(todos: List<Todo>): Boolean {
        if (todos.isEmpty()) return true
        // 先删除相应存在的任务，一条businessKey只能存在一次
        removeByBusinessKeys(todos.mapNotNull { it.businessKey })
        for (todo in TodoWrapper.build().listVO(todos)) {
            // 待办任务
            val userIds: List<String> = if (todo.userId != null) {
                // 如果已经有执行人，则候选人要清空
                todo.users = null
                listOf(todo.userId!!.toString())
            } else if (!todo.users.isNullOrBlank()) {
                // 待签任务
                val groupUserIds = AssigneeGetterRegister.getUsersByGroups(todo.users!!, todo.tenantId!!)
                groupUserIds.values.flatten().map { it.toString() }
            } else {
                // 无执行人，无候选人，不通知
                continue
            }
            userIds.forEach {
                // @TODO send message
            }
        }
        return this.saveBatch(todos)
    }

    private fun Todo.toDataUrl(): String {
        return "TODO://${this.businessCategory}/${this.toJsonBase64()}"
    }
}
