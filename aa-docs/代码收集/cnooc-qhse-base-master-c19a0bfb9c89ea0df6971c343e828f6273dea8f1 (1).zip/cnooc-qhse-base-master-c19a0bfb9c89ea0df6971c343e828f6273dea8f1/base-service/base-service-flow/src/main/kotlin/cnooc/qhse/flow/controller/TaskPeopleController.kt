package cnooc.qhse.flow.controller

import cnooc.qhse.common.utils.toColumn
import cnooc.qhse.flow.cache.TaskPeopleCache
import cnooc.qhse.flow.pojo.entity.TaskPeople
import cnooc.qhse.flow.service.ITaskPeopleService
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import springfox.documentation.annotations.ApiIgnore

/**
 * 任务人员表 控制器
 *
 * @author Hugh Gao
 * @since 2022-10-26
 */
@RestController
@RequestMapping("/task-people")
@Tag(name = "任务人员表", description = "任务人员表接口")
class TaskPeopleController @Autowired constructor(private val taskPeopleService: ITaskPeopleService) :
    BladeController() {

    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入taskPeople")
    @PreAuth("hasPermission('base:task_people:view')")
    fun detail(taskPeople: TaskPeople): R<TaskPeople> {
        val detail = taskPeopleService.getOne(Condition.getQueryWrapper(taskPeople)) ?: return R.fail("未找到对应对象")
        return R.data(detail)
    }

    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入taskPeople")
    @PreAuth("hasPermission('base:task_people:view')")
    fun list(@ApiIgnore @RequestParam taskPeople: Map<String, Any>, query: Query): R<IPage<TaskPeople>> {
        val qw = Condition.getQueryWrapper(taskPeople, TaskPeople::class.java)
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(TaskPeople::createTime.toColumn())
            qw.orderByDesc(TaskPeople::id.toColumn())
        }
        val pages = taskPeopleService.page(Condition.getPage(query), qw)
        return R.data(pages)
    }

    @PostMapping("/save")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "新增", description = "传入taskPeople")
    @PreAuth("hasPermission('base:task_people:add')")
    fun save(@Validated @RequestBody taskPeople: TaskPeople): R<Boolean> {
        CacheUtil.clear(TaskPeopleCache.TASK_PEOPLE_CACHE)
        return R.status(taskPeopleService.save(taskPeople))
    }

    @PostMapping("/update")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "修改", description = "传入taskPeople")
    @PreAuth("hasPermission('base:task_people:edit')")
    fun update(@Validated @RequestBody taskPeople: TaskPeople): R<Boolean> {
        CacheUtil.clear(TaskPeopleCache.TASK_PEOPLE_CACHE)
        return R.status(taskPeopleService.updateById(taskPeople))
    }

    @PostMapping("/remove")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "逻辑删除", description = "传入ids")
    @PreAuth("hasPermission('base:task_people:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        CacheUtil.clear(TaskPeopleCache.TASK_PEOPLE_CACHE)
        return R.status(taskPeopleService.deleteLogic(Func.toLongList(ids)))
    }
}
