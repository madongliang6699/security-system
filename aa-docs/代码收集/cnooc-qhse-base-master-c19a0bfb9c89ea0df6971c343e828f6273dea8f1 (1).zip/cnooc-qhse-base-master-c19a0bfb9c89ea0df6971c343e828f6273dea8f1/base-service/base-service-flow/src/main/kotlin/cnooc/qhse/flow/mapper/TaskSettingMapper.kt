package cnooc.qhse.base.mapper

import cnooc.qhse.flow.pojo.entity.TaskSetting
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 任务设置表 Mapper 接口
 */
interface TaskSettingMapper : BaseMapper<TaskSetting>
