package cnooc.qhse.flow.service.impl

import cnooc.qhse.common.service.impl.BaseServiceImplKt
import cnooc.qhse.common.utils.notNullRetrieve
import cnooc.qhse.flow.mapper.DoneMapper
import cnooc.qhse.flow.pojo.entity.Done
import cnooc.qhse.flow.pojo.vo.DoneVO
import cnooc.qhse.flow.service.IDoneService
import cnooc.qhse.flow.service.ITodoService
import cnooc.qhse.flow.wrapper.DoneWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.extension.kotlin.KtQueryWrapper
import com.baomidou.mybatisplus.extension.plugins.pagination.Page
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.DateUtil
import org.springblade.plugin.workflow.app.entity.WfAppProcess
import org.springblade.plugin.workflow.core.cache.WfCategoryCache
import org.springblade.plugin.workflow.feign.IWorkflowClient
import org.springblade.plugin.workflow.process.model.WfProcess
import org.springframework.stereotype.Service
import java.time.LocalDateTime

@Service
class DoneServiceImpl(
    private val nutFlowService: IWorkflowClient,
    private val todoService: ITodoService,
) : BaseServiceImplKt<DoneMapper, Done>(), IDoneService {

    override fun getDonePage(
        businessCategory: String?,
        isFlow: Boolean?,
        flowDeploymentCategory: String?,
        query: Query
    ): IPage<DoneVO> {
        val donePage = Page<Done>(query.current.toLong(), query.size.toLong())
        donePage.records = mutableListOf()
        getInnerDones(donePage, businessCategory, isFlow, query)
        getFlowableDones(donePage, businessCategory, isFlow, flowDeploymentCategory, query)
        return DoneWrapper.build().pageVO(donePage)
    }

    private fun getInnerDones(donePage: Page<Done>, businessCategory: String?, isFlow: Boolean?, query: Query) {
        if (isFlow == true) {
            return
        }
        val qw = KtQueryWrapper(Done::class.java).eq(Done::userId, AuthUtil.getUserId()).orderByDesc(Done::createTime)
        if (!businessCategory.isNullOrBlank()) {
            qw.eq(Done::businessCategory, businessCategory)
        }
        val page = this.page(Page(query.current.toLong(), query.size.toLong()), qw)
        donePage.total += page.total
        donePage.records.addAll(page.records)
    }

    fun getFlowableDones(
        donePage: Page<Done>, businessCategory: String?, isFlow: Boolean?,
        flowDeploymentCategory: String?, query: Query
    ) {
        if (isFlow == false) {
            return
        }
        // 查询流程实例
        val appProcess = WfAppProcess()
        if (!flowDeploymentCategory.isNullOrBlank()) {
            appProcess.category = WfCategoryCache.getCategoryIdByName(flowDeploymentCategory)?.toString()
        } else {
            appProcess.processDefinitionKey = businessCategory
        }
        val taskPage = nutFlowService.doneList(appProcess, query.current, query.size).notNullRetrieve()
        donePage.total += taskPage.total
        donePage.records.addAll(taskPage.records.map { process2Done(it) })
        donePage.records.sortByDescending { it.createTime }
    }

    private fun process2Done(process: WfProcess): DoneVO {
        return DoneVO(
            userId = process.assignee?.toLong(),
            businessCategory = process.processDefinitionKey,
            taskName = process.taskName,
            businessKey = null,
            beginTime = process.createTime?.let { DateUtil.toDateTime(it.toInstant()) },
            doneTime = process.endTime?.let { DateUtil.toDateTime(it.toInstant()) },
            flow = process
        )
    }

    override fun addDoneByBusinessKey(businessKey: Long) {
        val todo = todoService.getByBusinessKey(businessKey)
        todo?.let {
            val done = Done(
                userId = todo.userId,
                businessCategory = todo.businessCategory,
                taskName = todo.taskName,
                businessKey = it.businessKey,
                beginTime = it.beginTime,
                endTime = it.endTime,
                doneTime = LocalDateTime.now(),
                remark = it.remark,
                tenantId = todo.tenantId
            )
            save(done)
        }
    }
}
