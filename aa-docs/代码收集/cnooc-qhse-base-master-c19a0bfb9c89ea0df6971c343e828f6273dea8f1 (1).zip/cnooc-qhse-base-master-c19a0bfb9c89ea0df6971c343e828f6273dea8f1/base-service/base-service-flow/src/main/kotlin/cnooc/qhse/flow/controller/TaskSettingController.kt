package cnooc.qhse.flow.controller

import cnooc.qhse.common.utils.toColumn
import cnooc.qhse.flow.pojo.entity.TaskSetting
import cnooc.qhse.flow.pojo.vo.TaskSettingVO
import cnooc.qhse.flow.service.ITaskSettingService
import cnooc.qhse.flow.wrapper.TaskSettingWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.secure.annotation.PreAuth
import org.springblade.core.tool.api.R
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import org.springframework.web.bind.annotation.RequestParam
import springfox.documentation.annotations.ApiIgnore

/**
 * 任务设置表 控制器
 *
 * @author Hugh Gao
 * @since 2023-08-29
 */
@RestController
@RequestMapping("/task-setting")
@Tag(name = "任务设置表", description = "任务设置表接口")
class TaskSettingController @Autowired constructor(private val taskSettingService: ITaskSettingService) :
    BladeController() {

    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入taskSetting")
    @PreAuth("hasPermission('flowable:task_setting:view')")
    fun detail(taskSetting: TaskSetting): R<TaskSettingVO> {
        val detail =
            taskSettingService.getOne(Condition.getQueryWrapper(taskSetting)) ?: return R.fail("未找到对应对象")
        return R.data(TaskSettingWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入taskSetting")
    fun list(@ApiIgnore @RequestParam taskSetting: Map<String, Any>, query: Query): R<IPage<TaskSettingVO>> {
        val qw = Condition.getQueryWrapper(taskSetting, TaskSetting::class.java)
        if (query.ascs.isNullOrBlank() && query.descs.isNullOrBlank()) {
            qw.orderByDesc(TaskSetting::createTime.toColumn())
        }
        val pages = taskSettingService.page(Condition.getPage(query), qw)
        return R.data(TaskSettingWrapper.build().pageVO(pages))
    }


    @PostMapping("/save")
    @ApiOperationSupport(order = 3)
    @Operation(summary = "新增", description = "传入taskSetting")
    @PreAuth("hasPermission('flowable:task_setting:add')")
    fun save(@Validated @RequestBody taskSetting: TaskSetting): R<Boolean> {
        return R.status(taskSettingService.save(taskSetting))
    }

    @PostMapping("/update")
    @ApiOperationSupport(order = 4)
    @Operation(summary = "修改", description = "传入taskSetting")
    @PreAuth("hasPermission('flowable:task_setting:edit')")
    fun update(@Validated @RequestBody taskSetting: TaskSetting): R<Boolean> {
        return R.status(taskSettingService.updateById(taskSetting))
    }

    @PostMapping("/remove")
    @ApiOperationSupport(order = 5)
    @Operation(summary = "逻辑删除", description = "传入ids")
    @PreAuth("hasPermission('flowable:task_setting:delete')")
    fun remove(@Parameter(description = "主键集合", required = true) @RequestParam ids: String): R<Boolean> {
        return R.status(taskSettingService.deleteLogic(Func.toLongList(ids)))
    }
}
