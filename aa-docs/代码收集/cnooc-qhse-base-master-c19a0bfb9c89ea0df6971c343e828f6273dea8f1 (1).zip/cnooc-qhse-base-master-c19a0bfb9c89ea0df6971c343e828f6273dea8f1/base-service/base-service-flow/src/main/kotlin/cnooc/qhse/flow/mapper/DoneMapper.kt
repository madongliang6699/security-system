package cnooc.qhse.flow.mapper

import cnooc.qhse.flow.pojo.entity.Done
import com.baomidou.mybatisplus.core.mapper.BaseMapper

interface DoneMapper : BaseMapper<Done>
