package cnooc.qhse.flow.controller

import cnooc.qhse.flow.pojo.entity.Done
import cnooc.qhse.flow.pojo.vo.DoneVO
import cnooc.qhse.flow.service.IDoneService
import cnooc.qhse.flow.wrapper.DoneWrapper
import com.baomidou.mybatisplus.core.metadata.IPage
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.boot.ctrl.BladeController
import org.springblade.core.mp.support.Condition
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/done")
@Tag(name = "办结事项", description = "办结事项接口")
class DoneController(private val doneService: IDoneService) : BladeController() {
    @GetMapping("/detail")
    @ApiOperationSupport(order = 1)
    @Operation(summary = "详情", description = "传入done")
    fun detail(done: Done): R<DoneVO> {
        val detail = doneService.getOne(Condition.getQueryWrapper(done))
        return R.data(DoneWrapper.build().entityVO(detail))
    }

    @GetMapping("/list")
    @ApiOperationSupport(order = 2)
    @Operation(summary = "分页", description = "传入done")
    fun list(@RequestParam businessCategory: String?, @RequestParam isFlow: Boolean?,
             @RequestParam flowDeploymentCategory: String?, @RequestParam current: Int, @RequestParam size: Int):
            R<IPage<DoneVO>> {
        val query = Query()
        query.current = current
        query.size = size
        // 待办事项与待签事项合并
        return R.data(doneService.getDonePage(businessCategory, isFlow, flowDeploymentCategory, query))
    }
}
