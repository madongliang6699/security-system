package cnooc.qhse.flow.wrapper

import cnooc.qhse.base.assign.AssigneeConstant
import cnooc.qhse.flow.pojo.entity.Done
import cnooc.qhse.flow.pojo.vo.DoneVO
import org.springblade.core.mp.support.BaseEntityWrapper
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.system.cache.DictCache
import org.springblade.system.cache.UserCache

class DoneWrapper : BaseEntityWrapper<Done, DoneVO>() {
    override fun entityVO(done: Done): DoneVO {
        val doneVo = BeanUtil.copy(done, DoneVO::class.java)!!
        doneVo.businessCategoryName = DictCache.getValue(AssigneeConstant.DICT_BUSINESS_CATEGORY, doneVo.businessCategory)
        UserCache.getUser(doneVo.userId)?.let {
            doneVo.userName = it.realName
        }
        return doneVo
    }

    companion object {
        fun build(): DoneWrapper {
            return DoneWrapper()
        }
    }
}
