package cnooc.qhse.common.utils

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

internal class PostCodeUtilTest {

    @Test
    fun getNextPostCode() {
        assertEquals("A01", PostCodeUtil.getNextPostCode(null))
        assertEquals("A01", PostCodeUtil.getNextPostCode(" "))
        assertEquals("A02", PostCodeUtil.getNextPostCode("A01"))
        assertEquals("A11", PostCodeUtil.getNextPostCode("A10"))
        assertEquals("B01", PostCodeUtil.getNextPostCode("A99"))
        assertEquals("Z99A01", PostCodeUtil.getNextPostCode("Z99"))
    }

    @Test
    fun getSubPostCode() {
        assertEquals("A01", PostCodeUtil.getSubPostCode(null, "A01"))
        assertEquals("A01A01", PostCodeUtil.getSubPostCode("A01", null))
        assertEquals("A01A02", PostCodeUtil.getSubPostCode("A01", "A01A01"))
    }

    @Test
    fun cutPostCode() {
        assertEquals(listOf<String>(), PostCodeUtil.cutPostCode(null))
        assertEquals(listOf("A01"), PostCodeUtil.cutPostCode("A01"))
        assertEquals(listOf("A01", "A01A01"), PostCodeUtil.cutPostCode("A01A01"))
    }
}
