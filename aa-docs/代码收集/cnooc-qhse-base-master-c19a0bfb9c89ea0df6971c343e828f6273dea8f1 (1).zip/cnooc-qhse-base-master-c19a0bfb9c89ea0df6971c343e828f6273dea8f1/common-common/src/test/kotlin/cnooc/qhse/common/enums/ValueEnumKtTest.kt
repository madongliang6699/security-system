package cnooc.qhse.common.enums

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

internal class ValueEnumKtTest {
    enum class StringValueTest(override val value: String, override val title: String): StringValueEnum {
        A("a", "A"),
    }

    enum class IntValueTest(override val value: Int, override val title: String): IntValueEnum {
        A(1, "A"),
    }

    @Test
    fun enumByStringTest() {
        assertEquals(StringValueTest.A, enumByString<StringValueTest>("a"))
        assertNull(enumByString<StringValueTest>("b"))

        assertEquals(StringValueTest.A, enumByStringTitle<StringValueTest>("A"))
        assertNull(enumByStringTitle<StringValueTest>("a"))
    }

    @Test
    fun existEnumByString() {
        assertTrue(isStringEnumExist<StringValueTest>("a"))
        assertFalse(isStringEnumExist<StringValueTest>("b"))
    }

    @Test
    fun enumByIntTest() {
        assertEquals(IntValueTest.A, enumByInt<IntValueTest>(1))
        assertNull(enumByInt<IntValueTest>(2))
    }

    @Test
    fun existEnumByInt() {
        assertTrue(isIntEnumExist<IntValueTest>(1))
        assertFalse(isIntEnumExist<IntValueTest>(2))
    }
}
