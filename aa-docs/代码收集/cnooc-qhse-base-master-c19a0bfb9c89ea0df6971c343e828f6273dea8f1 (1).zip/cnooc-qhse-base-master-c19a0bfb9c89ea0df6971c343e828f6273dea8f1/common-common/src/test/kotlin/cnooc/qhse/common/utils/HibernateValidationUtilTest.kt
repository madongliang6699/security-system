package cnooc.qhse.common.utils

import cnooc.qhse.common.entity.TenantEntityKt
import cnooc.qhse.common.utils.HibernateValidationUtil.validateFields
import io.swagger.v3.oas.annotations.media.Schema
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import javax.validation.constraints.Max
import javax.validation.constraints.Min
import javax.validation.constraints.NotNull
import javax.validation.constraints.Size

internal class HibernateValidationUtilTest {
    class TestClass (
        @field:NotNull
        @field:Size(min = 1, max = 10)
        @Schema(description = "名称")
        var name: String? = null,

        @field:NotNull
        @field:Min(1)
        @field:Max(120)
        var age: Int? = null
    ): TenantEntityKt()

    @Test
    fun validateFields() {
        val testClass = TestClass()
        val errors = testClass.validateFields(TestClass::name, throws = false)
        assertEquals(1, errors.size)
        assertEquals("名称: 不能为null", errors[0])

        assertThrows<IllegalArgumentException> {
            testClass.validateFields(TestClass::name)
        }

        val testClass1 = TestClass(name = "")
        val errors1 = testClass1.validateFields(TestClass::name, throws = false)
        assertEquals(1, errors1.size)
        assertEquals("名称: 个数必须在1和10之间", errors1[0])

        val testClass2 = TestClass(name = "", age = 0)
        val errors2 = testClass2.validateFields(TestClass::name, TestClass::age, throws = false)
        assertEquals(2, errors2.size)
        assertEquals("名称: 个数必须在1和10之间", errors2[0])
        assertEquals("age: 最小不能小于1", errors2[1])
    }
}
