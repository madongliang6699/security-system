package cnooc.qhse.common.utils

import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

internal class ValueValidationUtilTest {

    @Test
    fun isInTheInterval() {
        assertTrue(ValueValidationUtil.isInTheInterval("2", "[1,2]"))
        assertFalse(ValueValidationUtil.isInTheInterval("2", "[1,2)"))
        assertTrue(ValueValidationUtil.isInTheInterval("2", "(-∞, 2]"))
        assertFalse(ValueValidationUtil.isInTheInterval("2", "(-∞, 2)"))
        assertTrue(ValueValidationUtil.isInTheInterval("2", "[2, ∞)"))
        assertFalse(ValueValidationUtil.isInTheInterval("2", "(2, ∞)"))
        assertTrue(ValueValidationUtil.isInTheInterval("0.04", "<5%"))
        assertTrue(ValueValidationUtil.isInTheInterval("0.06", "≥5%"))
        assertTrue(ValueValidationUtil.isInTheInterval("1.28", "(125%,135%)U(70%,80%)"))
        assertFalse(ValueValidationUtil.isInTheInterval("0.9", "(125%,135%)U(70%,80%)"))
    }
}
