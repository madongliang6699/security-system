package cnooc.qhse.common.utils

import cn.afterturn.easypoi.excel.annotation.Excel
import cn.afterturn.easypoi.excel.entity.result.ExcelVerifyHandlerResult
import cn.afterturn.easypoi.handler.inter.IExcelDataModel
import cn.afterturn.easypoi.handler.inter.IExcelVerifyHandler
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.constraints.Min
import jakarta.validation.constraints.Size
import jakarta.validation.groups.Default
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

internal class ExcelValidationUtilTest {
    interface Group

    class TestEntity(
        @Excel(name = "名称excel")
        @Schema(description = "名称api")
        @field:Size(min = 1, max = 3, message = "姓名长度在1与3之间", groups = [Group::class])
        var name: String,

        @Schema(description = "年龄api")
        @field:Min(value = 1, message = "年龄不能小于1")
        var age: Int,

        var noAnnotation: String? = null
    )

    class TestEntity1(
        @Excel(name = "名称excel")
        @Schema(description = "名称api")
        @field:Size(min = 1, max = 3, message = "姓名长度在1与3之间")
        var name: String,

        @Schema(description = "年龄api")
        @field:Min(value = 1, message = "年龄不能小于1")
        var age: Int,
    ) : IExcelDataModel {
        override fun getRowNum(): Int {
            return 1
        }

        override fun setRowNum(p0: Int?) {
        }
    }

    @Test
    fun validation() {
        // 全部分组
        val message1 =  ExcelValidationUtil.validation(
            TestEntity("test", 0),
            arrayOf(Default::class.java, Group::class.java)
        )
        assertTrue(message1!!.contains("姓名长度在1与3之间"))
        assertTrue(message1.contains("年龄不能小于1"))

        // 仅指定分组
        assertEquals("姓名长度在1与3之间", ExcelValidationUtil.validation(TestEntity("test", 0), arrayOf(Group::class.java)))

        // 带行号的
        val message = ExcelValidationUtil.validation(TestEntity1("test", 0), null)!!
        assertEquals("第2行：姓名长度在1与3之间\n第2行：年龄不能小于1".length, message.length)
        assertTrue(message.contains("第2行：姓名长度在1与3之间"))
        assertTrue(message.contains("第2行：年龄不能小于1"))
    }

    @Test
    fun getFieldFriendlyName() {
        // 有excel，有api
        assertEquals("名称excel", ExcelValidationUtil.getFieldFriendlyName(TestEntity::name))
        // 只有api
        assertEquals("年龄api", ExcelValidationUtil.getFieldFriendlyName(TestEntity::age))

        // 没有注解显示字段名称
        assertEquals("noAnnotation", ExcelValidationUtil.getFieldFriendlyName(TestEntity::noAnnotation))
    }

    @Test
    fun verifyObjects() {
        class VerifyHandler : IExcelVerifyHandler<TestEntity> {
            override fun verifyHandler(p0: TestEntity): ExcelVerifyHandlerResult {
                val result = ExcelVerifyHandlerResult()
                result.isSuccess = p0.age > 1
                if (!result.isSuccess) {
                    result.msg = "错误"
                }
                return result
            }
        }

        val results = ExcelValidationUtil.verifyObjects(
            VerifyHandler(),
            listOf(TestEntity("test", 0), TestEntity("test1", 2))
        )
        assertEquals(1, results.size)
        assertFalse(results[0].isSuccess)
        assertEquals("错误", results[0].msg)
    }
}
