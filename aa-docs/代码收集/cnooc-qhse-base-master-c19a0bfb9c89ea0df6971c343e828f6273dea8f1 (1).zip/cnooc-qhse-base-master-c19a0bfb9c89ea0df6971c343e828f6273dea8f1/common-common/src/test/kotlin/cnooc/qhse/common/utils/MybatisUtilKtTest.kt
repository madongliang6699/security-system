package cnooc.qhse.common.utils

import cnooc.qhse.common.entity.BaseEntityKt
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

internal class MybatisUtilKtTest {

    @Test
    fun toColumn() {
        assertEquals("create_time", BaseEntityKt::createTime.toColumn())
        assertEquals("status", BaseEntityKt::status.toColumn())
    }

    @Test
    fun resolveFieldName() {
        assertEquals("name", resolveFieldName("getName"))
        assertEquals("ok", resolveFieldName("isOk"))
        assertEquals("getName", resolveFieldName("GetName"))
        assertEquals("isOk", resolveFieldName("IsOk"))
        assertEquals("", resolveFieldName(""))
    }
}
