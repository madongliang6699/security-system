package cnooc.qhse.common.utils

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

internal class ObjectUtilKtTest {
    class TestClass1 {
        var name: String? = null
        var int1: Int? = null
        var long1: Long? = null
        var list1: List<String>? = null
    }

    class TestClass2 {
        var name: String? = null
        var int1: Int? = null
        var long1: Long? = null
        var list1: List<String>? = null
    }

    @Test
    fun copyPropsFrom() {
        val testClass1 = TestClass1()
        with(testClass1) {
            name = "test"
            int1 = 1
            long1 = 2L
            list1 = listOf("1", "2")
        }
        // 完整的拷贝
        val testClass2 = TestClass2()
        testClass2.copyPropsFrom(testClass1)
        assertEquals("test", testClass2.name)
        assertEquals(1, testClass2.int1)
        assertEquals(2L, testClass2.long1)
        assertEquals(testClass1.list1, testClass2.list1)

        // 只拷贝指定的属性
        val testClass3 = TestClass2()
        testClass3.copyPropsFrom(testClass1, TestClass1::name, TestClass1::list1)
        assertEquals(testClass1.name, testClass3.name)
        assertEquals(testClass1.list1, testClass3.list1)
        assertNull(testClass3.int1)
        assertNull(testClass3.long1)
    }

    @Test
    fun toJsonBase64() {
        val testClass1 = TestClass1()
        with(testClass1) {
            name = "test"
            int1 = 1
            long1 = 2L
            list1 = listOf("1", "2")
        }
        assertEquals(
            "eyJuYW1lIjoidGVzdCIsImludDEiOjEsImxvbmcxIjoyLCJsaXN0MSI6WyIxIiwiMiJdfQ==",
            testClass1.toJsonBase64()
        )
    }
}
