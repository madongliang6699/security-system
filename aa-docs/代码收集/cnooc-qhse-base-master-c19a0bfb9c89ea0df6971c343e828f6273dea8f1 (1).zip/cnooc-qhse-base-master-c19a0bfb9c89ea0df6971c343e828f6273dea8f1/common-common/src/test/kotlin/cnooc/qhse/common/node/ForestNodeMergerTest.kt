package cnooc.qhse.common.node

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

internal class ForestNodeMergerTest {
    data class TestNode(
        override var id: Long?, override var parentId: Long?, var content: String, override var children:
        List<TestNode>? = listOf()
    ) : INodeKt<TestNode>

    @Test
    fun merge() {
        val list = mutableListOf(
            TestNode(1L, 0L, "1"),
            TestNode(2L, 0L, "2"),
            TestNode(3L, 1L, "3"),
            TestNode(4L, 2L, "4"),
            TestNode(5L, 3L, "5"),
            TestNode(6L, 4L, "6"),
            TestNode(7L, 3L, "7"),
            TestNode(8L, 5L, "8"),
            TestNode(9L, 6L, "9"),
            TestNode(10L, 9L, "10"),
        )
        val tns = ForestNodeMergerKt.merge(list)
        assertEquals(
            listOf(
                TestNode(1L, 0L, "1", children = mutableListOf(
                        TestNode(3L, 1L, "3", children = mutableListOf(
                                TestNode(5L, 3L, "5", children = mutableListOf(
                                        TestNode(8L, 5L, "8")
                                    )
                                ),
                                TestNode(7L, 3L, "7")
                            )
                        ),
                    )
                ),
                TestNode(
                    2L, 0L, "2", children = mutableListOf(
                        TestNode(4L, 2L, "4", children = mutableListOf(
                                TestNode(6L, 4L, "6", children = mutableListOf(
                                        TestNode(9L, 6L, "9", children = mutableListOf(
                                                TestNode(10L, 9L, "10")
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                ),
            ), tns
        )

    }

    @Test
    fun getListAtLevel() {
        val list = listOf(
            TestNode(
                1L, 0L, "1", children = mutableListOf(
                    TestNode(3L, 1L, "3", children = mutableListOf(
                            TestNode(5L, 3L, "5", children = mutableListOf(
                                    TestNode(8L, 5L, "8")
                                )
                            ),
                            TestNode(7L, 3L, "7")
                        )
                    ),
                )
            ),
            TestNode(2L, 0L, "2", children = mutableListOf(
                    TestNode(4L, 2L, "4", children = mutableListOf(
                            TestNode(6L, 4L, "6", children = mutableListOf(
                                    TestNode(9L, 6L, "9", children = mutableListOf(
                                            TestNode(10L, 9L, "10")
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            ),
        )
        // 无效层
        val result = ForestNodeMergerKt.getListAtLevel(list, 0)
        assertEquals(listOf<TestNode>(), result)

        // 第一层
        val result1 = ForestNodeMergerKt.getListAtLevel(list, 1)
        assertEquals(result1, result1)

        // 第二层
        val result2 = ForestNodeMergerKt.getListAtLevel(list, 2)
        assertEquals(
            listOf(
                TestNode(3L, 1L, "3", children = mutableListOf(
                        TestNode(5L, 3L, "5", children = mutableListOf(
                                TestNode(8L, 5L, "8")
                            )
                        ),
                        TestNode(7L, 3L, "7")
                    )
                ),
                TestNode(4L, 2L, "4", children = mutableListOf(
                        TestNode(6L, 4L, "6", children = mutableListOf(
                                TestNode(9L, 6L, "9", children = mutableListOf(
                                        TestNode(10L, 9L, "10")
                                    )
                                )
                            )
                        )
                    )
                )
            ), result2
        )

        // 第三层
        val result3 = ForestNodeMergerKt.getListAtLevel(list, 3)
        assertEquals(
            listOf(
                TestNode(5L, 3L, "5", children = mutableListOf(
                        TestNode(8L, 5L, "8")
                    )
                ),
                TestNode(7L, 3L, "7"),
                TestNode(6L, 4L, "6", children = mutableListOf(
                        TestNode(9L, 6L, "9", children = mutableListOf(
                                TestNode(10L, 9L, "10")
                            )
                        )
                    )
                )
            ), result3
        )
    }

    @Test
    fun getListAtLevelIncludingParent() {
        val list = listOf(
            TestNode(1L, 0L, "1", children = mutableListOf(
                    TestNode(3L, 1L, "3", children = mutableListOf(
                            TestNode(5L, 3L, "5", children = mutableListOf(
                                    TestNode(8L, 5L, "8")
                                )
                            ),
                            TestNode(7L, 3L, "7")
                        )
                    ),
                )
            ),
            TestNode(2L, 0L, "2", children = mutableListOf(
                    TestNode(4L, 2L, "4", children = mutableListOf(
                            TestNode(6L, 4L, "6", children = mutableListOf(
                                    TestNode(9L, 6L, "9", children = mutableListOf(
                                            TestNode(10L, 9L, "10")
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            ),
        )
        // 无效层
        val result = ForestNodeMergerKt.getListAtLevelIncludingParent(list, 0)
        assertEquals(listOf<TestNode>(), result)

        // 第一层
        val result1 = ForestNodeMergerKt.getListAtLevelIncludingParent(list, 1)
        assertEquals(list, result1)

        // 第二层
        val result2 = ForestNodeMergerKt.getListAtLevelIncludingParent(list, 2)
        assertEquals(
            listOf(
                TestNode(1L, 0L, "1", children = mutableListOf(
                        TestNode(3L, 1L, "3", children = mutableListOf(
                                TestNode(5L, 3L, "5", children = mutableListOf(
                                        TestNode(8L, 5L, "8")
                                    )
                                ),
                                TestNode(7L, 3L, "7")
                            )
                        ),
                    )
                ),
                TestNode(2L, 0L, "2", children = mutableListOf(
                        TestNode(4L, 2L, "4", children = mutableListOf(
                                TestNode(6L, 4L, "6", children = mutableListOf(
                                        TestNode(9L, 6L, "9", children = mutableListOf(
                                                TestNode(10L, 9L, "10")
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                ),
                TestNode(3L, 1L, "3", children = mutableListOf(
                        TestNode(5L, 3L, "5", children = mutableListOf(
                                TestNode(8L, 5L, "8")
                            )
                        ),
                        TestNode(7L, 3L, "7")
                    )
                ),
                TestNode(4L, 2L, "4", children = mutableListOf(
                        TestNode(6L, 4L, "6", children = mutableListOf(
                                TestNode(9L, 6L, "9", children = mutableListOf(
                                        TestNode(10L, 9L, "10")
                                    )
                                )
                            )
                        )
                    )
                )
            ), result2
        )
    }

    @Test
    fun getListAtLevelIncludingChildren() {
        val list = listOf(
            TestNode(1L, 0L, "1", children = mutableListOf(
                    TestNode(3L, 1L, "3", children = mutableListOf(
                            TestNode(5L, 3L, "5", children = mutableListOf(
                                    TestNode(8L, 5L, "8")
                                )
                            ),
                            TestNode(7L, 3L, "7")
                        )
                    ),
                )
            ),
            TestNode(2L, 0L, "2", children = mutableListOf(
                    TestNode(4L, 2L, "4", children = mutableListOf(
                            TestNode(6L, 4L, "6", children = mutableListOf(
                                    TestNode(9L, 6L, "9", children = mutableListOf(
                                            TestNode(10L, 9L, "10")
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            ),
        )
        // 无效层
        val result = ForestNodeMergerKt.getListAtLevelIncludingChildren(list, 0)
        assertEquals(listOf<TestNode>(), result)

        // 第二层
        val result2 = ForestNodeMergerKt.getListAtLevelIncludingChildren(list, 2)
        assertEquals(
            listOf(
                TestNode(3L, 1L, "3", children = mutableListOf(
                        TestNode(5L, 3L, "5", children = mutableListOf(
                                TestNode(8L, 5L, "8")
                            )
                        ),
                        TestNode(7L, 3L, "7")
                    )
                ),
                TestNode(4L, 2L, "4", children = mutableListOf(
                        TestNode(6L, 4L, "6", children = mutableListOf(
                                TestNode(9L, 6L, "9", children = mutableListOf(
                                        TestNode(10L, 9L, "10")
                                    )
                                )
                            )
                        )
                    )
                ),
                TestNode(5L, 3L, "5", children = mutableListOf(
                        TestNode(8L, 5L, "8")
                    )
                ),
                TestNode(7L, 3L, "7"),
                TestNode(6L, 4L, "6", children = mutableListOf(
                        TestNode(9L, 6L, "9", children = mutableListOf(
                                TestNode(10L, 9L, "10")
                            )
                        )
                    )
                ),
                TestNode(8L, 5L, "8"),
                TestNode(9L, 6L, "9", children = mutableListOf(
                    TestNode(10L, 9L, "10")
                )),
                TestNode(10L, 9L, "10")
            ), result2
        )
    }
}
