package cnooc.qhse.common.excel

/**
 * 用于EasyExcel替换字符串。需要配合EasyExcelReplaceWithConverter系列转换器使用。
 *
 * 用法：
 * ```
 * @ExcelProperty("隐患来源", converter = EasyExcelReplaceWithConverter::class)
 * @ExcelReplaceWith(["人工提交_common", "专项检查_special", "巡检_inspection", "随手拍_shot"])
 * var hazardSource: String? = null,
 * ```
 * 再指定EasyExcelReplaceWithConverter，即可将excel中的男女替换为0和1
 */
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FIELD)
annotation class EasyExcelReplaceWith (
    val value: Array<String>,
)
