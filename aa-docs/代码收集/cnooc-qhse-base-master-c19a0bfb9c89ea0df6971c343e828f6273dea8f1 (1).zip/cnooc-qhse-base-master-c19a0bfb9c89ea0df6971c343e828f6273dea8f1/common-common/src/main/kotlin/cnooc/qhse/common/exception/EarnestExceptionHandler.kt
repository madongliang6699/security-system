package cnooc.qhse.common.exception

import io.github.oshai.kotlinlogging.KotlinLogging
import org.springblade.core.tool.api.R
import org.springframework.core.Ordered
import org.springframework.core.annotation.Order
import org.springframework.dao.DataAccessException
import org.springframework.dao.DuplicateKeyException
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.ResponseStatus
import org.springframework.web.bind.annotation.RestControllerAdvice
import java.sql.SQLException


private val log = KotlinLogging.logger {}

/**
 * 全局异常处理，兜底异常为上游的BladeRestExceptionTranslator类
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
class EarnestExceptionHandler {
    @ExceptionHandler(DuplicateKeyException::class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    fun handleDuplicateKeyException(e: DuplicateKeyException): R<*> {
        log.error(e) { "数据库中已存在该记录}" }
        return R.fail<Any>("数据库中已存在相同记录")
    }

    @ExceptionHandler(SQLException::class, DataAccessException::class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    fun databaseError(e: Exception): R<*> {
        log.error(e) { "数据库错误，请联系管理员" }
        return R.fail<Any>("数据库错误，请联系管理员")
    }
}
