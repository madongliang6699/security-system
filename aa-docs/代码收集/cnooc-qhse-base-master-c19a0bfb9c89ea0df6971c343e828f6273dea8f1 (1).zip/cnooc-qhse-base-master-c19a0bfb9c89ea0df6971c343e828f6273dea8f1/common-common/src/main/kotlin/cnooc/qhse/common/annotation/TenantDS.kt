package cnooc.qhse.common.annotation

import com.baomidou.dynamic.datasource.annotation.DS

/**
 * 指定租户动态数据源切换.
 */
@DS("#token.tenantId")
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY_GETTER,
    AnnotationTarget.PROPERTY_SETTER
)
@Retention(AnnotationRetention.RUNTIME)
@MustBeDocumented
annotation class TenantDS
