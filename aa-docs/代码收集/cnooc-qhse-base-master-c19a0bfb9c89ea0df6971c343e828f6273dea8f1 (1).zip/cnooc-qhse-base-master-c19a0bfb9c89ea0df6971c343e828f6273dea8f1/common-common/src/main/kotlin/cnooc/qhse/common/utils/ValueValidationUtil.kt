package cnooc.qhse.common.utils

import org.graalvm.polyglot.*

/**
 * 校验数据的正确性
 */
object ValueValidationUtil {
    /**
     * 判断data_value是否在interval区间范围内
     * @param data 数值类型的
     * @param interval 正常的数学区间，包括无穷大等，如：(1,3)、>5%、(-∞,6]、(125%,135%)U(70%,80%)
     * @return true：表示data_value在区间interval范围内，false：表示data_value不在区间interval范围内
     */
    fun isInTheInterval(data: String, interval: String): Boolean {
        //将区间和data_value转化为可计算的表达式
        val formula = getFormulaByAllInterval(data, interval, "||")
        return Context.create().use {
            it.eval("js", formula).asBoolean()
        }
    }

    /**
     * 将所有阀值区间转化为公式：如
     * [75,80)   =》        date_value < 80 && date_value >= 75
     * (125%,135%)U(70%,80%)   =》        (date_value < 1.35 && date_value > 1.25) || (date_value < 0.8 && date_value > 0.7)
     * @param date
     * @param interval  形式如：(125%,135%)U(70%,80%)
     * @param connector 连接符 如：") || ("
     */
    private fun getFormulaByAllInterval(date: String, interval: String, connector: String): String {
        val buff = StringBuilder()
        for (limit in interval.split("U").toTypedArray()) { //如：（125%,135%）U (70%,80%)
            buff.append("(").append(getFormulaByInterval(date, limit, " && ")).append(")").append(connector)
        }
        var allLimitInterval = buff.toString()
        val index = allLimitInterval.lastIndexOf(connector)
        allLimitInterval = allLimitInterval.substring(0, index)
        return allLimitInterval
    }

    /**
     * 将整个阀值区间转化为公式：如
     * 145)      =》         date_value < 145
     * [75,80)   =》        date_value < 80 && date_value >= 75
     * @param date
     * @param interval  形式如：145)、[75,80)
     * @param connector 连接符 如：&&
     */
    private fun getFormulaByInterval(date: String, interval: String, connector: String): String {
        val buff = StringBuilder()
        for (halfInterval in interval.split(",").toTypedArray()) { //如：[75,80)、≥80
            buff.append(getFormulaByHalfInterval(halfInterval, date)).append(connector)
        }
        var limitInterval = buff.toString()
        val index = limitInterval.lastIndexOf(connector)
        limitInterval = limitInterval.substring(0, index)
        return limitInterval
    }

    /**
     * 将半个阀值区间转化为公式：如
     * 145)      =》         date_value < 145
     * ≥80%      =》         date_value >= 0.8
     * [130      =》         date_value >= 130
     * <80%     =》         date_value < 0.8
     * @param halfInterval  形式如：145)、≥80%、[130、<80%
     * @param dateValue
     * @return date_value < 145
     */
    private fun getFormulaByHalfInterval(halfInterval: String, dateValue: String): String {
        val half = halfInterval.trim()
        if (half.contains("∞")) { //包含无穷大则不需要公式
            return "1 == 1"
        }
        val formula = StringBuffer()
        val data: String
        val opera: String
        if (half.matches(Regex("^([<>≤≥\\[(]{1}(-?\\d+\\.?\\d*%?))$"))) { //表示判断方向（如>）在前面 如：≥80%
            opera = half.substring(0, 1)
            data = half.substring(1)
        } else { //[130、145)
            opera = half.substring(half.length - 1)
            data = half.substring(0, half.length - 1)
        }
        val value = dealPercent(data)
        formula.append(dateValue).append(" ").append(opera).append(" ").append(value)
        val a = formula.toString()
        //转化特定字符
        return a.replace("[", ">=").replace("(", ">").replace("]", "<=")
            .replace(")", "<").replace("≤", "<=").replace("≥", ">=")
    }

    /**
     * 去除百分号，转为小数
     * @param str 可能含百分号的数字
     * @return
     */
    private fun dealPercent(str: String): Double {
        val d = if (str.contains("%")) {
            str.substring(0, str.length - 1).toDouble() / 100
        } else {
            str.toDouble()
        }
        return d
    }
}
