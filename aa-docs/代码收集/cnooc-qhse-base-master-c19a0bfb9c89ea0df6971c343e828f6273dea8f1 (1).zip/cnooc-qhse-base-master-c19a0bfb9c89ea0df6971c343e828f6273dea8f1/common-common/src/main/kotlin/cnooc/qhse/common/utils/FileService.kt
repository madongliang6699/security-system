package cnooc.qhse.common.utils

import cn.hutool.core.util.ZipUtil
import jakarta.servlet.http.HttpServletResponse
import org.springblade.core.tool.utils.FileUtil
import org.springframework.web.multipart.MultipartFile
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.nio.file.Paths
import java.util.*

object FileService{
    /**
     * 文件下载
     * @param inputStream
     * @param fileName
     * @param response
     */
    fun downloadFile(inputStream: InputStream, fileName: String, response: HttpServletResponse?) {
        response!!.contentType = "application/x-msdownload"
        response.setHeader("Content-Disposition", "attachment;filename=$fileName")
        var os: OutputStream? = null
        try {
            os = response.outputStream
            val buffer = ByteArray(1024)
            var len: Int
            while (inputStream.read(buffer).also { len = it } != -1) {
                os.write(buffer, 0, len)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            throw Exception("下载文件异常")
        } finally {
            os?.close()
            inputStream.close()
        }
    }

    /**
     * 解压MultiFile到指定目录并返回目录下的文件，如果目录下有多层嵌套的单个文件夹，则返回最深的那个文件夹下的文件
     * @throws Exception 如果文件不能读取或者解压失败
     */
    fun unzipMultiFileToDir(zipFile: MultipartFile, dir: File) : Array<File> {
        val tempDir = FileUtil.getTempDirPath()
        val uuid = UUID.randomUUID().toString()
        val zipRestoreFile = Paths.get(tempDir, "$uuid.zip").toFile()
        try {
            zipFile.transferTo(zipRestoreFile)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            ZipUtil.unzip(zipRestoreFile, dir, Charset.forName("GBK"))
        } catch (e: Exception) {
            FileUtil.deleteQuietly(zipRestoreFile)
        }
        var newDir = dir
        // 查找嵌套的文件夹
        do {
            val files = dir.listFiles()!!
            if (files.size == 1 && files[0].isDirectory) {
                newDir = files[0]
            } else {
                break
            }
        } while (true)
        return newDir.listFiles() ?: throw Exception("解压文件失败，文件不能读取")
    }
}
