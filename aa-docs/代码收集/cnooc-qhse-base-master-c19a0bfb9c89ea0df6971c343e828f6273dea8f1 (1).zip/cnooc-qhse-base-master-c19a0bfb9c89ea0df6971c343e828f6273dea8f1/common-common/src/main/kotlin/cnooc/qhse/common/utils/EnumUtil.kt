package cnooc.qhse.common.utils

import cnooc.qhse.common.enums.IntValueEnum
import cnooc.qhse.common.enums.StringValueEnum

object EnumUtil {
    /**
     * 通过int值获取枚举
     * @param clazz 需要转换到的枚举类
     * @param value int值
     * @return 枚举
     * @param <T> 枚举类
    </T> */
    fun <T : IntValueEnum> enumByInt(clazz: Class<T>, value: Int): T? {
        for (t in clazz.getEnumConstants()) {
            if (t.value == value) {
                return t
            }
        }
        return null
    }

    /**
     * 通过title获取枚举
     * @param clazz 需要转换到的枚举类
     * @param title title
     * @return 枚举
     * @param <T> 枚举类
    </T> */
    fun <T : IntValueEnum> enumByIntTitle(clazz: Class<T>, title: String): T? {
        for (t in clazz.getEnumConstants()) {
            if (t.title == title) {
                return t
            }
        }
        return null
    }

    /**
     * 判断int值对应用枚举是否存在
     */
    fun <T : IntValueEnum> isIntEnumExist(clazz: Class<T>, value: Int): Boolean {
        for (t in clazz.getEnumConstants()) {
            if (t!!.value == value) {
                return true
            }
        }
        return false
    }


    /**
     * 通过String值获取枚举
     * @param clazz 需要转换到的枚举类
     * @param value String字符串
     * @return 枚举
     * @param <T> 枚举类
    </T> */
    fun <T : StringValueEnum> enumByString(clazz: Class<T>, value: String): T? {
        for (t in clazz.getEnumConstants()) {
            if (t!!.value == value) {
                return t
            }
        }
        return null
    }

    /**
     * 通过title获取枚举
     * @param clazz 需要转换到的枚举类
     * @param title title
     * @return 枚举
     * @param <T> 枚举类
    </T> */
    fun <T : StringValueEnum> enumByStringTitle(clazz: Class<T>, title: String): T? {
        for (t in clazz.getEnumConstants()) {
            if (t.title == title) {
                return t
            }
        }
        return null
    }

    /**
     * 判断String值对应用枚举是否存在
     */
    fun <T : StringValueEnum> isStringEnumExist(clazz: Class<T>, value: String): Boolean {
        for (t in clazz.getEnumConstants()) {
            if (t.value == value) {
                return true
            }
        }
        return false
    }
}
