package cnooc.qhse.common.excel

/**
 * 用于任意Entity中的value与name之间的转换。需要配合EasyExcelEntityLabelAndValueConverter一起使用。
 *
 * @see EasyExcelEntityLabelAndValueConverter
 *
 * 设定如下：
 * ```
 * @EasyExcelEntityLabelAndValue(tableName, valueField, labelField)
 * ```
 * 系统可以根据valueField和labelField自动转换，其中tableName为数据表名，理论为为下划线分割的小写单词，valueField为数据表中的值字段名，labelField为数据表中的name字段名
 */
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FIELD)
annotation class EasyExcelEntityLabelAndValue (
    /**
     * 数据表名，理论为为下划线分割的小写单词
     */
    val tableName: String,
    /**
     * 数据表中的值字段名
     */
    val valueField: String,
    /**
     * 数据表中的name字段名
     */
    val labelField: String,
)
