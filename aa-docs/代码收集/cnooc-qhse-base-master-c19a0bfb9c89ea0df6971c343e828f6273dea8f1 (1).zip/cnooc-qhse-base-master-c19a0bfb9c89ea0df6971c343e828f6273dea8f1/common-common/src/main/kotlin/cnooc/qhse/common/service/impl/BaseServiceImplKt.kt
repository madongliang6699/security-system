package cnooc.qhse.common.service.impl

import cnooc.qhse.common.entity.BaseEntityKt
import cnooc.qhse.common.entity.TenantEntityKt
import cnooc.qhse.common.service.BaseServiceKt
import com.baomidou.mybatisplus.core.mapper.BaseMapper
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.BeanUtil
import org.springblade.core.tool.utils.Func
import org.springframework.transaction.annotation.Transactional
import org.springframework.validation.annotation.Validated
import java.time.LocalDateTime

@Validated
open class BaseServiceImplKt<M : BaseMapper<T>, T : BaseEntityKt> : ServiceImpl<M, T>(), BaseServiceKt<T> {

    override fun save(entity: T): Boolean {
        resolveEntity(entity)
        return super<ServiceImpl>.save(entity)
    }

    override fun saveBatch(entityList: Collection<T>, batchSize: Int): Boolean {
        entityList.forEach { resolveEntity(it) }
        return super<ServiceImpl>.saveBatch(entityList, batchSize)
    }

    override fun updateById(entity: T): Boolean {
        resolveEntity(entity)
        return super<ServiceImpl>.updateById(entity)
    }

    override fun updateBatchById(entityList: Collection<T>, batchSize: Int): Boolean {
        entityList.forEach { resolveEntity(it) }
        return super<ServiceImpl>.updateBatchById(entityList, batchSize)
    }

    override fun saveOrUpdate(entity: T): Boolean {
        return if (entity.id == null) save(entity) else updateById(entity)
    }

    override fun saveOrUpdateBatch(entityList: Collection<T>, batchSize: Int): Boolean {
        entityList.forEach { resolveEntity(it) }
        return super<ServiceImpl>.saveOrUpdateBatch(entityList, batchSize)
    }

    @Transactional(rollbackFor = [Exception::class])
    override fun deleteLogic(ids: List<Long>): Boolean {
        val user = AuthUtil.getUser()
        val list: MutableList<T> = ArrayList()
        ids.forEach{ id ->
            val entity = BeanUtil.newInstance<T>(currentModelClass())
            if (user != null) {
                entity!!.updateUser = user.userId
            }
            entity!!.updateTime = LocalDateTime.now()
            entity.id = id
            list.add(entity)
        }
        return super<ServiceImpl>.updateBatchById(list) && super<ServiceImpl>.removeByIds(ids)
    }

    override fun changeStatus(ids: List<Long>, status: Int): Boolean {
        val user = AuthUtil.getUser()
        val list: MutableList<T> = mutableListOf()
        ids.forEach{ id ->
            val entity = BeanUtil.newInstance<T>(currentModelClass())
            if (user != null) {
                entity.updateUser = user.userId
            }
            entity.updateTime = LocalDateTime.now()
            entity.id = id
            entity.status = status
            list.add(entity)
        }
        return super<ServiceImpl>.updateBatchById(list)
    }

    private fun resolveEntity(entity: T) {
        val user = AuthUtil.getUser()
        val now = LocalDateTime.now()
        // 新增
        if (entity.id == null) {
            // 如果字段有值，表示用户填写，不更新
            user?.let {
                if (entity.createUser == null) {
                    entity.createUser = user.userId
                }
                if (entity.createDept == null) {
                    entity.createDept = Func.firstLong(user.deptId)
                }
            }
            if (entity.createTime == null) {
                entity.createTime = now
            }
            if (entity.status == null) {
                // 默认状态为0
                entity.status = 0
            }
        }
        // 无论新增与更新
        if (user != null) {
            entity.updateUser = user.userId
        }
        entity.updateTime = now
        entity.isDeleted = BladeConstant.DB_NOT_DELETED
        // 处理多租户逻辑，若字段值为空，则不进行操作
        if (entity is TenantEntityKt && entity.tenantId.isNullOrBlank()) {
            entity.tenantId = null
        }
    }
}
