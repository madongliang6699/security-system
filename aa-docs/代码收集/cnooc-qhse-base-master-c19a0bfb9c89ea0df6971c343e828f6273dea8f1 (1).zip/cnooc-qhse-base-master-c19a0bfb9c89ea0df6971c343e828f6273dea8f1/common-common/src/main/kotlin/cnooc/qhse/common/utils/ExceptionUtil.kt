package cnooc.qhse.common.utils

import org.springframework.dao.DuplicateKeyException

object ExceptionUtil {
    fun extractDuplicateKeyExceptionMessage(e: Exception): String {
        return when (e) {
            is DuplicateKeyException -> {
                val message = e.message
                val start = message!!.indexOf("Duplicate entry '") + 17
                val end = message.indexOf("' for key")
                message.substring(start, end)
            }
            else -> {
                e.message!!
            }
        }
    }
}
