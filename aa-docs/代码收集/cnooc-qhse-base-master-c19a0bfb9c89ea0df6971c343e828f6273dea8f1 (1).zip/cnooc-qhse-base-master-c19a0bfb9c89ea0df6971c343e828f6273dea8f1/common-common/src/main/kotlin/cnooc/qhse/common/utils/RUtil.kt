package cnooc.qhse.common.utils

import org.springblade.core.log.exception.ServiceException
import org.springblade.core.tool.api.R


/**
 * 结果工具类
 */

/**
 * 解析结果的数据并返回，如果不成功或数据为null，返回异常
 */
fun <T> R<T>.notNullRetrieve(): T {
    return if (this.isSuccess) {
        this.data ?: throw ServiceException("数据为空")
    } else {
        throw ServiceException(this.msg)
    }
}

/**
 * 解析结果的数据并返回，如果不成功，返回异常
 */
fun <T> R<T>.retrieve(): T? {
    return if (this.isSuccess) {
        this.data
    } else {
        throw ServiceException(this.msg)
    }
}

/**
 * 解析结果的数据并返回，如果不成功或数据为null，返回null
 */
fun <T> R<T>.noThrowRetrieve(): T? {
    return if (this.isSuccess) this.data else null
}
