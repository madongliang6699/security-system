package cnooc.qhse.common.vo

data class TitleAndValueEntity(
    var value: Long,
    var title: String
)
