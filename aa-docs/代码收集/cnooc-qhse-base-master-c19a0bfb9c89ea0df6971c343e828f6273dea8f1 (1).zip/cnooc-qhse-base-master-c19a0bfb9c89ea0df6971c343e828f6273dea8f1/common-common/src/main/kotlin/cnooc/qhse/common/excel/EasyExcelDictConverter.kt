package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.DictBizCache
import org.springblade.system.cache.DictCache

/**
 * EasyExcel 字典键值转换器，支持单个与多个字典键值用英文逗号分隔的字符串。
 *
 * 用法：使用该转换器同时需要在字段上加@DictCode注解，表示使用的字典编码。该注解同时支持业务字典和系统字典，默认是业务字典，使用系统字典时需要在注解上加@DictCode(isDictBiz = false)
 *
 * 业务字典示例：
 * ```
 * @ExcelProperty("重大危险源级别", converter = EasyExcelDictConverter::class)
 * @DictCode("riskLevel")
 * var riskLevel: String? = null
 * ```
 *
 * 系统字典示例：
 * ```
 * @ExcelProperty("重大危险源级别", converter = EasyExcelDictConverter::class)
 * @DictCode("riskLevel", isDictBiz = false)
 * var riskLevel: String? = null
 * ```
 */
class EasyExcelDictConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将字典值(dictValue)转换为字典键(dictKey)
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val dictCodeAnnotation = context.contentProperty.field.getAnnotation(DictCode::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@DictCode注解")
        val dictCode = dictCodeAnnotation.value
        val isDictBiz = dictCodeAnnotation.isDictBiz
        val dictValues = Func.toStrList(context.readCellData.stringValue).toSet()

        if (isDictBiz) {
            val dictList = DictBizCache.getList(dictCode)
            if (dictList.isNullOrEmpty()) {
                throw IllegalArgumentException("字典编码${dictCode}未配置")
            }
            val keys = dictList.filter { it.dictValue in dictValues }.mapNotNull { it.dictKey }
            if (keys.isEmpty()) {
                throw IllegalArgumentException("找不到${dictCode}下对应的值: ${dictValues}")
            }
            return Func.join(keys)
        } else {
            val dictList = DictCache.getList(dictCode)
            if (dictList.isNullOrEmpty()) {
                throw IllegalArgumentException("字典编码${dictCode}未配置")
            }
            val keys = dictList.filter { it.dictValue in dictValues }.mapNotNull { it.dictKey }
            if (keys.isEmpty()) {
                throw IllegalArgumentException("找不到${dictCode}下对应的值: $dictValues")
            }
            return Func.join(dictList.filter { it.dictValue in dictValues }.mapNotNull { it.dictKey })
        }
    }

    /**
     * 将字典键(dictKey)转换为字典值(dictValue)
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val dictCodeAnnotation = context.contentProperty.field.getAnnotation(DictCode::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@DictCode注解")
        val dictCode = dictCodeAnnotation.value
        val isDictBiz = dictCodeAnnotation.isDictBiz
        val dictKeys = Func.toStrList(context.value)

        val values = if (isDictBiz) {
            dictKeys.map { DictBizCache.getValue(dictCode, it) }
        } else {
            dictKeys.map { DictCache.getValue(dictCode, it) }
        }
        if (values.isEmpty()) {
            throw IllegalArgumentException("找不到${dictCode}下对应的键: $dictKeys")
        }
        return WriteCellData<Any>(Func.join(values))
    }
}
