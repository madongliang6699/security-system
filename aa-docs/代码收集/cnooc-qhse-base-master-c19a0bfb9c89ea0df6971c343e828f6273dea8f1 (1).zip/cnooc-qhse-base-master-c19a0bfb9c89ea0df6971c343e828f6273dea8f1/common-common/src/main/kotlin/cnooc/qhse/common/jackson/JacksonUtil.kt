package cnooc.qhse.common.jackson

import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.core.JsonToken
import com.fasterxml.jackson.databind.ObjectMapper
import org.springblade.core.tool.utils.SpringUtil

object JacksonUtil {
    fun parseListStr(parser: JsonParser): List<String> {
        val list = mutableListOf<String>()
        while (parser.currentToken !== JsonToken.END_ARRAY) {
            if (parser.text == JsonToken.START_ARRAY.asString()) {
                parser.nextToken()
                continue
            }
            val field = parser.text
            parser.nextToken()
            list.add(field)
        }
        return list
    }

    /**
     * 获取对象的jsonStr
     */
    fun toJsonStr(obj: Any): String {
        val objectMapper = SpringUtil.getBean(ObjectMapper::class.java)
            .enable(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN)
        val jsonData: String = try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj)
        } catch (e: JsonProcessingException) {
            throw Exception("上报数据转换Json异常！")
        }
        return jsonData
    }
}
