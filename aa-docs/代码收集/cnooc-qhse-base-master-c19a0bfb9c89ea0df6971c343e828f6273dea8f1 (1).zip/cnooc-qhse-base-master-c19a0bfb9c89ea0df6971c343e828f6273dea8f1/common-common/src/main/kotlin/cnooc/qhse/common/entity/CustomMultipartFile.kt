package cnooc.qhse.common.entity

import org.springframework.web.multipart.MultipartFile
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.lang.IllegalStateException

/**
 * 自定义MultipartFile，用于向IOssClient.putFile传输文件
 */
class CustomMultipartFile(
    /**
     * 文件名
     */
    private val name: String,
    /**
     * 文件原名
     */
    private val originalFilename: String,
    /**
     * 文件类型, mime
     */
    private val contentType: String,
    /**
     * 文件内容
     */
    private val content: ByteArray
) : MultipartFile {
    override fun getName(): String {
        return name
    }

    override fun getOriginalFilename(): String {
        return originalFilename
    }

    override fun getContentType(): String  {
        return contentType
    }

    override fun isEmpty(): Boolean {
        return content.isEmpty()
    }

    override fun getSize(): Long {
        return content.size.toLong()
    }

    override fun getBytes(): ByteArray {
        return content
    }

    override fun getInputStream(): InputStream {
        return ByteArrayInputStream(content)
    }


    @Throws(IOException::class, IllegalStateException::class)
    override fun transferTo(dest: File) {
        FileOutputStream(dest).use { out ->
            out.write(content)
        }
    }
}
