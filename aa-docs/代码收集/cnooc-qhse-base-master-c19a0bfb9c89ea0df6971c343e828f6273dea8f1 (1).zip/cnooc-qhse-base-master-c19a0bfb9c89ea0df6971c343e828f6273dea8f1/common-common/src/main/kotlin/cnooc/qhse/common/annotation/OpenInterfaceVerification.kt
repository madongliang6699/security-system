package cnooc.qhse.common.annotation

/**
 * @Description:  开放接口自定义权限校验
 * @Version:    1.0
 */

@Target(AnnotationTarget.FUNCTION)
@Retention(AnnotationRetention.RUNTIME)
@MustBeDocumented
annotation class OpenInterfaceVerification(
    //有效期（分钟），避免重放攻击, 默认2分钟
    val value: Long = 2
)
