package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache

/**
 * EasyExcel 岗位id与名称之间的转换器
 *
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("岗位", converter = EasyExcelPostConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("岗位", converter = EasyExcelPostConverter::class)
 *  var postId: Long? = null
 *
 *  // Java
 *  @ExcelProperty(value = "岗位", converter = EasyExcelPostConverter.class)
 *  private Long postId;
 *  ```
 */
class EasyExcelPostConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将岗位名称转换为岗位id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val postIds = SysCache.getPostIds(AuthUtil.getTenantId(), context.readCellData.stringValue)
        if (postIds.isNullOrBlank()) throw IllegalArgumentException("岗位名称不存在: ${context.readCellData.stringValue}")
        return Func.toLongList(postIds).first()
    }

    /**
     * 将岗位id转换为岗位名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val postName = SysCache.getPostName(context.value)
        if (postName.isNullOrBlank()) throw IllegalArgumentException("岗位不存在: ${context.value}")
        return WriteCellData<Any>(postName)
    }
}
