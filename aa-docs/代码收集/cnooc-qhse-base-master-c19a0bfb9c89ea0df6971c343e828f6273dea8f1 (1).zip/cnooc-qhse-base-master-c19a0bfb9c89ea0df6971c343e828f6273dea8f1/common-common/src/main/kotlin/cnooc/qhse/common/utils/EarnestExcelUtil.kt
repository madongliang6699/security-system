package cnooc.qhse.common.utils

import cn.hutool.core.collection.IterUtil
import cnooc.qhse.common.excel.select.CustomCellSelectedSheetWriteHandler
import cnooc.qhse.common.excel.select.ExcelSelected
import com.alibaba.excel.EasyExcel
import com.alibaba.excel.annotation.ExcelProperty
import jakarta.servlet.http.HttpServletResponse
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import org.springblade.core.excel.listener.ImportListener
import org.springblade.core.excel.support.ExcelImporter
import org.springblade.core.excel.util.ExcelUtil
import org.springblade.core.tool.utils.DateUtil
import org.springframework.http.HttpHeaders
import org.springframework.web.multipart.MultipartFile
import java.io.InputStream
import java.io.OutputStream
import java.net.URLEncoder


object EarnestExcelUtil : ExcelUtil() {
    fun removeOtherSheets(sheetName: String, inputStream: InputStream, outputStream: OutputStream) {
        val workbook1 = XSSFWorkbook(inputStream)
        val sheet = workbook1.getSheet(sheetName)
        val sheetIndex = workbook1.getSheetIndex(sheet)
        for (i in workbook1.numberOfSheets - 1 downTo 0) {
            if (i != sheetIndex) {
                workbook1.removeSheetAt(i)
            }
        }
        workbook1.write(outputStream)
    }

    fun removeSheetWithName(sheetName: String, inputStream: InputStream, outputStream: OutputStream) {
        val workbook1 = XSSFWorkbook(inputStream)
        val sheet = workbook1.getSheet(sheetName)
        val sheetIndex = workbook1.getSheetIndex(sheet)
        if (sheetIndex >= 0) {
            workbook1.removeSheetAt(sheetIndex)
        }
        workbook1.write(outputStream)
    }

    /**
     * 导出Sheet页数据且含有下拉框的excel文件
     * 若用于下载带有下拉框列的excel模板,可将dataList传一个表头类型的空集合
     * @param [response]
     * @param [fileName] excel源文件名称
     * @param [sheetName] sheet页棉城
     * @param [dataList] 要导出的数据
     */
    inline fun <reified T> writeExcelBySelect(response: HttpServletResponse, fileName: String, sheetName: String, dataList: List<T>) {
        encodeFileName(response, fileName)
        val selectedMap = resolveSelectedAnnotation(IterUtil.getElementType(dataList) ?: T::class.java)
        EasyExcel.write(response.outputStream, T::class.java)
                .registerWriteHandler(CustomCellSelectedSheetWriteHandler.build(selectedMap))
                .sheet(sheetName).doWrite(dataList)
    }

    /**
     * 解析Excel表头中的下拉注解列
     * @param [head] excel表头
     * @return [Map<Int, ExcelSelected>] key:excel列的下标 value:下拉列对应的下拉注解
     */
    fun <T> resolveSelectedAnnotation(head: Class<T>): Map<Int, ExcelSelected> {
        return head.declaredFields
                .map { field ->
                    val property = field.getAnnotation(ExcelProperty::class.java)
                    val selected = field.getAnnotation(ExcelSelected::class.java)
                    Pair(property, selected)
                }
                .filter { (property, selected) -> property != null && selected != null }
                .associateBy(
                        { (property, _) -> property!!.index.takeIf { it >= 0 } ?: -1 },
                        { (_, selected) -> selected!! }
                )
    }

    /**
     * 设置导出excel文件名及header的参数设置
     * @param [response] excel表头
     * @param [fileName] 文件名称
     */
    fun encodeFileName(response: HttpServletResponse, fileName: String) {
        response.contentType = "application/vnd.ms-excel"
        response.characterEncoding = "utf-8"
        // 这里URLEncoder.encode可以防止中文乱码 当然和easyexcel没有关系
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=${URLEncoder.encode("$fileName${DateUtil.time()}", "UTF-8")}.xlsx")
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-cache")
        response.setHeader(HttpHeaders.PRAGMA, "no-cache")
        response.setDateHeader(HttpHeaders.EXPIRES, -1)
    }

    /**
     * 指定excel-sheet页读取数据保存
     * @param [excel] excel文件
     * @param [sheetNo] sheet页下标
     * @param [importer] excel导入类
     * @param [clazz] excel Class
     */
    fun <T> save(excel: MultipartFile, sheetNo: Int, importer: ExcelImporter<T>, clazz: Class<T>) {
        val importListener: ImportListener<T> = ImportListener(importer)
        val builder = getReaderBuilder(excel, importListener, clazz)
        builder?.sheet(sheetNo)?.doRead()
    }
}
