package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.UserCache

/**
 * EasyExcel 多个用户id字符串与名称之间的转换器。多个用户用英文,分开
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("用户", converter = EasyExcelUsersConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("用户", converter = EasyExcelUsersConverter::class)
 *  var userIds: String? = null
 *
 *  // Java
 *  @ExcelProperty(value = "用户", converter = EasyExcelUsersConverter.class)
 *  private String userIds;
 *  ```
 */
class EasyExcelUsersConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将用户名称转换为用户id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }

        val users = UserCache.getUsersByNameOrAccount(AuthUtil.getTenantId(), context.readCellData.stringValue)
        if (users.size != Func.toStrList(context.readCellData.stringValue).size) {
            throw IllegalArgumentException("用户解析错误: ${context.readCellData.stringValue}")
        }
        return Func.join(users.map { it.id })
    }

    /**
     * 将用户id转换为用户姓名
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val users = Func.toLongList(context.value).mapNotNull { UserCache.getUser(it) }
        if (users.size != Func.toStrList(context.value).size) {
            throw IllegalArgumentException("用户解析错误: ${context.value}")
        }
        return WriteCellData<Any>(Func.join(users.map { it.realName }))
    }
}
