package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache

/**
 * EasyExcel 多个岗位id字符串与名称之间的转换器。多个岗位用英文,分开
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("岗位", converter = EasyExcelPostsConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("岗位", converter = EasyExcelPostsConverter::class)
 *  var postIds: String? = null
 *
 *  // Java
 *  @ExcelProperty(value = "岗位", converter = EasyExcelPostsConverter.class)
 *  private String postIds;
 *  ```
 */
class PostsConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将岗位名称转换为岗位id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }

        val postIds = SysCache.getPostIds(AuthUtil.getTenantId(), context.readCellData.stringValue)
        if (Func.toStrList(postIds).size != Func.toStrList(context.readCellData.stringValue).size) {
            throw IllegalArgumentException("岗位解析错误: ${context.readCellData.stringValue}")
        }
        return postIds
    }

    /**
     * 将岗位id转换为岗位名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val postNames = SysCache.getPostNames(context.value) ?: throw IllegalArgumentException("岗位解析错误: ${context.value}")
        if (postNames.size != Func.toStrList(context.value).size) {
            throw IllegalArgumentException("岗位解析错误: ${context.value}")
        }
        return WriteCellData<Any>(Func.join(postNames))
    }
}
