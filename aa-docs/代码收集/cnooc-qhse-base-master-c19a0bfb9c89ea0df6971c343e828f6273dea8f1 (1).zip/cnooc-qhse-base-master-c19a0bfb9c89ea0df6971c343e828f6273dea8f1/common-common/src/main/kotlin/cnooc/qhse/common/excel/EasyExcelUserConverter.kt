package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.system.cache.UserCache

/**
 * EasyExcel 用户id与真实姓名之间的转换器
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("用户", converter = EasyExcelUserConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("用户", converter = EasyExcelUserConverter::class)
 *  var userId: Long? = null
 *
 *  // Java
 *  @ExcelProperty(value = "用户", converter = EasyExcelUserConverter.class)
 *  private Long userId;
 */
class EasyExcelUserConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将用户名称转换为用户id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        val value = context.readCellData.stringValue
        if (value.isNullOrBlank()) {
            return null
        }
        val users = UserCache.getUsersByNameOrAccount(AuthUtil.getTenantId(), value)
        if (users.isNullOrEmpty()) throw IllegalArgumentException("用户不存在: $value")
        if (users.size > 1) throw java.lang.IllegalArgumentException("重名用户，请使用用户名代替：$value")
        return users.first().id
    }

    /**
     * 将用户id转换为用户名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val user = UserCache.getUser(context.value)
        return WriteCellData<Any>(user?.realName ?: "用户不存在")
    }
}
