package cnooc.qhse.common.excel

import cnooc.qhse.common.utils.EarnestDateUtil
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.tool.utils.DateUtil
import java.time.LocalDate

/**
 * EasyExcel日期字段字符串与LocalDate之间的转换器
 *
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("起始有效日期", converter = EasyExcelDateConverter::class)
 * ```
 * 日期默认格式：yyyy-MM-dd
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("日期", converter = EasyExcelDateConverter::class)
 *  var startDate: LocalDate? = null
 *
 *  // Java
 *  @ExcelProperty(value = "日期", converter = EasyExcelDateConverter.class)
 *  private LocalDate startDate;
 *  ```
 */
class EasyExcelDateConverter : Converter<LocalDate> {
    override fun supportJavaTypeKey(): Class<*> {
        return LocalDate::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    override fun convertToJavaData(context: ReadConverterContext<*>): LocalDate? {
        val value = context.readCellData.stringValue
        if (!value.isNullOrBlank()) {
            return EarnestDateUtil.tryParseDate(value) ?: throw IllegalArgumentException("无效的日期格式：${value}")
        }
        val doubleValue = context.readCellData.numberValue?.toDouble()
        if (doubleValue != null) {
            return EarnestDateUtil.tryParseDoubleDate(doubleValue) ?: throw IllegalArgumentException("无效的日期格式：${doubleValue}")
        }
        return null
    }

    override fun convertToExcelData(context: WriteConverterContext<LocalDate>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        return WriteCellData<Any>(DateUtil.formatDate(context.value))
    }
}
