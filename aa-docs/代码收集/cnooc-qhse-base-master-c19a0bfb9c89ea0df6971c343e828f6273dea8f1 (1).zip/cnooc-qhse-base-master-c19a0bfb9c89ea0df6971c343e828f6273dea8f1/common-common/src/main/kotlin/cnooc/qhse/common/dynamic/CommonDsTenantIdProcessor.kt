package cnooc.qhse.common.dynamic

import com.baomidou.dynamic.datasource.processor.DsProcessor
import org.aopalliance.intercept.MethodInvocation
import org.springblade.core.secure.utils.AuthUtil

/**
 * 租户动态数据源解析器
 */
class CommonDsTenantIdProcessor : DsProcessor() {
    override fun matches(key: String): Boolean {
        return key == TENANT_ID_KEY
    }

    override fun doDetermineDatasource(invocation: MethodInvocation, key: String): String? {
        return AuthUtil.getTenantId()
    }

    companion object {
        const val TENANT_ID_KEY: String = "#token.tenantId"
    }
}
