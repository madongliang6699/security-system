package cnooc.qhse.common.vo

import io.swagger.v3.oas.annotations.media.Schema

/**
 * 通用结构：id、title、value
 */
@Schema(description = "通用结构：id、title、value")
class IdFieldTitleValue<T>(
    @Schema(description = "id") var id: Long? = null,
    @Schema(description = "属性") var field: String? = null,
    @Schema(description = "名称") var title: String? = null,
    @Schema(description = "值") var value: T? = null,
)
