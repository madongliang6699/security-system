package cnooc.qhse.common.vo

import com.fasterxml.jackson.annotation.JsonFormat
import io.swagger.v3.oas.annotations.media.Schema
import org.springframework.format.annotation.DateTimeFormat
import java.time.LocalDateTime

/**
 * 通用结构：id、title、value
 */
@Schema(description = "通用结构：id、startTime, endTime, title")
class IdTimeRangeTitleValue<T>(
    @Schema(description="id") var id: Long? = null,

    @Schema(description="startTime")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    var startTime: LocalDateTime? = null,

    @Schema(description="endTime")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    var endTime: LocalDateTime? = null,

    @Schema(description="title") var title: String? = null,
    @Schema(description="value") var value: T? = null,
)
