package cnooc.qhse.common.mybatis.methods

import com.baomidou.mybatisplus.core.injector.AbstractMethod
import com.baomidou.mybatisplus.core.metadata.TableFieldInfo
import com.baomidou.mybatisplus.core.metadata.TableInfo
import org.apache.ibatis.executor.keygen.NoKeyGenerator
import org.apache.ibatis.mapping.MappedStatement
import java.util.function.Consumer

/**
 *
 *
 *
 *
 * @author yuxiaobin
 * @date 2019/6/14
 */
class MysqlInsertAllBatch : AbstractMethod("MysqlInsertAllBatch") {
    override fun injectMappedStatement(
        mapperClass: Class<*>?,
        modelClass: Class<*>?,
        tableInfo: TableInfo
    ): MappedStatement {
        val sql = "<script>insert into %s %s values %s</script>"
        val fieldSql = prepareFieldSql(tableInfo)
        val valueSql = prepareValuesSqlForMysqlBatch(tableInfo)
        val sqlResult = String.format(sql, tableInfo.tableName, fieldSql, valueSql)
        val sqlSource = languageDriver.createSqlSource(configuration, sqlResult, modelClass)
        return addInsertMappedStatement(
            mapperClass,
            modelClass,
            "mysqlInsertAllBatch",
            sqlSource,
            NoKeyGenerator(),
            null,
            null
        )
    }

    private fun prepareFieldSql(tableInfo: TableInfo): String {
        val fieldSql = StringBuilder()
        fieldSql.append(tableInfo.keyColumn).append(",")
        tableInfo.fieldList.forEach(Consumer { x: TableFieldInfo -> fieldSql.append(x.column).append(",") })
        fieldSql.delete(fieldSql.length - 1, fieldSql.length)
        fieldSql.insert(0, "(")
        fieldSql.append(")")
        return fieldSql.toString()
    }

    private fun prepareValuesSqlForMysqlBatch(tableInfo: TableInfo): String {
        val valueSql = StringBuilder()
        valueSql.append("<foreach collection=\"list\" item=\"item\" index=\"index\" open=\"(\" separator=\"),(\" close=\")\">")
        valueSql.append("#{item.").append(tableInfo.keyProperty).append("},")
        tableInfo.fieldList.forEach(Consumer { x: TableFieldInfo ->
            valueSql.append("#{item.").append(x.property).append("},")
        })
        valueSql.delete(valueSql.length - 1, valueSql.length)
        valueSql.append("</foreach>")
        return valueSql.toString()
    }
}
