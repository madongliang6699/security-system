package cnooc.qhse.common.utils

import cn.afterturn.easypoi.excel.annotation.Excel
import cn.afterturn.easypoi.excel.entity.result.ExcelVerifyHandlerResult
import cn.afterturn.easypoi.handler.inter.IExcelDataModel
import cn.afterturn.easypoi.handler.inter.IExcelVerifyHandler
import com.alibaba.excel.annotation.ExcelProperty
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.ConstraintViolation
import jakarta.validation.Validation
import jakarta.validation.Validator
import kotlin.reflect.KProperty
import kotlin.reflect.jvm.javaField

/**
 * Excel导入字段有效性校验
 *
 * 该工具类依据实体类上标注的Hibernate Validator校验注解进行校验
 */
object ExcelValidationUtil {
    private val factory = Validation.buildDefaultValidatorFactory()
    private val validator: Validator = factory.validator

    /**
     * 检验对象是否符合验证规则
     * @param obj 待验证对象
     * @param verifyGroup 验证组
     */
    fun validation(obj: Any, verifyGroup: Array<Class<*>>?): String? {
        val set: Set<ConstraintViolation<Any>>? = if (verifyGroup != null) {
            validator.validate(obj, *verifyGroup)
        } else {
            validator.validate(obj)
        }
        return if (!set.isNullOrEmpty()) {
            getValidateErrMsg(set)
        } else null
    }

    private fun getValidateErrMsg(set: Set<ConstraintViolation<Any>>): String {
        val builder = StringBuilder()
        for (constraintViolation in set) {
            // 添加excel的行号
            if (constraintViolation.rootBean is IExcelDataModel) {
                builder.append(String.format("第%d行：", (constraintViolation.rootBean as IExcelDataModel).rowNum + 1))
            }
            builder.append(constraintViolation.message).append("\n")
        }
        return builder.substring(0, builder.length - 1)
    }

    // 获取字段上的注解中的名称
    fun getFieldFriendlyName(field: KProperty<*>): String {
        val javaField = field.javaField!!
        if (javaField.isAnnotationPresent(Excel::class.java)) {
            return javaField.getAnnotation(Excel::class.java).name
        } else if (javaField.isAnnotationPresent(ExcelProperty::class.java)) {
            return javaField.getAnnotation(ExcelProperty::class.java).value.toString()
        } else if (javaField.isAnnotationPresent(Schema::class.java)) {
            return javaField.getAnnotation(Schema::class.java).description
        }
        return field.name
    }

    /**
     * 使用自定义的检验方法检验各个对象
     */
    fun <T> verifyObjects(handler: IExcelVerifyHandler<T>, objects: List<T>): List<ExcelVerifyHandlerResult> {
        val results: MutableList<ExcelVerifyHandlerResult> = mutableListOf()
        for (obj in objects) {
            val result = handler.verifyHandler(obj!!)
            if (!result.isSuccess) {
                results.add(handler.verifyHandler(obj))
            }
        }
        return results
    }
}
