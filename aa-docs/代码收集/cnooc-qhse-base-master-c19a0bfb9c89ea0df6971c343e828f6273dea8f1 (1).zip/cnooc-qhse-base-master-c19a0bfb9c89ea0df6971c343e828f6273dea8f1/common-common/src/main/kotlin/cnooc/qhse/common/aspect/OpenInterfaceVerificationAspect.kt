package cnooc.qhse.common.aspect

import cnooc.qhse.common.annotation.OpenInterfaceVerification
import cnooc.qhse.common.utils.AesGcm128Util
import io.github.oshai.kotlinlogging.KotlinLogging
import org.aspectj.lang.ProceedingJoinPoint
import org.aspectj.lang.annotation.Around
import org.aspectj.lang.annotation.Aspect
import org.aspectj.lang.annotation.Pointcut
import org.aspectj.lang.reflect.MethodSignature
import org.springblade.core.log.exception.ServiceException
import org.springframework.stereotype.Component
import org.springframework.web.context.request.RequestContextHolder
import org.springframework.web.context.request.ServletRequestAttributes
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


private val logger = KotlinLogging.logger { }

/**
 * @Description:  开放接口自定义权限校验切面
 * 权限规则为：固定token+时间，然后进行AES加密（CBC模式），将加密后的base64字符串拼接前缀如“visitor：”，
 * 例如：safetyline-app:tABXP8kTTIaJ6loLbzOkrMbhOB6UY1Q8ibG1+/CTnjM=，然后放在请求头token中
 *
 * 校验规则：根据前缀找到key和IV进行解密，根据解密后的字符串，判断是否过期，和服务器端比较固定token是否一致
 * @Version:    1.0
 */
@Aspect
@Component
class OpenInterfaceVerificationAspect {

    //存放密钥，后续对外对接增多时考虑配置中心或者数据库存放
    companion object {
        val keyStore = mapOf(
            "safetyline-app" to KeyConfig(
                token = "i4E1dghxcokv9SIG",
                key = "~8ekWAqp90M-zI6M",
                iv = "PB5R0UC9S4U^9s0s"
            ),
            "visitor" to KeyConfig(
                token = "eC6AY9kSyTr81R69",
                key = "8yoHY1JYh7/D2yTxG27ocw==",
                iv = "wt#f7iZbHC*j5Z7F"
            )
        )

    }

    @Pointcut("@annotation(cnooc.qhse.common.annotation.OpenInterfaceVerification)")
    fun validatePointcut(){}


    @Around("validatePointcut()")
    fun validate(joinPoint: ProceedingJoinPoint): Any {
        val signature: MethodSignature = joinPoint.signature as MethodSignature
        val expirationTime = signature.method.getAnnotation(OpenInterfaceVerification::class.java).value
        val tokenAndKeyConfig = splitToken(signature)
        val keyConfig = tokenAndKeyConfig["keyConfig"]
        val keyAndTime = decrypt(tokenAndKeyConfig["token"].toString(), keyConfig as KeyConfig, signature)
        //校验密钥是否过期
        checkTimeEffective(expirationTime, keyAndTime["temporaryTime"], signature)
        //校验密钥是否正确
        if (keyConfig.token != keyAndTime["key"]) {
            logger.error { "当前请求密钥错误，请求路径：${signature.method}" }
            throw ServiceException("当前密钥有误")
        }
        return joinPoint.proceed()
    }

    //分解token  分解为：加密后的密钥和时间+发送方的加密参数
    private fun splitToken(signature: MethodSignature): HashMap<String, Any> {
        val request = (RequestContextHolder.getRequestAttributes() as ServletRequestAttributes).request
        //解析密钥  发送方：加密后的密钥和时间
        val from: String
        val token = try {
            val secretToken = request.getHeader("token").split(":")
            from = secretToken[0]
            secretToken[1]
        } catch (e: Exception) {
            logger.error { "当前请求密钥错误，请求路径：${signature.method}" }
            throw ServiceException("当前密钥有误")
        }
        val keyConfig = keyStore[from] ?: throw ServiceException("请联系管理员申请token")
        return hashMapOf("token" to token, "keyConfig" to keyConfig)
    }

    //解析加密后的密钥和时间,解析为：原始密钥+时间
    private fun decrypt(token: String, keyConfig: KeyConfig, signature: MethodSignature): HashMap<String, String?> {
        val key: String?
        val temporaryTime = try {
            val secretAndTime = AesGcm128Util.decrypt(token, keyConfig.key, keyConfig.iv)
            key = secretAndTime?.substring(0, secretAndTime.length - 12)
            secretAndTime?.substring(secretAndTime.length - 12)
        } catch (e: Exception) {
            logger.error { "当前请求密钥错误，请求路径：${signature.method}" }
            throw ServiceException("当前密钥有误")
        }
        return hashMapOf("key" to key, "temporaryTime" to temporaryTime)
    }

    //校验密钥是否过期
    private fun checkTimeEffective(
        expirationTime: Long,
        temporaryTime: String?,
        signature: MethodSignature
    ) {
        val requestTime = LocalDateTime.parse(temporaryTime, DateTimeFormatter.ofPattern("yyyyMMddHHmm"))
        //校验时间戳是否过期，有效期为5分钟
        val now = LocalDateTime.now()
        if (now.minusMinutes(expirationTime).isAfter(requestTime)) {
            logger.error { "当前请求密钥已过期，请求路径：${signature.method}" }
            throw ServiceException("当前密钥已过期")
        }
    }
}

data class KeyConfig(val token: String, val key: String, val iv: String)
