package cnooc.qhse.common.enums

/**
 * 一个实现了value和title的枚举接口，方便扩展
 *
 * ## Java下使用
 * ```java
 * import cnooc.qhse.common.enums.StringValueEnum;
 *
 * public enum MyEnum implements StringValueEnum {
 *     FIRST("1st", "First"),
 *     SECOND("2nd", "Second");
 *
 *     private final String value;
 *     private final String title;
 *
 *     MyEnum(String value, String title) {
 *         this.value = value;
 *         this.title = title;
 *     }
 *
 *     @Override
 *     public String getValue() {
 *         return value;
 *     }
 *
 *     @Override
 *     public String getTitle() {
 *         return title;
 *     }
 *
 *     @Override
 *     public boolean eq(String value) {
 *         return this.value.equals(value);
 *     }
 * }
 * ```
 *
 * ```java
 * import static cnooc.qhse.common.utils.EnumUtil.*;
 *
 * // 通过值获取枚举
 * MyEnum first = enumByString(MyEnum.class, "1st");
 * // 通过标题获取枚举
 * MyEnum first1 = enumByStringTitle(MyEnum.class, "First");
 * // 检查值对应的枚举是否存在
 * Boolean exist = isStringEnumExist(MyEnum.class, "1st");
 * ```
 * ## Kotlin下使用：
 * ```kotlin
 * enum class MyEnum(override val value: String, override val title: String) : StringValueEnum {
 *     FIRST("1st", "First"),
 *     SECOND("2nd", "Second");
 * }
 * // 通过值获取枚举
 * val status = enumByString<MyEnum>(0)
 * // 通过标题获取枚举
 * val status1 = enumByStringTitle<MyEnum>("First")
 * // 检查值对应的枚举是否存在
 * val exist = isStringEnumExist<MyEnum>(0)
 */
interface StringValueEnum {
    val value: String
    val title: String?

    fun eq(value1: String?) = value == value1
}

/**
 * 根据字符串值返回枚举值
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.enumByString]
 *
 */
inline fun <reified T: Enum<T>> enumByString(v: String): T? {
    for (value in enumValues<T>()) {
        if (value is StringValueEnum && value.value == v) {
            return value
        }
    }
    return null
}

/**
 * 根据枚举的title值返回枚举值
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.enumByStringTitle]
 */
inline fun <reified T: Enum<T>> enumByStringTitle(v: String): T? {
    for (value in enumValues<T>()) {
        if (value is StringValueEnum && value.title == v) {
            return value
        }
    }
    return null
}

/**
 * 判断字符串值对应的枚举是否存在
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.isStringEnumExist]
 */
inline fun <reified T: Enum<T>> isStringEnumExist(v: String): Boolean {
    for (value in enumValues<T>()) {
        if (value is StringValueEnum && value.value == v) {
            return true
        }
    }
    return false
}
