package cnooc.qhse.common.entity

import io.swagger.v3.oas.annotations.media.Schema
import java.io.Serializable
import java.time.LocalDateTime

abstract class TenantEntityKt (
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    @Schema(description = "租户ID")
    open var tenantId: String? = null,
) : BaseEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted), Serializable {
    companion object {
        private const val serialVersionUID = -5754935365981931287L
    }
}
