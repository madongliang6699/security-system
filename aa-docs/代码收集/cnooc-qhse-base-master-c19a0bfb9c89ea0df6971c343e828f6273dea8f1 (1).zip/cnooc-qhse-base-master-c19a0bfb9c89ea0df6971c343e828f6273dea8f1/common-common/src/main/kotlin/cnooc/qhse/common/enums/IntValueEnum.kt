package cnooc.qhse.common.enums

/**
 * 一个实现了value和title的枚举接口，方便扩展
 *
 * ## Java下使用
 * ```java
 * import cnooc.qhse.common.enums.IntValueEnum;
 *
 * public enum MyEnum implements IntValueEnum {
 *     FIRST(1, "First"),
 *     SECOND(2, "Second");
 *
 *     private final int value;
 *     private final String title;
 *
 *     MyEnum(int value, String title) {
 *         this.value = value;
 *         this.title = title;
 *     }
 *
 *     @Override
 *     public int getValue() {
 *         return value;
 *     }
 *
 *     @Override
 *     public String getTitle() {
 *         return title;
 *     }
 *
 *     @Override
 *     public boolean eq(Integer integer) {
 *         return this.value == integer;
 *     }
 * }
 * ```
 *
 * ```java
 * import static cnooc.qhse.common.utils.EnumUtil.*;
 *
 * // 通过整数获取枚举
 * MyEnum first = enumByInt(MyEnum.class, 1);
 * // 通过标题获取枚举
 * MyEnum first1 = enumByIntTitle(MyEnum.class, "First");
 * // 检查整数对应的枚举是否存在
 * Boolean exist = isIntEnumExist(MyEnum.class, 1);
 * ```
 * ## Kotlin下使用：
 * ```kotlin
 * enum class MyEnum(override val value: Int, override val title: String) : IntValueEnum {
 *     FIRST(1, "First"),
 *     SECOND(2, "Second");
 * }
 * // 通过整数获取枚举
 * val status = enumByInt<MyEnum>(0)
 * // 通过标题获取枚举
 * val status1 = enumByIntTitle<MyEnum>("First")
 * // 检查整数对应的枚举是否存在
 * val exist = isIntEnumExist<MyEnum>(0)
 */
interface IntValueEnum {
    val value: Int
    val title: String?

    fun eq(value1: Int?) = value == value1
}

/**
 * 根据int值返回枚举值
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.enumByInt]
 */
inline fun <reified T: Enum<T>> enumByInt(v: Int): T? {
    for (value in enumValues<T>()) {
        if (value is IntValueEnum && value.value == v) {
            return value
        }
    }
    return null
}

/**
 * 根据枚举的title值返回枚举值
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.enumByIntTitle]
 */
inline fun <reified T: Enum<T>> enumByIntTitle(v: String): T? {
    for (value in enumValues<T>()) {
        if (value is IntValueEnum && value.title == v) {
            return value
        }
    }
    return null
}

/**
 * 判断int值对应的枚举是否存在
 *
 * kotlin版本，java请使用
 * @see [cnooc.qhse.common.utils.EnumUtil.isIntEnumExist]
 */
inline fun <reified T: Enum<T>> isIntEnumExist(v: Int): Boolean {
    for (value in enumValues<T>()) {
        if (value is IntValueEnum && value.value == v) {
            return true
        }
    }
    return false
}
