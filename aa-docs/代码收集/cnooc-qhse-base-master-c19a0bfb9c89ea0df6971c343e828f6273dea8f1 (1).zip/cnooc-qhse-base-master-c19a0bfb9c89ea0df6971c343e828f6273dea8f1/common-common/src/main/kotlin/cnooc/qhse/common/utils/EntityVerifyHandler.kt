package cnooc.qhse.common.utils

import cn.afterturn.easypoi.excel.entity.result.ExcelVerifyHandlerResult
import cn.afterturn.easypoi.handler.inter.IExcelDataModel
import cn.afterturn.easypoi.handler.inter.IExcelModel
import cn.afterturn.easypoi.handler.inter.IExcelVerifyHandler


/**
 * 通用excel对象检验
 * 对于只使用Hibernate Validation的对象，可以使用此类直接完成校验并获取结果。
 */
class EntityVerifyHandler<T> : IExcelVerifyHandler<T> where T : IExcelModel, T : IExcelDataModel {
    override fun verifyHandler(obj: T): ExcelVerifyHandlerResult {
        val result = ExcelVerifyHandlerResult(true)
        val msg  = ExcelValidationUtil.validation(obj, null)
        if (msg != null) {
            result.isSuccess = false
            result.msg = msg
        }
        return result
    }
}
