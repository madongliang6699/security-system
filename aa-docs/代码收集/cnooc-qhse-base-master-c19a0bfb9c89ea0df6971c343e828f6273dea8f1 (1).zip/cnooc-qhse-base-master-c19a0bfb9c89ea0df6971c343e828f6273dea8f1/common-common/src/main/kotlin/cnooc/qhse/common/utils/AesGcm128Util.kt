package cnooc.qhse.common.utils

import org.apache.commons.codec.binary.Base64
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec


/**
 * Aes 128加解密
 * CBC PKCS5Padding
 */
object AesGcm128Util {
    private const val KEY_ALGORITHM = "AES"
    private const val CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding"
    private const val ENCODING = "utf-8"


    /**
     * 加密方法
     * @param data 要加密的数据
     * @param key  加密key
     * @param iv   加密iv
     * @return 加密的结果
     */
    fun encrypt(source: String, encodeKey: String, ivKey: String): String? {
        return try {
            val sourceBytes = source.toByteArray(charset(ENCODING))
            val cipher = Cipher.getInstance(CIPHER_ALGORITHM)
            val iv = IvParameterSpec(ivKey.toByteArray())
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(encodeKey.toByteArray(), KEY_ALGORITHM), iv)
            val encrypted = cipher.doFinal(sourceBytes)
            Base64.encodeBase64String(encrypted)
        } catch (e: Exception) {
            throw RuntimeException("加密数据失败", e)
        }
    }

    /**
     * 解密方法
     * @param data 要解密的数据
     * @param key  解密key
     * @param iv   解密iv
     * @return 解密的结果
     */
    fun decrypt(encryptStr: String, encodeKey: String, ivKey: String): String? {
        return try {
            val encryptedBytes = Base64.decodeBase64(encryptStr)
            val cipher = Cipher.getInstance(CIPHER_ALGORITHM)
            val iv = IvParameterSpec(ivKey.toByteArray())
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(encodeKey.toByteArray(), KEY_ALGORITHM), iv)
            val decrypted = cipher.doFinal(encryptedBytes)
            String(decrypted, charset(ENCODING))
        } catch (e: Exception) {
            throw RuntimeException("解密数据失败", e)
        }
    }
}
