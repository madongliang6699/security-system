package cnooc.qhse.common.excel

import cnooc.qhse.common.utils.EarnestDateUtil
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import java.time.LocalDateTime

/**
 * EasyExcel 日期时间字段字符串与LocalDateTime之间的转换器
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("时间", converter = EasyExcelDateTimeConverter::class)
 * ```
 * 时间默认格式：yyyy-MM-dd HH:mm:ss
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("日期", converter = EasyExcelDateTimeConverter::class)
 *  var startDateTime: LocalDateTime? = null
 *
 *  // Java
 *  @ExcelProperty(value = "日期", converter = EasyExcelDateTimeConverter.class)
 *  private LocalDateTime startDateTime;
 *  ```
 */
class EasyExcelDateTimeConverter : Converter<LocalDateTime> {
    override fun supportJavaTypeKey(): Class<*> {
        return LocalDateTime::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    override fun convertToJavaData(context: ReadConverterContext<*>): LocalDateTime? {
        val value = context.readCellData.stringValue
        if (!value.isNullOrBlank()) {
            return EarnestDateUtil.tryParseDateTime(value) ?: throw IllegalArgumentException("无效的时间格式：${value}")
        }
        val doubleValue = context.readCellData.numberValue?.toDouble()
        if (doubleValue != null) {
            return EarnestDateUtil.tryParseDoubleDateTime(doubleValue) ?: throw IllegalArgumentException("无效的时间格式：${doubleValue}")
        }
        return null
    }

    override fun convertToExcelData(context: WriteConverterContext<LocalDateTime>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        return WriteCellData<Any>(org.springblade.core.tool.utils.DateUtil.formatDateTime(context.value))
    }
}
