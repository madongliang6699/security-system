package cnooc.qhse.common.utils

import org.springblade.core.tool.jackson.JsonUtil
import kotlin.reflect.KMutableProperty
import kotlin.reflect.KProperty
import kotlin.reflect.full.isSupertypeOf
import kotlin.reflect.full.memberProperties
import kotlin.reflect.KClass
import org.springblade.core.tool.utils.Base64Util

/**
 * 从一个对象中提取属性值，并将属性值设置到另一个对象中
 * @param fromObject 源对象
 * @param props 可选，需要拷贝的源属性列表
 */
fun <T : Any, R : Any> T.copyPropsFrom(fromObject: R, vararg props: KProperty<*>) {
    // only consider mutable properties
    val mutableProps = this::class.memberProperties.filterIsInstance<KMutableProperty<*>>()
    // if source list is provided use that otherwise use all available properties
    val sourceProps = if (props.isEmpty()) fromObject::class.memberProperties else props.toList()
    // copy all matching
    mutableProps.forEach { targetProp ->
        sourceProps.find {
            // make sure properties have same name and compatible types
            it.name == targetProp.name && targetProp.returnType.isSupertypeOf(it.returnType)
        }?.let { matchingProp ->
            targetProp.setter.call(this, matchingProp.getter.call(fromObject))
        }
    }
}

fun <T : Any> T.toMap(): Map<String, Any?> {
    return (this::class as KClass<T>).memberProperties.associate { prop ->
        prop.name to prop.get(this)?.let { value ->
            if (value::class.isData) {
                value.toMap()
            } else {
                value
            }
        }
    }
}

/**
 * 将一个对象转换为json字符串再base64编码
 */
fun Any.toJsonBase64(): String {
    return Base64Util.encodeToString(JsonUtil.toJson(this).toByteArray())
}
