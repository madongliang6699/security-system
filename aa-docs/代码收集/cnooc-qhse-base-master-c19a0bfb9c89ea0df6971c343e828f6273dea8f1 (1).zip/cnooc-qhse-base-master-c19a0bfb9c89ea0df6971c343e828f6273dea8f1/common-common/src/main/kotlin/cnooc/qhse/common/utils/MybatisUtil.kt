package cnooc.qhse.common.utils

import com.baomidou.mybatisplus.core.toolkit.StringUtils
import kotlin.reflect.KCallable

/**
 * 根据例如Person::bedId一类的获取表对应的下划线的字段
 */
fun <T> KCallable<T>.toColumn(): String {
    return StringUtils.camelToUnderline(resolveFieldName(this.name))
}

/**
 * 解析 getMethodName -> propertyName
 *
 * @param getMethodName 需要解析的
 * @return 返回解析后的字段名称
 */
fun resolveFieldName(getMethodName: String): String? {
    var methodName = getMethodName
    if (getMethodName.startsWith("get")) {
        methodName = getMethodName.substring(3)
    } else if (getMethodName.startsWith(StringUtils.IS)) {
        methodName = getMethodName.substring(2)
    }
    // 小写第一个字母
    return StringUtils.firstToLowerCase(methodName)
}
