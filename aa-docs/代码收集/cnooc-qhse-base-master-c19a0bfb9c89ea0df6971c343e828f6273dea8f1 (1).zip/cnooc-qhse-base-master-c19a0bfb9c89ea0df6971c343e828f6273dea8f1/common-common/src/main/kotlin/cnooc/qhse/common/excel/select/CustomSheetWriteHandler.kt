package cnooc.qhse.common.excel.select

import cn.hutool.core.collection.CollUtil
import com.alibaba.excel.write.handler.SheetWriteHandler
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.util.CellRangeAddressList
import kotlin.reflect.full.createInstance
import kotlin.reflect.full.isSubclassOf

/**
 * @author zhangyanan
 * @version 1.0.0
 * @Description 自定义Excel sheet页带有下拉框的写出处理,配合EasyExcelUtil使用
 * @createTime 2024年04月11日 14:08:00
 */
class CustomCellSelectedSheetWriteHandler : SheetWriteHandler {

    /**
     * key：下拉选项要放到哪个单元格，比如A列的单元格那就是0，C列的单元格那就是2
     * value：key对应的那个单元格下拉列表的ExcelSelected注解，通过注解的配置来获取下拉值
     */
    lateinit var selectedMap: Map<Int, ExcelSelected>

    companion object {
        fun build(selectedMap: Map<Int, ExcelSelected>): CustomCellSelectedSheetWriteHandler {
            return CustomCellSelectedSheetWriteHandler().apply {
                this.selectedMap = selectedMap
            }
        }
    }

    /**
     * 想实现Excel引用其他sheet页数据作为单元格下拉选项值，
     * 下拉框列表使用关联隐藏sheet页的方式实现
     *
     *
     * 注意：下列为选择关联隐藏sheet页实现原因
     * 使用下面方法存在问题：下拉列字符值的长度超过255时,excel无法正常显示,所以使用链接隐藏sheet页的方式实现下拉框
     * val constraint = helper.createExplicitListConstraint(Array(128){"1"})
     * 查看源码最终将所有列的下拉框值拼接到一起例如：1,1,1,1,1 加来来的字符长度大于255则无法正常显示
     *
     * @param writeWorkbookHolder
     * @param writeSheetHolder
     */
    override fun afterSheetCreate(writeWorkbookHolder: WriteWorkbookHolder, writeSheetHolder: WriteSheetHolder) {
        // 获取第一个sheet页
        val sheet = writeSheetHolder.cachedSheet
        // 获取sheet页的数据校验对象
        val helper = sheet.dataValidationHelper
        // 获取工作簿对象，用于创建存放下拉数据的字典sheet数据页
        val workbook = writeWorkbookHolder.workbook
        // 迭代索引，用于存放下拉数据的字典隐藏sheet数据页命名
        var index = 1
        selectedMap.forEach {
            val excelSelected = it.value
            val dropDownList = analysisDropDownList(excelSelected)
            if (CollUtil.isEmpty(dropDownList)) {
                return@forEach
            }

            val hiddenDictSheetName = createHiddenDictSheet(index++, workbook, dropDownList)
            //设置下拉选项值显示行、列的范围区间,例如第1-100行、第1列
            // 如果要设置到最后一行，那么一定注意，最后一行的行索引是1048575，千万别写成1048576，不然会导致下拉列表失效，出不来
            val cellRangeAddressList = CellRangeAddressList(excelSelected.firstRow, excelSelected.lastRow, it.key, it.key)

            // 将上面设置好的下拉列表字典隐藏sheet页和目标sheet关联起来
            val constraint = helper.createFormulaListConstraint(hiddenDictSheetName)
            val dataValidation = helper.createValidation(constraint, cellRangeAddressList)
            dataValidation.showErrorBox = true
            dataValidation.createErrorBox("错误提示", "请输入选项中的内容")
            sheet.addValidationData(dataValidation)
        }
    }

    /**
     * 创建隐藏字典sheet页
     */
    private fun createHiddenDictSheet(index: Int, workbook: Workbook, dropDownList: List<String>): String {
        // 设置存放下拉数据的字典sheet，并把这些sheet隐藏掉，这样用户交互更友好
        val hiddenDictSheetName = "option_$index"
        val hiddenDictSheet = workbook.createSheet(hiddenDictSheetName)
        // 隐藏字典sheet页
        workbook.setSheetHidden(index, true)
        dropDownList.forEachIndexed { i, value ->
            // 向字典sheet写数据，从第一行开始写，此处可根据自己业务需要，自定
            // 义从第几行还是写，写的时候注意一下行索引是从0开始的即可
            hiddenDictSheet.createRow(i).createCell(0).setCellValue(value)
        }

        val name = workbook.createName()
        // 设置关联数据公式，这个格式跟Excel设置有效性数据的表达式是一样的
        name.nameName = hiddenDictSheetName
        // 将关联公式和sheet页做关联
        val rowLen = dropDownList.size
        name.refersToFormula = "$hiddenDictSheetName!\$A$1:\$A\$$rowLen"
        return hiddenDictSheetName
    }

    /**
     * 解析Excel列下拉注解的值
     * @param [excelSelected] excel下拉注解
     * @return [List<String>]
     */
    private fun analysisDropDownList(excelSelected: ExcelSelected): List<String> {
        val dropDownList = mutableListOf<String>()
        excelSelected.source.takeIf { CollUtil.isNotEmpty(it.toList()) }?.let {
            dropDownList.addAll(it)
        }
        //动态获取下拉框列表
        excelSelected.sourceClass.takeIf { it.isSubclassOf(ExcelDynamicSelect::class) && it.qualifiedName != ExcelDynamicSelect::class.qualifiedName }
                ?.createInstance()?.getSource()
                ?.takeIf { CollUtil.isNotEmpty(it) }
                ?.let {
                    dropDownList.addAll(it)
                }
        return dropDownList
    }
}
