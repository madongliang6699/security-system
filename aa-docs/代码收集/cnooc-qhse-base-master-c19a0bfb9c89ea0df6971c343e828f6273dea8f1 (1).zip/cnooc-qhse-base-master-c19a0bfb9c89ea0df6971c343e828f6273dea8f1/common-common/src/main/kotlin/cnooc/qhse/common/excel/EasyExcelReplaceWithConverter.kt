package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData

/**
 * EasyExcel字段文字替换器，即在String名称和String值中互转
 *
 * 用法：
 * 使用该转换器同时需要在字段上加@EasyExcelReplaceWith注解
 *
 * ```
 * @ExcelProperty("隐患来源", order = 12, converter = ReplaceWithConverter::class)
 * @ExcelReplaceWith(["人工提交_common", "专项检查_special", "巡检_inspection", "随手拍_shot"])
 * var hazardSource: String? = null,
 * ```
 * 上述代码为将excel中的“人工提交”替换为common，以此类推
 */
class EasyExcelReplaceWithConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val replaceAnnotation = context.contentProperty.field.getAnnotation(EasyExcelReplaceWith::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@ExcelReplaceWith注解")
        val replaces = replaceAnnotation.value
        if (replaces.isEmpty()) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@ExcelReplaceWith注解未配置")
        } else if (replaces.any { !it.contains("_") }) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@ExcelReplaceWith注解配置错误")
        }
        val dicts = replaces.associate { it.split("_")[0] to it.split("_")[1] }
        return dicts[context.readCellData.stringValue]
    }

    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val replaceAnnotation = context.contentProperty.field.getAnnotation(EasyExcelReplaceWith::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@ExcelReplaceWith注解")
        val replaces = replaceAnnotation.value
        if (replaces.isEmpty()) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@ExcelReplaceWith注解未配置")
        } else if (replaces.any { !it.contains("_") }) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@ExcelReplaceWith注解配置错误")
        }
        val dicts = replaces.associate { it.split("_")[1] to it.split("_")[0] }
        return WriteCellData<Any>(dicts[context.value] ?: "")
    }
}
