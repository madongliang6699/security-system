package cnooc.qhse.common.service

import com.baomidou.mybatisplus.extension.service.IService

/**
 * 基础业务接口
 */
interface BaseServiceKt<T> : IService<T> {
    /**
     * 逻辑删除
     *
     * @param ids id集合
     * @return
     */
    fun deleteLogic(ids: List<Long>): Boolean

    /**
     * 变更状态
     *
     * @param ids    id集合
     * @param status 状态值
     * @return
     */
    fun changeStatus(ids: List<Long>, status: Int): Boolean
}
