package cnooc.qhse.common.annotation

import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext
import java.util.*
import kotlin.reflect.KClass

class EnumValidatorImpl : ConstraintValidator<EnumValidator, String> {
    private var valueList: MutableList<String>? = null
    override fun isValid(value: String?, context: ConstraintValidatorContext): Boolean {
        if (value == null) {
            return false
        }
        return valueList!!.contains(value.uppercase(Locale.getDefault()))
    }

    override fun initialize(constraintAnnotation: EnumValidator) {
        valueList = mutableListOf()
        val enumClass: KClass<out Enum<*>> = constraintAnnotation.enumClass
        val enumValArr = enumClass.java.enumConstants
        for (enumVal in enumValArr) {
            valueList!!.add(enumVal.toString().uppercase(Locale.getDefault()))
            valueList!!.add(enumVal.name.uppercase(Locale.getDefault()))
        }
    }
}
