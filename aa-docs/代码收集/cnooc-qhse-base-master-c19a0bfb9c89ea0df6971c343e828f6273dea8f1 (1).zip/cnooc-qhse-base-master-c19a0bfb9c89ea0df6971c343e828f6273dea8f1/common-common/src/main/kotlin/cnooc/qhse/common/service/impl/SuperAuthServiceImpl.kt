package cnooc.qhse.common.service.impl

import cnooc.qhse.common.service.ISuperAuthService
import cnooc.qhse.common.utils.notNullRetrieve
import io.github.oshai.kotlinlogging.KotlinLogging
import org.springblade.core.launch.constant.TokenConstant
import org.springblade.core.secure.TokenInfo
import org.springblade.core.secure.utils.SecureUtil
import org.springblade.core.tool.api.R
import org.springblade.core.tool.support.Kv
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.UserCache
import org.springblade.system.feign.IUserClient
import org.springblade.system.pojo.entity.UserInfo
import org.springframework.beans.factory.annotation.Value
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.stereotype.Service
import org.springframework.web.client.RestTemplate
import org.springframework.web.client.exchange

private val log = KotlinLogging.logger {}

@Service
class SuperAuthServiceImpl(private val userService: IUserClient) :
    ISuperAuthService {
    @Value("\${server.port}")
    private val serverPort = 0

    override fun getSuperAuthorization(tenantId: String, account: String): TokenInfo? {
        val user = UserCache.getUser(tenantId, account) ?: return null
        val userInfo = userService.userInfo(user.id).notNullRetrieve()
        return createAuthInfo(userInfo)
    }

    override fun requestControllerApi(
        tenantId: String,
        account: String,
        restTemplate: RestTemplate,
        method: HttpMethod,
        url: String,
        body: Any?
    ): R<*>? {
        val authInfo = getSuperAuthorization(tenantId, account) ?: return null
        val headers = HttpHeaders()
        headers["Content-Type"] = "application/json;charset=utf8"
        headers.contentType = MediaType.APPLICATION_JSON
        headers["Blade-Auth"] = "bearer ${authInfo.token}"
        headers["Authorization"] = "Basic c2FiZXI6c2FiZXJfc2VjcmV0"
        val requestEntity = HttpEntity(body, headers)
        val res = restTemplate.exchange<R<*>>("http://localhost:${serverPort}/$url", method, requestEntity)
        return res.body
    }

    fun createAuthInfo(userInfo: UserInfo): TokenInfo? {
        val authInfo = Kv.create()
        val user = userInfo.user
        //拼装accessToken
        return try {
            //返回accessToken
            authInfo.set(TokenConstant.TOKEN_TYPE, TokenConstant.ACCESS_TOKEN)
                .set(TokenConstant.TENANT_ID, user.tenantId)
                .set(TokenConstant.USER_ID, Func.toStr(user.id))
                .set(TokenConstant.DEPT_ID, user.deptId)
                .set(TokenConstant.POST_ID, user.postId)
                .set(TokenConstant.ROLE_ID, user.roleId)
                .set(TokenConstant.OAUTH_ID, userInfo.oauthId)
                .set(TokenConstant.ACCOUNT, user.account)
                .set(TokenConstant.USER_NAME, user.account)
                .set(TokenConstant.NICK_NAME, user.realName)
                .set(TokenConstant.ROLE_NAME, Func.join(userInfo.roles))
                .set(TokenConstant.DETAIL, userInfo.detail)
            SecureUtil.createToken(authInfo)
        } catch (ex: Exception) {
            log.error { "create auth info failure: ${ex.message}" }
            null
        }
    }
}
