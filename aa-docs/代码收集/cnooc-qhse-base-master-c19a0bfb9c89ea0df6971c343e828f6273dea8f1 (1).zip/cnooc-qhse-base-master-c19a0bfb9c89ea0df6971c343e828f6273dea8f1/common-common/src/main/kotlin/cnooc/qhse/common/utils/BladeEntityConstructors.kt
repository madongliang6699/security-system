package cnooc.qhse.common.utils

import org.springblade.system.pojo.entity.Dept
import org.springblade.system.pojo.entity.DictBiz
import org.springblade.system.pojo.vo.UserVO

/**
 * 方便一行来构建一个DictBiz
 */
fun makeDictBiz(
    id: Long? = null, parentId: Long? = null, tenantId: String? = null,
    code: String? = null, dictKey: String? = null, dictValue: String? = null,
    sort: Int? = null, remark: String? = null
): DictBiz {
    val biz = DictBiz()
    biz.id = id
    biz.tenantId = tenantId
    biz.parentId = parentId
    biz.code = code
    biz.dictKey = dictKey
    biz.dictValue = dictValue
    biz.sort = sort
    biz.remark = remark
    return biz
}

/**
 * 方便一行来构建一个User
 */
fun makeUser(
    id: Long? = null, tenantId: String? = null, account: String? = null,
    realName: String? = null, phone: String? = null,
    email: String? = null,
    status: Int? = null, deptId: String? = null, roleName: String? = null
): UserVO {
    val user = UserVO()
    user.id = id
    user.tenantId = tenantId
    user.realName = realName
    user.account = account
    user.phone = phone
    user.email = email
    user.status = status
    user.deptId = deptId
    user.roleName = roleName
    return user
}

/**
 * 方便一行来构建一个Dept
 */
fun makeDept(
    id: Long? = null,
    tenantId: String? = null,
    deptName: String? = null,
    fullName: String? = null,
    ancestors: String? = null,
    parentId: Long? = null,
    sort: Int? = null,
    remark: String? = null
): Dept {
    val dept = Dept()
    dept.id = id
    dept.tenantId = tenantId
    dept.deptName = deptName
    dept.fullName = fullName
    dept.parentId = parentId
    dept.ancestors = ancestors
    dept.sort = sort
    dept.remark = remark
    return dept
}
