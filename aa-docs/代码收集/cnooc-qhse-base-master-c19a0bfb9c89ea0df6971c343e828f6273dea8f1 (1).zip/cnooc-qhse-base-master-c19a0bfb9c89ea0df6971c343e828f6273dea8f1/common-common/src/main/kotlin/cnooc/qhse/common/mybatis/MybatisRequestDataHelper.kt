package cnooc.qhse.common.mybatis

object MybatisRequestDataHelper {
    /**
     * 请求参数存取
     */
    private val REQUEST_DATA = ThreadLocal<Map<String, Any>?>()

    /**
     * 设置请求参数
     *
     * @param requestData 请求参数 MAP 对象
     */
    fun setRequestData(requestData: Map<String, Any>) {
        REQUEST_DATA.set(requestData)
    }

    /**
     * 获取请求参数
     *
     * @param param 请求参数
     * @return 请求参数 MAP 对象
     */
    fun <T> getRequestData(param: String): T? {
        val dataMap = getRequestData() ?: return null
        return if (dataMap.isNotEmpty()) {
            dataMap[param] as T?
        } else null
    }

    /**
     * 获取请求参数
     *
     * @return 请求参数 MAP 对象
     */
    fun getRequestData(): Map<String, Any>? {
        return REQUEST_DATA.get()
    }
}
