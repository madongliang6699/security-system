package cnooc.qhse.common.entity

import com.baomidou.mybatisplus.annotation.IdType
import com.baomidou.mybatisplus.annotation.TableId
import com.baomidou.mybatisplus.annotation.TableLogic
import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.core.tool.utils.DateUtil
import org.springframework.format.annotation.DateTimeFormat
import java.io.Serializable
import java.time.LocalDateTime

/**
 * Kotlin基础实体类
 */
abstract class BaseEntityKt (
    /**
     * 主键id
     */
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "主键id")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    open var id: Long? = null,

    /**
     * 创建人
     */
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "创建人")
    open var createUser: Long? = null,

    /**
     * 创建部门
     */
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "创建部门")
    open var createDept: Long? = null,

    /**
     * 创建时间
     */
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    @Schema(description = "创建时间")
    open var createTime: LocalDateTime? = null,

    /**
     * 更新人
     */
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "更新人")
    open var updateUser: Long? = null,

    /**
     * 更新时间
     */
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    @Schema(description = "更新时间")
    open var updateTime: LocalDateTime? = null,

    /**
     * 状态[1:正常]
     */
    @Schema(description = "业务状态")
    open var status: Int? = null,

    /**
     * 状态[0:未删除,1:删除]
     */
    @Schema(description = "是否已删除")
    @TableLogic(value = "0", delval = "EXTRACT(EPOCH FROM NOW())::INTEGER")
    @field:JsonProperty("isDeleted")
    open var isDeleted: Int? = null
) : Serializable {
    @JsonIgnore
    fun getIsDeleted(): Int? {
        return isDeleted
    }

    @JsonIgnore
    fun setIsDeleted(isDeleted: Int?) {
        this.isDeleted = isDeleted
    }

    companion object {
        private const val serialVersionUID = -6813022614675919347L
    }
}
