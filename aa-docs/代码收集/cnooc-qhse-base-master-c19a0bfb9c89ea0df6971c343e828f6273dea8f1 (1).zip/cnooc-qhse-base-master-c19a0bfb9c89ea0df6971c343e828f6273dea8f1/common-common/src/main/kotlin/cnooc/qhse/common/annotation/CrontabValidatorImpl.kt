package cnooc.qhse.common.annotation

import org.springblade.core.tool.utils.Func
import org.springframework.scheduling.support.CronExpression
import javax.validation.ConstraintValidator
import javax.validation.ConstraintValidatorContext

class CrontabValidatorImpl: ConstraintValidator<CrontabValidator, String> {

    private var required: Boolean? = null

    override fun initialize(cron: CrontabValidator?) {
        required = cron?.required
    }

    override fun isValid(expression: String?, context: ConstraintValidatorContext?): Boolean {

        if (Func.isBlank(expression)) {
            return required == false
        }

        return CronExpression.isValidExpression(expression)
    }
}
