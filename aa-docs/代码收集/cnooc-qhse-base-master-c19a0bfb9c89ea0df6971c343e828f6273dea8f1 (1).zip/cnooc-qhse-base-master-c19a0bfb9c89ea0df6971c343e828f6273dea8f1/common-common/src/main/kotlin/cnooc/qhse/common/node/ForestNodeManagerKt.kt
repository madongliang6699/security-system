package cnooc.qhse.common.node

/**
 * 森林管理类
 */
class ForestNodeManagerKt<T : INodeKt<T>>(nodes: List<T>) {
    /**
     * 森林的所有节点
     */
    private val nodeMap: Map<Long, T>

    init {
        nodeMap = nodes.associateBy { it.id!! }
    }

    /**
     * 森林的父节点ID
     */
    private val parentIdSet: MutableSet<Long> = mutableSetOf()

    /**
     * 根据节点ID获取一个节点
     *
     * @param id 节点ID
     * @return 对应的节点对象
     */
    fun getTreeNodeAt(id: Long): INodeKt<T>? {
        return nodeMap[id]
    }

    /**
     * 增加父节点ID
     *
     * @param parentId 父节点ID
     */
    fun addParentId(parentId: Long?) {
        parentId?.let {
            parentIdSet.add(parentId)
        }
    }

    /**
     * 获取树的根节点(一个森林对应多颗树)
     *
     * @return 树的根节点集合
     */
    val root: List<T>
        get() {
            val roots = mutableListOf<T>()
            nodeMap.forEach { (_: Long, node: T) ->
                if (node.parentId == 0L || parentIdSet.contains(node.id)) {
                    roots.add(node)
                }
            }
            return roots
        }
}
