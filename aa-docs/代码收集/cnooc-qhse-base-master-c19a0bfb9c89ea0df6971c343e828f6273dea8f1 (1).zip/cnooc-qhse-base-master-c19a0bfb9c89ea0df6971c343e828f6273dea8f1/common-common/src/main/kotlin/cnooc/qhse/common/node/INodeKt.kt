package cnooc.qhse.common.node

import java.io.Serializable

/**
 * Created by Blade.
 */
interface INodeKt<T> : Serializable {
    /**
     * 主键
     *
     * @return Long
     */
    var id: Long?

    /**
     * 父主键
     *
     * @return Long
     */
    var parentId: Long?

    /**
     * 子孙节点
     *
     * @return List<T>
    </T> */
    var children: List<T>?

    /**
     * 是否有子孙节点
     *
     * @return Boolean
     */
    val hasChildren: Boolean
        get() = false
}
