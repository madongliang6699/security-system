package cnooc.qhse.common.utils

/**
 * 流水号生成规则(按默认规则递增，数字从1-99开始递增，数字到99，递增字母;位数不够增加位数)
 * A001
 * A001A002
 */
object PostCodeUtil {
    // 数字位数(默认生成3位的数字)
    private const val numLength = 2 //代表数字位数

    /**
     * 根据前一个code，获取同级下一个code
     * 例如:当前最大code为D01A04，下一个code为：D01A05
     *
     * @param code
     * @return
     */
    @Synchronized
    fun getNextPostCode(code: String?): String {
        val newCode: String
        if (code.isNullOrBlank()) {
            val alphabet = "A"
            val num = getStrNum(1)
            newCode = alphabet + num
        } else {
            val beforeCode = code.substring(0, code.length - 1 - numLength)
            val afterCode = code.substring(code.length - 1 - numLength, code.length)
            val afterCodeAlphabet = afterCode.substring(0, 1)[0]
            val afterCodeNum = afterCode.substring(1).toInt()
            // 先判断数字等于999*，则计数从1重新开始，递增
            val nextNum: String = if (afterCodeNum == getMaxNumByLength(numLength)) {
                getNextStrNum(0)
            } else {
                getNextStrNum(afterCodeNum)
            }
            // 先判断数字等于999*，则字母从A重新开始,递增
            val nextAlphabet: Char = if (afterCodeNum == getMaxNumByLength(numLength)) {
                getNextAlphabet(afterCodeAlphabet)
            } else {
                afterCodeAlphabet
            }

            // 例如Z99，下一个code就是Z99A01
            newCode =
                if ('Z' == afterCodeAlphabet && getMaxNumByLength(numLength) == afterCodeNum) {
                    code + (nextAlphabet.toString() + nextNum)
                } else {
                    beforeCode + (nextAlphabet.toString() + nextNum)
                }
        }
        return newCode
    }

    /**
     * 根据父亲code,获取下级的下一个code
     *
     * 例如：父亲CODE:A01
     * 当前CODE:A01B03
     * 获取的code:A01B04
     *
     * @param parentCode   上级code
     * @param localCode    同级code
     * @return
     */
    @Synchronized
    fun getSubPostCode(parentCode: String?, localCode: String?): String {
        return if (!parentCode.isNullOrBlank() && !localCode.isNullOrBlank()) {
            getNextPostCode(localCode)
        } else if (parentCode.isNullOrBlank()) {
            "A" + getNextStrNum(0)
        } else {
            parentCode + "A" + getNextStrNum(0)
        }
    }

    /**
     * 将数字前面位数补零
     *
     * @param num
     * @return
     */
    private fun getNextStrNum(num: Int): String {
        return getStrNum(num + 1)
    }

    /**
     * 将数字前面位数补零
     *
     * @param num
     * @return
     */
    private fun getStrNum(num: Int): String {
        return String.format("%0" + numLength + "d", num)
    }

    /**
     * 递增获取下个字母
     */
    private fun getNextAlphabet(alphabet: Char): Char {
        if (alphabet == 'Z') {
            return 'A'
        }
        return alphabet + 1
    }

    /**
     * 根据数字位数获取最大值
     * @param length
     * @return
     */
    private fun getMaxNumByLength(length: Int): Int {
        if (length == 0) {
            return 0
        }
        var maxNum = ""
        for (i in 0 until length) {
            maxNum += "9"
        }
        return maxNum.toInt()
    }

    fun cutPostCode(code: String?): List<String> {
        return if (code.isNullOrBlank()) {
            listOf()
        } else {
            //获取标准长度为numLength+1,截取的数量为code.length/numLength+1
            val c = code.length / (numLength + 1)
            val cutCode = mutableListOf<String>()
            for (i in 0 until c) {
                cutCode.add(code.substring(0, (i + 1) * (numLength + 1)))
            }
            cutCode
        }
    }
}
