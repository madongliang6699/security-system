package cnooc.qhse.common.node

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer

/**
 * 节点基类
 */
open class BaseNodeKt<T> : INodeKt<T> {
    /**
     * 主键ID
     */
	@JsonSerialize(using = ToStringSerializer::class)
    override var id: Long? = null

    /**
     * 父节点ID
     */
	@JsonSerialize(using = ToStringSerializer::class)
    override var parentId: Long? = null

    /**
     * 子孙节点
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    override var children: List<T>? = null
    /**
     * 是否有子孙节点
     *
     * @return Boolean
     */
    /**
     * 是否有子孙节点
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    override val hasChildren: Boolean = false
        get() = if (children != null && children!!.isNotEmpty()) {
            true
        } else {
            field
        }

    companion object {
        private const val serialVersionUID = 1L
    }
}
