package cnooc.qhse.common.excel.select

import kotlin.reflect.KClass

/**
 * @author zhangyanan
 * @version 1.0.0
 * @Description 用于excel导出下拉框列表注解,配合EasyExcel使用
 * @see TrainQuestionExcelImportVO 使用可参考此类
 * @createTime 2024年04月11日 13:36:00
 */
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FIELD)
annotation class ExcelSelected(

    /**
         * 固定下拉内容
         */
        val source: Array<String> = [],

    /**
         * 动态下拉内容
         */
        val sourceClass: KClass<out ExcelDynamicSelect> = ExcelDynamicSelect::class,

    /**
         * 设置下拉框的启始行,默认为excel第二行
         */
        val firstRow: Int = 1,

        //设置下拉框的结束行,默认为excel最后一行
    val lastRow: Int = 0x10080
)
