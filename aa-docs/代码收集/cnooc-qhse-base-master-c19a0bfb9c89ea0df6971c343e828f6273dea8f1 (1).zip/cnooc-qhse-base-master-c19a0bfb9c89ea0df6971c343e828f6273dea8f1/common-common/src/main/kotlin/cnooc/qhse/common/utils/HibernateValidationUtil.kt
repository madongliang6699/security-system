package cnooc.qhse.common.utils

import jakarta.validation.Validation
import jakarta.validation.Validator
import kotlin.reflect.KProperty

/**
 * 该工具类提供依据实体类上标注的Hibernate Validator校验注解进行校验的各种工具
 */
object HibernateValidationUtil {
    private val factory = Validation.buildDefaultValidatorFactory()
    private val validator: Validator = factory.validator

    fun Any.validateFields(vararg fields: KProperty<*>, throws: Boolean = true): List<String> {
        val results = mutableListOf<String>()
        fields.forEach {
            validator.validateProperty(this, it.name).forEach { r ->
                results.add(ExcelValidationUtil.getFieldFriendlyName(it) + ": " + r.message)
            }
        }
        if (throws && results.isNotEmpty()) {
            throw IllegalArgumentException(results.joinToString("\n"))
        }
        return results
    }
}

