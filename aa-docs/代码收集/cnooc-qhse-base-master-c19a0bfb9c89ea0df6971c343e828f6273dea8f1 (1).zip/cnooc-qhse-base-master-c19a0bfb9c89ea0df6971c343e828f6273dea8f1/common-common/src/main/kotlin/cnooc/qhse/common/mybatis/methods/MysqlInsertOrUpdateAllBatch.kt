package cnooc.qhse.common.mybatis.methods

import com.baomidou.mybatisplus.core.injector.AbstractMethod
import com.baomidou.mybatisplus.core.metadata.TableInfo
import org.apache.ibatis.executor.keygen.NoKeyGenerator
import org.apache.ibatis.mapping.MappedStatement
import org.springframework.stereotype.Component

/**
 *
 *
 *
 *
 * @author yuxiaobin
 * @date 2019/6/14
 */
@Component
class MysqlInsertOrUpdateAllBatch : AbstractMethod("mysqlInsertOrUpdateAllBatch") {
    override fun injectMappedStatement(
        mapperClass: Class<*>?,
        modelClass: Class<*>?,
        tableInfo: TableInfo
    ): MappedStatement {
        val sql = "<script>insert into %s %s values %s ON DUPLICATE KEY UPDATE %s</script>"
        val fieldSql = prepareFieldSql(tableInfo)
        val valueSql = prepareValuesSqlForMysqlBatch(tableInfo)
        val updateSql = prepareUpdateFieldSql(tableInfo)
        val sqlResult = String.format(sql, tableInfo.tableName, fieldSql, valueSql, updateSql)
        val sqlSource = languageDriver.createSqlSource(configuration, sqlResult, modelClass)
        return addInsertMappedStatement(
            mapperClass, modelClass, "mysqlInsertOrUpdateAllBatch", sqlSource,
            NoKeyGenerator(), null, null
        )
    }

    private fun prepareFieldSql(tableInfo: TableInfo): String {
        val fieldSql = StringBuilder()
        fieldSql.append(tableInfo.keyColumn).append(",")
        // 去除租户id
        for (x in tableInfo.fieldList) {
            if (TENANT_COLUMN != x.column) {
                fieldSql.append(x.column).append(",")
            }
        }
        fieldSql.delete(fieldSql.length - 1, fieldSql.length)
        fieldSql.insert(0, "(")
        fieldSql.append(")")
        return fieldSql.toString()
    }

    private fun prepareUpdateFieldSql(tableInfo: TableInfo): String {
        val fieldSql = StringBuilder()
        //		fieldSql.append(tableInfo.getKeyColumn()).append("=VALUES(").append(tableInfo.getKeyColumn()).append(")");
        // 去除租户id
        for (x in tableInfo.fieldList) {
            if (TENANT_COLUMN != x.column) {
                fieldSql.append(x.column).append("=VALUES(").append(x.column).append("),")
            }
        }
        fieldSql.delete(fieldSql.length - 1, fieldSql.length)
        return fieldSql.toString()
    }

    private fun prepareValuesSqlForMysqlBatch(tableInfo: TableInfo): String {
        val valueSql = StringBuilder()
        valueSql.append("<foreach collection=\"list\" item=\"item\" index=\"index\" open=\"(\" separator=\"),(\" close=\")\">")
        valueSql.append("#{item.").append(tableInfo.keyProperty).append("},")
        for (x in tableInfo.fieldList) { // 去除租户id
            if (TENANT_COLUMN != x.column) {
                valueSql.append("#{item.").append(x.property).append("},")
            }
        }
        valueSql.delete(valueSql.length - 1, valueSql.length)
        valueSql.append("</foreach>")
        return valueSql.toString()
    }

    companion object {
        private const val TENANT_COLUMN = "tenant_id"
    }
}
