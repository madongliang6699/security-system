package cnooc.qhse.common.constants

object CommonConstant {
    // 路径分隔符，比如：area1/area2/area3
    const val PathSplitter = "/"
}
