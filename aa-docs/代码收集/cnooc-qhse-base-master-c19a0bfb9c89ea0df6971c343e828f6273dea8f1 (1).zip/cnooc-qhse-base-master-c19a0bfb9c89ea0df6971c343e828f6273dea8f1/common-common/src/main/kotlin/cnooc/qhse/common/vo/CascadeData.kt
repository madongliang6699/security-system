package cnooc.qhse.common.vo

import org.springblade.system.pojo.entity.DictBiz

/**
 * 提供一个与前端一致的存放级联数据的类
 */
data class CascadeData(
    var value: String,
    var title: String,
    var children: MutableList<CascadeData>? = null
) {
    fun getLabelByValueRecursively(value: String): String? {
        if (this.value == value) {
            return this.title
        }
        if (this.children == null) {
            return null
        }
        for (e in this.children!!) {
            val re = e.getLabelByValueRecursively(value)
            if (re != null) {
                return re
            }
        }
        return null
    }

    fun getAllValues(): List<String> {
        val re = mutableListOf<String>()
        re.add(this.value)
        if (this.children == null) {
            return re
        }
        for (e in this.children!!) {
            re.addAll(e.getAllValues())
        }
        return re
    }

    fun getCascaderDataByValue(value: String): CascadeData? {
        if (this.value == value) {
            return this
        }
        if (this.children == null) {
            return null
        }
        for (e in this.children!!) {
            val re = e.getCascaderDataByValue(value)
            if (re != null) {
                return re
            }
        }
        return null
    }

    companion object {
        fun fromDictBizs(list: List<DictBiz>): List<CascadeData> {
            val re = mutableListOf<CascadeData>()
            val id2CascadeData = mutableMapOf<Long, CascadeData>()
            for (e in list) {
                val parent = id2CascadeData[e.parentId]
                if (parent == null) {
                    val cascadeData = CascadeData(
                        value = e.dictKey,
                        title = e.dictValue,
                    )
                    id2CascadeData[e.id] = cascadeData
                    re.add(cascadeData)
                } else {
                    if (parent.children == null) {
                        parent.children = mutableListOf()
                    }
                    parent.children!!.add(CascadeData(
                        value = e.dictKey,
                        title = e.dictValue,
                    ))
                }
            }
            return re
        }
    }
}
