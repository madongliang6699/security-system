package cnooc.qhse.common.utils

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

/**
 * 时间工具类
 */
object EarnestDateUtil {
    /**
     * 获取一年中每个月的第一天和最后一天
     * @param year 年份
     */
    fun getEveryMonthFirstAndLastDay(year: Int): List<List<LocalDateTime>> {
        val allMonth = mutableListOf<List<LocalDateTime>>()
        for (i in 1 until 13) {
            val firstDayOfMonth = LocalDateTime.of(year, i, 1, 0, 0, 0)
            val lastDayOfMonth = firstDayOfMonth.with(TemporalAdjusters.lastDayOfMonth())
                .withHour(23)
                .withMinute(59)
                .withSecond(59)
            val month = listOf<LocalDateTime>(firstDayOfMonth, lastDayOfMonth)
            allMonth.add(month)
        }
        return allMonth
    }

    /**
     * 将一段时间按照给定的周期分割
     * @param startTime 开始时间
     * @param endTime 结束时间
     * @param period 分割周期(天)
     */
    fun splitTimeRangeByPeriod(
        startTime: LocalDateTime,
        endTime: LocalDateTime,
        period: Int
    ): List<List<LocalDateTime>> {
        val allPeriod = mutableListOf<List<LocalDateTime>>()
        var start = startTime
        while (start.isBefore(endTime)) {
            val periodEnd = start.plusDays(period.toLong())
            if (periodEnd.isAfter(endTime)) {
                allPeriod.add(listOf(start, endTime))
                break
            }
            allPeriod.add(listOf(start, periodEnd))
            start = periodEnd
        }
        return allPeriod
    }

    fun tryParseDateTime(str: String): LocalDateTime? {
        val formatters = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd",
            "yyyy-M-d HH:mm:ss",
            "yyyy-M-d HH:mm",
            "yyyy-M-d H:m:s",
            "yyyy-M-d H:m",
            "yyyy/MM/dd HH:mm:ss",
            "yyyy/MM/dd HH:mm",
            "yyyy/MM/dd",
            "yyyy/M/d HH:mm:ss",
            "yyyy/M/d HH:mm",
            "yyyy/M/d H:m:s",
            "yyyy/M/d H:m",
            "yyyy年MM月dd日 HH:mm:ss",
            "yyyy年MM月dd日 HH:mm",
            "yyyy年MM月dd日",
            "yyyy年M月d日 HH:mm:ss",
            "yyyy年M月d日 HH:mm",
            "yyyy年M月d日 H:m:s",
            "yyyy年M月d日 H:m",
            "yyyy年M月d日",
            "yyyy年MM月dd日 HH时mm分ss秒",
            "yyyy年MM月dd日 HH时mm分",
            "yyyy年MM月dd日 HH时mm分ss秒",
            "yyyy年MM月dd日 HH时mm分",
            "yyyy年M月d日 HH时mm分ss秒",
            "yyyy年M月d日 HH时mm分",
            "yyyy年M月d日 H时m分s秒",
            "yyyy年M月d日 H时m分"
        )
        for (formatter in formatters) {
            try {
                return LocalDateTime.parse(str, DateTimeFormatter.ofPattern(formatter))
            } catch (e: Exception) {
            }
        }
        return null
    }

    fun tryParseDate(str: String): LocalDate? {
        val formatters = listOf(
            "yyyy-M-d",
            "yyyy-MM-dd",
            "yyyy/M/d",
            "yyyy/MM/dd",
            "yyyy年MM月dd日",
            "yyyy年M月d日",
        )
        for (formatter in formatters) {
            try {
                return LocalDate.parse(str, DateTimeFormatter.ofPattern(formatter))
            } catch (e: Exception) {
            }
        }
        return null
    }

    fun tryParseDoubleDateTime(value: Double): LocalDateTime? {
        if (value < 0) {
            return null
        }
        // Excel's base date (January 1, 1900)
        val baseDate = LocalDate.of(1900, 1, 1)

        // Separating the date and time parts
        val daysPart = value.toInt()
        val timePart = value - daysPart

        // Adjusting for Excel's leap year bug and 1-based index in date part
        val targetDate = baseDate.plusDays(daysPart.toLong() - 2)

        // Converting the fractional day to a time of day
        val totalSecondsInDay = (timePart * 24 * 60 * 60).toInt()
        val hours = totalSecondsInDay / 3600
        val minutes = (totalSecondsInDay % 3600) / 60
        val seconds = totalSecondsInDay % 60
        val targetTime = LocalTime.of(hours, minutes, seconds)

        return LocalDateTime.of(targetDate, targetTime)
    }

    fun tryParseDoubleDate(value: Double): LocalDate? {
        if (value < 0) {
            return null
        }
        // Excel's base date (January 1, 1900)
        val baseDate = LocalDate.of(1900, 1, 1)

        // Separating the date and time parts
        val daysPart = value.toInt()

        // Adjusting for Excel's leap year bug and 1-based index in date part
        val targetDate = baseDate.plusDays(daysPart.toLong() - 2)

        return targetDate
    }
}
