package cnooc.qhse.common.node

/**
 * 森林节点类
 */
class ForestNodeKt<T: INodeKt<T>>(
    override var id: Long?, override var parentId: Long?,
    /**
     * 森林节点的内容
     */
    var content: T
) : BaseNodeKt<ForestNodeKt<T>>() {
    companion object {
        private const val serialVersionUID = 1L
    }
}
