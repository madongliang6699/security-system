package cnooc.qhse.common.service

import org.springblade.core.secure.TokenInfo
import org.springblade.core.tool.api.R
import org.springframework.http.HttpMethod
import org.springframework.web.client.RestTemplate

interface ISuperAuthService {
    /**
     * 获取指定用户授权信息
     * ** 慎用 **
     * @param tenantId 租户id
     * @param account 用户账号
     * @return 授权信息
     */
    fun getSuperAuthorization(tenantId: String, account: String): TokenInfo?

    /**
     * 使用指定用户授权信息请求指定接口
     * ** 慎用 **
     *
     * @param tenantId 租户id
     * @param account 用户账号
     * @param restTemplate restTemplate
     * @param url 请求地址，不包含host和端口
     * @return 请求结果
     */
    fun requestControllerApi(
        tenantId: String,
        account: String,
        restTemplate: RestTemplate,
        method: HttpMethod,
        url: String,
        body: Any? = null
    ): R<*>?
}
