package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData

/**
 * EasyExcel字段文字替换器，Boolean版本，即在String和Boolean中互转
 *
 * 用法：
 * 使用该转换器同时需要在字段上加@EasyExcelReplaceWith注解
 *
 * ```
 * @ExcelProperty("是否领导", converter = EasyExcelReplaceWithBooleanConverter::class)
 * @ExcelReplaceWith(["是_true", "否_false"])
 * var leader: Boolean? = null,
 * ```
 * 上述代码为将excel中的“是”替换为true，“否”替换为false
 */
class EasyExcelReplaceWithBooleanConverter : Converter<Boolean> {
    override fun supportJavaTypeKey(): Class<*> {
        return Boolean::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    override fun convertToJavaData(context: ReadConverterContext<*>): Boolean? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val replaceAnnotation = context.contentProperty.field.getAnnotation(EasyExcelReplaceWith::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@EasyExcelReplaceWith注解")
        val replaces = replaceAnnotation.value
        if (replaces.isEmpty()) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@EasyExcelReplaceWith注解未配置")
        } else if (replaces.any { !it.contains("_") }) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@EasyExcelReplaceWith注解配置错误")
        }
        val dicts = replaces.associate { it.split("_")[0] to it.split("_")[1] }
        return dicts[context.readCellData.stringValue] == "true"
    }

    override fun convertToExcelData(context: WriteConverterContext<Boolean>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val replaceAnnotation = context.contentProperty.field.getAnnotation(EasyExcelReplaceWith::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@EasyExcelReplaceWith注解")
        val replaces = replaceAnnotation.value
        if (replaces.isEmpty()) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@EasyExcelReplaceWith注解未配置")
        } else if (replaces.any { !it.contains("_") }) {
            throw IllegalArgumentException("字段${context.contentProperty.field.name}上@EasyExcelReplaceWith注解配置错误")
        }
        val dicts = replaces.associate { it.split("_")[1] to it.split("_")[0] }
        val value = if (context.value) "true" else "false"
        return WriteCellData<String>(dicts[value] ?: "")
    }
}
