package cnooc.qhse.common.excel

/**
 * 字典编码注解，用于标示字典的编码，结合字典转换类EasyExcelDictConverter一同使用。
 *
 * @see EasyExcelDictConverter
 *
 */
@MustBeDocumented
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FIELD)
annotation class DictCode(
    val value: String,
    /**
     * 是否业务字典，默认为是，false表示内置字典
     */
    val isDictBiz: Boolean = true
)
