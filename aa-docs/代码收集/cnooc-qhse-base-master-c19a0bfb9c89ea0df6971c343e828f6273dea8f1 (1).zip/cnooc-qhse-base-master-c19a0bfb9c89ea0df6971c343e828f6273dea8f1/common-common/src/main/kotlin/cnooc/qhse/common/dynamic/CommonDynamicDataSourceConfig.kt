package cnooc.qhse.common.dynamic

import com.baomidou.dynamic.datasource.processor.DsProcessor
import com.baomidou.dynamic.datasource.processor.DsSpelExpressionProcessor
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class CommonDynamicDataSourceConfig {
    @Bean
    fun dsProcessor(): DsProcessor {
        val headerProcessor: DsProcessor = com.baomidou.dynamic.datasource.processor.DsJakartaHeaderProcessor()
        val sessionProcessor: DsProcessor = com.baomidou.dynamic.datasource.processor.DsJakartaSessionProcessor()
        val tenantIdProcessor = CommonDsTenantIdProcessor()
        val spelExpressionProcessor = DsSpelExpressionProcessor()
        headerProcessor.setNextProcessor(sessionProcessor)
        sessionProcessor.setNextProcessor(tenantIdProcessor)
        tenantIdProcessor.setNextProcessor(spelExpressionProcessor)
        return headerProcessor
    }
}
