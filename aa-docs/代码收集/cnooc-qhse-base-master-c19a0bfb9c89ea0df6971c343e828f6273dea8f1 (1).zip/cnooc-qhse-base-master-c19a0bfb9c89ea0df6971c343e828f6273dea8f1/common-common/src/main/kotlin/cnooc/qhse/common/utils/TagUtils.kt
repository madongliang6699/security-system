package cnooc.qhse.common.utils

import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.tuple.ImmutablePair
import org.apache.commons.lang3.tuple.Pair
import java.util.regex.Pattern

object TagUtils {
    /**
     * 解析形如 'UnitNo|%2d;InstallNo|%2d;PhotoNo|%06d;String|-;Distance|%.0fM;Height|H%.0f;Direction|%s;Floor|%02d;String|-;Locator|%s',
     * 'SealType|%s;SealNo|%02d'的格式，将其解析为一系列如(UnitNo, "%02d), (UnitCode, %Xs)一类的格式串。
     * 格式：除了字符串有特殊外，其他均遵循String.format的格式，例如"%10d"
     * 对于字符串，可以指定前置、后置，前置为%10Xs表示前置X补足10位，后置为%-10Xs；
     * @param formatter 字符串
     * @return 已经解析过的格式化列表，形如：[{TagFormatField: string}]
     */
    fun getFormatters(formatter: String): List<Pair<String, String>> {
        val formatters = mutableListOf<Pair<String, String>>()
        val fields = formatter.split(";")
        for (field in fields) {
            val items = field.split("|", limit = 2)
            require(items.size == 2) { "Tag格式错误" }
            formatters.add(ImmutablePair(items[0], items[1]))
        }
        return formatters
    }

    fun getFormatFields(formatter: String): List<String> {
        return getFormatters(formatter).map { obj -> obj.left }
    }

    /**
     * 根据提供的tag formatter的格式，格式化字符串并返回格式化后的字符串; 匹配的格式为：%s, %5Xs, %-5Xs, %5XXs、XX%5XXsXX一类的
     *
     * @param format 类似%s, %10Ps, %-10Ps的格式
     * @param value  要格式化的字符串
     * @return 格式化后的字符串
     */
    fun formatTagString(format: String, value: String): String {
        if (format == "%s" || format.isBlank()) {
            return value
        }
        // 匹配%s, %5Xs, %-5Xs, %5XXs、XX%5XXsXX一类的
        val pattern = "(.*)%([-\\d+|\\d*]*)([A-Za-z]*)s(.*)"
        val r = Pattern.compile(pattern)
        val m = r.matcher(format)
        if (!m.matches()) {
            return value
        }
        val prefix = m.group(1)
        val suffix = m.group(4)
        // eg. 10 or -10
        var number = 0
        if (m.group(2).isNotEmpty()) {
            number = m.group(2).toInt()
        }
        // eg. X
        val padStr = m.group(3)
        // 大于0前补
        val formatResult: String = if (number > 0) {
            // 如果没有前置字符，则补空格
            if (StringUtils.isEmpty(padStr)) {
                StringUtils.leftPad(value, number)
            } else {
                StringUtils.leftPad(value, number, padStr)
            }
        } else if (number < 0) {
            if (StringUtils.isEmpty(padStr)) {
                StringUtils.rightPad(value, -number)
            } else {
                StringUtils.rightPad(value, -number, padStr)
            }
        } else {
            value
        }
        return prefix + formatResult + suffix
    }
}
