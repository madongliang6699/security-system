package cnooc.qhse.common.mybatis.handler

import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import org.apache.ibatis.type.BaseTypeHandler
import org.apache.ibatis.type.JdbcType
import java.sql.CallableStatement
import java.sql.PreparedStatement
import java.sql.ResultSet
/**
 * 自定义JsonNode处理器
 */

class JsonNodeTypeHandler : BaseTypeHandler<JsonNode>() {

    private val objectMapper = ObjectMapper()

    override fun setNonNullParameter(ps: PreparedStatement, i: Int, parameter: JsonNode, jdbcType: JdbcType) {
        try {
            ps.setString(i, parameter.toString())
        } catch (e: JsonProcessingException) {
            throw RuntimeException("Error converting JSONNode to String", e)
        }
    }

    override fun getNullableResult(rs: ResultSet, columnName: String): JsonNode? {
        return convertToJsonNode(rs.getString(columnName))
    }

    override fun getNullableResult(rs: ResultSet, columnIndex: Int): JsonNode? {
        return convertToJsonNode(rs.getString(columnIndex))
    }

    override fun getNullableResult(cs: CallableStatement, columnIndex: Int): JsonNode? {
        return convertToJsonNode(cs.getString(columnIndex))
    }

    private fun convertToJsonNode(jsonString: String?): JsonNode? {
        return if (jsonString != null) {
            objectMapper.readTree(jsonString)
        } else {
            null
        }
    }
}
