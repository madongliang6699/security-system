package cnooc.qhse.common.mapper

import cnooc.qhse.common.vo.TitleAndValueEntity
import com.baomidou.mybatisplus.core.mapper.BaseMapper

/**
 * 报警配置表 Mapper 接口
 */
interface TitleAndValueMapper : BaseMapper<TitleAndValueEntity> {
    fun selectValuesByTitle(tableName: String, valueField: String, titleField: String, tenantId: String, title: String): List<TitleAndValueEntity>
    fun selectTitleByValue(tableName: String, valueField: String, titleField: String, value: Long): TitleAndValueEntity?
}
