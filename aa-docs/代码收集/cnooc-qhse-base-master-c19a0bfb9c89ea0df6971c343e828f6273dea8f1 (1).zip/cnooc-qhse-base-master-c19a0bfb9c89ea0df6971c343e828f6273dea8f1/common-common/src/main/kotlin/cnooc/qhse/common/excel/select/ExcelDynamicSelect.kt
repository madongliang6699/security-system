package cnooc.qhse.common.excel.select

/**
 * @author zhangyanan
 * @version 1.0.0
 * @Description 获取Excel列动态下拉数据接口,配合EasyExcel使用
 * @see TrainQuestionCategoryKeyCnDynamicSelect 使用可参考此类
 * @createTime 2024年04月11日 14:01:00
 */
interface ExcelDynamicSelect {

    /**
     * 获取动态生成的下拉框可选数据
     * @return [Array<String>]
     */
    fun getSource(): List<String>
}
