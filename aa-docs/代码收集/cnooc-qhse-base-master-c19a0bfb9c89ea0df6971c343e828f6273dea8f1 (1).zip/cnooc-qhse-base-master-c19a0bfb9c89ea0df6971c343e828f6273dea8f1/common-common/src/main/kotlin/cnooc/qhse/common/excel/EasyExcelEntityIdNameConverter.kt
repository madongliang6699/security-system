package cnooc.qhse.base.excel

import cnooc.qhse.common.excel.EasyExcelEntityLabelAndValue
import cnooc.qhse.common.mapper.TitleAndValueMapper
import cnooc.qhse.common.vo.TitleAndValueEntity
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.SpringUtil

/**
 * 数据库表键值转换
 */
class EasyExcelEntityLabelAndValueConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将用户名称转换为用户id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        val value = context.readCellData.stringValue
        if (value.isNullOrBlank()) {
            return null
        }
        val annotation = context.contentProperty.field.getAnnotation(EasyExcelEntityLabelAndValue::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@ExcelEntityAndField注解")
        val tableName = annotation.tableName
        val idField = annotation.valueField
        val nameField = annotation.labelField
        val mapper = SpringUtil.getBean(TitleAndValueMapper::class.java)
        val entities = mapper.selectValuesByTitle(tableName, idField, nameField, AuthUtil.getTenantId(), value)
        if (entities.isEmpty()) {
            throw IllegalArgumentException("数据不存在: $value")
        } else if (entities.size > 1) {
            throw IllegalArgumentException("重名数据：$value")
        }
        return entities.first().value
    }

    /**
     * 将用户id转换为用户名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val annotation = context.contentProperty.field.getAnnotation(EasyExcelEntityLabelAndValue::class.java)
            ?: throw IllegalArgumentException("字段${context.contentProperty.field.name}上未加@ExcelEntityAndField注解")
        val tableName = annotation.tableName
        val idField = annotation.valueField
        val nameField = annotation.labelField
        val mapper = SpringUtil.getBean(TitleAndValueMapper::class.java)
        val entity = mapper.selectTitleByValue(tableName, idField, nameField, context.value) ?: TitleAndValueEntity(
            value = context.value,
            title = "未找到有效的风险排查要求编号"
        )
        return WriteCellData<Any>(entity.title)
    }
}
