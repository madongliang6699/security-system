package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache

/**
 * EasyExcel 多个部门id字符串与名称之间的转换器。多个部门用英文,分开
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("部门", converter = EasyExcelDepartmentsConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("部门", converter = EasyExcelDepartmentsConverter::class)
 *  var deptIds: String? = null
 *
 *  // Java
 *  @ExcelProperty(value = "部门", converter = EasyExcelDepartmentsConverter.class)
 *  private String deptIds;
 *  ```
 */
class EasyExcelDepartmentsConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将部门名称转换为部门id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }

        val deptIds = SysCache.getDeptIds(AuthUtil.getTenantId(), context.readCellData.stringValue)
        if (Func.toStrList(deptIds).size != Func.toStrList(context.readCellData.stringValue).size) {
            throw IllegalArgumentException("部门解析错误: ${context.readCellData.stringValue}")
        }
        return deptIds
    }

    /**
     * 将部门id转换为部门名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val deptNames = SysCache.getDeptNames(context.value)
        if (deptNames.size != Func.toStrList(context.value).size) {
            throw IllegalArgumentException("部门解析错误: ${context.value}")
        }
        return WriteCellData<Any>(Func.join(deptNames))
    }
}
