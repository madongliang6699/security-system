package cnooc.qhse.common.excel

import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache

/**
 * EasyExcel 部门id与名称之间的转换器
 * 用法：在实体字段上添加
 * ```
 * @ExcelProperty("部门", converter = EasyExcelDepartmentConverter::class)
 * ```
 *
 * ```
 *  // Kotlin
 *  @ExcelProperty("部门", converter = EasyExcelDepartmentConverter::class)
 *  var deptId: Long? = null
 *
 *  // Java
 *  @ExcelProperty(value = "部门", converter = EasyExcelDepartmentConverter.class)
 *  private Long deptId;
 *  ```
 */
class EasyExcelDepartmentConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将部门名称转换为部门id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val deptIds = SysCache.getDeptIds(AuthUtil.getTenantId(), context.readCellData.stringValue)
        if (deptIds.isNullOrBlank()) throw IllegalArgumentException("部门名称不存在: ${context.readCellData.stringValue}")
        return Func.toLongList(deptIds).first()
    }

    /**
     * 将部门id转换为部门名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val deptName = SysCache.getDeptName(context.value)
        if (deptName.isNullOrBlank()) throw IllegalArgumentException("部门不存在: ${context.value}")
        return WriteCellData<Any>(deptName)
    }
}
