package cnooc.qhse.common.utils

import com.baomidou.dynamic.datasource.toolkit.DynamicDataSourceContextHolder
import org.springblade.core.tenant.TenantUtil
import org.springblade.core.tenant.exception.TenantDataSourceException
import org.springblade.system.cache.SysCache
import java.util.function.Consumer

/**
 * 多租户数据库数据处理工具。此工具通过切换租户上下文来完成多租户数据操作。用法类似：
 *
 * ```
 * // kotlin
 * val areas = mutableListOf<AreaEntity>()
 * CrossTenantDataBaseUtil.doInTenants(listOf("236233", "028059", "020225"),
 *     { tenantId ->
 *         val tenantAreas = this.list(KtQueryWrapper(AreaEntity::class.java).eq(AreaEntity::tenantId, tenantId))
 *         areas.addAll(tenantAreas)
 *     })
 *  ```
 *
 *  ```
 *  // java
 *. List<String> tenantIds = new ArrayList<>() {
 * 		 {
 * 			 add("111111");
 * 			 add("222222");
 * 		 }
 * 	 };
 * 	 List<AreaEntity> areas = new ArrayList<AreaEntity>();
 * 	 CrossTenantDataBaseUtil.doInTenants(tenantIds, tenantId -> {
 * 		 QueryWrapper<AreaEntity> qw = new QueryWrapper<>();
 * 		 qw.lambda().eq(AreaEntity::tenantId, tenantId);
 * 		 areas.addAll(areaService.list(qw));
 * 	 });
 * ```
 */
object CrossTenantDataBaseUtil {
    /**
     * 在给定所有租户id下执行数据库操作。
     * @param tenantIds 租户id列表
     * @param handler 数据库操作 (tenantId) -> void
     */
    @JvmStatic
    fun doInTenants(tenantIds: List<String>, handler: Consumer<String>) {
        tenantIds.forEach { it ->
            try {
                if (it.isNotBlank()) {
                    DynamicDataSourceContextHolder.push(it)
                    TenantUtil.use(it, Runnable { handler.accept(it) })
                }
            } catch (e: Exception) {
                throw TenantDataSourceException(e.message)
            } finally {
                if (it.isNotBlank()) {
                    DynamicDataSourceContextHolder.poll()
                }
            }
        }
    }

    /**
     * 对指定租户及子租户的数据进行操作
     * @param tenantId 租户id
     * @param handler 数据库操作
     */
    @JvmStatic
    fun selfAndChildrenHandle(tenantId: String, handler: Consumer<String>) {
        val childrenTenantIds = SysCache.getChildrenTenantIds(tenantId)
        val tenantIds = mutableListOf(tenantId)
        tenantIds.addAll(childrenTenantIds)
        doInTenants(tenantIds, handler)
    }

    /**
     * 仅对子租户的数据进行操作
     * @param tenantId 租户id
     * @param handler 数据库操作
     */
    @JvmStatic
    fun childrenHandle(tenantId: String, handler: Consumer<String>) {
        val childrenTenantIds = SysCache.getChildrenTenantIds(tenantId)
        doInTenants(childrenTenantIds, handler)
    }

    /**
     * 对指定租户及所有后辈租户的数据进行操作
     * @param tenantId 租户id
     * @param handler 数据库操作
     */
    @JvmStatic
    fun selfAndDescendentsHandle(tenantId: String, handler: Consumer<String>) {
        val parentsTenantIds = SysCache.getDescendentTenantIds(tenantId)
        val tenantIds = mutableListOf(tenantId)
        tenantIds.addAll(parentsTenantIds)
        doInTenants(tenantIds, handler)
    }

    /**
     * 仅对后辈的数据进行操作
     * @param tenantId 租户id
     * @param handler 数据库操作
     */
    @JvmStatic
    fun descendentsHandle(tenantId: String, handler: Consumer<String>) {
        val parentsTenantIds = SysCache.getDescendentTenantIds(tenantId)
        doInTenants(parentsTenantIds, handler)
    }
}
