package cnooc.qhse.common.node


/**
 * 森林节点归并类
 */
object ForestNodeMergerKt {
    /**
     * 将节点数组归并为一个森林（多棵树）（填充节点的children域）
     * 时间复杂度为O(n^2)
     *
     * @param items 节点域
     * @return 多棵树的根节点集合
     */
    fun <T : INodeKt<T>> merge(items: List<T>): List<T> {
        val forestNodeManager = ForestNodeManagerKt(items)
        items.forEach {
            if (it.parentId != 0L) {
                val node = forestNodeManager.getTreeNodeAt(it.parentId!!)
                if (node != null) {
                    node.children = (node.children ?: listOf()) + it
                } else {
                    forestNodeManager.addParentId(it.id)
                }
            }
        }
        return forestNodeManager.root
    }

    /**
     * 获取指定层级的节点列表, 通过levelComparable可以判断哪个层级属于目标范围，比如
     * levelComparable = { currentLevel, designatedLevel -> currentLevel <= designatedLevel } 表示获取小于等于指定层级的节点列表，即父节点也算做指定层级的节点
     * levelComparable = { currentLevel, designatedLevel -> currentLevel == designatedLevel } 表示获取指定层级的节点列表，即父节点不算做指定层级的节点
     */
    private fun <T : INodeKt<T>> getListAtLevel(nodes: List<T>, level: Int, levelComparable: (currentLevel: Int, designatedLevel: Int) -> Boolean): List<T> {
        val result = mutableListOf<T>()
        if (nodes.isEmpty() || level < 1) {
            return result
        }
        val queue = ArrayDeque<T>()
        queue.addAll(nodes)
        var currentLevel = 1
        while (!queue.isEmpty()) {
            val size = queue.size
            for (i in 0 until size) {
                val node = queue.removeFirst()
                if (levelComparable(currentLevel, level)) {
                    result.add(node)
                }
                if (!node.children.isNullOrEmpty()) {
                    queue.addAll(node.children!!)
                }
            }
            currentLevel++
            if (currentLevel > level) {
                break
            }
        }
        return result
    }

    /**
     * 获取指定层级的节点列表, 包含父节点，即父节点也算做指定层级的节点
     */
    fun <T : INodeKt<T>> getListAtLevelIncludingParent(nodes: List<T>, level: Int): List<T> {
        return getListAtLevel(nodes, level) { currentLevel, designatedLevel -> currentLevel <= designatedLevel }
    }

    /**
     * 获取指定层级的节点列表, 不包含父节点，即父节点不算做指定层级的节点
     */
    fun <T : INodeKt<T>> getListAtLevel(nodes: List<T>, level: Int): List<T> {
        return getListAtLevel(nodes, level) { currentLevel, designatedLevel -> currentLevel == designatedLevel }
    }

    /**
     * 获取指定层级的节点列表, 包含子节点，即子节点也算做指定层级的节点
     */
    fun <T : INodeKt<T>> getListAtLevelIncludingChildren(nodes: List<T>, level: Int): List<T> {
        val result = mutableListOf<T>()
        if (nodes.isEmpty() || level < 1) {
            return result
        }
        val queue = ArrayDeque<T>()
        queue.addAll(nodes)
        var currentLevel = 1
        while (!queue.isEmpty()) {
            val size = queue.size
            for (i in 0 until size) {
                val node = queue.removeFirst()
                if (currentLevel >= level) {
                    result.add(node)
                }
                if (!node.children.isNullOrEmpty()) {
                    queue.addAll(node.children!!)
                }
            }
            currentLevel++
        }
        return result
    }
}
