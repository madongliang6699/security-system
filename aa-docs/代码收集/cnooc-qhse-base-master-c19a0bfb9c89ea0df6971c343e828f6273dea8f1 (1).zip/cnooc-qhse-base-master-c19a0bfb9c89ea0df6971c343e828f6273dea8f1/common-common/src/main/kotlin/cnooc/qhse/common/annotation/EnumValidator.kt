package cnooc.qhse.common.annotation

import jakarta.validation.Constraint
import jakarta.validation.Payload
import jakarta.validation.ReportAsSingleViolation
import kotlin.reflect.KClass

/**
 * 枚举类型校验注解，使用此注解的字段必须是枚举类型，且toString()方法返回值必须是枚举的值，而不是名称
 */
@MustBeDocumented
@Constraint(validatedBy = [EnumValidatorImpl::class])
@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.FIELD)
@ReportAsSingleViolation
annotation class EnumValidator(
    val enumClass: KClass<out Enum<*>>,
    val message: String = "Value is not valid",
    val groups: Array<KClass<*>> = [],
    val payload: Array<KClass<out Payload>> = []
)
