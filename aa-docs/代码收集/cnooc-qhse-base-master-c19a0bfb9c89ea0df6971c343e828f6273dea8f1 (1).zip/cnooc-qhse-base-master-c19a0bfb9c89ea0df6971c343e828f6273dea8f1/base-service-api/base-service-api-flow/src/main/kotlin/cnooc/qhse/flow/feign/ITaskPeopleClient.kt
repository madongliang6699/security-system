package cnooc.qhse.flow.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.flow.pojo.entity.TaskPeople
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam

/**
 * 任务分配人员接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
@Tag(name = "任务分配人员接口", description = "任务分配人员接口")
interface ITaskPeopleClient {
    companion object {
        const val API_PREFIX = "/feign/client/task-people"
        const val TASK_PEOPLE = "$API_PREFIX/task-people"
        const val TASK_PEOPLE_WITH_EXTEND1 = "$API_PREFIX/task-people-extend1"
        const val TASK_PEOPLE_WITH_EXTEND12 = "$API_PREFIX/task-people-extend12"
        const val TASK_PEOPLE_WITH_EXTEND123 = "$API_PREFIX/task-people-extend123"
    }

    /**
     * 获取所有相关的任务人员
     * @param tenantId 租户id
     * @param businessCategory 业务分类标识
     * @param taskCode 任务标识
     */
    @Operation(description = "获取所有相关的任务人员")
    @GetMapping(TASK_PEOPLE)
    fun getTaskPeople(
        @RequestParam tenantId: String,
        @RequestParam businessCategory: String,
        @RequestParam taskCode: String
    ): R<List<TaskPeople>>

    /**
     * 获取所有相关的任务人员，包含了根据extend1筛选参数
     */
    @GetMapping(TASK_PEOPLE_WITH_EXTEND1)
    fun getTaskPeopleWithExtend1(
        @RequestParam tenantId: String, @RequestParam businessCategory: String,
        @RequestParam taskCode: String, @RequestParam extend1: String
    ): R<List<TaskPeople>>

    /**
     * 获取所有相关的任务人员，包含了根据extend1和extend2筛选参数
     */
    @GetMapping(TASK_PEOPLE_WITH_EXTEND12)
    fun getTaskPeopleWithExtend12(
        @RequestParam tenantId: String, @RequestParam businessCategory: String,
        @RequestParam taskCode: String, @RequestParam extend1: String, @RequestParam extend2: String
    ): R<List<TaskPeople>>

    /**
     * 获取所有相关的任务人员，包含了根据extend1和extend2和extend3筛选参数
     */
    @GetMapping(TASK_PEOPLE_WITH_EXTEND123)
    fun getTaskPeopleWithExtend123(
        @RequestParam tenantId: String, @RequestParam businessCategory: String,
        @RequestParam taskCode: String, @RequestParam extend1: String, @RequestParam extend2: String, @RequestParam extend3: String
    ): R<List<TaskPeople>>
}
