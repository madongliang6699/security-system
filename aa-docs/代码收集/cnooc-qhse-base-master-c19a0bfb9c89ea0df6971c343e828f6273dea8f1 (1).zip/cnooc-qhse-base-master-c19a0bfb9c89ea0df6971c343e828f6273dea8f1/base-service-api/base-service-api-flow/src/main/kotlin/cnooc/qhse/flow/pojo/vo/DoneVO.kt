package cnooc.qhse.flow.pojo.vo

import cnooc.qhse.flow.pojo.entity.Done
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.plugin.workflow.process.model.WfProcess
import java.time.LocalDateTime

class DoneVO(
    @Schema(description = "事务类型名称")
    var businessCategoryName: String? = null,

    @Schema(description = "工作流对象")
    var flow: WfProcess? = null,

    @Schema(description = "用户名称")
    var userName: String? = null,
    userId: Long? = null,
    businessCategory: String? = null,
    taskName: String? = null,
    businessKey: Long? = null,
    beginTime: LocalDateTime? = null,
    endTime: LocalDateTime? = null,
    doneTime: LocalDateTime? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : Done(
    userId,
    businessCategory,
    taskName,
    businessKey,
    beginTime,
    endTime,
    doneTime,
    remark,
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId
)
