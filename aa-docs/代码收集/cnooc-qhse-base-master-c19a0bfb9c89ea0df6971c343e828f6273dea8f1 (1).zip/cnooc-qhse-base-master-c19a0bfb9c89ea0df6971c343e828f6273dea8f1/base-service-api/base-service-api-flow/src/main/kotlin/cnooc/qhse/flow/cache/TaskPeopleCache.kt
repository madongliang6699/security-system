package cnooc.qhse.flow.cache

import cnooc.qhse.common.utils.notNullRetrieve
import cnooc.qhse.flow.feign.ITaskPeopleClient
import cnooc.qhse.flow.pojo.entity.TaskPeople
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import kotlin.jvm.java

/**
 * 任务分配人员缓存
 */
object TaskPeopleCache {
    const val TASK_PEOPLE_CACHE = "earnest_base:task_people:"
    private const val TASK_PEOPLE = "task_people"


    private var taskPeopleService: ITaskPeopleClient? = null

    private fun getTaskPeopleService(): ITaskPeopleClient {
        if (taskPeopleService == null) {
            taskPeopleService = SpringUtil.getBean(ITaskPeopleClient::class.java)
        }
        return taskPeopleService!!
    }

    fun getTaskPeople(tenantId: String, businessCategory: String, taskCode: String): List<TaskPeople> {
        return CacheUtil.get(TASK_PEOPLE_CACHE, TASK_PEOPLE, tenantId + businessCategory + taskCode + "noExtend")
        {
            getTaskPeopleService().getTaskPeople(tenantId, businessCategory, taskCode).notNullRetrieve()
        } ?: listOf()
    }

    fun getTaskPeople(
        tenantId: String,
        businessCategory: String,
        taskId: String,
        extend1: String
    ): List<TaskPeople> {
        return CacheUtil.get(TASK_PEOPLE_CACHE, TASK_PEOPLE, tenantId + businessCategory + taskId + "extend1" + extend1)
        {
            getTaskPeopleService().getTaskPeopleWithExtend1(tenantId, businessCategory, taskId, extend1).notNullRetrieve()
        } ?: listOf()
    }

    fun getTaskPeople(
        tenantId: String,
        businessCategory: String,
        taskId: String,
        extend1: String,
        extend2: String
    ): List<TaskPeople> {
        return CacheUtil.get(
            TASK_PEOPLE_CACHE,
            TASK_PEOPLE,
            tenantId + businessCategory + taskId + "extend1" + extend1 + "extend2" + extend2
        )
        {
            getTaskPeopleService().getTaskPeopleWithExtend12(tenantId, businessCategory, taskId, extend1, extend2)
                .notNullRetrieve()
        } ?: listOf()
    }

    fun getTaskPeople(
        tenantId: String,
        businessCategory: String,
        taskId: String,
        extend1: String,
        extend2: String,
        extend3: String
    ): List<TaskPeople> {
        return CacheUtil.get(
            TASK_PEOPLE_CACHE,
            TASK_PEOPLE,
            tenantId + businessCategory + taskId + "extend1" + extend1 + "extend2" + extend2 + "extend3" + extend3
        )
        {
            getTaskPeopleService().getTaskPeopleWithExtend123(
                tenantId,
                businessCategory,
                taskId,
                extend1,
                extend2,
                extend3
            )
                .notNullRetrieve()
        } ?: listOf()
    }
}
