package cnooc.qhse.flow.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.NullSerializer
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.constraints.Min
import jakarta.validation.constraints.NotEmpty
import jakarta.validation.constraints.NotNull
import java.time.LocalDateTime

/**
 * 流程节点操作实体类
 */
@TableName("earnest_flow_operation")
@Schema(description = "流程节点操作")
open class FlowOperation(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    /**
     * 事务类型
     */
    @Schema(description = "事务类型")
    @NotEmpty(message = "事务类型不能为空") var businessCategory: String? = null,
    /**
     * 任务节点id
     */
    @Schema(description = "任务节点id")
    @NotEmpty(message = "任务节点id不能为空") var taskId: String? = null,
    /**
     * 操作集合
     */
    @Schema(description = "操作")
    @NotEmpty(message = "操作不能为空") var operation: String? = null,
    /**
     * 操作集合
     */
    @Schema(description = "操作名称")
    @NotEmpty(message = "操作名称不能为空")
    var operationName: String? = null,

    @Schema(description = "排序")
    @Min(value = 0, message = "排序不能小于0")
    var sort: Int? = null,

    @Schema(description = "表单id")
    @JsonSerialize(using = ToStringSerializer::class, nullsUsing = NullSerializer::class)
    @NotEmpty(message = "表单id不能为空")
    @NotNull(message = "表单id不能为空")
    var formId: Long? = null,

    @Schema(description = "任务说明")
    var taskInstruction: String? = null,

    @Schema(description = "执行操作后是否完成任务")
    @NotNull(message = "执行操作后是否完成任务不能为空")
    var completed: Boolean? = null,

    @Schema(description = "备注")
    var remark: String? = null
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {

    companion object {
        private const val serialVersionUID = 1L
    }
}
