package cnooc.qhse.flow.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.NullSerializer
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.core.tool.utils.DateUtil
import org.springframework.format.annotation.DateTimeFormat
import java.io.Serial
import java.time.LocalDateTime

/**
 * 待办事项实体类
 */
@TableName("earnest_todo")
@Schema(description = "待办事项")
open class Todo(
    @JsonSerialize(using = ToStringSerializer::class, nullsUsing = NullSerializer::class)
    @Schema(description = "用户id")
    var userId: Long? = null,

    @Schema(description = "候选用户或组")
    var users: String? = null,

    /**
     * 事务类型
     */
    @Schema(description = "事务类型")
    var businessCategory: String? = null,

    /**
     * 任务名称
     */
    @Schema(description = "任务名称")
    var taskName: String? = null,

    /**
     * 业务id
     */
    @Schema(description = "业务id")
    @JsonSerialize(using = ToStringSerializer::class, nullsUsing = NullSerializer::class)
    var businessKey: Long? = null,

    @Schema(description = "开始时间")
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    var beginTime: LocalDateTime? = null,

    /**
     * 过期时间
     */
    @Schema(description = "过期时间")
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    var endTime: LocalDateTime? = null,

    @Schema(description = "备注")
    var remark: String? = null,

    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {

    companion object {
        @Serial
        private const val serialVersionUID = 1L
    }
}
