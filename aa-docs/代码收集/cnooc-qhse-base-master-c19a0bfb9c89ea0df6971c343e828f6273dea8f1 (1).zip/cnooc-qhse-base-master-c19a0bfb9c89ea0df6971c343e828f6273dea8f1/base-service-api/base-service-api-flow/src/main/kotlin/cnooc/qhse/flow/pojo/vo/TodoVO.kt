package cnooc.qhse.flow.pojo.vo

import cnooc.qhse.flow.pojo.entity.Todo
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.plugin.workflow.process.model.WfProcess
import java.time.LocalDateTime


/**
 * 待办事项视图实体类
 */
@Schema(name = "TodoVO对象", description = "待办事项")
class TodoVO(
    @Schema(description = "事务类型名称")
    var businessCategoryName: String? = null,

    @Schema(description = "工作流对象")
    var flow: WfProcess? = null,

    @Schema(description = "用户名称")
    var userName: String? = null,

    @Schema(description = "是否过期")
    var expired: Boolean? = null,

    userId: Long? = null,
    users: String? = null,
    businessCategory: String? = null,
    taskName: String? = null,
    businessKey: Long? = null,
    beginTime: LocalDateTime? = null,
    endTime: LocalDateTime? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null
) : Todo(
    userId,
    users,
    businessCategory,
    taskName,
    businessKey,
    beginTime,
    endTime,
    remark,
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
