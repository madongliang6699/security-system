package cnooc.qhse.flow.constant

/**
 * 流程中使用的变量名称
 */
object FlowVariable {
    /**
     * 操作名称
     */
    const val ACTION = "action"

    // 任务节点人员表中的数据，这个要用在流程的自定义中
    const val TASK_PEOPLE = "taskPeople"

    // 提前结束循环任务的变量名称
    const val END_LOOP = "endLoop"
}
