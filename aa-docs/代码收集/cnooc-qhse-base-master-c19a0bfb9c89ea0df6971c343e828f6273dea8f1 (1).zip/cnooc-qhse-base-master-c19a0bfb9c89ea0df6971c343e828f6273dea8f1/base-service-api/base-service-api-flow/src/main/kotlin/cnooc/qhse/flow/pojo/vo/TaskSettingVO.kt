package cnooc.qhse.flow.pojo.vo

import cnooc.qhse.flow.pojo.entity.TaskSetting
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 任务设置表视图实体类
 */
@Schema(name = "TaskSettingVO", description = "任务设置表")
open class TaskSettingVO(
    businessCategory: String? = null,
    taskId: String? = null,
    positionNeeded: Boolean? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TaskSetting(
    businessCategory,
    taskId,
    positionNeeded,
    remark,
    id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
