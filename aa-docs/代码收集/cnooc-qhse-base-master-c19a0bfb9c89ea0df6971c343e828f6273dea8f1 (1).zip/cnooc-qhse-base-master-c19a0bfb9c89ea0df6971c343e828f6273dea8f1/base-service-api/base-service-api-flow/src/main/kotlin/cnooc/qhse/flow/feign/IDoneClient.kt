package cnooc.qhse.flow.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.flow.pojo.vo.DoneVO
import com.baomidou.mybatisplus.core.metadata.IPage
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestParam

@FeignClient(value = BaseConstant.APP_NAME)
@Tag(name = "办结事项接口", description = "办结事项接口")
interface IDoneClient {
    companion object {
        const val API_PREFIX = "/feign/client/done"
        const val GET_DONES = "$API_PREFIX/dones"
        const val ADD_DONE = "$API_PREFIX/add-done"
    }

    /**
     * 根据条件查询办结事项
     * @param businessCategory 业务分类标识
     * @param isFlow 是否是流程
     * @param flowDeploymentCategory 流程部署分类
     * @param query 分页及排序参数
     */
    @Operation(description = "根据条件查询办结事项")
    @GetMapping(GET_DONES)
    fun getDones(
        @RequestParam businessCategory: String,
        @RequestParam isFlow: Boolean,
        @RequestParam flowDeploymentCategory: String?,
        @RequestBody query: Query
    ): R<IPage<DoneVO>>

    /**
     * 添加办结事项
     * @param businessKey 业务主键
     */
    @Operation(description = "添加办结事项")
    @PostMapping(ADD_DONE)
    fun addDone(@RequestParam businessKey: Long): R<Boolean>
}
