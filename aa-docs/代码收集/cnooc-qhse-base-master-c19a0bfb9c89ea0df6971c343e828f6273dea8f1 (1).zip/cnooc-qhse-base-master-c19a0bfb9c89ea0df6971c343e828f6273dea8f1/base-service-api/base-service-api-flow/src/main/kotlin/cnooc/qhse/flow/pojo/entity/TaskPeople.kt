package cnooc.qhse.flow.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 任务人员表实体类
 */
@TableName("earnest_task_people")
@Schema(description = "任务人员表")
open class TaskPeople(
    @Schema(description = "业务类型")
    var businessCategory: String? = null,
    @Schema(description = "任务ID")
    var taskCode: String? = null,
    @Schema(description = "用户编码")
    var people: String? = null,
    @Schema(description = "扩展字段1")
    var extend1: String? = null,
    @Schema(description = "扩展字段2")
    var extend2: String? = null,
    @Schema(description = "扩展字段3")
    var extend3: String? = null,
    @Schema(description = "备注")
    var remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
