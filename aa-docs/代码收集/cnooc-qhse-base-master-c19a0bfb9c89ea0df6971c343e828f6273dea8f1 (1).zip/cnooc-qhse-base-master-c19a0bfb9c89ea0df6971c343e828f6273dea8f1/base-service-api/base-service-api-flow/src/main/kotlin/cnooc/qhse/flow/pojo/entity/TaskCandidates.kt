package cnooc.qhse.flow.pojo.entity

data class TaskCandidates(val users: List<Long>, val groups: List<String>)
