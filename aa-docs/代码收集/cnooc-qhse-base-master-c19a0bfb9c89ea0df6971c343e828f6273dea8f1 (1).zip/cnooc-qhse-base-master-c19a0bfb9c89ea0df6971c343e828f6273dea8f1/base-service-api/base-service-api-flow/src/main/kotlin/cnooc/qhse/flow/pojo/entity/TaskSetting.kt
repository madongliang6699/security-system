package cnooc.qhse.flow.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 任务设置表实体类
 */
@TableName("earnest_task_setting")
@Schema(description = "任务设置表")
open class TaskSetting(
    @Schema(description = "业务类别")
    var businessCategory: String? = null,
    @Schema(description = "任务ID")
    var taskId: String? = null,
    @Schema(description = "是否需要定位")
    var positionNeeded: Boolean? = null,
    @Schema(description = "备注")
    var remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
