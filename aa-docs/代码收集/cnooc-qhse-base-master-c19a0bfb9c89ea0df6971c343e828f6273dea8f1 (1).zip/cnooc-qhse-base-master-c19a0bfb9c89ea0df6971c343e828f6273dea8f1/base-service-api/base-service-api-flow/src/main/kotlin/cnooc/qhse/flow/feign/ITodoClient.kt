package cnooc.qhse.flow.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.flow.pojo.entity.Todo
import cnooc.qhse.flow.pojo.vo.TodoVO
import com.baomidou.mybatisplus.core.metadata.IPage
import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.tags.Tag
import org.springblade.core.mp.support.Query
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestParam

@FeignClient(value = BaseConstant.APP_NAME)
@Tag(name = "待办事项接口", description = "待办事项接口")
interface ITodoClient {
    companion object {
        const val API_PREFIX = "/feign/client/todo"
        const val GET_TODOS = "$API_PREFIX/todos"
        const val REMOVE_TODOS = "$API_PREFIX/remove-todos"
        const val GET_BY_BUSINESS_KEY = "$API_PREFIX/get-by-business-key"
        const val ADD_TODOS = "$API_PREFIX/add-todos"
    }

    /**
     * 根据条件查询待办事项
     * @param businessCategory 业务分类标识
     * @param isFlow 是否是流程
     * @param flowDeploymentCategory 流程部署分类
     * @param query 分页及排序参数
     */
    @Operation(description = "根据条件查询待办事项")
    @GetMapping(GET_TODOS)
    fun getTodos(
        @RequestParam businessCategory: String,
        @RequestParam isFlow: Boolean,
        @RequestParam flowDeploymentCategory: String?,
        @RequestBody query: Query
    ): R<IPage<TodoVO>>

    /**
     * 通过业务主键来删除待办事项
     * @param businessKeys 业务主键列表
     */
    @Operation(description = "通过业务主键来删除待办事项")
    @DeleteMapping(REMOVE_TODOS)
    fun removeByBusinessKeys(@RequestBody businessKeys: List<Long>): R<Boolean>

    /**
     * 通过业务主键来获取待办事项
     * @param businessKey 业务主键
     */
    @Operation(description = "通过业务主键来获取待办事项")
    @GetMapping(GET_BY_BUSINESS_KEY)
    fun getByBusinessKey(@RequestParam businessKey: Long): R<Todo?>

    /**
     * 添加待办事项
     * @param todos 待办事项列表
     */
    @Operation(description = "添加待办事项")
    @PostMapping(ADD_TODOS)
    fun addTodos(@RequestBody todos: List<Todo>): R<Boolean>
}
