package cnooc.qhse.message.pojo.vo;

import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serial;

/**
 * 待办补偿机制表 视图实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MqTodoFailCmdVO extends MqTodoFailCmdEntity {
	@Serial
	private static final long serialVersionUID = 1L;

}
