package cnooc.qhse.message.pojo.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springblade.core.tenant.mp.TenantEntity;

import java.util.Date;

/**
 * 待办补偿机制表 实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@TableName("message_mq_todo_fail_cmd")
@Schema(description = "MqTodoFailCmd对象")
@EqualsAndHashCode(callSuper = true)
public class MqTodoFailCmdEntity extends TenantEntity {

	/**
	 * 业务id
	 */
	@Schema(description = "业务id")
	private String srcTodoId;
	/**
	 * 接收人
	 */
	@Schema(description = "接收人")
	private String mqReceiver;
	/**
	 * 接收人名字
	 */
	@Schema(description = "接收人名字")
	private String mqReceiverName;
	/**
	 * 类型
	 */
	@Schema(description = "类型")
	private String mqType;
	/**
	 * 内容
	 */
	@Schema(description = "内容")
	private String mqContent;
	/**
	 * 创建内容
	 */
	@Schema(description = "创建内容")
	private Date creationTime;
	/**
	 * 重试次数
	 */
	@Schema(description = "重试次数")
	private Long mqRetrycount;
	/**
	 * mq状态
	 */
	@Schema(description = "mq状态")
	private Integer mqStatus;

}
