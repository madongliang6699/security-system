package cnooc.qhse.message.pojo.dto;

import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serial;

/**
 * 待办补偿机制表 数据传输对象实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MqTodoFailCmdDTO extends MqTodoFailCmdEntity {
	@Serial
	private static final long serialVersionUID = 1L;

}
