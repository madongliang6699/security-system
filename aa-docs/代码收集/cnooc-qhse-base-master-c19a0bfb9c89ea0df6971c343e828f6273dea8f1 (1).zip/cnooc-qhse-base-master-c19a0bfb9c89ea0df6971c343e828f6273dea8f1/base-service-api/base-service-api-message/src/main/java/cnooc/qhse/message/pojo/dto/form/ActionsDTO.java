package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ActionsDTO {
	@JsonProperty("key")
	private String key;
	@JsonProperty("name")
	private String name;
	@JsonProperty("minSegments")
	private Integer minSegments;
	@JsonProperty("maxSegments")
	private Integer maxSegments;
	@JsonProperty("opinionRequired")
	private Boolean opinionRequired;
	@JsonProperty("allowModifySegments")
	private Boolean allowModifySegments;
	@JsonProperty("selectUsersInteractively")
	private Boolean selectUsersInteractively;
	@JsonProperty("segments")
	private List<SegmentsDTO> segments;
}
