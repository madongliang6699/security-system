package cnooc.qhse.message.constant;

/**
 * @author zqy
 */
public class ActionType {
	/**
	 * 新增
	 */
	public static final String CREATE = "UT_TODO_CREATE";
	/**
	 * 更新
	 */
	public static final String UPDATE = "UT_TODO_UPDATE";
	/**
	 * 移除
	 */
	public static final String REMOVE = "UT_TODO_REMOVE";
}
