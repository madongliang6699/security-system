package cnooc.qhse.message.pojo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@Data
public class ProcessForm {

	@JsonProperty("formId")
	private String formId;
	@JsonProperty("categoryId")
	private String categoryId;
	@JsonProperty("action")
	private String action;
	@JsonProperty("userAccount")
	private String userAccount;
	@JsonProperty("appId")
	private String appId;
	@JsonProperty("opinion")
	private String opinion;
	@JsonProperty("steps")
	private List<String> steps;
	@JsonProperty("srcCallSystem")
	private String srcCallSystem;
}
