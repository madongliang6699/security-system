package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class TodoUsersDTO {

	@JsonProperty("account")
	private String account;
}
