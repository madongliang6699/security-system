package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class HistoryDTO {
	@JsonProperty("username")
	private String username;
	@JsonProperty("operateTime")
	private String operateTime;
	@JsonProperty("opinion")
	private String opinion;
	@JsonProperty("action")
	private String action;
	@JsonProperty("account")
	private String account;
	@JsonProperty("extraInfo")
	private List<?> extraInfo;
}
