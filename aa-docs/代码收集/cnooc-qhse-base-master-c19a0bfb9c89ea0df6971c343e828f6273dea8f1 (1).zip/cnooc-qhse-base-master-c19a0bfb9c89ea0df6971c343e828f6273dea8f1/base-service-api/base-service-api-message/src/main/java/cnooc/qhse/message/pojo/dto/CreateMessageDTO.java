package cnooc.qhse.message.pojo.dto;

import cnooc.qhse.message.constant.ActionType;
import lombok.Data;

/**
 * 待办发送实体
 * 例子：
 * {
 * 	"extSysId": "demo",
 * 	"srcTodoId": "1",
 * 	"receiver": "ex_renchao",
 * 	"receiverName": "任超",
 * 	"actionType": "UT_TODO_CREATE",
 * 	"title": "待办创建测试01",
 * 	"pcAddr": "https://demo.cnooc.com.cn/dosm/orderDetail?id=1",
 * 	"mobileAddr": "https://m.demo.cnooc.com.cn/dosm/orderDetail?id=1",
 * 	"sender": "ex_zhaowp",
 * 	"senderName": "赵文鹏",
 * 	"sentDate": 1701755760056,
 * 	"seenDate": 1701755770056,
 * 	"creatorAccount": "ex_nanxl",
 * 	"creatorName": "南小龙",
 * 	"enableMessage": 0
 * }
 *
 * @author zqy
 */
@Data
public class CreateMessageDTO extends BaseMessageDTO {

	public CreateMessageDTO() {
		setActionType(ActionType.CREATE);
	}
}
