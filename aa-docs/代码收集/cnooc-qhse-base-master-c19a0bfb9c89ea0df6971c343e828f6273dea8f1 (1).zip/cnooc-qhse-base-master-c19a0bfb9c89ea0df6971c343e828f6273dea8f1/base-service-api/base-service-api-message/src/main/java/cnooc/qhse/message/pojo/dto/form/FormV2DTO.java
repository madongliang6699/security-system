package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class FormV2DTO {
	@JsonProperty("version")
	private Integer version;
	@JsonProperty("id")
	private String id;
	@JsonProperty("categoryId")
	private String categoryId;
	@JsonProperty("formDefinitionId")
	private String formDefinitionId;
	@JsonProperty("lastApprovalTime")
	private String lastApprovalTime;
	@JsonProperty("lastApprover")
	private String lastApprover;
	@JsonProperty("readonly")
	private Boolean readonly;
	@JsonProperty("subject")
	private String subject;
	@JsonProperty("submitter")
	private String submitter;
	@JsonProperty("submitTime")
	private String submitTime;
	@JsonProperty("description")
	private String description;
	@JsonProperty("allowEdit")
	private Boolean allowEdit;
	@JsonProperty("type")
	private String type;
	@JsonProperty("valueGroups")
	private List<ValueGroupsDTO> valueGroups;
	@JsonProperty("attachments")
	private List<AttachmentsDTO> attachments;
	@JsonProperty("actions")
	private List<ActionsDTO> actions;
	@JsonProperty("history")
	private List<HistoryDTO> history;
	@JsonProperty("todoUsers")
	private List<TodoUsersDTO> todoUsers;
}
