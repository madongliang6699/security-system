package cnooc.qhse.message.pojo.dto;

import cnooc.qhse.message.constant.ActionType;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 更新消息实体类
 * 例子：
 * {
 * "extSysId": "demo",
 * "srcTodoId": "1",
 * "receiver": "ex_renchao",
 * "receiverName": "任超",
 * "actionType": "UT_TODO_UPDATE",
 * "title": "待办更新测试01",
 * "pcAddr": "https://demo.cnooc.com.cn/dosm/orderDetail?id=1",
 * "mobileAddr": "https://m.demo.cnooc.com.cn/dosm/orderDetail?id=1",
 * "sender": "ex_zhaowp",
 * "senderName": "赵文鹏",
 * "sentDate": 1701755760056,
 * "seenDate": 1701755770056,
 * "creatorAccount": "ex_nanxl",
 * "creatorName": "南小龙"
 * }
 *
 * @author zqy
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UpdateMessageDTO extends BaseMessageDTO {
	public UpdateMessageDTO() {
		setActionType(ActionType.UPDATE);
	}
}
