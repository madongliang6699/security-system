package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AttachmentsDTO {
	@JsonProperty("isInternetAddress")
	private Boolean isInternetAddress;
	@JsonProperty("linkAddress")
	private String linkAddress;
	@JsonProperty("name")
	private String name;
	@JsonProperty("size")
	private Integer size;
	@JsonProperty("extraInfo")
	private List<?> extraInfo;
}
