package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SegmentsDTO {

	@JsonProperty("adPath")
	private List<?> adPath;
	@JsonProperty("id")
	private String id;
	@JsonProperty("multiSteps")
	private Boolean multiSteps;
	@JsonProperty("name")
	private String name;
	@JsonProperty("selectUserFromAD")
	private Boolean selectUserFromAD;
	@JsonProperty("stepOptions")
	private List<StepOptionsDTO> stepOptions;
	@JsonProperty("required")
	private Boolean required;
}
