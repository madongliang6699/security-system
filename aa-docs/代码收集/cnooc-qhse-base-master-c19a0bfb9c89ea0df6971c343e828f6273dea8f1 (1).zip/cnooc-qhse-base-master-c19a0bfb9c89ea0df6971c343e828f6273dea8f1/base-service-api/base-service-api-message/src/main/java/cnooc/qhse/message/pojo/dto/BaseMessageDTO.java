package cnooc.qhse.message.pojo.dto;

import cnooc.qhse.message.constant.ActionType;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author zqy
 */
@Data
@NoArgsConstructor
public class BaseMessageDTO {
	/**
	 * 所属业务系统ID
	 */
	@JsonProperty("extSysId")
	@NotNull
	private String extSysId;
	/**
	 * 业务数据ID
	 */
	@JsonProperty("srcTodoId")
	@NotNull
	private String srcTodoId;
	/**
	 * 待办接收人账号
	 */
	@JsonProperty("receiver")
	@NotNull
	private String receiver;
	/**
	 * 待办接收人姓名
	 */
	@JsonProperty("receiverName")
	@NotNull
	private String receiverName;
	/**
	 * 取值范围，{@link ActionType}
	 * 1、创建待办: UT_TODO_CREATE
	 * 2、更新待办: UT_TODO_UPDATE
	 * 3、删除待办: UT_TODO_REMOVE
	 */
	@JsonProperty("actionType")
	@NotNull
	private String actionType;
	/**
	 * 待办标题
	 */
	@JsonProperty("title")
	@NotNull
	private String title;
	/**
	 * PC端打开地址: 业务系统的访问地址
	 */
	@JsonProperty("pcAddr")
	@NotNull
	private String pcAddr;
	/**
	 * 移动端打开地址: 业务系统的访问地址。非H5审批页面（详情页面）参数值传null。
	 */
	@JsonProperty("mobileAddr")
	@NotNull
	private String mobileAddr;
	/**
	 * 待办发送人账号: 是上一级（环节）处理人
	 */
	@JsonProperty("sender")
	@NotNull
	private String sender;
	/**
	 * 待办发送人姓名: 是上一级（环节）处理人
	 */
	@JsonProperty("senderName")
	@NotNull
	private String senderName;
	/**
	 * 发送时间
	 */
	@JsonProperty("sentDate")
	@NotNull
	private Long sentDate;
	/**
	 * 上一步处理时间
	 */
	@JsonProperty("seenDate")
	@NotNull
	private Long seenDate;
	/**
	 * 业务发起人账号
	 */
	@JsonProperty("creatorAccount")
	@NotNull
	private String creatorAccount;
	/**
	 * 业务发起人名称
	 */
	@JsonProperty("creatorName")
	@NotNull
	private String creatorName;
	/**
	 * 是否推送消息待办提醒：0，不推送；1，推送
	 */
	@JsonProperty("enableMessage")
	@NotNull
	private Integer enableMessage;

	/**
	 * 详情页面为非H5页面时，必填：传入业务分类参数值
	 */
	@JsonProperty("appCat")
	@NotNull
	private String appCat;
}
