package cnooc.qhse.message.pojo.dto;

import cnooc.qhse.message.constant.ActionType;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 移除待办实体
 * 例子：
 * {
 * 	"extSysId": "demo",
 * 	"srcTodoId": "1",
 * 	"receiver": "zhangyq",
 * 	"actionType": "UT_TODO_REMOVE"
 * }
 *
 * @author zqy
 */
@Data
public class RemoveMessageDTO {
	/**
	 * 所属业务系统ID
	 */
	@JsonProperty("extSysId")
	@NotNull
	private String extSysId;
	/**
	 * 业务数据ID
	 */
	@JsonProperty("srcTodoId")
	@NotNull
	private String srcTodoId;
	/**
	 * 待办接收人账号
	 */
	@JsonProperty("receiver")
	@NotNull
	private String receiver;
	/**
	 * 取值范围
	 * 默认：UT_TODO_REMOVE
	 */
	@JsonProperty("actionType")
	@NotNull
	private String actionType;
	public RemoveMessageDTO() {
		setActionType(ActionType.REMOVE);
	}
}
