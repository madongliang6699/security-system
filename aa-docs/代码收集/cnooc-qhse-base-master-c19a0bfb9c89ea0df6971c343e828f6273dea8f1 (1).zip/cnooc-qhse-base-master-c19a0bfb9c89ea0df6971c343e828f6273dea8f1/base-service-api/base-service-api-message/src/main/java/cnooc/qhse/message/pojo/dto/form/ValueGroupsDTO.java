package cnooc.qhse.message.pojo.dto.form;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author zqy
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ValueGroupsDTO {
	@JsonProperty("name")
	private String name;
	@JsonProperty("expand")
	private Boolean expand;
	@JsonProperty("values")
	private List<ValuesDTO> values;
	@JsonProperty("childGroups")
	private List<?> childGroups;
}
