package cnooc.qhse.message.feign;

import org.springblade.core.mp.support.BladePage;
import cnooc.qhse.message.pojo.entity.MqTodoFailCmdEntity;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 待办补偿机制表 Feign接口类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@FeignClient(
    value = "cnooc-qhse-message"
)
public interface IMqTodoFailCmdClient {

    String API_PREFIX = "/feign/client/mqTodoFailCmd";
    String TOP = API_PREFIX + "/top";

    /**
     * 获取待办补偿机制表列表
     *
     * @param current   页号
     * @param size      页数
     * @return BladePage
     */
    @GetMapping(TOP)
    BladePage<MqTodoFailCmdEntity> top(@RequestParam("current") Integer current, @RequestParam("size") Integer size);

}
