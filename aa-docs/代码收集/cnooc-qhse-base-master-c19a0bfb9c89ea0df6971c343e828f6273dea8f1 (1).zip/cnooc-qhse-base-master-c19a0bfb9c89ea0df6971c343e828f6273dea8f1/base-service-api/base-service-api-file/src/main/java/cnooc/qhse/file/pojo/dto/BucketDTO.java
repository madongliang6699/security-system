package cnooc.qhse.file.pojo.dto;

import cnooc.qhse.file.pojo.entity.Bucket;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 存储空间实体
 *
 * @className: Bucket
 * @author: zhuqinyang
 * @date: 2024/10/8 上午10:58
 * @Version: 1.0
 * @description:
 */
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Data
public class BucketDTO extends Bucket {

}
