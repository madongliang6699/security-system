package cnooc.qhse.file.pojo.entity;

import java.util.HashMap;
import java.util.Map;

/**
 * 数据索引实体类
 *
 * @author zhuqinyang
 */
public class DataIndex extends HashMap<String, Object> {

	public static final String ID = "Id";
	public static final String SUMMARY_CONTENT = "summaryContent";

	public DataIndex(String id, Map<String, Object> data) {
		super();
		this.putAll(data);
		put(ID, id);
	}

	/**
	 * 获取数据索引序号，对应 ES documentId
	 *
	 * @return 数据索引序号
	 */
	public String getId() {
		return String.valueOf(get(ID));
	}

	/**
	 * 设置数据索引序号，对应 ES documentId
	 *
	 * @param id 指定索引序号
	 */
	public void setId(String id) {
		put(ID, id);
	}

	/**
	 * 检索摘要内容
	 * 例如："经营<font color='#ee5f00'>管理</font>系统部"
	 *
	 * @return 检索摘要内容
	 */
	public String getSummaryContent() {
		return (String) get(SUMMARY_CONTENT);
	}
}
