package cnooc.qhse.file.pojo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

/**
 * 文件实体
 *
 * @author zhuqinyang
 */
@Data
@NoArgsConstructor
public class FileInfo {
	/**
	 * 存储空间名称
	 */
	@JsonProperty("bucketName")
	private String bucketName;

	/**
	 * 指定上传文件夹名称，以”/”分隔文件夹层级并以”/”结尾，为空表示在存储空间根路径
	 */
	@JsonProperty("folderName")
	private String folderName;

	@JsonProperty("multipartFile")
	private MultipartFile multipartFile;

	/**
	 * 文件提交人，为空默认为当前租户
	 */
	@JsonProperty("createUser")
	private String createUser;

	/**
	 * 添加文件标签，多标签以逗号分隔，可为空
	 */
	@JsonProperty("labelList")
	private String labelList;

	/**
	 * 是否提取智能标签，默认为 false：不提取，true：提取
	 */
	@JsonProperty("isNpl")
	private String isNpl;
}
