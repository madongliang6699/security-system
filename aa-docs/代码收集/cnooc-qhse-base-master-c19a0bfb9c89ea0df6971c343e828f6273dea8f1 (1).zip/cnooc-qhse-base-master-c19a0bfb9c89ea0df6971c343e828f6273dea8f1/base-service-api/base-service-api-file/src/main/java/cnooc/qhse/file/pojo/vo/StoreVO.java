package cnooc.qhse.file.pojo.vo;

import cnooc.qhse.file.pojo.entity.StoreEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serial;

/**
 * 附件存储表 视图实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class StoreVO extends StoreEntity {
	@Serial
	private static final long serialVersionUID = 1L;

}
