package cnooc.qhse.file.pojo.dto;

import cnooc.qhse.file.pojo.entity.FileInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @className: FileInfo
 * @author: zhuqinyang
 * @date: 2024/10/8 上午11:38
 * @Version: 1.0
 * @description:
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class FileInfoDTO extends FileInfo {

}
