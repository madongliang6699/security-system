package cnooc.qhse.file.pojo.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springblade.core.tenant.mp.TenantEntity;

/**
 * 附件存储表 实体类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@Data
@TableName("file_store")
@Schema(description = "Store对象")
@EqualsAndHashCode(callSuper = true)
public class StoreEntity extends TenantEntity {

	/**
	 * 业务主键
	 */
	@Schema(description = "业务主键")
	private String businessId;
	/**
	 * 业务类型
	 */
	@Schema(description = "业务类型")
	private String businessType;
	/**
	 * 管理云文件id
	 */
	@Schema(description = "管理云文件id")
	private String objectId;
	/**
	 * 文件大小
	 */
	@Schema(description = "文件大小")
	private Double fileSize;
	/**
	 * 文件名称
	 */
	@Schema(description = "文件名称")
	private String fileName;
	/**
	 * 源文件名称
	 */
	@Schema(description = "源文件名称")
	private String originalFileName;
	/**
	 * 文件扩展名
	 */
	@Schema(description = "文件扩展名")
	private String fileType;
	/**
	 * 存放管理云中的文件夹
	 */
	@Schema(description = "存放管理云中的文件夹")
	private String folderPath;

}
