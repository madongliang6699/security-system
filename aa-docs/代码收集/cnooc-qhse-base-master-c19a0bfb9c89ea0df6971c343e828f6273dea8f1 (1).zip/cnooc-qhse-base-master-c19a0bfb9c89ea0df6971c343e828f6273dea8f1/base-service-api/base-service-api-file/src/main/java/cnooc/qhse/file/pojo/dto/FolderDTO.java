package cnooc.qhse.file.pojo.dto;

import cnooc.qhse.file.pojo.entity.Folder;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 文件夹实体
 *
 * @className: Folder
 * @author: zhuqinyang
 * @date: 2024/10/8 上午11:33
 * @Version: 1.0
 * @description:
 */
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@Data
public class FolderDTO extends Folder {

	/**
	 * 存储空间名称
	 */
	@JsonProperty("bucketName")
	private String bucketName;
	/**
	 * 创建的文件夹名称，以"/"分隔文件夹层级并以"/"结尾，例如：在 a/b 文件夹之下创建文件夹 c，folderName 应为"a/b/c/"
	 */
	@JsonProperty("folderName")
	private String folderName;
}
