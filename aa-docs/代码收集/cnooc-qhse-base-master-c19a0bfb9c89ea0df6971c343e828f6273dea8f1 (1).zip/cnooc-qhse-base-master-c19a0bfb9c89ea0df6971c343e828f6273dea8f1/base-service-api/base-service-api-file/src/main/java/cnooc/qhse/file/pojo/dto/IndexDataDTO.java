package cnooc.qhse.file.pojo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * 索引数据实体
 *
 * @author zqy
 */
@Data
@NoArgsConstructor
public class IndexDataDTO {
	/**
	 * 索引名称
	 */
	private String indexName;
	/**
	 * 文档id
	 */
	private String id;
	/**
	 * 文档数据
	 */
	private Map<String, Object> data;
}
