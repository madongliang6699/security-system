package cnooc.qhse.file.pojo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 数据索引对象
 *
 * @author zqy
 */
@Data
@NoArgsConstructor
public class DataIndexDTO {
	/**
	 * 数据索引名称，ES 索引名称=租户代码+indexName
	 */
	private String indexName;
	/**
	 * 是否覆盖原索引标识，”true”为覆盖原索引，”false”为不覆盖原索引，若存在同名索引返回异常信息
	 */
	private String overwrite;
}
