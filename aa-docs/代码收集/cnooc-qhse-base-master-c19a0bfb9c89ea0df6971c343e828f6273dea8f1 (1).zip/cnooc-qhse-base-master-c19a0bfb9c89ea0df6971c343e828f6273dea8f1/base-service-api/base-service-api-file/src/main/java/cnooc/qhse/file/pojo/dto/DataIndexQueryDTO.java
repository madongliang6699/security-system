package cnooc.qhse.file.pojo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @className: DataIndexQueryDTO
 * @author: zhuqinyang
 * @date: 2024/10/8 下午3:33
 * @Version: 1.0
 * @description:
 */
@Data
@NoArgsConstructor
public class DataIndexQueryDTO {
	/**
	 * 数据索引名称
	 */
	@JsonProperty("indexName")
	private String indexName;
	/**
	 * 检索查询的关键字，以逗号分隔查询条件，此参数与Request Body 查询条件二选一，不可二者皆为空；二者皆不为空表示“与逻辑”条件关系
	 */
	@JsonProperty("keywords")
	private String keywords;
	/**
	 * 检索字段范围，以逗号分隔字段名，为空表示对所有字段检索
	 */
	@JsonProperty("searchFields")
	private String searchFields;
	/**
	 * 检索结果中包含的字段范围，以逗号分隔字段名，为空则仅返回 ES documentId 和检索摘要数据
	 */
	@JsonProperty("dataFields")
	private String dataFields;
	/**
	 * 对检索结果进行计分排序的字段，为空表示不进行计分排序
	 */
	@JsonProperty("rescoreField")
	private String rescoreField;
	/**
	 * 对检索结果进行计分排序的条件，为空表示不进行计分排序
	 */
	@JsonProperty("rescoreKeyword")
	private String rescoreKeyword;
}
