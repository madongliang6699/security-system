package cnooc.qhse.file.feign;

import cnooc.qhse.file.pojo.entity.StoreEntity;
import org.springblade.core.mp.support.BladePage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 附件存储表 Feign接口类
 *
 * @author zhuqinyang
 * @since 2024-10-15
 */
@FeignClient(
        value = "cnooc-qhse-file"
)
public interface IStoreClient {

    String API_PREFIX = "/feign/client/store";
    String TOP = API_PREFIX + "/top";

    /**
     * 获取附件存储表列表
     *
     * @param current 页号
     * @param size    页数
     * @return BladePage
     */
    @GetMapping(TOP)
    BladePage<StoreEntity> top(@RequestParam("current") Integer current, @RequestParam("size") Integer size);

}
