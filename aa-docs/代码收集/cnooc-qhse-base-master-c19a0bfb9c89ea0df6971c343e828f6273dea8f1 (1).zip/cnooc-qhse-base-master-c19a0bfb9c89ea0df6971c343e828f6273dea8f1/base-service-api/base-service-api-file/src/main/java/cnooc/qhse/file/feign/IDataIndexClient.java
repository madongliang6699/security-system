package cnooc.qhse.file.feign;

import cnooc.qhse.file.pojo.dto.*;
import cnooc.qhse.file.pojo.entity.DataIndex;
import org.springblade.core.tool.api.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 数据检索Feign
 *
 * @author zhuqinyang
 */
@FeignClient(
	value = "cnooc-qhse-file"
)
public interface IDataIndexClient {
	String API_PREFIX = "/fileStore";

	/**
	 * 创建索引
	 */
	String CREATE_DATA_INDEX = API_PREFIX + "/createDataIndex";
	/**
	 * 检索数据
	 */
	String SEARCH_DATA_INDEX = API_PREFIX + "/searchDataIndex";
	/**
	 * 向索引中添加数据 post
	 */
	String APPEND_INDEX_DATA = API_PREFIX + "/appendIndexData";
	/**
	 * 更新文档数据
	 */
	String UPDATE_INDEX_DATA = API_PREFIX + "/updateIndexData";
	/**
	 * 删除文档数据
	 */
	String DELETE_INDEX_DATA = API_PREFIX + "/deleteIndexData";
	/**
	 * 查询文档详细信息
	 */
	String QUERY_INDEX_DATA = API_PREFIX + "/queryIndexData";


	/**
	 * 用于业务系统创建指定的 ES 数据索引，可指定覆盖或不覆盖原索引，不覆盖则返回已存在同名索引异常
	 *
	 * @param dataIndexDTO 索引名称和是否重写
	 * @return 是否成功
	 */
	@PostMapping(CREATE_DATA_INDEX)
	R<String> createDataIndex(DataIndexDTO dataIndexDTO);

	/**
	 * 用于业务系统在指定数据索引中检索数据
	 *
	 * @param dataIndexQueryDTO    url查询条件
	 * @param dataIndexBodyDTOList 对应关键词与字段精确匹配的查询检索，多个 condition 为“与逻辑”条件关系
	 * @return 检索出来的数据
	 */
	@PostMapping(SEARCH_DATA_INDEX)
	R<List<DataIndexResponse>> searchDataIndex(@SpringQueryMap DataIndexQueryDTO dataIndexQueryDTO, @RequestBody List<DataIndexBodyDTO> dataIndexBodyDTOList);

	/**
	 * 用于业务系统向指定数据索引追加一条检索数据，对应一个新的 ES Document 记录
	 *
	 * @param indexDataDTO 数据实体
	 * @return 是否成功
	 */
	@PostMapping(APPEND_INDEX_DATA)
	R<String> appendIndexData(IndexDataDTO indexDataDTO);

	/**
	 * 用于业务系统向指定数据索引更新检索数据
	 *
	 * @param indexDataDTO 数据索引名称
	 * @return
	 */
	@PostMapping(UPDATE_INDEX_DATA)
	R<String> updateIndexData(IndexDataDTO indexDataDTO);

	/**
	 * 用于业务系统向指定数据索引删除检索数据
	 *
	 * @param indexDataDTO 要删除的索引信息，indexName、id
	 * @return 是否成功
	 */
	@PostMapping(DELETE_INDEX_DATA)
	R<String> deleteIndexData(IndexDataDTO indexDataDTO);

	/**
	 * 用于业务系统在指定数据索引中查询某 document 的详细信息
	 *
	 * @param indexDataDTO 要查询的索引信息，indexName、id
	 * @return JSON格式数据
	 */
	@GetMapping(QUERY_INDEX_DATA)
	R<DataIndex> queryIndexData(@SpringQueryMap IndexDataDTO indexDataDTO);
}
