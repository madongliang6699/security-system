package cnooc.qhse.file.feign;

import cnooc.qhse.file.pojo.dto.DeleteFileDTO;
import cnooc.qhse.file.pojo.dto.DownloadDTO;
import cnooc.qhse.file.pojo.dto.FolderDTO;
import org.apache.ibatis.annotations.Param;
import org.springblade.core.tool.api.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.cloud.openfeign.SpringQueryMap;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 文件服务接口Feign
 *
 * @author zhuqinyang
 */
@FeignClient(
	value = "cnooc-qhse-file"
)
public interface IFileStoreClient {

	String API_PREFIX = "/dataIndex";
	/**
	 * 新增文件夹
	 */
	String CREATE_FOLDER = API_PREFIX + "/createFolder";
	/**
	 * 获取子文件夹
	 */
	String GET_FOLDERS = API_PREFIX + "/getFolders";
	/**
	 * 上传文件
	 */
	String UPLOAD_FILE = API_PREFIX + "/uploadFile";
	/**
	 * 下载文件
	 */
	String DOWNLOAD_FILE = API_PREFIX + "/downloadFile";
	/**
	 * 删除文件
	 */
	String DELETE_FILE = API_PREFIX + "/deleteFile";

	/**
	 * 用于业务系统在指定存储空间创建文件夹
	 *
	 * @param folder 文件夹信息
	 * @return 是否创建成功
	 */
	@PostMapping(CREATE_FOLDER)
	R<String> createFolder(@RequestBody FolderDTO folder);

	/**
	 * 用于业务系统获取指定存储空间中的文件夹清单
	 *
	 * @param folder 查询实体
	 * @return 指定父文件夹之下的全部文件夹（不含下级）
	 */
	@GetMapping(GET_FOLDERS)
	R<List<String>> getFolders(@SpringQueryMap FolderDTO folder);

	/**
	 * 用于业务系统向指定文件夹上传文件。
	 *
	 * @param file       文件
	 * @param bucketName 存储空间名称
	 * @param folderName 文件夹名称
	 * @return 文件唯一标识
	 */
	@PostMapping(value = UPLOAD_FILE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	R<String> uploadFile(@RequestPart("file") @Param("file") MultipartFile file,
						 @RequestPart("bucketName") @Param("bucketName") String bucketName,
						 @RequestPart("folderName") @Param("folderName") String folderName);

	/**
	 * 用于业务系统下载指定文件或指定文件版本
	 *
	 * @param downloadDTO 下载文件实体
	 * @return 返回文件字节
	 */
	@GetMapping(value = DOWNLOAD_FILE, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	ResponseEntity<byte[]> downloadFile(@SpringQueryMap DownloadDTO downloadDTO);

	/**
	 * 用于业务系统删除指定文件或指定文件版本
	 *
	 * @param deleteFileDTO 删除文件实体
	 * @return 删除结果提示
	 */
	@PostMapping(DELETE_FILE)
	R<String> deleteFile(DeleteFileDTO deleteFileDTO);
}
