package cnooc.qhse.file.pojo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 存储空间实体
 *
 * @author zhuqinyang
 */
@NoArgsConstructor
@Data
public class Bucket {

	/**
	 * 存储空间名称
	 */
	@JsonProperty("bucketName")
	private String bucketName;
	/**
	 * 存储空间容量,单位为 GB
	 */
	@JsonProperty("storageCapacity")
	private Integer storageCapacity;
	/**
	 * 存储空间是否加密
	 */
	@JsonProperty("isEncrypt")
	private Boolean isEncrypt;
	/**
	 * 存储空间状态，readWrite：读写状态；readOnly：为只读状态；disabled：为停用状态
	 */
	@JsonProperty("status")
	private String status;

	/**
	 * 存储空间已使用量，单位为 GB
	 */
	@JsonProperty("occupied")
	private Long occupied;


}
