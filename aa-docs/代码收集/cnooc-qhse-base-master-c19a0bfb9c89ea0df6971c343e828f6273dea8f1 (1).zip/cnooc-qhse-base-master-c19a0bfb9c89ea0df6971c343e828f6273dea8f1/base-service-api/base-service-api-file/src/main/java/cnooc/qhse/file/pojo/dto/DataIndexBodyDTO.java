package cnooc.qhse.file.pojo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @className: DataIndexBodyDTO
 * @author: zhuqinyang
 * @date: 2024/10/8 下午3:41
 * @Version: 1.0
 * @description:
 */
@NoArgsConstructor
@Data
public class DataIndexBodyDTO {
	/**
	 * 检索查询的关键字，以逗号分隔查询条件，不可为空
	 */
	@JsonProperty("keywords")
	private String keywords;

	/**
	 * 检索字段范围，以逗号分隔字段名，不可为空
	 */
	@JsonProperty("searchFields")
	private String searchFields;
}
