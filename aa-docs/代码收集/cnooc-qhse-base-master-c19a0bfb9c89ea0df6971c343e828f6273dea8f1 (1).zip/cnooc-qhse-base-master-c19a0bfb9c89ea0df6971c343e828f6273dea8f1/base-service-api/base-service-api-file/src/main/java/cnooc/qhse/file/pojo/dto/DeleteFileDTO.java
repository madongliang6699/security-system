package cnooc.qhse.file.pojo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 删除文件参数
 *
 * @author zhuqinyang
 */
@Data
@NoArgsConstructor
public class DeleteFileDTO {
	/**
	 * 存储空间名称
	 */
	@JsonProperty("bucketName")
	private String bucketName;

	/**
	 * 指定文件夹名称，以”/”分隔文件夹层级并以”/”结尾，为空表示在存储空间根路径
	 */
	@JsonProperty("folderName")
	private String folderName;

	/**
	 * 指定文件的 objectId
	 */
	@JsonProperty("objectId")
	private String objectId;

	/**
	 * 批量删除传文件 objectId 数组，objectId 与 objectIdList 参数二选一使用
	 */
	@JsonProperty("objectIdList")
	private List<String> objectIdList;

	/**
	 * 指定文件时间版本，为空表示最新文件版本
	 */
	@JsonProperty("versionTime")
	private String versionTime;

	/**
	 * 是否删除全部版本，true：是，默认 false：否
	 */
	@JsonProperty("deleteAll")
	private Boolean deleteAll;
}
