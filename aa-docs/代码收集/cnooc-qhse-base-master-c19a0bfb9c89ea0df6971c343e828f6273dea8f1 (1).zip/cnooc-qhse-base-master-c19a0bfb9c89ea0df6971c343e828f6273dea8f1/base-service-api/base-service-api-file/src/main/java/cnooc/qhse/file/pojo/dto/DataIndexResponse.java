package cnooc.qhse.file.pojo.dto;

import cnooc.qhse.file.pojo.entity.DataIndex;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 数据检索实体
 *
 * @author zqy
 */
@NoArgsConstructor
@Data
public class DataIndexResponse {

	/**
	 * documentId
	 */
	@JsonProperty("documentId")
	private String documentId;
	/**
	 * 文档数据
	 */
	@JsonProperty("indexData")
	private DataIndex indexData;
	/**
	 * 索引名称
	 */
	@JsonProperty("indexName")
	private String indexName;
	/**
	 * 内容摘要
	 */
	@JsonProperty("summaryContents")
	private List<String> summaryContents;
	/**
	 * 总大小
	 */
	@JsonProperty("totalSize")
	private String totalSize;
}
