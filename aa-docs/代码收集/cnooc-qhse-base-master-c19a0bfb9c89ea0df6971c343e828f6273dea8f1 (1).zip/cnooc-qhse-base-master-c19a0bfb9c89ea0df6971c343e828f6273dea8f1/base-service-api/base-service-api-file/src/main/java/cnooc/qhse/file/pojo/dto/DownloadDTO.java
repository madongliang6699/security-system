package cnooc.qhse.file.pojo.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文件下载
 *
 * @className: 文件下载查询实体
 * @author: zhuqinyang
 * @date: 2024/10/8 下午1:10
 * @Version: 1.0
 * @description:
 */
@Data
@NoArgsConstructor
public class DownloadDTO {

	/**
	 * 存储空间名称
	 */
	@JsonProperty("bucketName")
	private String bucketName;

	/**
	 * 指定文件夹名称，以”/”分隔文件夹层级并以”/”结尾，为空表示在存储空间根路径
	 */
	@JsonProperty("folderName")
	private String folderName;

	/**
	 * 指定文件的 objectId
	 */
	@JsonProperty("objectId")
	private String objectId;

	/**
	 * 指定文件时间版本，为空表示最新版本
	 */
	@JsonProperty("versionTime")
	private String versionTime;

	/**
	 * 文件分享码，若不为空则验证其是否存在、是否在有效期内。支持分享链接后通过浏览器直接下载
	 */
	@JsonProperty("shareCode")
	private String shareCode;
}
