package cnooc.qhse.mongo.util

import cnooc.qhse.common.utils.toMap
import org.springblade.core.tool.support.Kv
import org.springblade.core.tool.utils.DateUtil
import org.springblade.core.tool.utils.Func
import org.springblade.core.tool.utils.StringUtil
import org.springframework.data.domain.Sort
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query

object MongoCondition {
    private const val EQUAL = "_equal"
    private const val NOT_EQUAL = "_notequal"
    private const val LIKE = "_like"
    private const val LIKE_LEFT = "_likeleft"
    private const val LIKE_RIGHT = "_likeright"
    private const val NOT_LIKE = "_notlike"
    private const val GE = "_ge"
    private const val LE = "_le"
    private const val GT = "_gt"
    private const val LT = "_lt"
    private const val DATE_GE = "_datege"
    private const val DATE_GT = "_dategt"
    private const val DATE_EQUAL = "_dateequal"
    private const val DATE_LT = "_datelt"
    private const val DATE_LE = "_datele"
    private const val IS_NULL = "_null"
    private const val NOT_NULL = "_notnull"
    private const val IGNORE = "_ignore"
    private const val IN = "_in"

    /**
     * Mongodb 条件构造器
     *
     * @param
     */
    fun buildQuery(map: Map<String, Any?>): Query {
        // 排除其他非业务字段
        val exclude = Kv.create().set("Blade-Auth", "Blade-Auth").set("current", "current").set("size", "size")
            .set("ascs", "ascs").set("descs", "descs")
        val newMap = mutableMapOf<String, Any?>()
        map.forEach { (k, v) ->
            if (Func.isNotEmpty(v) && !exclude.containsKey(k)) {
                newMap[k] = v
            }
        }
        val query = Query()
        if (Func.isEmpty(newMap)) {
            return query
        }
        // 创建一个映射来存储字段与它们的Criteria的关系
        val criteriaMap = HashMap<String, Criteria>()
        newMap.forEach { (k: String, v: Any?) ->
            if (Func.hasEmpty(k, v) || k.endsWith(IGNORE)) {
                return@forEach
            }
            // 获取基本字段名称，无视任何可能的后缀
            val fieldName = k.substringBeforeLast("_")
            // 逐个检查条件并把它们添加到map中
            val criteria = criteriaMap.getOrPut(fieldName) { Criteria.where(fieldName) }
            when {
                k.endsWith(EQUAL) -> criteria.`is`(v)
                k.endsWith(NOT_EQUAL) -> criteria.ne(v)
                k.endsWith(LIKE_LEFT) -> criteria.regex("^$v")
                k.endsWith(LIKE_RIGHT) -> criteria.regex("$v$")
                k.endsWith(NOT_LIKE) -> criteria.not().regex(v.toString())
                k.endsWith(GE) -> criteria.gte(v as Comparable<*>)
                k.endsWith(LE) -> criteria.lte(v as Comparable<*>)
                k.endsWith(GT) -> criteria.gt(v as Comparable<*>)
                k.endsWith(LT) -> criteria.lt(v as Comparable<*>)
                k.endsWith(DATE_GE) -> criteria.gte(DateUtil.parse(v.toString(), DateUtil.PATTERN_DATETIME))
                k.endsWith(DATE_GT) -> criteria.gt(DateUtil.parse(v.toString(), DateUtil.PATTERN_DATETIME))
                k.endsWith(DATE_EQUAL) -> criteria.`is`(DateUtil.parse(v.toString(), DateUtil.PATTERN_DATETIME))
                k.endsWith(DATE_LE) -> criteria.lte(DateUtil.parse(v.toString(), DateUtil.PATTERN_DATETIME))
                k.endsWith(DATE_LT) -> criteria.lt(DateUtil.parse(v.toString(), DateUtil.PATTERN_DATETIME))
                k.endsWith(IS_NULL) -> criteria.isNull()
                k.endsWith(NOT_NULL) -> criteria.not().isNull()
                k.endsWith(IN) -> criteria.`in`(Func.toStrList(v.toString()))
                else -> criteria.regex(v.toString())
            }
        }
        // 添加所有的Criteria到Query对象
        criteriaMap.values.forEach { query.addCriteria(it) }
        return query
    }

    /**
     * 获取数据库字段
     *
     * @param column  字段名
     * @param keyword 关键字
     * @return
     */
    private fun getColumn(column: String, keyword: String): String {
        return StringUtil.removeSuffix(column, keyword)
    }

    fun <T> buildQuery(entity: T): Query {
        return buildQuery(entity!!.toMap())
    }

    fun Query.withMPQuery(query: org.springblade.core.mp.support.Query) {
        if (!query.ascs.isNullOrBlank()) {
            this.with(Sort.by(Func.toStrList(query.ascs).map { Sort.Order.asc(it) }))
        }
        if (!query.descs.isNullOrBlank()) {
            this.with(Sort.by(Func.toStrList(query.descs).map { Sort.Order.desc(it) }))
        }
    }
}
