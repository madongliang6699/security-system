package cnooc.qhse.mongo.entity

import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonIgnore
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.core.tool.utils.DateUtil
import org.springframework.data.annotation.Id
import org.springframework.format.annotation.DateTimeFormat
import java.io.Serializable
import java.time.LocalDateTime

/**
 * 基础实体类
 *
 * @author Chill
 */
abstract class MongoBaseEntity(
    /**
     * 主键id
     */
    @field:JsonSerialize(using = ToStringSerializer::class) @Schema(description = "主键id") @Id open var id: String? = null,

    /**
     * 创建人
     */
    @field:JsonSerialize(using = ToStringSerializer::class) @Schema(description = "创建人") open var createUser: Long? = null,

    /**
     * 创建部门
     */
    @field:JsonSerialize(using = ToStringSerializer::class) @Schema(description = "创建部门") open var createDept: Long? = null,

    /**
     * 创建时间
     */
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME) @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME) @Schema(
        description = "创建时间"
    ) open var createTime: LocalDateTime? = null,

    /**
     * 更新人
     */
    @field:JsonSerialize(using = ToStringSerializer::class) @Schema(description = "更新人") open var updateUser: Long? = null,

    /**
     * 更新时间
     */
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME) @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME) @Schema(
        description = "更新时间"
    ) open var updateTime: LocalDateTime? = null,

    /**
     * 状态[1:正常]
     */
    @Schema(description = "业务状态") open var status: Int? = null,

    /**
     * 状态[0:未删除,1:删除]
     */
    @Schema(description = "是否已删除") @field:JsonProperty("isDeleted") open var isDeleted: Long? = null
) : Serializable {
    @JsonIgnore
    fun getIsDeleted(): Long? {
        return isDeleted
    }

    @JsonIgnore
    fun setIsDeleted(isDeleted: Long?) {
        this.isDeleted = isDeleted
    }

    companion object {
        private const val serialVersionUID = -6813022614675919347L
    }
}
