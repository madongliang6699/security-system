package cnooc.qhse.mongo.service

import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.core.toolkit.Wrappers
import com.mongodb.client.result.UpdateResult
import org.springframework.data.domain.Pageable
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Query

/**
 * 基础业务接口
 */
interface MongoBaseService<T> {
    fun getTemplate(): MongoTemplate
    fun getEntityClass(): Class<*>

    /**
     * 保存
     * @param entity 实体对象
     */
    fun save(entity: T): T

    /**
     * 批量保存
     * @param entityList 实体对象集合
     */
    fun saveBatch(entityList: Collection<T>): MutableCollection<T>

    /**
     * 批量保存或更新
     * @param entityList 实体对象集合
     */
    fun saveOrUpdateBatch(entityList: Collection<T>): Boolean

    /**
     * 根据 ID 彻底删除数据（非逻辑删除）
     * @param id 主键ID
     */
    fun removeById(id: String): Boolean

    /**
     * 根据 columnMap 条件，删除记录(非逻辑删除)
     * @param columnMap 表字段 map 对象
     */
    fun removeByMap(columnMap: Map<String, Any>): Boolean

    /**
     * 根据 query 条件，删除记录(非逻辑删除)
     * @param query 条件
     */
    fun remove(query: Query): Boolean

    /**
     * 删除（根据ID 批量删除）
     *
     * @param ids 主键ID或实体列表
     */
    fun removeByIds(ids: Collection<String>): Boolean

    /**
     * 根据 ID 选择修改
     *
     * @param entity 实体对象
     */
    fun updateById(entity: T): T

    /**
     * 根据 query 条件，更新记录
     *
     * @param entity        实体对象
     * @param query 条件
     */
    fun update(entity: T, query: Query): Boolean

    /**
     * 根据ID 批量更新
     *
     * @param entityList 实体对象集合
     */
    fun updateBatchById(entityList: Collection<T>): Boolean

    /**
     * TableId 注解存在更新记录，否插入一条记录
     *
     * @param entity 实体对象
     */
    fun saveOrUpdate(entity: T): Boolean

    /**
     * 根据 ID 查询，包含已删除数据
     *
     * @param id 主键ID
     */
    fun getById(id: String): T?

    /**
     * 查询（根据ID 批量查询），包含已删除数据
     *
     * @param ids 主键ID列表
     */
    fun listByIds(ids: Collection<String>): List<T>

    /**
     * 查询（根据 columnMap 条件）
     *
     * @param columnMap 表字段 map 对象
     * @param includeDeleted 是否包含已删除数据
     */
    fun listByMap(columnMap: Map<String, Any?>, includeDeleted: Boolean = false): List<T>

    /**
     * 根据 query，查询一条记录 <br></br>
     *
     * @param query 条件
     * @param includeDeleted 是否包含已删除数据
     */
    fun getOne(query: Query, includeDeleted: Boolean = false): T?

    /**
     * 根据实体条件查询一条记录
     * @param entity 实体对象
     * @param includeDeleted 是否包含已删除数据
     */
    fun getOne(entity: T, includeDeleted: Boolean = false): T?

    /**
     * 查询指定条件是否存在数据
     *
     * @see Wrappers.emptyWrapper
     * @param query 条件
     * @param includeDeleted 是否包含已删除数据
     */
    fun exists(query: Query, includeDeleted: Boolean = false): Boolean

    /**
     * 查询总记录数
     *
     * @param includeDeleted 是否包含已删除数据
     */
    fun count(includeDeleted: Boolean = false): Long

    /**
     * 根据 query 条件，查询总记录数
     *
     */
    fun count(query: Query, includeDeleted: Boolean = false): Long

    /**
     * 查询列表
     */
    fun list(query: Query, includeDeleted: Boolean = false): List<T>

    /**
     * 查询列表
     */
    fun list(query: Query, pageable: Pageable, includeDeleted: Boolean = false): List<T>

    /**
     * 查询所有
     *
     */
    fun list(includeDeleted: Boolean = false): List<T>

    /**
     * 分页查询单表数据
     *
     * @param pageable 分页条件
     * @return 列表数据
     */
    fun list(pageable: Pageable, includeDeleted: Boolean = false): List<T>

    /**
     * 翻页查询
     *
     * @param query 条件
     * @param pageable         翻页对象
     */
    fun page(query: Query, pageable: Pageable, includeDeleted: Boolean = false): IPage<T>

    /**
     * 无条件翻页查询
     *
     * @param pageable 翻页对象
     */
    fun page(pageable: Pageable, includeDeleted: Boolean = false): IPage<T>

    /**
     * 逻辑删除
     *
     * @param ids id集合
     * @return
     */
    fun deleteLogic(ids: List<String>): UpdateResult

    /**
     * 修改状态
     * @param ids id集合
     * @param status 状态
     */
    fun changeStatus(ids: List<String>, status: Int): UpdateResult
}
