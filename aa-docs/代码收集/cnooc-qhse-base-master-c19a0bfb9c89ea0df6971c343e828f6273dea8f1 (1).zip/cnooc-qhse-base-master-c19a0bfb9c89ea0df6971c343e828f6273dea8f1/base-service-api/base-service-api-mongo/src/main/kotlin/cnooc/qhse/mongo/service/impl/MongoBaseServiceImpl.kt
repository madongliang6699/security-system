package cnooc.qhse.mongo.service.impl


import cnooc.qhse.mongo.entity.MongoBaseEntity
import cnooc.qhse.mongo.entity.MongoTenantEntity
import cnooc.qhse.mongo.service.MongoBaseService
import cnooc.qhse.mongo.util.MongoCondition
import com.baomidou.mybatisplus.core.metadata.IPage
import com.baomidou.mybatisplus.core.toolkit.reflect.GenericTypeUtils
import com.baomidou.mybatisplus.extension.plugins.pagination.Page
import com.mongodb.client.result.UpdateResult
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.Func
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Pageable
import org.springframework.data.mongodb.core.BulkOperations
import org.springframework.data.mongodb.core.MongoTemplate
import org.springframework.data.mongodb.core.query.Criteria
import org.springframework.data.mongodb.core.query.Query
import org.springframework.data.mongodb.core.query.Update
import org.springframework.stereotype.Service
import org.springframework.transaction.annotation.Transactional
import java.time.LocalDateTime

@Service
class MongoBaseServiceImpl<T : MongoBaseEntity> : MongoBaseService<T> {
    @Autowired
    protected val mongoTemplate: MongoTemplate? = null

    protected val typeArguments: Array<Class<*>>? =
        GenericTypeUtils.resolveTypeArguments(javaClass, MongoBaseServiceImpl::class.java)

    override fun getEntityClass(): Class<T> {
        return typeArguments!![0] as Class<T>
    }

    override fun getTemplate(): MongoTemplate {
        return mongoTemplate!!
    }

    override fun save(entity: T): T {
        resolveEntity(entity)
        return getTemplate().insert(entity)
    }

    override fun saveBatch(entityList: Collection<T>): MutableCollection<T> {
        entityList.forEach { resolveEntity(it) }
        return getTemplate().insertAll(entityList)
    }

    override fun saveOrUpdateBatch(entityList: Collection<T>): Boolean {
        entityList.forEach { resolveEntity(it) }
        val bulkOperations = getTemplate().bulkOps(BulkOperations.BulkMode.UNORDERED, getEntityClass())

        entityList.forEach {
            if (it.id == null) {
                bulkOperations.insert(it)
            } else {
                val query = Query(Criteria.where(MongoTenantEntity::id.name).`is`(it.id))
                bulkOperations.replaceOne(query, it)
            }
        }
        bulkOperations.execute()
        return true
    }

    override fun removeById(id: String): Boolean {
        return getTemplate().remove(
            Query(Criteria.where(MongoTenantEntity::id.name).`is`(id)),
            getEntityClass()
        ).deletedCount > 0
    }

    override fun removeByMap(columnMap: Map<String, Any>): Boolean {
        val query = Query()
        columnMap.forEach { (k, v) ->

            query.addCriteria(Criteria.where(k).`is`(v))
        }
        return getTemplate().remove(query, getEntityClass()).deletedCount > 0
    }

    override fun remove(query: Query): Boolean {
        return getTemplate().remove(query, getEntityClass()).deletedCount > 0
    }

    override fun removeByIds(ids: Collection<String>): Boolean {
        return getTemplate().remove(
            Query(Criteria.where(MongoTenantEntity::id.name).`in`(ids)),
            getEntityClass()
        ).deletedCount > 0
    }

    override fun update(entity: T, query: Query): Boolean {
        TODO("Not yet implemented")
    }

    override fun updateById(entity: T): T {
        resolveEntity(entity)
        return getTemplate().save(entity)
    }

    override fun updateBatchById(entityList: Collection<T>): Boolean {
        entityList.forEach { resolveEntity(it) }
        val bulkOperations = getTemplate().bulkOps(BulkOperations.BulkMode.UNORDERED, getEntityClass())
        entityList.forEach {
            val query = Query(Criteria.where(MongoTenantEntity::id.name).`is`(it.id))
            bulkOperations.replaceOne(query, it)
        }
        bulkOperations.execute()
        return true
    }

    override fun saveOrUpdate(entity: T): Boolean {
        return if (entity.id == null) save(entity) != null else updateById(entity) != null
    }

    override fun getById(id: String): T? {
        return getTemplate().findById(id, getEntityClass())
    }

    override fun listByIds(ids: Collection<String>): List<T> {
        return getTemplate().find(Query(Criteria.where(MongoTenantEntity::id.name).`in`(ids)), getEntityClass())
    }

    override fun listByMap(columnMap: Map<String, Any?>, includeDeleted: Boolean): List<T> {
        val query = Query().withTenantId()
        columnMap.forEach { (k, v) ->
            query.addCriteria(Criteria.where(k).`is`(v))
        }
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().find(query, getEntityClass())
    }

    override fun getOne(query: Query, includeDeleted: Boolean): T? {
        query.withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().findOne(query, getEntityClass())
    }

    override fun getOne(entity: T, includeDeleted: Boolean): T? {
        val q = MongoCondition.buildQuery(entity).withTenantId()
        if (!includeDeleted) {
            q.noDeteled()
        }
        return getTemplate().findOne(q, getEntityClass())
    }

    override fun exists(query: Query, includeDeleted: Boolean): Boolean {
        query.withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().exists(query, getEntityClass())
    }

    override fun count(includeDeleted: Boolean): Long {
        val q = Query().withTenantId()
        if (!includeDeleted) {
            q.noDeteled()
        }
        return getTemplate().count(q, getEntityClass())
    }

    override fun count(query: Query, includeDeleted: Boolean): Long {
        query.withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().count(query, getEntityClass())
    }

    override fun list(includeDeleted: Boolean): List<T> {
        val query = Query().withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
            return getTemplate().find(query, getEntityClass())
        }
        return getTemplate().find(query, getEntityClass())
    }

    override fun list(pageable: Pageable, includeDeleted: Boolean): List<T> {
        val query = Query().withTenantId().with(pageable)
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().find(query, getEntityClass())
    }

    override fun list(query: Query, includeDeleted: Boolean): List<T> {
        query.withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().find(query, getEntityClass())
    }

    override fun list(query: Query, pageable: Pageable, includeDeleted: Boolean): List<T> {
        query.with(pageable).withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        return getTemplate().find(query, getEntityClass())
    }

    override fun page(query: Query, pageable: Pageable, includeDeleted: Boolean): IPage<T> {
        query.withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        val total: Long = getTemplate().count(query, getEntityClass())
        query.with(pageable)
        val list = getTemplate().find(query, getEntityClass())
        val page: IPage<T> = Page(pageable.pageNumber.toLong(), pageable.pageSize.toLong(), total)
        page.records = list
        return page
    }

    override fun page(pageable: Pageable, includeDeleted: Boolean): IPage<T> {
        val query = Query().with(pageable).withTenantId()
        if (!includeDeleted) {
            query.noDeteled()
        }
        val total: Long = getTemplate().count(query, getEntityClass())
        val list = getTemplate().find(query, getEntityClass())
        val page: IPage<T> = Page(pageable.pageNumber.toLong(), pageable.pageSize.toLong(), total)
        page.records = list
        return page
    }

    override fun changeStatus(ids: List<String>, status: Int): UpdateResult {
        val user = AuthUtil.getUser()
        val query = Query(Criteria.where(MongoTenantEntity::id.name).`in`(ids))
        val update = Update()
        update.set(MongoTenantEntity::updateUser.name, user.userId)
            .set(MongoTenantEntity::updateTime.name, LocalDateTime.now())
            .set(MongoTenantEntity::status.name, status)
        return getTemplate().updateMulti(query, update, getEntityClass())
    }


    @Transactional(rollbackFor = [Exception::class])
    override fun deleteLogic(ids: List<String>): UpdateResult {
        val user = AuthUtil.getUser()
        val query = Query(Criteria.where(MongoTenantEntity::id.name).`in`(ids))
        val update = Update()
        update.set(MongoTenantEntity::updateUser.name, user.userId)
            .set(MongoTenantEntity::updateTime.name, LocalDateTime.now())
            .set(MongoTenantEntity::isDeleted.name, System.currentTimeMillis())
        return getTemplate().updateMulti(query, update, getEntityClass())
    }

    private fun resolveEntity(entity: T) {
        val user = AuthUtil.getUser()
        val now = LocalDateTime.now()
        if (entity.id == null) {
            // 处理新增逻辑
            user?.let {
                if (entity.createUser == null) {
                    entity.createUser = user.userId
                }
                if (entity.createDept == null) {
                    entity.createDept = Func.firstLong(user.deptId)
                }
                entity.updateUser = user.userId
            }
            if (entity.status == null) {
                // 默认状态为0
                entity.status = 0
            }
            entity.createTime = now
        } else if (user != null) {
            // 处理修改逻辑
            entity.updateUser = user.userId
        }
        // 处理通用逻辑
        entity.updateTime = now
        entity.isDeleted = BladeConstant.DB_NOT_DELETED.toLong()
        // 处理多租户逻辑，若字段值为空，则不进行操作
        if (entity is MongoTenantEntity && entity.tenantId.isNullOrBlank()) {
            entity.tenantId = AuthUtil.getTenantId()
        }
    }
}

fun Query.noDeteled(): Query {
    this.addCriteria(Criteria.where(MongoTenantEntity::isDeleted.name).`is`(BladeConstant.DB_NOT_DELETED))
    return this
}

fun Query.withTenantId(): Query {
    this.addCriteria(
        Criteria.where(MongoTenantEntity::tenantId.name)
            .`is`(Func.toStr(AuthUtil.getTenantId(), BladeConstant.ADMIN_TENANT_ID))
    )
    return this
}
