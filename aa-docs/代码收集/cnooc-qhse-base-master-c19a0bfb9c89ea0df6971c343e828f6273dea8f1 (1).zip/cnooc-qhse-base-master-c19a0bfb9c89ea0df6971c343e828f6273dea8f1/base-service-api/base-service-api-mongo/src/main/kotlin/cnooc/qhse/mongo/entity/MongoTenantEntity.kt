package cnooc.qhse.mongo.entity

import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

abstract class MongoTenantEntity(
    id: String? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Long? = null,
    @Schema(description = "租户ID") open var tenantId: String? = null,
) : MongoBaseEntity(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted)
