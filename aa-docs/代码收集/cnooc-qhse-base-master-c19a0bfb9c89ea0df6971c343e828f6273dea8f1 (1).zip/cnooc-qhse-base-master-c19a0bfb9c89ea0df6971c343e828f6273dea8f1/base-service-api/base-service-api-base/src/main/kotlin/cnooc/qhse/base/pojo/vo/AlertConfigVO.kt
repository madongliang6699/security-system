package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.AlertConfig
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 报警配置表视图实体类
 */
@Schema(description = "报警配置表")
open class AlertConfigVO(
    alertCategory: String? = null,
    level1AlertTime: Int? = null,
    level1UserGroup: String? = null,
    level1SendEmail: Boolean? = null,
    level1NoAlertTime: Int? = null,
    level2AlertTime: Int? = null,
    level2UserGroup: String? = null,
    level2SendEmail: Boolean? = null,
    level2NoAlertTime: Int? = null,
    level3AlertTime: Int? = null,
    level3UserGroup: String? = null,
    level3SendEmail: Boolean? = null,
    level3NoAlertTime: Int? = null,
    level4AlertTime: Int? = null,
    level4UserGroup: String? = null,
    level4SendEmail: Boolean? = null,
    level4NoAlertTime: Int? = null,
    level5AlertTime: Int? = null,
    level5UserGroup: String? = null,
    level5SendEmail: Boolean? = null,
    level5NoAlertTime: Int? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    @Schema(description = "一级用户组名称")
    var level1UserGroupName: String? = null,
    @Schema(description = "二级用户组名称")
    var level2UserGroupName: String? = null,
    @Schema(description = "三级用户组名称")
    var level3UserGroupName: String? = null,
    @Schema(description = "四级用户组名称")
    var level4UserGroupName: String? = null,
    @Schema(description = "五级用户组名称")
    var level5UserGroupName: String? = null,
) : AlertConfig(
    alertCategory,
    level1AlertTime,
    level1UserGroup,
    level1SendEmail,
    level1NoAlertTime,
    level2AlertTime,
    level2UserGroup,
    level2SendEmail,
    level2NoAlertTime,
    level3AlertTime,
    level3UserGroup,
    level3SendEmail,
    level3NoAlertTime,
    level4AlertTime,
    level4UserGroup,
    level4SendEmail,
    level4NoAlertTime,
    level5AlertTime,
    level5UserGroup,
    level5SendEmail,
    level5NoAlertTime,
    remark,
    id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
