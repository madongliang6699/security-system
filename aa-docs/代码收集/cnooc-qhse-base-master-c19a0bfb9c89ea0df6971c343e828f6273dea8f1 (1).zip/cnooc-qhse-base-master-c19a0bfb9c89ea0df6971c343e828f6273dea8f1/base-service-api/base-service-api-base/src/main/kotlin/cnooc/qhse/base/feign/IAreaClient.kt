package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam

/**
 * 区域接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface IAreaClient {
    companion object {
        const val API_PREFIX = "/feign/client/area"
        const val AREA_BY_ID = "$API_PREFIX/{id}"
        const val AREA_BY_CODE = "$API_PREFIX/area-by-code"
        const val AREA_PATH_NAME_BY_ID = "$API_PREFIX/path-name/{id}"
        const val AREA_TREE = "$API_PREFIX/tree/{tenantId}"
        const val AREA_USER_IDS = "$API_PREFIX/user-ids/{id}"
        const val AREA_USER_IDS_BY_CODE = "$API_PREFIX/area-users-by-code"
        const val AREAS_BY_USER_ID = "$API_PREFIX/areas-by-user-id"
        const val AREAS_WITH_LAST_LEVEL = "$API_PREFIX/areas-with_last_level"
        const val AREA_BY_CODE_OR_NAME = "$API_PREFIX/area-by-code-or-name"
        const val AREAS_BY_PARENT_ID = "$API_PREFIX/areas-by-parent-id"
    }

    /**
     * 获取区域树
     */
    @GetMapping(AREA_TREE)
    fun tree(@PathVariable tenantId: String): R<List<AreaVO>>

    /**
     * 根据id查询区域下的用户id
     */
    @GetMapping(AREA_USER_IDS)
    fun getUserIdsByAreaId(@PathVariable id: Long): R<List<Long>>

    /**
     * 根据用户id查询区域
     */
    @GetMapping(AREAS_BY_USER_ID)
    fun getAreasByUserId(
        @RequestParam("userId") userId: Long
    ): R<List<AreaEntity>>

    /**
     * 根据code查询区域
     */
    @GetMapping(AREA_BY_CODE)
    fun getAreaByCode(@RequestParam("code") code: String, @RequestParam("tenantId") tenantId: String): R<AreaEntity?>

    /**
     * 根据id查询区域
     */
    @GetMapping(AREA_BY_ID)
    fun getAreaById(@PathVariable id: Long): R<AreaEntity?>

    /**
     * 根据code查询区域下的用户id
     */
    @GetMapping(AREA_USER_IDS_BY_CODE)
    fun getUserIdsByAreaCode(@RequestParam("code") code: String, @RequestParam("tenantId") tenantId: String): R<List<Long>>

    /**
     * 根据id查询区域路径名称
     */
    @GetMapping(AREA_PATH_NAME_BY_ID)
    fun getAreaPathNameById(@PathVariable id: Long): R<String>

    /**
     * 获取最后一级的区域列表
     * @param tenantId 租户
     * @return 最后一级的区域列表
     */
    @GetMapping(AREAS_WITH_LAST_LEVEL)
    fun getLastLevelAreas(@RequestParam tenantId: String): R<List<AreaVO>>

    /**
     * 根据code或者name查询区域
     * @param areaCodeOrName 区域编码或者名称
     * @param tenantId 租户
     * @return 区域
     */
    @GetMapping(AREA_BY_CODE_OR_NAME)
    fun getAreasByCodeOrName(@RequestParam areaCodeOrName: String, @RequestParam tenantId: String): R<List<AreaEntity>>

    /**
     * 根据父id查询子区域
     * @param parentId 父id
     * @return 子区域列表
     */
    @GetMapping(AREAS_BY_PARENT_ID)
    fun getAreasByParentId(@RequestParam("parentId") parentId: Long): R<List<AreaEntity>>
}
