package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.ICalendarClient
import cnooc.qhse.base.pojo.entity.CalendarPO
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import java.time.LocalDate

object CalendarCache {
    const val CALENDAR_CACHE = "earnest:calendar"
    private const val CALENDAR_DATE = "date:";

    private var calendarClient: ICalendarClient? = null

    fun getCalendarClient(): ICalendarClient {
        if (calendarClient == null)
            calendarClient = SpringUtil.getBean(ICalendarClient::class.java)
        return calendarClient!!
    }

    fun getByDate(date: LocalDate): CalendarPO? {
        return CacheUtil.get(CALENDAR_CACHE, CALENDAR_DATE, date) {
            getCalendarClient().getByDate(date).retrieve()
        }
    }
}
