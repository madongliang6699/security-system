package cnooc.qhse.base.pojo.enums

import cnooc.qhse.common.enums.StringValueEnum

/**
 *  文件附件用途
 */
enum class FileAttachmentUsage(override val value: String, override val title: String) : StringValueEnum {
    DOCUMENT("document", "文件"),
    AWAITING_ANALYSIS("awaiting_analysis", "待解析"),
}
