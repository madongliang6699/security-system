package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.Shift
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 交接班视图实体类
 */
@Schema(description = "交接班")
class ShiftVO(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    code: String? = null,
    name: String? = null,
    userId: Long? = null,
    workTime: Int? = null,
    shiftTime: LocalDateTime? = null,
    record: String? = null,
    builtIn: Boolean? = null,
    remark: String? = null,
    @Schema(description = "当前人员姓名") var userName: String? = null
) : Shift(
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId,
    code,
    name,
    userId,
    workTime,
    shiftTime,
    record,
    builtIn,
    remark
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
