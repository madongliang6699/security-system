package cnooc.qhse.base.pojo.dto

import cnooc.qhse.base.pojo.entity.CustomParameterEntity

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数表数据传输对象实体类
 */
class CustomParameterDto : CustomParameterEntity() {
    companion object{
        private const val serialVersionUID = 1L
    }
}
