package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 报警配置表实体类
 */
@TableName("earnest_alert_config")
@Schema(description = "报警配置表")
open class AlertConfig(
    @Schema(description = "预警类型")
    var alertCategory: String? = null,
    @Schema(description = "一级预警时间(分钟)")
    var level1AlertTime: Int? = null,
    @Schema(description = "一级预警人员组")
    var level1UserGroup: String? = null,
    @Schema(description = "一级预警是否发送邮件")
    var level1SendEmail: Boolean? = null,
    @Schema(description = "一级预警不重复预警时间(分钟)")
    var level1NoAlertTime: Int? = null,
    @Schema(description = "二级预警时间(分钟)")
    var level2AlertTime: Int? = null,
    @Schema(description = "二级预警人员组")
    var level2UserGroup: String? = null,
    @Schema(description = "二级预警是否发送邮件")
    var level2SendEmail: Boolean? = null,
    @Schema(description = "二级预警不重复预警时间(分钟)")
    var level2NoAlertTime: Int? = null,
    @Schema(description = "三级预警时间(分钟)")
    var level3AlertTime: Int? = null,
    @Schema(description = "三级预警人员组")
    var level3UserGroup: String? = null,
    @Schema(description = "三级预警是否发送邮件")
    var level3SendEmail: Boolean? = null,
    @Schema(description = "三级预警不重复预警时间(分钟)")
    var level3NoAlertTime: Int? = null,
    @Schema(description = "四级预警时间(分钟)")
    var level4AlertTime: Int? = null,
    @Schema(description = "四级预警人员组")
    var level4UserGroup: String? = null,
    @Schema(description = "四级预警是否发送邮件")
    var level4SendEmail: Boolean? = null,
    @Schema(description = "四级预警不重复预警时间(分钟)")
    var level4NoAlertTime: Int? = null,
    @Schema(description = "五级预警时间(分钟)")
    var level5AlertTime: Int? = null,
    @Schema(description = "五级预警人员组")
    var level5UserGroup: String? = null,
    @Schema(description = "五级预警是否发送邮件")
    var level5SendEmail: Boolean? = null,
    @Schema(description = "五级预警不重复预警时间(分钟)")
    var level5NoAlertTime: Int? = null,
    @Schema(description = "备注")
    var remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
