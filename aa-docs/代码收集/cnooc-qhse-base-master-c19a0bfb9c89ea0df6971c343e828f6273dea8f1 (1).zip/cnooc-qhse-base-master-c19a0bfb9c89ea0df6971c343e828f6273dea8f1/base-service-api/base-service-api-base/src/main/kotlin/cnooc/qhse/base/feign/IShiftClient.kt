package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam

/**
 * 值班接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface IShiftClient {
    companion object {
        const val API_PREFIX = "/feign/client/shift"
        const val SHIFT_NAME_BY_CODE = "$API_PREFIX/shift/name-by-code/{code}"
        const val USER_ID_BY_CODE = "$API_PREFIX/shift/user-id-by-code/{code}"
        const val SHIFT_CODES_BY_USER_ID = "$API_PREFIX/shift/codes-by-user-id"
    }
    /**
     * 根据用户岗位获取用户id列表
     */
    @GetMapping(SHIFT_NAME_BY_CODE)
    fun getNameByCode(@PathVariable code: String, @RequestParam tenantId: String): R<String?>

    /**
     * 根据值班编码获取当前用户
     */
    @GetMapping(USER_ID_BY_CODE)
    fun getUserIdByCode(@PathVariable code: String, @RequestParam tenantId: String): R<Long?>

    /**
     * 根据用户id获取值班编码
     */
    @GetMapping(SHIFT_CODES_BY_USER_ID)
    fun getShiftCodesByUserId(@RequestParam userId: Long): R<List<String>>
}
