package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.IAlertConfigClient
import cnooc.qhse.base.pojo.entity.AlertConfig
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import kotlin.collections.firstOrNull
import kotlin.jvm.java

/**
 * 报警配置缓存
 */
object AlertConfigCache {
    const val ALERT_CONFIG_CACHE = "earnest:alert_config"
    private const val ALERT_CONFIG_LIST = "alert_list"
    private const val ALERT_CONFIG_BY_TYPE = "alert_list"

    private var alertConfigClient: IAlertConfigClient? = null

    fun getAlertConfigClient(): IAlertConfigClient {
        if (alertConfigClient == null) {
            alertConfigClient = SpringUtil.getBean(IAlertConfigClient::class.java)
        }
        return alertConfigClient!!
    }

    fun getAlertConfigList(tenantId: String): List<AlertConfig> {
        return CacheUtil.get(ALERT_CONFIG_CACHE, ALERT_CONFIG_LIST, tenantId, {
            getAlertConfigClient().getAlertConfigList(tenantId).retrieve()
        }, false) ?: emptyList()
    }

    fun getAlertConfig(tenantId: String, alertType: String): AlertConfig? {
        return CacheUtil.get(ALERT_CONFIG_CACHE, ALERT_CONFIG_BY_TYPE, tenantId + alertType, {
            getAlertConfigList(tenantId).firstOrNull { it.alertCategory == alertType}
        }, false)
    }
}
