package cnooc.qhse.base.assign

import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.cache.BladeEnhancedCache
import cnooc.qhse.base.cache.ShiftCache
import cnooc.qhse.common.utils.notNullRetrieve
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.system.cache.SysCache
import org.springblade.system.cache.UserCache
import org.springblade.system.feign.IUserSearchClient

// 通过岗位编号获取用户id集合
fun postCodeGetter(postCode: String, tenantId: String): List<Long> {
    return BladeEnhancedCache.getUserIdsByPostCode(postCode, tenantId)
}

// 通过区域编号获取对应责任人id集合
fun areaManagerCodeGetter(areaCode: String, tenantId: String): List<Long> {
    return AreaCache.getUserIdsByAreaCode(areaCode, tenantId)
}

// 通过区域id获取对应责任人id集合
fun areaManagerIdGetter(areaId: String, tenantId: String): List<Long> {
    return AreaCache.getUserIdsByAreaId(areaId.toLong())
}

// 直接获取用户id
fun userIdGetter(userId: String, tenantId: String): List<Long> {
    return listOf(userId.toLong())
}

// 通用用户名称获取用户id
fun userAccountGetter(account: String, tenantId: String): List<Long> {
    return UserCache.getUser(tenantId, account)?.id?.let { listOf(it) } ?: emptyList()
}

// 通过角色id获取用户id集合
fun roleIdGetter(roleId: String, tenantId: String): List<Long> {
    return SpringUtil.getBean(IUserSearchClient::class.java).listByRole(roleId).notNullRetrieve().map { it.id }
}

// 通过角色名称获取用户id集合
fun roleNameGetter(roleName: String, tenantId: String): List<Long> {
    val roleIds = SysCache.getRoleIds(tenantId, roleName)
    return SpringUtil.getBean(IUserSearchClient::class.java).listByRole(roleIds).notNullRetrieve().map { it.id }
}

// 通过部门id获取其下的用户id集合
fun departIdGetter(deptId: String, tenantId: String): List<Long> {
    return SpringUtil.getBean(IUserSearchClient::class.java).listByDept(deptId).notNullRetrieve().map { it.id }
}

// 通过部门全称获取其下的用户id集合
fun departNameGetter(deptName: String, tenantId: String): List<Long> {
    val deptIds = SysCache.getDeptIds(tenantId, deptName)
    if (deptIds.length != 1) return emptyList()
    return departIdGetter(deptIds.first().toString(), tenantId)
}

// 通过值班编码获取用户id
fun shiftCodeGetter(shiftCode: String, tenantId: String): List<Long> {
    val userId = ShiftCache.getUserIdByShiftCode(shiftCode, tenantId) ?: return listOf()
    return listOf(userId)
}

// 通过用户id取用户姓名
fun userIdNameGetter(userId: String, tenantId: String): String? {
    return UserCache.getUser(userId.toLong())?.let { "用户：" + it.realName }
}

// 直接获取用户姓名
fun userAccountNameGetter(account: String, tenantId: String): String {
    return UserCache.getUser(tenantId, account)?.let { "用户：" + it.realName } ?: "用户：$account"
}

// 通过角色id获取角色名称集合
fun roleIdNameGetter(roleId: String, tenantId: String): String? {
    return SysCache.getRoleName(roleId.toLong())?.let { "角色：$it" }
}

// 通过角色名称获取角色名称集合
fun roleNameNameGetter(roleName: String, tenantId: String): String {
    return "角色：$roleName"
}

// 通过岗位编号获取岗位名称列表
fun postCodeNameGetter(postCode: String, tenantId: String): String? {
    val posts = SysCache.getPostsByCodes(tenantId, postCode)
    if (posts.isNullOrEmpty()) return null
    return "岗位：" + posts[0].postName
}

// 通过区域编号获取对应责任人名称集合
fun areaManagerCodeNameGetter(areaCode: String, tenantId: String): String? {
    return AreaCache.getAreaByCode(areaCode, tenantId)?.let { "区域：" + it.areaName }
}

// 通过区域id获取对应责任人名称集合
fun areaManagerIdNameGetter(areaId: String, tenantId: String): String? {
    return AreaCache.getArea(areaId.toLong())?.let { "区域：" + it.areaName }
}

// 通过部门id获取部门名称
fun departIdNameGetter(deptId: String, tenantId: String): String? {
    return SysCache.getDeptName(deptId.toLong())?.let { "部门：$it" }
}

// 通过部门名称获取部门名称
fun departNameNameGetter(deptName: String, tenantId: String): String {
    return "部门：$deptName"
}

// 通过值班编码获取值班名称
fun shiftCodeNameGetter(shiftCode: String, tenantId: String): String? {
    return ShiftCache.getShiftNameByCode(shiftCode, tenantId)?.let { "值班：" + it }
}
