package cnooc.qhse.base.pojo.entity

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/**
 * 编号规则解析实例，用于解析编号规则后的存放
 */
data class NumberRule(
    /**
     * 代码，表示该项所代表的意义，比如TIME代表时间
     */
    val code: String,
    /**
     * 规则，为值显示的格式，比如时间可以对应为HH:mm:ss
     */
    val rule: String,
) {
    /**
     * 解析后的值
     */
    var value: String? = null

    /**
     * 通用解析最终值，支持：
     * TIME: 时间
     * STRING: 常量字符串
     * RANDOM_INT: 随机整数，rule中可以指定范围，格式，以逗号分隔，例如：1,100,%02d
     * RANDOM_DOUBLE: 随机浮点值，rule中可以指定范围，格式，以逗号分隔，例如：0.1,100,%.2f
     */
    fun resolveCommonValue() {
        value = when (code) {
            "TIME" -> LocalDateTime.now().format(DateTimeFormatter.ofPattern(rule))
            "STRING" -> rule
            "RANDOM_INT" -> {
                val range = rule.split(",")
                if (range.size != 3) {
                    throw IllegalArgumentException("编号规则格式错误: $this")
                }
                String.format(range[2], Random.nextInt(range[0].toInt(), range[1].toInt()))
            }
            "RANDOM_DOUBLE" -> {
                val range = rule.split(",")
                if (range.size != 3) {
                    throw IllegalArgumentException("编号规则格式错误: $this")
                }
                String.format(range[2], Random.nextDouble(range[0].toDouble(), range[1].toDouble()))
            }
            else -> value
        }
    }

    override fun toString(): String {
        return "$code|$rule"
    }

    companion object {
        /**
         * 解析编号规则，不同规则之间用;分隔，单一规则代码与规则之间用|分隔
         * 解析形如
         * 1. 'UnitNo|%2d;InstallNo|%2d;PhotoNo|%06d;String|-;Distance|%.0fM;Height|H%.0f;Direction|%s;Floor|%02d;
         * String|-;Locator|%s', 'SealType|%s;SealNo|%02d'的格式，将其解析为一系列如(UnitNo, "%02d), (UnitCode, %Xs)一类的格式串。
         * 格式：除了字符串有特殊外，其他均遵循String.format的格式，例如"%10d"
         * 对于字符串，可以指定前置、后置，前置为%10Xs表示前置X补足10位，后置为%-10Xs；
         * @param formatter 字符串
         * @return 已经解析过的格式化列表，形如：[{TagFormatField: string}]
         */
        fun parseNumberRules(formatter: String): List<NumberRule> {
            val fields = formatter.split(";")
            return fields.map {
                val items = it.split("|", limit = 2)
                if (items.size != 2) {
                    throw IllegalArgumentException("编号规则格式错误: $formatter")
                }
                NumberRule(items[0], items[1])
            }
        }
    }
}
