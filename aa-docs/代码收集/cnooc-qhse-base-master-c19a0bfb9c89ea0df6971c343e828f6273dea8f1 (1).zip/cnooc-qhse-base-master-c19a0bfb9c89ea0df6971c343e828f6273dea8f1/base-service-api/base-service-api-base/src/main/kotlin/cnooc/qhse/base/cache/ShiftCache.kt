package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.IShiftClient
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.core.tool.utils.StringPool

object ShiftCache {
    const val SHIFT_CACHE = "earnest:shift"
    private const val SHIFT_NAME = "earnest:shift_name:"
    private const val SHIFT_USER_ID = "earnest:shift_user_id:"
    private const val SHIFT_CODE_BY_USER_ID = "earnest:shift_code_by_user_id:"

    private var shiftClient: IShiftClient? = null

    private fun getShiftClient(): IShiftClient {
        if (shiftClient == null) {
            shiftClient = SpringUtil.getBean(IShiftClient::class.java)
        }
        return shiftClient!!
    }

    /**
     * 通过值班Code获取值班岗位名称
     */
    fun getShiftNameByCode(shiftCode: String, tenantId: String): String? {
        return CacheUtil.get(
            SHIFT_CACHE, SHIFT_NAME + StringPool.COLON + tenantId, shiftCode
        ) { getShiftClient().getNameByCode(shiftCode, tenantId).retrieve() }
    }

    /**
     * 通过值班Code获取当前岗位的人员id
     */
    fun getUserIdByShiftCode(shiftCode: String, tenantId: String): Long? {
        return CacheUtil.get(
            SHIFT_CACHE, SHIFT_USER_ID + StringPool.COLON + tenantId,
            shiftCode
        ) { getShiftClient().getUserIdByCode(shiftCode, tenantId).retrieve() }
    }

    /**
     * 通过人员id获取其他值班岗位
     */
    fun getShiftCodeByUserId(userId: Long): List<String> {
        return CacheUtil.get(
            SHIFT_CACHE, SHIFT_CODE_BY_USER_ID, userId
        ) { getShiftClient().getShiftCodesByUserId(userId).retrieve() } ?: listOf()
    }
}
