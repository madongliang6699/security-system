package cnooc.qhse.base.pojo.entity

import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.annotation.JsonFormat
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.core.tool.utils.DateUtil
import org.springframework.format.annotation.DateTimeFormat
import java.time.LocalDateTime

/**
 * 软件版本信息实体类
 */
@TableName("earnest_software_version")
@Schema(description = "软件版本信息")
class SoftwareVersion(
    @Schema(description = "id")
    var id: Long? = null,
    /**
     * 主版本号
     */
    @Schema(description = "主版本号")
    var majorVersionNumber: Int? = null,

    /**
     * 子版本号
     */
    @Schema(description = "子版本号")
    var minorVersionNumber: Int? = null,

    /**
     * 修正版本号
     */
    @Schema(description = "修正版本号")
    var revisionNumber: Int? = null,

    /**
     * 编译版本号
     */
    @Schema(description = "编译版本号")
    var buildNumber: Int? = null,

    /**
     * 软件下载地址
     */
    @Schema(description = "软件下载地址")
    var softwareDownloadUrl: String? = null,

    /**
     * 更新内容
     */
    @Schema(description = "更新内容")
    var updateContent: String? = null,

    /**
     * 发布时间
     */
    @Schema(description = "发布时间")
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    var publishDatetime: LocalDateTime? = null,

    /**
     * 类型
     */
    @Schema(description = "类型")
    var type: String? = null,

    /**
     * 是否强制更新
     */
    @Schema(description = "是否强制更新")
    var forceUpdate: Boolean? = null,
) {
    override fun toString(): String {
        return majorVersionNumber.toString() + minorVersionNumber.toString() + revisionNumber.toString() + buildNumber.toString()
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
