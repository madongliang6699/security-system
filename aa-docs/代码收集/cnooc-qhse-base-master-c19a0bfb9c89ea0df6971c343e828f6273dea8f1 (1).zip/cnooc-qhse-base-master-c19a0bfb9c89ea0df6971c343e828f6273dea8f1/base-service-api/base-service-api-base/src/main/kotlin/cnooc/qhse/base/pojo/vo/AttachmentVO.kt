package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.Attachment
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 附件视图实体类
 */
@Schema(description = "附件")
class AttachmentVO(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    businessId: String? = null,
    originalName: String? = null,
    name: String? = null,
    extension: String? = null,
    fileUsage: String? = null,
    fileUsageName: String? = null,
    sort: Int? = null,
    @Schema(description = "文件链接") var link: String? = null,
) : Attachment(
    id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId, businessId,
    originalName, name, extension, fileUsage, fileUsageName, sort
) {
    override fun toString(): String {
        return "AttachmentVO(id=$id, isDeleted=$isDeleted, tenantId=$tenantId, businessId=$businessId, " +
                "originalName=$originalName, name=$name, extension=$extension, fileUsage=$fileUsage, fileUsageName=$fileUsageName, " +
                "sort=$sort, link=$link"
    }

    companion object {
        private const val serialVersionUID = 1L
    }
}
