package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.IAreaClient
import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.base.pojo.vo.AreaVO
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.constant.BladeConstant
import org.springblade.core.tool.utils.SpringUtil
import kotlin.collections.joinToString
import kotlin.collections.reverse
import kotlin.jvm.java

object AreaCache {
    const val AREA_CACHE = "earnest:area"
    private const val AREA_ID = "areaId:"
    private const val AREA_CODE = "areaCode:"
    private const val AREA_CODE_OR_NAME = "areaCodeOrName:"
    private const val AREA_NAME_ID = "areaName:id:"
    private const val AREA_TREE = "areaTree:"
    private const val AREA_PATH_NAME = "areaPathName:"
    private const val AREA_USER_ID_BY_ID = "userIdById:"
    private const val AREA_USER_ID_BY_CODE = "userIdByCode:"
    private const val AREAS_BY_USER_ID = "areasByUserId:"
    private const val AREA_BY_PARENT_ID = "areaByParentId:"
    private const val AREA_WITH_LAST_LEVEL = "areaWithLastLevel:"

    private var areaClient: IAreaClient? = null;

    fun getAreaClient(): IAreaClient {
        if (areaClient == null) {
            areaClient = SpringUtil.getBean(IAreaClient::class.java)
        }
        return areaClient!!
    }

    /**
     * 获取现场区域
     *
     * @param id 主键
     */
    fun getArea(id: Long): AreaEntity? {
        return CacheUtil.get(AREA_CACHE, AREA_ID, id) { getAreaClient().getAreaById(id).retrieve() }
    }

    /**
     * 获取现场区域
     *
     * @param areaCode 主键
     * @return 区域
     */
    fun getAreaByCode(areaCode: String, tenantId: String): AreaEntity? {
        return CacheUtil.get(AREA_CACHE, AREA_CODE + tenantId, areaCode) {
            getAreaClient().getAreaByCode(areaCode, tenantId).retrieve()
        }
    }

    /**
     * 根据区域名称或编号获取区域
     * @param areaNameOrCode 区域名称或编号
     * @param tenantId 租户id
     */
    fun getAreasByNameOrCode(areaNameOrCode: String, tenantId: String): List<AreaEntity> {
        return CacheUtil.get(AREA_CACHE, AREA_CODE_OR_NAME + tenantId, areaNameOrCode) {
            getAreaClient().getAreasByCodeOrName(areaNameOrCode, tenantId).retrieve()
        } ?: listOf()
    }

    /**
     * 获取区域名
     *
     * @param id 主键
     * @return 部门名
     */
    fun getAreaName(id: Long): String? {
        return CacheUtil.get(AREA_CACHE, AREA_NAME_ID, id) { getAreaClient().getAreaById(id).retrieve()?.areaName}
    }


    /**
     * 获取区域名称（全路径）
     * @param id 区域id
     * @return 区域名称以/分隔的全区域路径
     */
    fun getAreaPathName(id: Long): String? {
        return CacheUtil.get(AREA_CACHE, AREA_PATH_NAME, id) {
            val areaNames = mutableListOf<String>()
            var area: AreaEntity?
            var tempId = id
            do {
                area = getArea(tempId)
                if (area == null) {
                    break
                }
                areaNames.add(area.areaName!!)
                tempId = area.parentId!!
            } while (tempId == BladeConstant.TOP_PARENT_ID)
            areaNames.reverse()

            areaNames.joinToString("/")
        }
    }

    /**
     * 获取区域树
     *
     * @param tenantId 租户
     * @return 区域
     */
    fun getAreaTree(tenantId: String): List<AreaVO> {
        return CacheUtil.get(AREA_CACHE, AREA_TREE, tenantId) {
            getAreaClient().tree(tenantId).retrieve()
        } ?: listOf()
    }

    /**
     * 获取区域id关联的负责人id
     *
     * @param areaId 职务编码
     * @return 区域
     */
    fun getUserIdsByAreaId(areaId: Long): List<Long> {
        return CacheUtil.get(AREA_CACHE, AREA_USER_ID_BY_ID, areaId) {
            getAreaClient().getUserIdsByAreaId(areaId).retrieve()
        } ?: listOf()
    }

    /**
     * 获取区域编码关联的负责人id
     *
     * @param areaCode 区域编码
     * @return 区域
     */
    fun getUserIdsByAreaCode(areaCode: String, tenantId: String): List<Long> {
        return CacheUtil.get(AREA_CACHE, AREA_USER_ID_BY_CODE, areaCode) {
            getAreaClient().getUserIdsByAreaCode(areaCode, tenantId).retrieve()
        } ?: listOf()
    }

    fun getAreasByUserId(userId: Long): List<AreaEntity> {
        return CacheUtil.get(AREA_CACHE, AREAS_BY_USER_ID, userId) {
            getAreaClient().getAreasByUserId(userId).retrieve()
        } ?: listOf()
    }

    fun getLastLevelAreas(tenantId: String): List<AreaVO> {
        return CacheUtil.get(AREA_CACHE, AREA_WITH_LAST_LEVEL, tenantId) {
            getAreaClient().getLastLevelAreas(tenantId).retrieve()
        } ?: listOf()
    }
    /**
     *
     */
    fun getAreasByParentId(parentId: Long): List<AreaEntity> {
        return CacheUtil.get(AREA_CACHE, AREA_BY_PARENT_ID, parentId) {
            getAreaClient().getAreasByParentId(parentId).retrieve()
        } ?: emptyList()
    }
}
