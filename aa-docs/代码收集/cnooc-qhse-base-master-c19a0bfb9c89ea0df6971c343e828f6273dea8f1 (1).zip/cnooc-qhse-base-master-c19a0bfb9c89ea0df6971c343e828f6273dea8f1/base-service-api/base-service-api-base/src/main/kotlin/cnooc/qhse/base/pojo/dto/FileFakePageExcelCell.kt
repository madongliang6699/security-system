package cnooc.qhse.base.pojo.dto

import cnooc.qhse.base.constant.FileFakePageConstant
import java.util.*

/**
 * FileFakePage表格类自定义单元格信息
 */
class FileFakePageExcelCell(
    /**
     * 单元格所在Excel行
     */
    var row: Int? = null,

    /**
     * 单元格所在Excel列
     */
    var column: Int? = null,

    /**
     * 是否合并单元格
     */
    var merged: Boolean = false,

    /**
     * 合并信息  row,column
     */
    var mergedRowCount: Int = 1,
    var mergedColumnCount: Int = 1,

    /**
     * 单元格数据类型
     */
    var dataType: String = FileFakePageConstant.STR,

    /**
     * 单元格数据
     */
    var data: String? = null,

    /**
     * 单元格样式
     */
    var customCellStyle: FileFakePageCustomCellStyle? = null,

    /**
     * 多格式单元格样式
     */
    var customCellStyles: List<FileFakePageCustomCellStyle>? = null
) {
    //重写比较方法,如果行和列号一致，则认为为同一个单元格
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is FileFakePageExcelCell) return false
        return (row == other.row) && (column == other.column)
    }

    override fun hashCode(): Int {
        return Objects.hash(row, column)
    }

    override fun toString(): String {
        return "ExcelCell{" +
                "row=" + row +
                ", column=" + column +
                ", merged=" + merged +
                ", mergedRowCount=" + mergedRowCount +
                ", mergedColumnCount=" + mergedColumnCount +
                ", dataType='" + dataType + '\'' +
                ", data='" + data + '\'' +
                '}'
    }
}
