package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.BaseEntityKt
import com.baomidou.mybatisplus.annotation.TableField
import com.baomidou.mybatisplus.annotation.TableName
import java.time.LocalDateTime

/**
 * 日历表
 */
@TableName("earnest_calendar")
class CalendarPO(

    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,

    /**
     * 年份
     */
    @TableField(value = "year")
    var year: Int? = null,

    /**
     * 月份
     */
    @TableField(value = "month")
    var month: Int? = null,

    /**
     * 日
     */
    @TableField(value = "day")
    var day: Int? = null,

    /**
     * 当前周第几天 1-周一 2-周二 ... 7-周日
     */
    @TableField(value = "week_day")
    var weekDay: Int? = null,

    /**
     * 天干地支纪年法描述 例如：戊戌
     */
    @TableField(value = "year_tips")
    var yearTips: String? = null,

    /**
     * 类型 0 工作日 1 休息日 2 节假日
     */
    @TableField(value = "type")
    var type: Int? = null,

    /**
     * 类型描述 比如 国庆,休息日,工作日
     */
    @TableField(value = "type_desc")
    var typeDesc: String? = null,

    /**
     * 属相 例如：狗
     */
    @TableField(value = "chinese_zodiac")
    var chineseZodiac: String? = null,

    /**
     * 节气描述 例如：小雪
     */
    @TableField(value = "solar_terms")
    var solarTerms: String? = null,

    /**
     * 农历日期
     */
    @TableField(value = "lunar_calendar")
    var lunarCalendar: String? = null,

    /**
     * 禁忌
     */
    @TableField(value = "avoid")
    var avoid: String? = null,

    /**
     * 宜事项
     */
    @TableField(value = "suit")
    var suit: String? = null,

    /**
     * 这一年的第几天
     */
    @TableField(value = "day_of_year")
    var dayOfYear: Int? = null,

    /**
     * 这一年的第几周
     */
    @TableField(value = "week_of_year")
    var weekOfYear: Int? = null,

    /**
     * 星座
     */
    @TableField(value = "constellation")
    var constellation: String? = null,

    /**
     * 如果当前是工作日 则返回是当前月的第几个工作日，否则返回0
     */
    @TableField(value = "index_workday_of_month")
    var indexWorkdayOfMonth: Int? = null

) : BaseEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted)
