package cnooc.qhse.base.assign

import com.fasterxml.jackson.annotation.JsonValue

/**
 * 任务执行人变量内置前缀
 */
enum class AssigneePrefix(@field:JsonValue val code: String) {
    USER_ID("USER_ID"),  // 用户id，此处在解析用户组时并不解析，它一般用于嵌套在用户组中，但当工作流监听时，将直接转换为实际用户
    USER_ACCOUNT("USER_ACCOUNT"),  // 用户帐号名
    USER_ID_VARIABLE("USER_ID_VARIABLE"),  // 变量指定的用户id
    ROLE_ID("ROLE_ID"),  // 角色id
    ROLE_NAME("ROLE_NAME"),  // 角色名称
    SHIFT_CODE("SHIFT_CODE"),  // 当班岗位编码, 此处在解析用户组时并不解析，它一般用于嵌套在用户组中，但当工作流监听时，将直接转换为实际用户
    POST_CODE("POST_CODE"),  // 岗位编码
    AREA_MANAGER_CODE("AREA_CODE"),  // 区域负责人编码
    AREA_MANAGER_ID("AREA_ID"),  // 区域负责人(区域ID）
    DEPART_ID("DEPART_ID"), // 隶属该部门id的用户，指定部门时使用机构id，并保证唯一
    DEPART_NAME("DEPART_NAME"); // 隶属该部门名称的用户，指定部门时使用机构名称，并保证唯一

    fun getGroup(value: String): AssignGroup {
        return AssignGroup(this, value)
    }

    companion object {
        fun parse(prefix: String): AssigneePrefix {
            return entries.firstOrNull { it.code == prefix } ?: throw IllegalArgumentException("无效的用户前缀：$prefix")
        }

        fun isValidAssigneePrefix(prefix: String): Boolean {
            return entries.any { it.code == prefix }
        }
    }
}
