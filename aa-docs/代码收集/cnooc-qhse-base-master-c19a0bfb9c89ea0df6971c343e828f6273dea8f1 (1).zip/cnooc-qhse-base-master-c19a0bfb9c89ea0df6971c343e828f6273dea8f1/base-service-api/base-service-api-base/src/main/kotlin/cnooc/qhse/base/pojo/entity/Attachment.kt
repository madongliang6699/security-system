package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.io.Serializable
import java.time.LocalDateTime

/**
 * 附件实体类
 */
@TableName("earnest_attachment")
@Schema(description = "附件")
open class Attachment(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    /**
     * 业务id
     */
    @Schema(description = "业务id")
    var businessId: String? = null,

    /**
     * 文件名
     */
    @Schema(description = "原文件名")
    var originalName: String? = null,

    /**
     * 文件名
     */
    @Schema(description = "文件名")
    var name: String? = null,

    /**
     * 附件文件类型
     */
    @Schema(description = "附件扩展名")
    var extension: String? = null,

    /**
     * 附件用途
     */
    @Schema(description = "附件用途")
    var fileUsage: String? = null,

    @Schema(description = "附件用途名称")
    var fileUsageName: String? = null,

    @Schema(description = "排序")
    var sort: Int? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId),
    Serializable {

    companion object {
        private const val serialVersionUID = 1L
    }
}
