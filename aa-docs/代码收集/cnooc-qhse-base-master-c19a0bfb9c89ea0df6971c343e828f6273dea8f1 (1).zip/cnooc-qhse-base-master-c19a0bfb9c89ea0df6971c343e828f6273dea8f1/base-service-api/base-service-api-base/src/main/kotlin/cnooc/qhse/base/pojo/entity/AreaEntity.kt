package cnooc.qhse.base.pojo.entity

import cn.afterturn.easypoi.excel.annotation.Excel
import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.NullSerializer
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.constraints.NotBlank
import java.time.LocalDateTime

/**
 * 区域实体类
 */
@TableName("earnest_area")
@Schema(description = "")
open class AreaEntity(
    @Schema(description = "父级节点")
    @JsonSerialize(using = ToStringSerializer::class, nullsUsing = NullSerializer::class)
    var parentId: Long? = null,

    @Schema(description = "祖级区域主键")
    var ancestors: String? = null,

    @Schema(description = "区域名称")
    @Excel(name = "区域名称", width = 100.0)
    @field:NotBlank(message = "区域名称不能为空")
    var areaName: String? = null,

    @Schema(description = "区域编码")
    @Excel(name = "区域编码", width = 15.0)
    var areaCode: String? = null,

    @Schema(description = "区域坐标")
    @Excel(name = "区域坐标", width = 15.0)
    var areaCoordinates: String? = null,

    @Schema(description = "责任部门")
    @Excel(name = "责任部门", width = 15.0)
    var deptIds: String? = null,

    @Schema(description = "责任人")
    @Excel(name = "责任人", width = 15.0)
    var userIds: String? = null,

    @Schema(description = "备注")
    @Excel(name = "备注")
    var remark: String? = null,

    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
