package cnooc.qhse.base.pojo.vo

import io.swagger.v3.oas.annotations.media.Schema

@Schema(description = "通用文件信息视图类")
class FileFakePageListVO(
    @Schema(description = "模块") var module: String? = null,
    @Schema(description = "存储文件类型") var fileType: String? = null,
    @Schema(description = "存储路径") var link: String? = null,
    @Schema(description = "解析数据") var excelStr: String? = null,
    @Schema(description = "文件后缀") var extension: String? = null,
    @Schema(description = "标题") var name: String? = null,
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
