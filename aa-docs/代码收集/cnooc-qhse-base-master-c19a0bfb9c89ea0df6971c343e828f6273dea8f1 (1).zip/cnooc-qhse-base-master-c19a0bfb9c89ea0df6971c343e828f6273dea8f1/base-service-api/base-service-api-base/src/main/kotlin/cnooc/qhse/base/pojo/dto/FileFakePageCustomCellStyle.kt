package cnooc.qhse.base.pojo.dto

/**
 * FileFakePage excel自定义单元格格式
 */
class FileFakePageCustomCellStyle(
    /**
     * 起始范围
     */
    var startIndex: Int? = null,
    var endIndex: Int? = null,

    /**
     * 填充颜色
     */
    var backGroundColor: String? = null,

    /**
     * 是否加粗
     */
    var fontWeight: Boolean = false,

    /**
     * 字体颜色
     */
    var color: String? = null,

    /**
     * 字体大小
     */
    var fontSize: Short = 0
)
