package cnooc.qhse.base.pojo.entity

import cn.afterturn.easypoi.excel.annotation.Excel
import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.NullSerializer
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.constraints.NotBlank
import java.time.LocalDateTime

@TableName("earnest_category")
@Schema(description = "")
open class CategoryData (
    @Schema(description = "父级节点")
    @JsonSerialize(using = ToStringSerializer::class, nullsUsing = NullSerializer::class)
    var parentId: Long? = null,

    @Schema(description = "所有祖级主键")
    var ancestors: String? = null,

    @Schema(description = "分类名称")
    @Excel(name = "分类名称", width = 100.0)
    @field:NotBlank(message = "分类名称不能为空")
    var categoryName: String? = null,

    @Schema(description = "分类编码")
    @Excel(name = "分类编码", width = 15.0)
    var categoryCode: String? = null,

    @Schema(description = "扩展数据1")
    @Excel(name = "扩展数据1", width = 15.0)
    var extend1: String? = null,

    @Schema(description = "扩展数据2")
    @Excel(name = "扩展数据2", width = 15.0)
    var extend2: String? = null,

    @Schema(description = "扩展数据3")
    @Excel(name = "扩展数据3", width = 15.0)
    var extend3: String? = null,

    @Schema(description = "备注")
    var remark: String? = null,

    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
