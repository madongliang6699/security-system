package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.ICategoryDataClient
import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.core.tool.utils.StringPool

object CategoryDataCache {
    const val CATEGORY_CACHE = "earnest:category"
    private const val CATEGORY_ID = "category:id:"
    private const val CATEGORY_NAME_ID = "category:id:"
    private const val CATEGORY_PATH_NAME_BY_ID = "category:path_name_by_id:"
    private const val CATEGORY_BY_CODE = "category:by_code:"
    private const val CATEGORY_BY_NAME = "category:by_name:"
    private const val CATEGORY_TREE = "category:tree:"

    private var categoryClient: ICategoryDataClient? = null

    private fun getCategoryClient(): ICategoryDataClient {
        if (categoryClient == null)
            categoryClient = SpringUtil.getBean(ICategoryDataClient::class.java)
        return categoryClient!!
    }

    /**
     * 获取分类
     *
     * @param id 主键
     * @return 分类
     */
    fun getCategory(id: Long): CategoryData? {
        return CacheUtil.get(CATEGORY_CACHE, CATEGORY_ID, id) {
            getCategoryClient().getCategoryById(id).retrieve()
        }
    }

    /**
     * 获取分类名称
     *
     * @param id 主键
     * @return 分类名称
     */
    fun getCategoryName(id: Long): String? {
        return CacheUtil.get(CATEGORY_CACHE, CATEGORY_NAME_ID, id) { getCategory(id)?.categoryName }
    }

    /**
     * 获取分类名称（全路径）
     */
    fun getCategoryPathName(id: Long): String? {
        return CacheUtil.get(CATEGORY_CACHE, CATEGORY_PATH_NAME_BY_ID, id) {
            getCategoryClient().getCategoryPathNameById(id).retrieve()
        }
    }

    /**
     * 获取分类树
     *
     * @return 分类树
     */
    fun getCategoryTree(rootCode: String, tenantId: String): List<CategoryDataVO> {
        return CacheUtil.get(CATEGORY_CACHE, CATEGORY_TREE + tenantId + StringPool.COLON, rootCode) {
            getCategoryClient().getCategorySingleTree(rootCode, tenantId).retrieve()
        } ?: listOf()
    }

    /**
     * 获取分类树
     *
     * @return 分类
     */
    fun getCategoryByCode(code: String, tenantId: String): CategoryData? {
        return CacheUtil.get(CATEGORY_CACHE, CATEGORY_BY_CODE+ tenantId + StringPool.COLON, code) {
            getCategoryClient().getCategoryByCode(code, tenantId).retrieve()
        }
    }

    /**
     * 根据分类名称获取匹配的分类列表
     *
     * @return 分类列表
     */
    fun getCategoriesByName(name: String, tenantId: String): List<CategoryData> {
        return CacheUtil.get(CategoryDataCache.CATEGORY_CACHE, CATEGORY_BY_NAME + tenantId + StringPool.COLON, name) {
            getCategoryClient().getCategoriesByName(name, tenantId).retrieve()
        } ?: listOf()
    }
}
