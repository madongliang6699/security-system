package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.ICustomParameterClient
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.core.tool.utils.StringPool

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数缓存
 */
object CustomParameterCache {

    private const val CUSTOM_PARAMETER_CACHE = "earnest:custom_parameter"

    private var customParameterClient: ICustomParameterClient? = null

    private fun getCustomParameterClient(): ICustomParameterClient {
        if (customParameterClient == null) {
            customParameterClient = SpringUtil.getBean(ICustomParameterClient::class.java)
        }
        return customParameterClient!!
    }

    /**
     * 通过键获取参数值
     * @param moduleCode 模块code
     * @param parameterKey 参数键
     * @param tenantId 租户id
     */
    fun getValueByParameterKey(moduleCode: String, parameterKey: String, tenantId: String): String? {
        return CacheUtil.get(CUSTOM_PARAMETER_CACHE, moduleCode + StringPool.COLON + parameterKey, tenantId, {
            getCustomParameterClient().getValueByParameterKey(moduleCode, parameterKey, tenantId).data?.parameterValues
        }, false)
    }

}
