package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 文件虚拟页面配置表
 * 文件虚拟页面是一个页面可以上传文件，然后页面进行渲染展示的一个虚假crud。其中excel文件会被渲染成表格，图片被展示。其他文件当作附件进行展示
 */
@TableName("earnest_file_fake_page_info")
@Schema(description = "CommonFileStorageInfo配置表")
open class FileFakePageInfo (
    @Schema(description = "模块名称")
    var module: String? = null,
    @Schema(description = "备注")
    var remark: String? = null,

    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId)
