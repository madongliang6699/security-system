package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.FieldConfig
import com.fasterxml.jackson.databind.JsonNode
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 字段控制表视图实体类
 */
@Schema(description = "字段控制表")
open class FieldConfigVO(
    formTableName: String? = null,
    scheme: JsonNode? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : FieldConfig(
    formTableName,
    scheme,
    remark,
    id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
