package cnooc.qhse.base.pojo.dto

import cnooc.qhse.base.pojo.entity.AlertConfig

/**
 * 报警配置表数据传输对象实体类
 */
open class AlertConfigDTO : AlertConfig() {
    companion object{
        private const val serialVersionUID = 1L
    }
}
