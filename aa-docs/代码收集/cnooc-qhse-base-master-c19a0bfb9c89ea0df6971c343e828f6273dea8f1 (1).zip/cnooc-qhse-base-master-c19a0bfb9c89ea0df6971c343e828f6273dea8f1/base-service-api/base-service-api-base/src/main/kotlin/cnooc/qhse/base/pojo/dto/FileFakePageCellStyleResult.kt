package cnooc.qhse.base.pojo.dto

/**
 * FileFakePage Excel解析的格式结果,用以处理多格式时判断
 */
class FileFakePageCellStyleResult(
    /**
     * 是否为多格式
     */
    var isMulti: Boolean = false,

    /**
     * 单格式内容
     */
    var cellStyle: FileFakePageCustomCellStyle? = null,
    /**
     * 多格式集合
     */
    var cellStyles: List<FileFakePageCustomCellStyle>? = null
)
