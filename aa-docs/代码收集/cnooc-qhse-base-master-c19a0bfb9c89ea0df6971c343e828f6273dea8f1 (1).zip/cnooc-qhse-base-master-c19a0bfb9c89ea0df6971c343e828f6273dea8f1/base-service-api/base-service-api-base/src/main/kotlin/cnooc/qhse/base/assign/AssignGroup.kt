package cnooc.qhse.base.assign

import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUPS_AND_SPLITTER
import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUPS_OR_SPLITTER
import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUP_ITEM_SPLITTER
import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUP_TENANT_SPLITTER

/**
 * 执行人或用户组变量解析组，类似USER_ID|312，将被解析为AssignGroup(USER_ID, 312)
 */
data class AssignGroup(
    val prefix: AssigneePrefix, val value: String, val tenantId: String? = null,
    val name: String? = null
) {
    override fun toString(): String {
        if (!tenantId.isNullOrBlank()) {
            return "$tenantId$ASSIGN_GROUP_TENANT_SPLITTER${prefix.code}$ASSIGN_GROUP_ITEM_SPLITTER$value"
        }
        return "${prefix.code}$ASSIGN_GROUP_ITEM_SPLITTER$value"
    }

    companion object {
        // 解析分组条件，分组前缀与值用|分隔，分组之间用,或;分隔, ,表示与，;表示或
        fun parseCondition(condition: String): List<List<AssignGroup>> {
            val result = mutableListOf<List<AssignGroup>>()
            val groups = condition.split(ASSIGN_GROUPS_AND_SPLITTER)
            groups.map { group ->
                if (group.contains(ASSIGN_GROUPS_OR_SPLITTER)) {
                    val groups1 = group.split(ASSIGN_GROUPS_OR_SPLITTER)
                    result.add(groups1.map { parseGroup(it) })
                } else {
                    result.add(listOf(parseGroup(group)))
                }
            }
            return result
        }

        private fun parseGroup(group: String): AssignGroup {
            val tenantId: String?
            val newGroup: String
            if (group.contains(ASSIGN_GROUP_TENANT_SPLITTER)) {
                val items = group.split(ASSIGN_GROUP_TENANT_SPLITTER)
                if (items.size != 2) {
                    throw IllegalArgumentException("无效的用户分组格式：$group")
                }
                tenantId = items[0]
                newGroup = items[1]
            } else {
                tenantId = null
                newGroup = group
            }
            val items = newGroup.split(ASSIGN_GROUP_ITEM_SPLITTER)
            if (items.size == 2) {
                return AssignGroup(AssigneePrefix.Companion.parse(items[0]), items[1], tenantId)
            } else {
                throw IllegalArgumentException("无效的用户分组格式：$group")
            }
        }
    }
}
