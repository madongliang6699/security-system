package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数表
 */
@TableName("earnest_custom_parameter")
@Schema(description = "CustomParameter对象")
open class CustomParameterEntity(


    @Schema(description = "模块编码")
    var moduleCode: String? = null,

    @Schema(description = "模块名称")
    var moduleName: String? = null,

    @Schema(description = "参数名称")
    var parameterName: String? = null,


    @Schema(description = "参数key")
    var parameterKey: String? = null,

    @Schema(description = "参数类型")
    var parameterType: String? = null,

    @Schema(description = "参数值")
    var parameterValues: String? = null,


    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,

    ) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
