package cnooc.qhse.base.assign

object AssigneeConstant {
    const val TASK_USR_PREFIX = "taskUser_"
    const val ASSIGN_GROUP_ITEM_SPLITTER = "|"
    const val ASSIGN_GROUPS_AND_SPLITTER = ","
    const val ASSIGN_GROUPS_OR_SPLITTER = ";"

    const val ASSIGN_GROUP_TENANT_SPLITTER = "-"
    /**
     * 字典：事务类型
     */
    const val DICT_BUSINESS_CATEGORY = "businessCategory"
}
