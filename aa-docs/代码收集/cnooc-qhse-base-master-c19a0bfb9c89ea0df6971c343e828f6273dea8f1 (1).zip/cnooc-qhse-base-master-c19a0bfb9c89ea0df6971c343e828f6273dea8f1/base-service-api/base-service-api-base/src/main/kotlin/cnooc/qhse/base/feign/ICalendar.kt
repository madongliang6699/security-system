package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.entity.CalendarPO
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import java.time.LocalDate

/**
 * 日历服务接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface ICalendarClient {
    companion object {
        const val API_PREFIX = "/feign/client/calendar"
        const val CALENDAR_BY_DATE = "$API_PREFIX/calendar-by-date"
    }
    /**
     * 根据日期获取日期详情
     */
    @GetMapping(CALENDAR_BY_DATE)
    fun getByDate(@RequestParam("date") date: LocalDate): R<CalendarPO>
}
