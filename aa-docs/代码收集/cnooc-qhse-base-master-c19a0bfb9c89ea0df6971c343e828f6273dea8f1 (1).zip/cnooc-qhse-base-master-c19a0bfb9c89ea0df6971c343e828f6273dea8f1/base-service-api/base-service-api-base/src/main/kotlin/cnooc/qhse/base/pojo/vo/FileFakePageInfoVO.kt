package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.FileFakePageInfo
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

@Schema(description = "通用文件数据列表视图类")
class FileFakePageInfoVO(
    module: String? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    @Schema(description = "附件列表")
    var commonFiles: List<AttachmentVO>? = null,
) : FileFakePageInfo(
    module,
    remark,
    id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId
) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
