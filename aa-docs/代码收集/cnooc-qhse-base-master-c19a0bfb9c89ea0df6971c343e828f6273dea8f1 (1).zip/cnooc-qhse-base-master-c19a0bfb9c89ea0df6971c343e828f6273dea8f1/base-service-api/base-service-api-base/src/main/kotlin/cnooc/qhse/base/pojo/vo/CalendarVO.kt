package cnooc.qhse.base.pojo.vo

import io.swagger.v3.oas.annotations.media.Schema
import java.io.Serializable

@Schema(description = "日历")
class CalendarVO(

    @Schema(description = "主键")
    var id: Long? = null,

    @Schema(description = "状态")
    var status: Int? = null,

    @Schema(description = "年份")
    var year: Int? = null,

    @Schema(description = "月份")
    var month: Int? = null,

    @Schema(description = "日")
    var day: Int? = null,

    @Schema(description = "当前周第几天 1-周一 2-周二 ... 7-周日")
    var weekDay: Int? = null,

    @Schema(description = "天干地支纪年法描述 例如：戊戌")
    var yearTips: String? = null,

    @Schema(description = "类型 0 工作日 1 休息日 2 节假日")
    var type: Int? = null,

    @Schema(description = "类型描述 比如 国庆,休息日,工作日")
    var typeDesc: String? = null,

    @Schema(description = "属相 例如：狗")
    var chineseZodiac: String? = null,

    @Schema(description = "节气描述 例如：小雪")
    var solarTerms: String? = null,

    @Schema(description = "农历日期")
    var lunarCalendar: String? = null,

    @Schema(description = "宜事项")
    var suit: String? = null,

    @Schema(description = "这一年的第几天")
    var dayOfYear: Int? = null,

    @Schema(description = "这一年的第几周")
    var weekOfYear: Int? = null,

    @Schema(description = "星座")
    var constellation: String? = null,

    @Schema(description = "如果当前是工作日 则返回是当前月的第几个工作日，否则返回0")
    var indexWorkdayOfMonth: Int? = null

) : Serializable
