package cnooc.qhse.base.assign

import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUP_TENANT_SPLITTER
import org.springblade.core.tool.utils.StringUtil

/**
 * 用户解析注册器
 */
object AssigneeGetterRegister {
    // 用户变量解析器，第一个参数为用户解析前缀，第二个参数为用户获取函数，传递解析后的变量，返回用户的id集合
    private val userParsers = mutableMapOf<AssigneePrefix, (value: String, tenantId: String) -> List<Long>>(
        // 内置的一些解析器
        AssigneePrefix.USER_ID to ::userIdGetter,
        AssigneePrefix.USER_ACCOUNT to ::userAccountGetter,
        AssigneePrefix.ROLE_ID to ::roleIdGetter,
        AssigneePrefix.ROLE_NAME to ::roleNameGetter,
        AssigneePrefix.POST_CODE to ::postCodeGetter,
        AssigneePrefix.AREA_MANAGER_CODE to ::areaManagerCodeGetter,
        AssigneePrefix.AREA_MANAGER_ID to ::areaManagerIdGetter,
        AssigneePrefix.DEPART_ID to ::departIdGetter,
        AssigneePrefix.DEPART_NAME to ::departNameGetter,
        AssigneePrefix.SHIFT_CODE to ::shiftCodeGetter,
    )

    // 用户或用户组名称解析器，第一个参数为用户解析前缀，第二个参数为用户获取函数，传递解析后的变量，返回分组的名称集合
    private val userNameParsers = mutableMapOf<AssigneePrefix, (value: String, tenantId: String) -> String?>(
        // 内置的一些解析器
        AssigneePrefix.USER_ID to ::userIdNameGetter,
        AssigneePrefix.USER_ACCOUNT to ::userAccountNameGetter,
        AssigneePrefix.ROLE_ID to ::roleIdNameGetter,
        AssigneePrefix.ROLE_NAME to ::roleNameNameGetter,
        AssigneePrefix.POST_CODE to ::postCodeNameGetter,
        AssigneePrefix.AREA_MANAGER_CODE to ::areaManagerCodeNameGetter,
        AssigneePrefix.AREA_MANAGER_ID to ::areaManagerIdNameGetter,
        AssigneePrefix.DEPART_ID to ::departIdNameGetter,
        AssigneePrefix.DEPART_NAME to ::departNameNameGetter,
        AssigneePrefix.SHIFT_CODE to ::shiftCodeNameGetter,
    )

    /**
     * 注册用户解析器
     */
    fun register(getter: AssigneeGetter) {
        userParsers[getter.prefix] = getter.getUserIds
        userNameParsers[getter.prefix] = getter.getUserNames
    }

    fun isValidAssigneeGroup(group: String): Boolean {
        val newGroup: String
        if (group.contains(ASSIGN_GROUP_TENANT_SPLITTER)) {
            val items = group.split(ASSIGN_GROUP_TENANT_SPLITTER)
            if (items.size != 2) {
                return false
            }
            if (!StringUtil.isNumeric(items[0])) {
                return false
            }
            newGroup = items[1]
        } else {
            newGroup = group
        }

        val items = newGroup.split(AssigneeConstant.ASSIGN_GROUP_ITEM_SPLITTER)
        return AssigneePrefix.Companion.isValidAssigneePrefix(items[0])
    }

    fun isValidAssigneeGroups(groups: String): Boolean {
        val items = groups.split(AssigneeConstant.ASSIGN_GROUPS_OR_SPLITTER)
        return items.all { isValidAssigneeGroup(it) }
    }

    /**
     * 通过前缀及值获取用户id
     */
    fun getUserIds(prefix: AssigneePrefix, value: String, tenantId: String): List<Long> {
        return userParsers[prefix]?.invoke(value, tenantId) ?: listOf()
    }

    /**
     * 根据用户变量获取用户id
     */
    fun getUserIdsByCondition(condition: String, tenantId: String): List<Long> {
        val groups = AssignGroup.Companion.parseCondition(condition).flatten()
        return groups.flatMap { getUserIds(it.prefix, it.value, tenantId) }
    }

    /**
     * 通过前缀及值获取用户名称
     */
    fun getUserNames(prefix: AssigneePrefix, value: String, tenantId: String): String? {
        return userNameParsers[prefix]?.invoke(value, tenantId)
    }

    /**
     * 根据用户变量获取用户名称
     */
    fun getUserNamesByCondition(condition: String, tenantId: String): List<String> {
        val groups = AssignGroup.Companion.parseCondition(condition).flatten()
        return groups.mapNotNull { getUserNames(it.prefix, it.value, tenantId) }
    }

    fun getUsersByGroups(condition: String, tenantId: String): Map<AssigneePrefix, List<Long>> {
        if (condition.isBlank()) {
            return mapOf()
        }
        val groups = AssignGroup.Companion.parseCondition(condition).flatten()
        val result = mutableMapOf<AssigneePrefix, MutableList<Long>>()
        groups.forEach {
            result.computeIfAbsent(it.prefix) { mutableListOf() }.addAll(
                getUserIds(it.prefix, it.value, tenantId)
            )
        }
        return result
    }


    /**
     * 判断条件是否匹配。根据给定的条件，在实际可用的用户组中匹配，如果匹配则返回true，否则返回false
     * @param condition 条件，例如：条件为：USER_NAME|test;SHIFT_CODE|班长,USER_NAME|test1，其中分号为或的关系，逗号为与的关系
     * @param actualGroups 实际可用的用户组，例如：[AssignGroup("USER_NAME", "test"), AssignGroup("SHIFT_CODE", "班长")]
     */
    fun matchCondition(condition: String, actualGroups: List<AssignGroup>): Boolean {
        val conditions = AssignGroup.Companion.parseCondition(condition)
        return conditions.all { conditionGroups ->
            conditionGroups.any { conditionGroup ->
                actualGroups.any { actualGroup ->
                    actualGroup.prefix == conditionGroup.prefix && actualGroup.value == conditionGroup.value
                }
            }
        }
    }
}
