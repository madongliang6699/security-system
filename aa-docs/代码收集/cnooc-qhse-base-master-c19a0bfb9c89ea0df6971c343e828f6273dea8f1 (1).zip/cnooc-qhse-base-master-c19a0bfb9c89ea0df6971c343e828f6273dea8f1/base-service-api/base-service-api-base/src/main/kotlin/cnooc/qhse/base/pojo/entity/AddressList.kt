package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.node.INodeKt
import com.fasterxml.jackson.annotation.JsonInclude
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.system.pojo.entity.Dept
import org.springblade.system.pojo.vo.UserVO

/**
 * 通讯录
 */
@Schema(description = "通讯录")
class AddressList(
    @JvmField
    @Suppress("INAPPLICABLE_JVM_FIELD")
    override var id: Long? = null,

    @JvmField
    @Suppress("INAPPLICABLE_JVM_FIELD")
    override var parentId: Long? = null,

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    override var children: List<AddressList>? = null,

    @Schema(description = "人员")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    var users: List<UserVO>? = null
) : Dept(), INodeKt<AddressList> {
    override fun getId(): Long? = id
    override fun setId(value: Long?) {
        id = value
    }

    override fun getParentId(): Long? = parentId
    override fun setParentId(value: Long?) {
        id = value
    }


    /**
     * 是否有子孙节点
     */
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    override val hasChildren: Boolean = !children.isNullOrEmpty() || !users.isNullOrEmpty()
}
