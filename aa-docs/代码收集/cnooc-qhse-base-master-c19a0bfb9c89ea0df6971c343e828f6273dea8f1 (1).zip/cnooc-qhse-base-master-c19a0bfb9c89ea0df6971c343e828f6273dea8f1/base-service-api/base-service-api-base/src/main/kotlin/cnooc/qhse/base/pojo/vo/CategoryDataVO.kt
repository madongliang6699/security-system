package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.common.node.INodeKt
import java.time.LocalDateTime

class CategoryDataVO(
    var parentName: String? = null,
    parentId: Long? = null,
    ancestors: String? = null,
    categoryName: String? = null,
    categoryCode: String? = null,
    extend1: String? = null,
    extend2: String? = null,
    extend3: String? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    override var children: List<CategoryDataVO>? = null
) : CategoryData(
    parentId,
    ancestors,
    categoryName,
    categoryCode,
    extend1,
    extend2,
    extend3,
    remark,
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId
), INodeKt<CategoryDataVO> {

    companion object {
        private const val serialVersionUID = 1L
    }
}
