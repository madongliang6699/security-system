package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 交接班日志实体类
 */
@TableName("earnest_shift_log")
@Schema(description = "交接班日志")
open class ShiftLog(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    /**
     * 编码
     */
    @Schema(description = "编码")
    var code: String? = null,

    /**
     * 名称
     */
    @Schema(description = "名称")
    var name: String? = null,

    /**
     * 上一个用户ID
     */
    @Schema(description = "上一个用户ID")
    @JsonSerialize(using = ToStringSerializer::class)
    var oldUserId: Long? = null,

    /**
     * 当前用户ID
     */
    @Schema(description = "当前用户ID")
    @JsonSerialize(using = ToStringSerializer::class)
    var newUserId: Long? = null,

    @Schema(description = "工作记录")
    var record: String? = null,

    @Schema(description = "备注")
    var remark: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId)
