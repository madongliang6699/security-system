package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.AreaEntity
import cnooc.qhse.common.node.INodeKt
import java.time.LocalDateTime

class AreaVO(
    var parentName: String? = null,
    var userNames: String? = null,
    var deptNames: String? = null,
    override var children: List<AreaVO>? = null,
    parentId: Long? = null,
    ancestors: String? = null,

    areaName: String? = null,
    areaCode: String? = null,
    deptIds: String? = null,
    areaCoordinates: String? = null,
    userIds: String? = null,
    remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : AreaEntity(
    parentId,
    ancestors,
    areaName,
    areaCode,
    areaCoordinates,
    deptIds,
    userIds,
    remark,
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId
), INodeKt<AreaVO> {
    companion object {
        private const val serialVersionUID = 1L
    }
}
