package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant.APP_NAME
import cnooc.qhse.base.pojo.entity.Attachment
import cnooc.qhse.base.pojo.vo.AttachmentVO
import org.springblade.core.oss.model.BladeFile
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.*

/**
 * 附件接口
 */
@FeignClient(value = APP_NAME)
interface IAttachmentClient {
    companion object {
        const val API_PREFIX = "/feign/client/attachment"
        const val ADD_ATTACHMENTS = "$API_PREFIX/attachments"
        const val ADD_ATTACHMENTS_BY_BLADE_FILES = "$API_PREFIX/attachments-by-blade-files"
        const val GET_ATTACHMENTS_BY_BUSINESS_ID_FILE_USAGE = "$API_PREFIX/attachments/{businessId}/{fileUsage}"
        const val GET_ATTACHMENTS_BY_BUSINESS_ID = "$API_PREFIX/attachments/{businessId}"
        const val GET_ATTACHMENTS_BY_BUSINESS_IDS = "$API_PREFIX/attachments/businessIds"
        const val GET_ATTACHMENTS_INCLUDE_DELETED = "$API_PREFIX/attachments/include-deleted"
        const val REMOVE_BY_IDS = "$API_PREFIX/attachments"
        const val REMOVE_BY_BUSINESS_IDS = "$API_PREFIX/attachments/business-ids"
        const val REMOVE_BY_BUSINESS_IDS_USAGE = "$API_PREFIX/attachments/{fileUsage}/business-ids"
    }

    /**
     * 新增附件
     */
    @PostMapping(ADD_ATTACHMENTS)
    fun addAttachments(@RequestBody attachments: List<Attachment>): R<Boolean>

    /**
     * 新增附件
     */
    @PostMapping(ADD_ATTACHMENTS_BY_BLADE_FILES)
    fun addAttachments(
        @RequestBody files: List<BladeFile>, @RequestParam tenantId: String,
        @RequestParam businessId: String, @RequestParam fileUsage: String
    ): R<List<AttachmentVO>>

    /**
     * 根据业务id和用途获取附件，参数不能全部为null
     * @param businessId 业务id
     * @param fileUsage 附件用途
     * @return 附件列表
     */
    @GetMapping(GET_ATTACHMENTS_BY_BUSINESS_ID_FILE_USAGE)
    fun getAttachments(@PathVariable businessId: String, @PathVariable fileUsage: String): R<List<AttachmentVO>>

    /**
     * 根据业务id获取附件，参数不能全部为null
     * @param businessId 业务id
     * @return 附件列表
     */
    @GetMapping(GET_ATTACHMENTS_BY_BUSINESS_ID)
    fun getAttachments(@PathVariable businessId: String): R<List<AttachmentVO>>

    /**
     * 根据业务id集合获取附件，参数不能全部为null
     * @param businessId 业务id
     * @return 附件列表
     */
    @PostMapping(GET_ATTACHMENTS_BY_BUSINESS_IDS)
    fun getAttachments(@RequestBody businessIds: List<String>): R<List<AttachmentVO>>

    @GetMapping(GET_ATTACHMENTS_INCLUDE_DELETED)
    fun getAttachmentsIncludeDeleted(@RequestParam businessId: String,@RequestParam fileUsage: String): R<List<AttachmentVO>>

    /**
     * 根据业务id删除附件
     * @param businessIds 业务id列表
     * @return 是否成功
     */
    @DeleteMapping(REMOVE_BY_BUSINESS_IDS)
    fun removeByBusinessIds(@RequestBody businessIds: List<String>): R<Boolean>

    /**
     * 根据业务id和用途删除附件
     */
    @DeleteMapping(REMOVE_BY_BUSINESS_IDS_USAGE)
    fun removeByBusinessesAndUsage(@RequestBody businessIds: List<String>, @PathVariable fileUsage: String): R<Boolean>

    /**
     * 根据业务id删除附件
     */
    @DeleteMapping(REMOVE_BY_IDS)
    fun removeByIds(@RequestBody ids: List<Long>): R<Boolean>
}
