package cnooc.qhse.base.constant

/**
 * 文件附件常量
 */
object FileFakePageConstant {
    const val PICTURE = "PICTURE" // 图片
    const val STR = "STR" // 字符串
    const val EXCEL_STR = "excel_str" // Excel解析后的字符串
    const val DEFAULT_FONT_COLOR = "FF000000" // 默认字体颜色 纯黑色
}
