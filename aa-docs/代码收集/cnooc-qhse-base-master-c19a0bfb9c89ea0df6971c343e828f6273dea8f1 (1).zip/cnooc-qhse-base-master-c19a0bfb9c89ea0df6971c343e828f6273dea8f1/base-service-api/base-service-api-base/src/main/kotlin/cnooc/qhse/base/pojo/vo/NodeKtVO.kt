package cnooc.qhse.base.pojo.vo

import cnooc.qhse.common.node.INodeKt
import io.swagger.v3.oas.annotations.media.Schema

/**
 * TreeNode通用格式，用于生成选择树
 */
@Schema(description = "DeptVO对象")
data class NodeKtVO(
    override var id: Long? = null,
    override var parentId: Long? = null,
    var title: String? = null,
    override var children: List<NodeKtVO>? = null
) : INodeKt<NodeKtVO> {
    companion object {
        private const val serialVersionUID = 1L
    }
}
