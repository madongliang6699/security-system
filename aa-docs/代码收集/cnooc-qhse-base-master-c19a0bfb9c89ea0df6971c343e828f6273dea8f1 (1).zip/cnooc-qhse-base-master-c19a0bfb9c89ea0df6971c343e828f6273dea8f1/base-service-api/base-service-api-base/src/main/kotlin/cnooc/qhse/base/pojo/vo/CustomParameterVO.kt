package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.CustomParameterEntity
import io.swagger.v3.oas.annotations.media.Schema

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数表视图实体类
 */
@Schema(description = "CustomParameterVo对象")
class CustomParameterVO : CustomParameterEntity() {
    companion object{
        private const val serialVersionUID = 1L
    }
}
