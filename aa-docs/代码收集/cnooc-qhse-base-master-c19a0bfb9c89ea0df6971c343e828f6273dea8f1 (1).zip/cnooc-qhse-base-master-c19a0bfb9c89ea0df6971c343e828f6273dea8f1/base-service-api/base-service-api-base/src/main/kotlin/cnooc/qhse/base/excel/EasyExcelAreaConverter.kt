package cnooc.qhse.base.excel

import cnooc.qhse.base.cache.AreaCache
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil

/**
 * 单个区域的转换器
 */
class EasyExcelAreaConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将区域编码转换为区域id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val areas = AreaCache.getAreasByNameOrCode(context.readCellData.stringValue, AuthUtil.getTenantId())
        if (areas.isEmpty()) {
            throw IllegalArgumentException("区域编号或名称不存在: ${context.readCellData.stringValue}")
        } else if (areas.size > 1) {
            throw IllegalArgumentException("区域编号或名称重复，请使用唯一编号代替: ${context.readCellData.stringValue}")
        }
        return areas[0].id
    }

    /**
     * 将部门id转换为部门名称
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val area = AreaCache.getArea(context.value)
        return WriteCellData<Any>(area?.areaName?: "区域不存在")
    }
}
