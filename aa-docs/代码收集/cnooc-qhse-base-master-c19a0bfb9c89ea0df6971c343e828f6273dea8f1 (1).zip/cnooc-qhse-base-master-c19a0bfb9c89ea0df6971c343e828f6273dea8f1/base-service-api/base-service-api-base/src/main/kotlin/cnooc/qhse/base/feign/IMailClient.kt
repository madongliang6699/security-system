package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant.APP_NAME
import cnooc.qhse.base.pojo.dto.MailInfo
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.*

/**
 * 附件接口
 */
@FeignClient(value = APP_NAME)
interface IMailClient {
    companion object {
        const val API_PREFIX = "/feign/client/mail"
        const val SEND_SIMPLE_MAIL = "$API_PREFIX/send-simple-mail"
        const val SEND_HTML_MAIL = "$API_PREFIX/send-html-mail"
    }

    /**
     * 发送简单邮件
     */
    @PostMapping(SEND_SIMPLE_MAIL)
    fun sendSimpleMail(@RequestBody mailInfo: MailInfo): R<Boolean>

    /**
     * 发送HTML邮件
     */
    @PostMapping(SEND_HTML_MAIL)
    fun sendHtmlMail(@RequestBody mailInfo: MailInfo): R<Boolean>
}
