package cnooc.qhse.base.pojo.entity

import com.baomidou.mybatisplus.annotation.IdType
import com.baomidou.mybatisplus.annotation.TableId
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import jakarta.validation.constraints.NotBlank
import java.time.LocalDateTime

/**
 * APP报错信息表实体类
 */
@TableName("earnest_app_error")
@Schema(description = "APP报错信息表")
open class AppError(
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "主键id")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    open var id: Long? = null,
    @Schema(description = "手机型号")
    var phoneModel: String? = null,
    @Schema(description = "报错信息")
    @field:NotBlank(message = "报错信息不能为空")
    var errorInfo: String? = null,
    var createTime: LocalDateTime? = null
)
