package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.IBladeEnhancedClient
import cnooc.qhse.base.pojo.entity.AddressList
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.constant.CacheConstant
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import org.springblade.core.tool.utils.StringPool
import org.springblade.system.cache.UserCache

object BladeEnhancedCache {
    private const val USER_NAME_CACHE = "user:enhanced:name:"
    private const val POST_USER_IDS = "user:enhanced:post_user_ids:"
    private const val POST_CODES_BY_USER_ID = "user:enhanced:post_codes_by_user_id:"
    private const val POST_ID = "post:enhanced:post_id:"
    private const val ADDRESS_LIST = "user:enhanced:addresslist:"

    private var bladeEnhancedClient: IBladeEnhancedClient? = null

    private fun getBladeEnhancedClient(): IBladeEnhancedClient {
        if (bladeEnhancedClient == null) {
            bladeEnhancedClient = SpringUtil.getBean(IBladeEnhancedClient::class.java)
        }
        return bladeEnhancedClient!!
    }

    fun getUserName(id: Long): String {
        return CacheUtil.get(CacheConstant.USER_CACHE, USER_NAME_CACHE, id) {
            val user = UserCache.getUser(id)
            if (user != null) {
                return@get user.realName
            }
            ""
        } ?: ""
    }

    /**
     * 获取岗位关联的用户id列表
     *
     * @param postCode 岗位编码
     * @return user id list
     */
    fun getUserIdsByPostCode(postCode: String, tenantId: String): List<Long> {
        return CacheUtil.get(CacheConstant.USER_CACHE, POST_USER_IDS + StringPool.COLON + tenantId, postCode)
        { getBladeEnhancedClient().getUserIdsByPostCode(postCode, tenantId).retrieve() } ?: listOf()
    }

    /**
     * 获取用户关联的岗位编码
     *
     * @param userId 用户id
     * @return 岗位编码集合
     */
    fun getPostCodeByUserId(userId: Long): List<String> {
        return CacheUtil.get(CacheConstant.USER_CACHE, POST_CODES_BY_USER_ID, userId)
        { getBladeEnhancedClient().getPostCodeByUserId(userId).retrieve() } ?: listOf()
    }

    /**
     * 获取岗位编码对应的岗位id
     *
     * @param postCode 岗位编码
     * @return 岗位id
     */
    fun getPostIdByCode(postCode: String, tenantId: String): Long? {
        return CacheUtil.get(CacheConstant.SYS_CACHE, POST_ID + StringPool.COLON + tenantId, postCode)
        { getBladeEnhancedClient().getPostIdByCode(postCode, tenantId).retrieve() } // 返回值可能为null
    }

    /**
     * 获取通讯录
     */
    fun getAddressList(tenantId: String): List<AddressList> {
        return CacheUtil.get(CacheConstant.USER_CACHE, ADDRESS_LIST, tenantId)
        { getBladeEnhancedClient().getAddressList(tenantId).retrieve() } ?: listOf()
    }
}
