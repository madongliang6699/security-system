package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.entity.AlertConfig
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam

/**
 * 预警
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface IAlertConfigClient {
    companion object {
        const val API_PREFIX = "/feign/client/alert-config"
        const val ALERT_ALL_CONFIGS = "$API_PREFIX/alert-all-configs"
    }
    /**
     * 获取所有的预警配置列表
     */
    @GetMapping(ALERT_ALL_CONFIGS)
    fun getAlertConfigList(@RequestParam("tenantId") tenantId: String): R<List<AlertConfig>>
}
