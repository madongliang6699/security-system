package cnooc.qhse.base.constant

object BaseConstant {
    const val APP_NAME = "cnooc-qhse-base"
    const val AREA_CODE_LENGTH = 3 // 区域编码长度
    const val CATEGORY_CODE_LENGTH = 3 // 数据分类编码长度

    /**
     * 数据分类的代码与编号对应表
     */
    const val EARNEST_CATEGORY = "earnest_category"
}
