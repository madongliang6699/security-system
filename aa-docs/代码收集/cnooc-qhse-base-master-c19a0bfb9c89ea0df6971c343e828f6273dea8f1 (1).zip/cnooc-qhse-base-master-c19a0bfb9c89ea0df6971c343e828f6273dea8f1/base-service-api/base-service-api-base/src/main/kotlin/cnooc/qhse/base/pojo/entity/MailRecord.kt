package cnooc.qhse.base.pojo.entity

import com.baomidou.mybatisplus.annotation.IdType
import com.baomidou.mybatisplus.annotation.TableId
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 邮件发送记录
 */
@TableName("earnest_mail_record")
@Schema(description = "邮件发送记录")
open class MailRecord(
    @field:JsonSerialize(using = ToStringSerializer::class)
    @Schema(description = "主键id")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    open var id: Long? = null,
    @Schema(description = "主题")
    var subject: String? = null,
    @Schema(description = "内容")
    var content: String? = null,
    @Schema(description = "收件人")
    var recipient: String? = null,
    @Schema(description = "抄送人")
    var ccs: String? = null,
    @Schema(description = "密送人")
    var bccs: String? = null,
    @Schema(description = "发送时间")
    var sendTime: LocalDateTime? = null,
    @Schema(description = "发送时间")
    var tenantId: String? = null
)
