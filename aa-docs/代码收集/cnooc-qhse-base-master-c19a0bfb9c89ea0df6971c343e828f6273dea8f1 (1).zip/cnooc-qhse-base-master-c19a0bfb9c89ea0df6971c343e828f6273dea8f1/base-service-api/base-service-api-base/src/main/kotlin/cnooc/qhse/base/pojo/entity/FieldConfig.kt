package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableField
import com.baomidou.mybatisplus.annotation.TableName
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler
import com.fasterxml.jackson.databind.JsonNode
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 字段控制表实体类
 */
@TableName("earnest_field_config", autoResultMap = true)
@Schema(description = "字段控制表")
open class FieldConfig(
    @Schema(description = "表单或列表的名称")
    var formTableName: String? = null,
    @Schema(description = "方案")
    @TableField(typeHandler = JacksonTypeHandler::class)
    var scheme: JsonNode? = null,
    @Schema(description = "备注")
    var remark: String? = null,
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
