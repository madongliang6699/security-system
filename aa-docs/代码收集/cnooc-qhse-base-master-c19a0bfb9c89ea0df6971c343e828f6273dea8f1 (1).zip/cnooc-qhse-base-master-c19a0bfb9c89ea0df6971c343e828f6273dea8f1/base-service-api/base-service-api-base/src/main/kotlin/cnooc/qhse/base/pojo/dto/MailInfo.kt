package cnooc.qhse.base.pojo.dto

/**
 * mail实体类
 */
class MailInfo(
    //邮件标题
    var subject: String? = null,
    //邮件正文
    var content: String? = null,
    //收件人
    var recipients: List<String>? = null,
    //抄送人
    var ccs: List<String>? = null,
    //密件抄送人
    var bccs: List<String>? = null,
    //是否为邮件组-默认不分组
    var isGroup: Boolean = false,
    //租户
    var tenantId: String? = null
)
