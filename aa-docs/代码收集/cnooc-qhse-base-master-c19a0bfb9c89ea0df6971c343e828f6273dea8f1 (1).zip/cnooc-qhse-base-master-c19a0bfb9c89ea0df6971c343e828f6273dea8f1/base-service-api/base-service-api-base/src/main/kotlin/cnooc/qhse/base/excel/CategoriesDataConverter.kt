package cnooc.qhse.base.excel

import cnooc.qhse.base.cache.CategoryDataCache
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func

/**
 * 多个数据分类的转换器
 */
class CategoriesDataConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将数据分类编码转换为分类id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }

        val categories = Func.toStrList(context.readCellData.stringValue).mapNotNull {
            CategoryDataCache.getCategoryByCode(AuthUtil.getTenantId(), it)
        }
        if (categories.size != Func.toStrList(context.readCellData.stringValue).size) {
            throw IllegalArgumentException("解析后的分类数量与指定的分类数量不一致: ${context.readCellData.stringValue}")
        }
        return Func.join(categories.map { it.id })
    }

    /**
     * 将数据分类id转换为分类编码
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val categories = Func.toLongList(context.value).mapNotNull { CategoryDataCache.getCategory(it) }
        return WriteCellData<Any>(Func.join(categories.map { it.categoryName}))
    }
}
