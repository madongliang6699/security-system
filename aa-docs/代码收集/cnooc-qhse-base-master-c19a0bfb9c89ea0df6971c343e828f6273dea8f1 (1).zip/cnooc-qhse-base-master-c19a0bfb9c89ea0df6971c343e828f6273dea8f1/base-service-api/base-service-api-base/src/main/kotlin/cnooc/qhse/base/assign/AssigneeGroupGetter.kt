package cnooc.qhse.base.assign

import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUP_ITEM_SPLITTER
import cnooc.qhse.base.assign.AssigneeConstant.ASSIGN_GROUP_TENANT_SPLITTER
import cnooc.qhse.base.cache.AreaCache
import cnooc.qhse.base.cache.ShiftCache
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func
import org.springblade.system.cache.SysCache
import org.springblade.system.cache.UserCache

object AssigneeGroupGetter {
    /**
     * 获取用户的岗位分组
     * @return 分组列表，比如["POST_CODE|班长"]
     */
    fun getUserPostCodeGroups(userId: Long): List<String> {
        val user = UserCache.getUser(userId) ?: return listOf()
        if (user.postId.isNullOrBlank()) return listOf()
        val posts = Func.toLongList(user.postId).mapNotNull { SysCache.getPost(it) }
        return posts.map { AssigneePrefix.POST_CODE.code + ASSIGN_GROUP_ITEM_SPLITTER + it.postCode }
    }
    /**
     * 获取用户的岗位分组+租户
     * @return 分组列表，比如["POST_CODE|111111-班长"]
     */
    private fun getUserPostCodeGroupsAndTenant(userId: Long): List<String> {

        val user = UserCache.getUser(userId) ?: return listOf()
        if (user.postId.isNullOrBlank()) return listOf()
        val posts = Func.toLongList(user.postId).mapNotNull { SysCache.getPost(it) }
        val tenantId= AuthUtil.getTenantId()
        return posts.map { AssigneePrefix.POST_CODE.code + ASSIGN_GROUP_ITEM_SPLITTER +
                tenantId + ASSIGN_GROUP_TENANT_SPLITTER + it.postCode }
    }
    /**
     * 获取用户的id分组
     * @return 分组列表，比如["USER_ID|1"]
     */
    fun getUserIdGroups(userId: Long): String {
        return AssigneePrefix.USER_ID.code + ASSIGN_GROUP_ITEM_SPLITTER + userId
    }

    /**
     * 获取用户帐号分组
     * @return 分组列表，比如["USER_ACCOUNT|admin"]
     */
    fun getUserAccountGroup(userId: Long): String {
        val user = UserCache.getUser(userId) ?: return ""
        return AssigneePrefix.USER_ACCOUNT.code + ASSIGN_GROUP_ITEM_SPLITTER + user.account
    }

    /**
     * 获取用户的角色的id分组
     */
    fun getRoleIdGroups(userId: Long): List<String> {
        val user = UserCache.getUser(userId)
        if (user == null || user.roleId.isNullOrBlank()) return listOf()
        val roleIds = Func.toLongList(user.roleId)
        return roleIds.map { AssigneePrefix.ROLE_ID.code + ASSIGN_GROUP_ITEM_SPLITTER + it }
    }


    /**
     * 获取用户的角色名称分组
     */
    fun getRoleNameGroups(userId: Long): List<String> {
        val user = UserCache.getUser(userId)
        if (user == null || user.roleId.isNullOrBlank()) return listOf()
        val roleNames = SysCache.getRoleNames(user.roleId) ?: return listOf()
        return roleNames.map { AssigneePrefix.ROLE_NAME.code + ASSIGN_GROUP_ITEM_SPLITTER + it }
    }

    /**
     * 获取用户的区域管理员编码岗位分组
     * @return 分组列表，比如["AREA_MANAGER_CODE|区域1"]
     */
    fun getAreaAdminPostCodeGroups(userId: Long): List<String> {
        val areas = AreaCache.getAreasByUserId(userId)
        if (areas.isEmpty()) return listOf()
        return areas.map { AssigneePrefix.AREA_MANAGER_CODE.code + ASSIGN_GROUP_ITEM_SPLITTER + it.areaCode }
    }

    /**
     * 获取用户的角色名称分组+租户
     */
    private fun getRoleNameGroupsAndTenant(userId: Long): List<String> {

        val user = UserCache.getUser(userId)
        if (user == null || user.roleId.isNullOrBlank()) return listOf()
        val roleNames = SysCache.getRoleNames(user.roleId) ?: return listOf()
        val tenantId=AuthUtil.getTenantId()
        return roleNames.map { AssigneePrefix.ROLE_NAME.code + ASSIGN_GROUP_ITEM_SPLITTER +
                tenantId + ASSIGN_GROUP_TENANT_SPLITTER + it }
    }

    /**
     * 获取用户的区域管理员id分组
     * @return 分组列表，比如["AREA_MANAGER_ID|1"]
     */
    fun getAreaAdminIdGroups(userId: Long): List<String> {
        val areas = AreaCache.getAreasByUserId(userId)
        if (areas.isEmpty()) return listOf()
        return areas.map {
            AssigneePrefix.AREA_MANAGER_ID.code + ASSIGN_GROUP_ITEM_SPLITTER + it.id
        }
    }

    /**
     * 获取用户的部门id分组
     * @return 分组列表，比如["DEPT_ID|1"]
     */
    fun getDeptIdGroups(userId: Long): List<String> {
        val user = UserCache.getUser(userId) ?: return listOf()
        if (user.deptId.isNullOrBlank()) return listOf()
        return Func.toStrList(user.deptId)
            .map { AssigneePrefix.DEPART_ID.code + ASSIGN_GROUP_ITEM_SPLITTER + it }
    }

    /**
     * 获取用户的部门名称分组
     * @return 分组列表，比如["DEPT_NAME|部门1"]
     */
    fun getDeptNameGroups(userId: Long): List<String> {
        val user = UserCache.getUser(userId) ?: return listOf()
        if (user.deptId.isNullOrBlank()) return listOf()
        val deptNames = SysCache.getDeptNames(user.deptId) ?: return listOf()
        return deptNames.map { AssigneePrefix.DEPART_NAME.code + ASSIGN_GROUP_ITEM_SPLITTER + it }
    }

    /**
     * 获取用户的部门名称分组+租户
     * @return 分组列表，比如["DEPT_NAME|111111-部门1"]
     */
    private fun getDeptNameGroupsAndTenant(userId: Long): List<String> {
        val user = UserCache.getUser(userId) ?: return listOf()
        if (user.deptId.isNullOrBlank()) return listOf()
        val deptNames = SysCache.getDeptNames(user.deptId) ?: return listOf()
        val tenantId=AuthUtil.getTenantId()
        return deptNames.map { AssigneePrefix.DEPART_NAME.code + ASSIGN_GROUP_ITEM_SPLITTER +
                tenantId + ASSIGN_GROUP_TENANT_SPLITTER + it }
    }




    /**
     * 获取用户的值班编码分组
     * @return 分组列表，比如["SHIFT_CODE|班长"]
     */
    fun getShiftCodeGroups(userId: Long): List<String> {
        val shiftCodes = ShiftCache.getShiftCodeByUserId(userId)
        return shiftCodes.map { AssigneePrefix.SHIFT_CODE.code + ASSIGN_GROUP_ITEM_SPLITTER + it }
    }

    /**
     * 获取用户的值班编码分组
     * @return 分组列表，比如["SHIFT_CODE|班长"]
     */
    fun getShiftCodeGroupsAndTenant(userId: Long): List<String> {
        val shiftCodes = ShiftCache.getShiftCodeByUserId(userId)
        val tenantId=AuthUtil.getTenantId()
        return shiftCodes.map { AssigneePrefix.SHIFT_CODE.code + ASSIGN_GROUP_ITEM_SPLITTER +
                tenantId + ASSIGN_GROUP_TENANT_SPLITTER+ it }
    }


    /**
     * 获取用户的候选分组
     */
    fun getUserCandidateGroups(userId: Long): List<String> {
        val groups = listOf(getUserIdGroups(userId), getUserAccountGroup(userId)) +  getRoleIdGroups(userId) + getRoleNameGroups(userId) +
                getUserPostCodeGroups(userId) + getAreaAdminPostCodeGroups(userId) + getAreaAdminIdGroups(userId) +
                getDeptIdGroups(userId) + getDeptNameGroups(userId) + getShiftCodeGroups(userId)+
                getRoleNameGroupsAndTenant(userId) + getUserPostCodeGroupsAndTenant(userId)+ getDeptNameGroupsAndTenant(userId)+
                getShiftCodeGroupsAndTenant(userId)
        val tenantId = AuthUtil.getTenantId()
        val tenantAddedGroups = groups.map { tenantId + ASSIGN_GROUP_TENANT_SPLITTER + AuthUtil.getTenantId() }
        return groups + tenantAddedGroups
    }
}
