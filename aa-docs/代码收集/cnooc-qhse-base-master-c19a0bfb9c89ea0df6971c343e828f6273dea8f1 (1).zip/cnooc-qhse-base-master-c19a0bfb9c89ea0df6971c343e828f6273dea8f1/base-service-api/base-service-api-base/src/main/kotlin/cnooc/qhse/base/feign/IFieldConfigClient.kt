package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.vo.FieldConfigVO
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam

/**
 * 字段配置
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface IFieldConfigClient {
    companion object {
        const val API_PREFIX = "/feign/client/field-config"
        const val FIELD_ALL_CONFIGS = "$API_PREFIX/field-all-configs"
    }
    /**
     * 获取所有的字段配置列表
     */
    @GetMapping(FIELD_ALL_CONFIGS)
    fun getAllFieldConfigs(@RequestParam("tenantId") tenantId: String): R<List<FieldConfigVO>>
}
