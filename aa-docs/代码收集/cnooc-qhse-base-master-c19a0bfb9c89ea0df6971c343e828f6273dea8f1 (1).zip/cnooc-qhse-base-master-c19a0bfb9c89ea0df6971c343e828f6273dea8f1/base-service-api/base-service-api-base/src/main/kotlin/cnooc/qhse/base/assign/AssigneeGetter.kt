package cnooc.qhse.base.assign

/**
 * 任务执行人获取器
 * 可以根据前缀选择相应的方法然后获取用户列表
 */
data class AssigneeGetter(
    /**
     * 用户变量前缀，去除后获取的值根据getUserId可以获取用户id
     */
    val prefix: AssigneePrefix,

    /**
     * 获取用户id，传递的值为去除前缀后的值，通过此方法可以获取用户id
     */
    val getUserIds: (value: String, tenantId: String) -> List<Long>,

    /**
     * 获取用户或用户组的名称，传递的值为去除前缀后的值，通过此方法可以获取用户或用户组的名称
     */
    val getUserNames: (value: String, tenantId: String) -> String?
)
