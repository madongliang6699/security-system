package cnooc.qhse.base.cache

import cnooc.qhse.base.feign.IFieldConfigClient
import cnooc.qhse.base.pojo.vo.FieldConfigVO
import cnooc.qhse.common.utils.retrieve
import org.springblade.core.cache.utils.CacheUtil
import org.springblade.core.tool.utils.SpringUtil
import kotlin.jvm.java

/**
 * 字段配置缓存
 */
object FieldConfigCache {
    const val FIELD_CONFIG_CACHE = "field_config:field_config"
    private const val FIELD_CONFIG_ALL = "all"

    private var fieldConfigClient: IFieldConfigClient? = null

    fun getFieldConfigClient(): IFieldConfigClient {
        if (fieldConfigClient == null) {
            fieldConfigClient = SpringUtil.getBean(IFieldConfigClient::class.java)
        }
        return fieldConfigClient!!
    }

    fun getAllFieldConfigs(tenantId: String): List<FieldConfigVO> {
        return CacheUtil.get(FIELD_CONFIG_CACHE, FIELD_CONFIG_ALL, tenantId)
        {
            getFieldConfigClient().getAllFieldConfigs(tenantId).retrieve()
        }
            ?: listOf()
    }
}
