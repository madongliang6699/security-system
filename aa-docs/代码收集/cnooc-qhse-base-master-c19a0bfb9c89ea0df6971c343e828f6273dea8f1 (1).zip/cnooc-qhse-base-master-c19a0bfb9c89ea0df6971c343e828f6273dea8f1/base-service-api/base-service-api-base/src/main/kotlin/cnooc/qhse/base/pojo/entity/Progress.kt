package cnooc.qhse.base.pojo.entity

import org.springblade.core.cache.utils.CacheUtil
import java.io.Serializable

/**
 * 处理的进度，用于反馈给前端某一个任务的处理进度
 */
data class Progress(
    /**
     * redis的缓存key
     */
    val key: String,
    val progress: Int = 0, // 进度
    val status: Status = Status.Start, // 状态
    val message: String? = null // 信息
) : Serializable {
    enum class Status(val value: Int) {
        Loading(0), Success(1), Fail(-1), Start(-2);
    }

    fun fail(msg: String?): Progress {
        val progress = this.copy(status = Status.Fail, message = msg)
        writeCache(progress)
        return progress
    }

    fun success(msg: String): Progress {
        val progress = this.copy(status = Status.Success, progress = 100, message = msg)
        writeCache(progress)
        return progress
    }

    fun success(): Progress {
        val progress = this.copy(status = Status.Success, progress = 100)
        writeCache(progress)
        return progress
    }

    /**
     * 进行到百分之多少了
     */
    fun progress(progress: Int): Progress {
        val p = this.copy(progress = progress, status = Status.Loading)
        writeCache(p)
        return p
    }

    /**
     * 进行到百分之多少了，并且提示信息
     */
    fun progress(progress: Int, message: String): Progress {
        val p = this.copy(progress = progress, status = Status.Loading, message = message)
        writeCache(p)
        return p
    }

    val isLoading: Boolean
        get() = status == Status.Loading

    val isSuccess: Boolean
        get() = status == Status.Success

    val isFail: Boolean
        get() = status == Status.Fail

    companion object {
        const val ProgressCache = "ProgressCache"

        private fun writeCache(progress: Progress) {
            CacheUtil.put(ProgressCache, progress.key, progress.key, progress)
        }

        /**
         * 返回key对应的进度对象
         */
        @JvmStatic
        fun of(key: String): Progress {
            val obj = CacheUtil.get(ProgressCache, key, key) as Progress?
            return obj ?: Progress(key)
        }
    }
}
