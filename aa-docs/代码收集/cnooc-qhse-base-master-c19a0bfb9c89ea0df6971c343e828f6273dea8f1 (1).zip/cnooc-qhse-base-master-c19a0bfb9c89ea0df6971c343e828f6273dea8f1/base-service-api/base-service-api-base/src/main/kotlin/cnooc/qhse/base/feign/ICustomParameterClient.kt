package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.vo.CustomParameterVO
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam

/**
 *
 * @author AnJs
 * @date 2024/10/21
 * @Description 自定义参数接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface ICustomParameterClient {

    companion object {
        const val API_PREFIX = "/feign/client/parameter"
        const val PARAMETER_BY_KEY = "$API_PREFIX/parameter"

    }

    /**
     * 根据参数key查询参数值
     */
    @GetMapping(PARAMETER_BY_KEY)
    fun getValueByParameterKey(@RequestParam("moduleCode") moduleCode: String,
                               @RequestParam("parameterKey") parameterKey: String,
                               @RequestParam("tenantId") tenantId: String): R<CustomParameterVO?>

}
