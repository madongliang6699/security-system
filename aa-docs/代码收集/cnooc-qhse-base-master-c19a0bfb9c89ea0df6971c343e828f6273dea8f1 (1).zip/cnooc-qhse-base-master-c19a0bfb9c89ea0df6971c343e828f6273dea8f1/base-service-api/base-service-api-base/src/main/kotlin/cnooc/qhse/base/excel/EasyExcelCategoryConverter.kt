package cnooc.qhse.base.excel

import cnooc.qhse.base.cache.CategoryDataCache
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil

/**
 * 单个数据分类的转换器
 * 支持单元格中是分类编码，也支持单元格中是分类名称
 */
class EasyExcelCategoryConverter : Converter<Long> {
    override fun supportJavaTypeKey(): Class<*> {
        return Long::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将数据分类编码转换为分类id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): Long? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }
        val category = CategoryDataCache.getCategoryByCode(context.readCellData.stringValue, AuthUtil.getTenantId())
        if (category == null) {
            val categories = CategoryDataCache.getCategoriesByName(context.readCellData.stringValue, AuthUtil.getTenantId())
            if (categories.size == 1) {
                return categories[0].id
            } else if (categories.size > 1) {
                throw IllegalArgumentException("分类名称不唯一: ${context.readCellData.stringValue}")
            } else {
                throw IllegalArgumentException("分类不存在: ${context.readCellData.stringValue}")
            }
        }
        return category.id
    }

    /**
     * 将分类id转换为分类编码
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<Long>): WriteCellData<*> {
        if (context.value == null) {
            return WriteCellData<Any>("")
        }
        val category = CategoryDataCache.getCategory(context.value)
        return WriteCellData<Any>(category?.categoryName ?: "分类不存在")
    }
}
