package cnooc.qhse.base.pojo.vo

import cnooc.qhse.base.pojo.entity.ShiftLog
import io.swagger.v3.oas.annotations.media.Schema
import java.time.LocalDateTime

/**
 * 交接班日志视图实体类
 */
@Schema(description = "交接班日志")
class ShiftLogVO(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    code: String? = null,
    name: String? = null,
    oldUserId: Long? = null,
    newUserId: Long? = null,
    record: String? = null,
    remark: String? = null,
    @Schema(description = "上一个用户姓名") var oldUserName: String? = null,
    @Schema(description = "接班用户姓名") var newUserName: String? = null
) : ShiftLog(
    id,
    createUser,
    createDept,
    createTime,
    updateUser,
    updateTime,
    status,
    isDeleted,
    tenantId,
    code,
    name,
    oldUserId,
    newUserId,
    record,
    remark
)
