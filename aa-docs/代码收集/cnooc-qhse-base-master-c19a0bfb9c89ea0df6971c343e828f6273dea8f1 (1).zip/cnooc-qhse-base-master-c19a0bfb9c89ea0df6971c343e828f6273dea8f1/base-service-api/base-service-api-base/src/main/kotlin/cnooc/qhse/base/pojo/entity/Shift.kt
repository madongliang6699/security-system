package cnooc.qhse.base.pojo.entity

import cnooc.qhse.common.entity.TenantEntityKt
import com.baomidou.mybatisplus.annotation.TableName
import com.fasterxml.jackson.annotation.JsonFormat
import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.JsonSerialize
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer
import io.swagger.v3.oas.annotations.media.Schema
import org.springblade.core.tool.utils.DateUtil
import org.springframework.format.annotation.DateTimeFormat
import java.time.LocalDateTime

/**
 * 交接班实体类
 */
@TableName("earnest_shift")
@Schema(description = "交接班")
open class Shift(
    id: Long? = null,
    createUser: Long? = null,
    createDept: Long? = null,
    createTime: LocalDateTime? = null,
    updateUser: Long? = null,
    updateTime: LocalDateTime? = null,
    status: Int? = null,
    isDeleted: Int? = null,
    tenantId: String? = null,
    /**
     * 编码
     */
    @Schema(description = "编码")
    var code: String? = null,

    /**
     * 名称
     */
    @Schema(description = "名称")
    var name: String? = null,

    /**
     * 用户ID
     */
    @Schema(description = "用户ID")
    @JsonSerialize(using = ToStringSerializer::class)
    var userId: Long? = null,

    /**
     * 最长工作时间
     */
    @Schema(description = "最长工作时间")
    var workTime: Int? = null,

    @Schema(description = "最近交接时间")
    @field:DateTimeFormat(pattern = DateUtil.PATTERN_DATETIME)
    @field:JsonFormat(pattern = DateUtil.PATTERN_DATETIME)
    var shiftTime: LocalDateTime? = null,

    @Schema(description = "工作记录")
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    var record: String? = null,

    @Schema(description = "是否内置")
    var builtIn: Boolean? = null,

    @Schema(description = "备注")
    var remark: String? = null,
) : TenantEntityKt(id, createUser, createDept, createTime, updateUser, updateTime, status, isDeleted, tenantId) {
    companion object {
        private const val serialVersionUID = 1L
    }
}
