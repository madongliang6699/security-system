package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.entity.AddressList
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam

/**
 * Blade功能增强接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface IBladeEnhancedClient {
    companion object {
        const val API_PREFIX = "/feign/client/blade-enhanced"
        const val USER_IDS_BY_POST_CODE = "$API_PREFIX/user-ids-by-post-code"
        const val POST_CODE_BY_USER_ID = "$API_PREFIX/post-code/user/{userId}"
        const val POST_ID_BY_CODE = "$API_PREFIX/post-id-by-code"
        const val ADDRESS_LIST = "$API_PREFIX/address-list"
    }
    /**
     * 根据用户岗位获取用户id列表
     */
    @GetMapping(USER_IDS_BY_POST_CODE)
    fun getUserIdsByPostCode(@RequestParam("postCode") postCode: String, @RequestParam("tenantId") tenantId: String): R<List<Long>>

    /**
     * 根据用户id获取岗位编码
     */
    @GetMapping(POST_CODE_BY_USER_ID)
    fun getPostCodeByUserId(@PathVariable userId: Long): R<List<String>>

    /**
     * 根据岗位编码获取岗位id
     */
    @GetMapping(POST_ID_BY_CODE)
    fun getPostIdByCode(@RequestParam("postCode") postCode: String, @RequestParam("tenantId") tenantId: String): R<Long?>

    /**
     * 获取通讯录
     */
    @GetMapping(ADDRESS_LIST)
    fun getAddressList(@RequestParam("tenantId") tenantId: String): R<List<AddressList>>
}
