package cnooc.qhse.base.excel

import cnooc.qhse.base.cache.AreaCache
import com.alibaba.excel.converters.Converter
import com.alibaba.excel.converters.ReadConverterContext
import com.alibaba.excel.converters.WriteConverterContext
import com.alibaba.excel.enums.CellDataTypeEnum
import com.alibaba.excel.metadata.data.WriteCellData
import org.springblade.core.secure.utils.AuthUtil
import org.springblade.core.tool.utils.Func

/**
 * 多个区域的转换器
 */
class EasyExcelAreasConverter : Converter<String> {
    override fun supportJavaTypeKey(): Class<*> {
        return String::class.java
    }

    override fun supportExcelTypeKey(): CellDataTypeEnum {
        return CellDataTypeEnum.STRING
    }

    /**
     * 将区域编码转换为区域id
     *
     * @param context
     * @return
     */
    override fun convertToJavaData(context: ReadConverterContext<*>): String? {
        if (context.readCellData.stringValue.isNullOrBlank()) {
            return null
        }

        val areas = Func.toStrList(context.readCellData.stringValue).flatMap {
            AreaCache.getAreasByNameOrCode(it, AuthUtil.getTenantId())
        }
        if (areas.size != Func.toStrList(context.readCellData.stringValue).size) {
            throw IllegalArgumentException("解析后的区域数量与指定的区域数量不一致: ${context.readCellData.stringValue}")
        }
        return Func.join(areas.map { it.id })
    }

    /**
     * 将区域id转换为区域编码
     *
     * @return
     */
    override fun convertToExcelData(context: WriteConverterContext<String>): WriteCellData<*> {
        if (context.value.isNullOrBlank()) {
            return WriteCellData<Any>("")
        }
        val areas = Func.toLongList(context.value).mapNotNull { AreaCache.getArea(it)}
        return WriteCellData<Any>(Func.join(areas.map { it.areaName }))
    }
}
