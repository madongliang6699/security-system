package cnooc.qhse.base.feign

import cnooc.qhse.base.constant.BaseConstant
import cnooc.qhse.base.pojo.entity.CategoryData
import cnooc.qhse.base.pojo.vo.CategoryDataVO
import org.springblade.core.tool.api.R
import org.springframework.cloud.openfeign.FeignClient
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam

/**
 * 数据分类接口
 */
@FeignClient(value = BaseConstant.APP_NAME)
interface ICategoryDataClient {
    companion object {
        const val API_PREFIX = "/feign/client/category-data"
        const val CATEGORY_BY_ID = "$API_PREFIX/category-by-id/{id}"
        const val CATEGORY_BY_CODE = "$API_PREFIX/category-by-code/{code}"
        const val CATEGORY_PATH_NAME_BY_ID = "$API_PREFIX/category-path-name/{id}"
        const val CATEGORY_TREE = "$API_PREFIX/category-tree/{tenantId}"
        const val CATEGORY_SINGLE_TREE = "$API_PREFIX/category-single-tree/{rootCode}"
        const val CATEGORIES_BY_NAME = "$API_PREFIX/categories-by-name"
    }

    /**
     * 根据id查询区域
     */
    @GetMapping(CATEGORY_BY_ID)
    fun getCategoryById(@PathVariable id: Long): R<CategoryData?>

    /**
     * 根据code查询区域
     */
    @GetMapping(CATEGORY_BY_CODE)
    fun getCategoryByCode(@PathVariable code: String, @RequestParam tenantId: String): R<CategoryData?>

    /**
     * 根据id查询区域路径名称
     */
    @GetMapping(CATEGORY_PATH_NAME_BY_ID)
    fun getCategoryPathNameById(@PathVariable id: Long): R<String>

    /**
     * 获取区域树
     */
    @GetMapping(CATEGORY_TREE)
    fun getCategoryTree(@PathVariable tenantId: String): R<List<CategoryDataVO>>

    /**
     * 获取分类区域树
     */
    @GetMapping(CATEGORY_SINGLE_TREE)
    fun getCategorySingleTree(@PathVariable rootCode: String, @RequestParam tenantId: String): R<List<CategoryDataVO>>

    /**
     * 根据名称查询分类列表
     */
    @GetMapping(CATEGORIES_BY_NAME)
    fun getCategoriesByName(@RequestParam name: String, @RequestParam tenantId: String): R<List<CategoryData>>
}
