package cnooc.qhse.xxljob.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Data
@ConfigurationProperties(prefix = "xxl.job.sdk")
@Configuration
@Primary
public class XxlJobAdminProperties {
    private String adminUrl = "http://localhost:8080/xxl-job-admin";
    private String userName = "admin";
    private String password = "123456";
    private Integer connectionTimeOut = 5000;

    //执行器AppName [选填]：执行器心跳注册分组依据；为空则关闭自动注册
    private String appname;
    //执行器通讯TOKEN [选填]：非空时启用；
    private String accessToken;
    //执行器注册 [选填]：优先使用该配置作为注册地址，为空时使用内嵌服务 ”IP:PORT“ 作为注册地址。从而更灵活的支持容器类型执行器动态IP和动态映射端口问题。
    private String address;
    //执行器IP [选填]：默认为空表示自动获取IP，多网卡时可手动设置指定IP，该IP不会绑定Host仅作为通讯实用；地址信息用于 "执行器注册" 和 "调度中心请求并触发任务"；
    private String ip;
    //执行器端口号 [选填]：小于等于0则自动获取；默认端口为9999，单机部署多个执行器时，注意要配置不同执行器端口；
    private Integer port;
    //执行器运行日志文件存储磁盘路径 [选填] ：需要对该路径拥有读写权限；为空则使用默认路径；
    private String logPath;
    //执行器日志文件保存天数 [选填] ： 过期日志自动清理, 限制值大于等于3时生效; 否则, 如-1, 关闭自动清理功能；
    private Integer logRetentionDays = 30;

    //执行器名称 [选填]：新增执行器依据；为空则关闭自动新增
    private String groupTitle;
    //执行器地址注册方式 [选填]：0：自动注册，1：手动录入 默认自动
    private Integer addressType = 0;
    //执行器地址列表 [选填]：地址注册方式为手动时必填,多地址逗号分隔
    private String addressList;

}
