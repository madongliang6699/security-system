package cnooc.qhse.base.common.cache

/**
 * 缓存名
 *
 * @author Chill
 */
object CacheNames {

}
