package cnooc.qhse.base.common.constant

/**
 * 通用常量
 *
 * @author Chill
 */
object CommonConstant {
    /**
     * 默认密码
     */
    const val DEFAULT_PASSWORD = "4a#nVr7kVT87"
}
