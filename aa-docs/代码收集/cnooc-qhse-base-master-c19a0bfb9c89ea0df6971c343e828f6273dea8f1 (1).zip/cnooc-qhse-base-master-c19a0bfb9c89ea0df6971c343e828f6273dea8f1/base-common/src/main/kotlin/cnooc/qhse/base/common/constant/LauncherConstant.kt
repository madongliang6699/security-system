package cnooc.qhse.base.common.constant

import org.springblade.core.launch.constant.AppConstant
import org.springblade.core.launch.constant.AppConstant.APPLICATION_NAME_PREFIX

/**
 * 通用常量
 *
 * @author Chill
 */
object LauncherConstant {
    /**
     * seata 服务组格式
     *
     * @param appName 服务名
     * @return group
     */
    @JvmStatic
    fun seataServiceGroup(appName: String): String {
        return appName + GROUP_NAME
    }

    /**
     * 动态获取nacos地址
     *
     * @param profile 环境变量
     * @return addr
     */
    @JvmStatic
    fun nacosAddr(profile: String): String {
        when (profile) {
            (AppConstant.PROD_CODE) -> return NACOS_PROD_ADDR
            (AppConstant.TEST_CODE) -> return NACOS_TEST_ADDR
            else -> return NACOS_DEV_ADDR
        }
    }

    /**
     * 动态获取sentinel地址
     *
     * @param profile 环境变量
     * @return addr
     */
    @JvmStatic
    fun sentinelAddr(profile: String): String {
        when (profile) {
            (AppConstant.PROD_CODE) -> return SENTINEL_PROD_ADDR
            (AppConstant.TEST_CODE) -> return SENTINEL_TEST_ADDR
            else -> return SENTINEL_DEV_ADDR
        }
    }

    /**
     * 动态获取seata地址
     *
     * @param profile 环境变量
     * @return addr
     */
    @JvmStatic
    fun seataAddr(profile: String): String {
        when (profile) {
            (AppConstant.PROD_CODE) -> return SEATA_PROD_ADDR
            (AppConstant.TEST_CODE) -> return SEATA_TEST_ADDR
            else -> return SEATA_DEV_ADDR
        }
    }

    /**
     * nacos 用户名
     */
    const val NACOS_USERNAME: String = "nacos"

    /**
     * nacos 密码
     */
    const val NACOS_PASSWORD: String = "nacos"

    /**
     * xxljob
     */
    val APPLICATION_XXLJOB_NAME: String = APPLICATION_NAME_PREFIX + "xxljob"

    /**
     * xxljob
     */
    val APPLICATION_XXLJOB_ADMIN_NAME: String = APPLICATION_NAME_PREFIX + "xxljob-admin"

    /**
     * nacos namespace id
     */
    const val NACOS_NAMESPACE: String = "f447a694-519a-4255-95f9-bcbb5a5d6369"

    /**
     * nacos dev 地址
     */
    const val NACOS_DEV_ADDR: String = "100.64.0.3:8848"

    /**
     * nacos prod 地址
     */
    const val NACOS_PROD_ADDR: String = "172.30.0.48:8848"

    /**
     * nacos test 地址
     */
    const val NACOS_TEST_ADDR: String = "100.64.0.3:8848"

    /**
     * sentinel dev 地址
     */
    const val SENTINEL_DEV_ADDR: String = "127.0.0.1:8858"

    /**
     * sentinel prod 地址
     */
    const val SENTINEL_PROD_ADDR: String = "172.30.0.58:8858"

    /**
     * sentinel test 地址
     */
    const val SENTINEL_TEST_ADDR: String = "172.30.0.58:8858"

    /**
     * seata dev 地址
     */
    const val SEATA_DEV_ADDR: String = "127.0.0.1:8091"

    /**
     * seata prod 地址
     */
    const val SEATA_PROD_ADDR: String = "172.30.0.68:8091"

    /**
     * seata test 地址
     */
    const val SEATA_TEST_ADDR: String = "172.30.0.68:8091"

    /**
     * dbuuo提供者
     */
    val APPLICATION_DUBBO_PROVIDER_NAME: String = APPLICATION_NAME_PREFIX + "dubbo-provider"

    /**
     * dbuuo消费者
     */
    val APPLICATION_DUBBO_CONSUMER_NAME: String = APPLICATION_NAME_PREFIX + "dubbo-consumer"

    /**
     * seata订单
     */
    val APPLICATION_SEATA_ORDER_NAME: String = APPLICATION_NAME_PREFIX + "seata-order"

    /**
     * seata库存
     */
    val APPLICATION_SEATA_STORAGE_NAME: String = APPLICATION_NAME_PREFIX + "seata-storage"

    /**
     * easypoi
     */
    val APPLICATION_EASYPOI_NAME: String = APPLICATION_NAME_PREFIX + "easypoi"

    /**
     * kafka
     */
    val APPLICATION_KAFKA_NAME: String = APPLICATION_NAME_PREFIX + "kafka"

    /**
     * rabbit
     */
    val APPLICATION_RABBIT_NAME: String = APPLICATION_NAME_PREFIX + "rabbit"

    /**
     * stream消费者
     */
    val APPLICATION_STREAM_CONSUMER_NAME: String = APPLICATION_NAME_PREFIX + "stream-consumer"

    /**
     * stream生产者
     */
    val APPLICATION_STREAM_PROVIDER_NAME: String = APPLICATION_NAME_PREFIX + "stream-provider"

    /**
     * seata file模式
     */
    const val FILE_MODE: String = "file"

    /**
     * seata nacos模式
     */
    const val NACOS_MODE: String = "nacos"

    /**
     * seata default模式
     */
    const val DEFAULT_MODE: String = "default"

    /**
     * seata group后缀
     */
    const val GROUP_NAME: String = "-group"
}
