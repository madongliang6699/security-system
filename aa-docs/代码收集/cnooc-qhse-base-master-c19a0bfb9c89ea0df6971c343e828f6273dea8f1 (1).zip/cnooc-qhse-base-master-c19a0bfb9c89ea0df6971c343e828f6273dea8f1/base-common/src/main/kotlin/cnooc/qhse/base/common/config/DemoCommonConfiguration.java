
package cnooc.qhse.base.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * 公共封装包配置类
 *
 */
@Configuration(proxyBeanMethods = false)
public class DemoCommonConfiguration {

}
