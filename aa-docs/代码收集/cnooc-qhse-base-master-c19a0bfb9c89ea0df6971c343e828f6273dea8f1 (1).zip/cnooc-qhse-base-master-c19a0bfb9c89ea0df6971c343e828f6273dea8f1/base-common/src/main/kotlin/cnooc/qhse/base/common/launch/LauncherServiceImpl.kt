package cnooc.qhse.base.common.launch

import cnooc.qhse.base.common.constant.LauncherConstant
import cnooc.qhse.base.common.constant.LauncherConstant.nacosAddr
import cnooc.qhse.base.common.constant.LauncherConstant.seataAddr
import cnooc.qhse.base.common.constant.LauncherConstant.seataServiceGroup
import cnooc.qhse.base.common.constant.LauncherConstant.sentinelAddr
import org.springblade.core.auto.service.AutoService
import org.springblade.core.launch.service.LauncherService
import org.springblade.core.launch.utils.PropsUtil
import org.springframework.boot.builder.SpringApplicationBuilder

/**
 * 启动参数拓展
 *
 * @author smallchil
 */
@AutoService(LauncherService::class)
class LauncherServiceImpl : LauncherService {
    override fun launcher(builder: SpringApplicationBuilder?, appName: String, profile: String, isLocalDev: Boolean) {
        val props = System.getProperties()
        // 通用注册
        PropsUtil.setProperty(props, "spring.cloud.nacos.username", LauncherConstant.NACOS_USERNAME)
        PropsUtil.setProperty(props, "spring.cloud.nacos.password", LauncherConstant.NACOS_PASSWORD)
        PropsUtil.setProperty(props, "spring.cloud.nacos.discovery.server-addr", nacosAddr(profile))
        PropsUtil.setProperty(props, "spring.cloud.nacos.config.server-addr", nacosAddr(profile))
        PropsUtil.setProperty(props, "spring.cloud.sentinel.transport.dashboard", sentinelAddr(profile))

        // seata注册地址
        PropsUtil.setProperty(props, "seata.service.grouplist.default", seataAddr(profile))
        // seata注册group格式
        PropsUtil.setProperty(props, "seata.tx-service-group", seataServiceGroup(appName))
        // seata配置服务group
        PropsUtil.setProperty(
            props,
            "seata.service.vgroup-mapping." + seataServiceGroup(appName),
            LauncherConstant.DEFAULT_MODE
        )

        // seata注册模式配置
        // PropsUtil.setProperty(props, "seata.registry.type", LauncherConstant.NACOS_MODE);
        // PropsUtil.setProperty(props, "seata.registry.nacos.server-addr", LauncherConstant.nacosAddr(profile));
        // PropsUtil.setProperty(props, "seata.config.type", LauncherConstant.NACOS_MODE);
        // PropsUtil.setProperty(props, "seata.config.nacos.server-addr", LauncherConstant.nacosAddr(profile));
    }
}
