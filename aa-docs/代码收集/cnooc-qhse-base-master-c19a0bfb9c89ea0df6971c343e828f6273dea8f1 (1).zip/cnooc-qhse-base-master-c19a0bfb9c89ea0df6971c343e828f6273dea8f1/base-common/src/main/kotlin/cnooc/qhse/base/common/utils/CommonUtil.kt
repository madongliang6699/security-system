package cnooc.qhse.base.common.utils

/**
 * 通用工具类
 *
 * @author Chill
 */
class CommonUtil
