/**
 * BladeX Commercial License Agreement
 * Copyright (c) 2018-2099, https://bladex.cn. All rights reserved.
 * <p>
 * Use of this software is governed by the Commercial License Agreement
 * obtained after purchasing a license from BladeX.
 * <p>
 * 1. This software is for development use only under a valid license
 * from BladeX.
 * <p>
 * 2. Redistribution of this software's source code to any third party
 * without a commercial license is strictly prohibited.
 * <p>
 * 3. Licensees may copyright their own code but cannot use segments
 * from this software for such purposes. Copyright of this software
 * remains with BladeX.
 * <p>
 * Using this software signifies agreement to this License, and the software
 * must not be used for illegal purposes.
 * <p>
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY. The author is
 * not liable for any claims arising from secondary or illegal development.
 * <p>
 * Author: Chill Zhuang (bladejava@qq.com)
 */
package org.springblade.core.excel.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelDataConvertException;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.excel.support.ExcelError;
import org.springblade.core.excel.support.ExcelException;
import org.springblade.core.excel.support.ExcelImporter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Excel监听器
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Slf4j
public class ImportListener<T> extends AnalysisEventListener<T> {

	/**
	 * 默认每隔3000条存储数据库
	 */
	private int batchCount = 3000;
	/**
	 * 缓存的数据列表
	 */
	private List<T> list = new ArrayList<>();
	/**
	 * 数据导入类
	 */
	private final ExcelImporter<T> importer;

	private List<ExcelError> errors = new ArrayList<>();

	@Override
	public void invoke(T data, AnalysisContext analysisContext) {
		// 检验并加入错误信息
		String validateMsg = importer.validate(data);
		if (validateMsg != null) {
			errors.add(new ExcelError(analysisContext.readRowHolder().getRowIndex(), null, null, validateMsg));
		}
		list.add(data);
		// 达到BATCH_COUNT，则调用importer方法入库，防止数据几万条数据在内存，容易OOM
		if (list.size() >= batchCount) {
			if (errors.isEmpty()) {
				// 调用importer方法
				importer.save(list);
			}
			// 存储完成清理list
			list.clear();
		}
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
		if (errors.isEmpty()) {
			// 调用importer方法
			importer.save(list);
		} else {
			List<String> errorMsgs = errors.stream().map(excelError -> {
				String msg = "第" + excelError.getRow() + "行";
				if (excelError.getColumn() != null) {
					msg += "，第" + excelError.getColumn() + "列";
				}
				msg += "解析异常";
				if (excelError.getData() != null) {
					msg += "，数据为：" + excelError.getData().getStringValue();
				}
				msg += "，错误信息：" + excelError.getErrorMsg();
				return msg;
			}).collect(Collectors.toList());

			// 最新抛出异常
			throw new ExcelException(String.join("\n", errorMsgs));
		}
		// 存储完成清理list
		list.clear();
	}

	/**
	 * 在转换异常 获取其他异常下会调用本接口。抛出异常则停止读取。如果这里不抛出异常则 继续读取下一行。
	 */
	@Override
	public void onException(Exception exception, AnalysisContext context) {
		log.error("解析失败，但是继续解析下一行:{}", exception.getMessage());
		// 如果是某一个单元格的转换异常 能获取到具体行号
		// 如果要获取头的信息 配合invokeHeadMap使用
		if (exception instanceof ExcelDataConvertException) {
			ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
			log.error("第{}行，第{}列解析异常，数据为:{}，错误信息:{}", excelDataConvertException.getRowIndex(),
				excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData().getStringValue(),
				exception.getCause().getMessage());
			errors.add(new ExcelError(excelDataConvertException.getRowIndex(),
				excelDataConvertException.getColumnIndex(), excelDataConvertException.getCellData(),
				exception.getCause().getMessage()));
		}
	}
}
