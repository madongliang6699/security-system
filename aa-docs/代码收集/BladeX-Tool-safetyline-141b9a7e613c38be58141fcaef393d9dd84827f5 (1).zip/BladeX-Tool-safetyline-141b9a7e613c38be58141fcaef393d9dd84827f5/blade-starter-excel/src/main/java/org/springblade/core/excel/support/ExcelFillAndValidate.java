package org.springblade.core.excel.support;

/**
 * Excel统一导入接口
 *
 * @author Chill
 */
public interface ExcelFillAndValidate<T> {

	/**
	 * 填充数据
	 * @param data 数据
	 */
	void fill(T data);

	/**
	 * 检验数据并返回错误信息
	 * @param data 对象
	 */
	default String validate(T data) {
		return null;
	}
}
