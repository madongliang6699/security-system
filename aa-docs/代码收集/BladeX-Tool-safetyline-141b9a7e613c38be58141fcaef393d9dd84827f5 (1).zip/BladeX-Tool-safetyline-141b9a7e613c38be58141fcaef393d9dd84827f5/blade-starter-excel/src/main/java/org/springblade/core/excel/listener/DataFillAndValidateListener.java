/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.core.excel.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.exception.ExcelDataConvertException;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.excel.support.ExcelError;
import org.springblade.core.excel.support.ExcelFillAndValidate;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Excel监听器
 *
 * @author Chill
 */
@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Slf4j
public class DataFillAndValidateListener<T> extends AnalysisEventListener<T> {
	/**
	 * 缓存的数据列表
	 */
	private List<T> list = new ArrayList<>();
	/**
	 * 数据导入类
	 */
	private final ExcelFillAndValidate<T> fillAndValidate;

	private List<ExcelError> errors = new ArrayList<>();

	@Override
	public void invoke(T data, AnalysisContext analysisContext) {
		fillAndValidate.fill(data);
		// 检验并加入错误信息
		String validateMsg = fillAndValidate.validate(data);
		if (validateMsg != null) {
			errors.add(new ExcelError(analysisContext.readRowHolder().getRowIndex(), null, null, validateMsg));
		}
		list.add(data);
	}

	@Override
	public void doAfterAllAnalysed(AnalysisContext analysisContext) {
	}

	/**
	 * 在转换异常 获取其他异常下会调用本接口。抛出异常则停止读取。如果这里不抛出异常则 继续读取下一行。
	 */
	@Override
	public void onException(Exception exception, AnalysisContext context) {
		log.error("解析失败，但是继续解析下一行:{}", exception.getMessage());
		// 如果是某一个单元格的转换异常 能获取到具体行号
		// 如果要获取头的信息 配合invokeHeadMap使用
		if (exception instanceof ExcelDataConvertException) {
			ExcelDataConvertException excelDataConvertException = (ExcelDataConvertException) exception;
			log.error("第{}行，第{}列解析异常，数据为:{}，错误信息:{}", excelDataConvertException.getRowIndex() + 1,
				excelDataConvertException.getColumnIndex() + 1, excelDataConvertException.getCellData().getStringValue(),
				exception.getCause().getMessage());
			errors.add(new ExcelError(excelDataConvertException.getRowIndex() + 1,
				excelDataConvertException.getColumnIndex() + 1, excelDataConvertException.getCellData(),
				exception.getCause().getMessage()));
		}
	}

	public String getWholeErrorMessage() {
		List<String> errorMsgs = errors.stream().map(excelError -> {
			String msg = "第" + (excelError.getRow()) + "行";
			if (excelError.getColumn() != null) {
				msg += "，第" + (excelError.getColumn()) + "列";
			}
			msg += "解析异常";
			if (excelError.getData() != null) {
				msg += "，数据为：" + excelError.getData().getStringValue();
			}
			msg += "，错误信息：" + excelError.getErrorMsg();
			return msg;
		}).collect(Collectors.toList());
		return String.join("\n", errorMsgs);
	}

	public Boolean hasError() {
		return errors.size() > 0;
	}
}
