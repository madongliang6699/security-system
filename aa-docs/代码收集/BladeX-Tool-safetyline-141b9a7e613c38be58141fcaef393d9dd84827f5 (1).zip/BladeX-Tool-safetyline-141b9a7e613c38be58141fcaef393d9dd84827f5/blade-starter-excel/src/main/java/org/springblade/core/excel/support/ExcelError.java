package org.springblade.core.excel.support;

import com.alibaba.excel.metadata.data.CellData;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ExcelError {
	private Integer row;
	private Integer column;
	private CellData data;
	private String errorMsg;
}
